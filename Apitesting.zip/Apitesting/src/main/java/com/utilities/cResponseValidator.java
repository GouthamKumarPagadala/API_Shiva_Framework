package com.utilities;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.InvalidPathException;
import com.jayway.jsonpath.JsonPath;

/**
 * Name & Use       :   <Name of class file and its utility as description>
 * Created by       :   <Author Name>
 * Created Date     :   <Date in mm-dd-yyy format>
 * Last Edited by   :   <Editor Name>
 * Last Edited Date :   <Date in mm-dd-yyy format>
 * Edit History     :   <Describe the changes made in code as a summary>
 */

public class cResponseValidator {

    @BeforeClass(alwaysRun=true)
    public void testSetup()
    {}
    	String strResponse;
    	Object document;
    	
    	public cResponseValidator(String strResponse)
    	{
    		
    		this.strResponse=strResponse;
    		document=Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
    	}

		
    public void nodeMatches(String strJsonPath,String strExpected,String strDescription)
    {
    	try
    	{
    	String strActual= String.valueOf(JsonPath.read(document, strJsonPath));
    	Assert.assertTrue(strActual.matches(strExpected), "Expected:" + strExpected +"...Actual:" +strActual);
    	}
    	
    	catch(InvalidPathException | NullPointerException e)
    	{
    		Assert.fail("Cannot find json node in response :" +strJsonPath);
    		
    	}
    	
    }
    
    
    
    public void nodeContains(String strJsonPath,String strExpected,String strDescription)
    {
    	try
    	{
    	String strActual= String.valueOf(JsonPath.read(document, strJsonPath));
    	Assert.assertTrue(strActual.contains(strExpected), "Expected:" + strExpected +"...Actual:" +strActual);
    	}
    	
    	catch(InvalidPathException | NullPointerException e)
    	{
    		Assert.fail("Cannot find json node in response :" +strJsonPath);
    		
    	}
    }
    	
    
    
    
    	 public void nodeEquals(String strJsonPath,String strExpected,String strDescription)
    	    {
    	    	try
    	    	{
    	    	String strActual= String.valueOf(JsonPath.read(document, strJsonPath));
    	    	Assert.assertEquals(strActual,strExpected);
    	    	}
    	    	catch(InvalidPathException | NullPointerException e)
    	    	{
    	    		Assert.fail("Cannot find json node in response :" +strJsonPath);
    	    		
    	    	}
    	
    }
    
    	 
    	 
    	 public void nodeNotEquals(String strJsonPath,String strExpected,String strDescription)
 	    {
 	    	try
 	    	{
 	    	String strActual= String.valueOf(JsonPath.read(document, strJsonPath));
 	    	Assert.assertNotEquals(strActual,strExpected,strDescription);
 	    	}
 	    	catch(InvalidPathException | NullPointerException e)
 	    	{
 	    		Assert.fail("Cannot find json node in response :" +strJsonPath);
 	    		
 	    	}
 	
 }

}
