package com.utilities;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.URL;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.testng.Reporter;




public class cConnectionCreator {

//static Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("23.219.133.171",443));




public static String getRequest(String strURL,int intExpectedResponseCode ) throws Exception {

return genericRESTCall("GET", strURL, null,  null, intExpectedResponseCode);
}



public static String getRequest(String strURL, HashMap<String, String> mapHeaders) throws Exception {

return genericRESTCall("GET", strURL, null,   mapHeaders, 200);
}


public static String postRequest(String strURL, String strPayload) throws Exception {

return genericRESTCall("POST", strURL, strPayload,  null, 200);
}


public static String postRequest(String strURL, String strPayload, int intExpectedResponseCode) throws Exception {

return genericRESTCall("POST", strURL, strPayload,   null, intExpectedResponseCode);
}


public static String postRequest(String strURL, String strPayload,  HashMap<String, String> mapHeaders, int intExpectedResponseCode) throws Exception {

return genericRESTCall("POST", strURL, strPayload,   mapHeaders, intExpectedResponseCode);
}



public static String deleteRequest(String strURL,  int intExpectedResponseCode) throws Exception {

return genericRESTCall("DELETE", strURL, null,   null, intExpectedResponseCode);
}



public static String putRequest(String strURL, String strPayload) throws Exception {

return genericRESTCall("PUT", strURL, strPayload,   null, 200);
}


public static String putRequest(String strURL, String strPayload,  HashMap<String, String> mapHeaders,int intExpectedResponseCode) throws Exception {

return genericRESTCall("PUT", strURL, strPayload,   mapHeaders, intExpectedResponseCode);
}


public static String genericRESTCall(String strMethod, String strURL, String strPayload,  HashMap<String, String> mapHeaders, int intExpectedResponseCode)  {

	
	StringBuffer strRequestResponseLog = new StringBuffer();
	StringBuffer strRequestHeaders = new StringBuffer();
	Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("104.121.229.178",443));
	HttpURLConnection conn = null;
	try {
	



strRequestResponseLog.append("URL \n" + strMethod + " " + strURL);
System.out.println(strMethod + " " + strURL);


// test server details


	URL url = new URL(strURL);


conn = (HttpURLConnection) url.openConnection();

conn.setRequestMethod(strMethod);
conn.setDoOutput(true);
conn.setDoInput(true);
conn.setConnectTimeout(60000);
conn.setReadTimeout(60000);

conn.setRequestProperty("Content-Type", "application/json");
conn.setRequestProperty("Accept", "application/json");




if (strMethod.equals("POST") || strMethod.equals("PUT")) {
OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
out.write(strPayload.trim());
out.close();
}

StringBuffer sb = new StringBuffer();

// System.out.println(conn.getURL() + strPayload);

InputStream inputStream;

inputStream = (conn.getResponseCode() == 200) ? conn.getInputStream() : conn.getErrorStream();

BufferedReader br = new BufferedReader(new InputStreamReader(
(inputStream)));

String output;

System.out.println("Adapter Response \n");
while ((output = br.readLine()) != null) {
sb.append(output);

}

strRequestResponseLog.append(sb);

return new String(sb);
}
catch (Exception e) {
e.printStackTrace();
return "";
}
finally {
Reporter.log( strRequestResponseLog.toString());
conn.disconnect();

}

}}


