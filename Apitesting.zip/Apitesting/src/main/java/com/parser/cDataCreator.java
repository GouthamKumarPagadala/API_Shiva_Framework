package com.parser;

/**
 * Name & Use       :   <Name of class file and its utility as description>
 * Created by       :   <Author Name>
 * Created Date     :   <Date in mm-dd-yyy format>
 * Last Edited by   :   <Editor Name>
 * Last Edited Date :   <Date in mm-dd-yyy format>
 * Edit History     :   <Describe the changes made in code as a summary>
 */

public class cDataCreator {

    public void stagingDataExtractor()
    {
        //use the output from Data Mapping Parser to populate data from Staging
    }

    public void syntheticDataCreator()
    {
        //use the output from Data Mapping Parser to populate synthetic data
    }


}
