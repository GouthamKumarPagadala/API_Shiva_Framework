package com.api;

import org.testng.annotations.Test;

import com.utilities.cConnectionCreator;
import com.utilities.cResponseValidator;

import static com.utilities.cRequestCreator.application_add;

/**
 * Unit test for simple App.
 */
public class Testcase1 
{
	
	cResponseValidator validator;

	@Test(groups="test")
	public void sampletest() throws Exception 
	{
		
		System.out.println("Success");
		
		String strurl=application_add;
		
		String strResponse = cConnectionCreator.getRequest(strurl, 400);
		
		validator=new cResponseValidator(strResponse);
		
		System.out.println(strResponse);
		
		//validator.nodeEquals("$.payload.categories[0].name","siva", "hh");
	}
	
	
}
