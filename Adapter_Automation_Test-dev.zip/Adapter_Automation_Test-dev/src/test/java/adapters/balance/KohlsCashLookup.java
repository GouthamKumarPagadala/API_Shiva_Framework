package test.java.adapters.balance;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.Utilities.CompareType;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import static main.java.common.TestData.mapheader;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Kohls Cash")
@Stories({ "Kohls Cash Balance" })
public class KohlsCashLookup {
	ResponseValidator validator;

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_1 KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass one KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void SingleKohlsCashLookup() {

		// TestData.getRunTimeData("KOHLS_CASH_NO", true);
		String[] arrKC = TestData.createKohlsCash(50);

		// TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\"" + arrKC[0]
				+ "\",\"pin\":\"" + arrKC[1] + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Kohls Cash",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without kohlsCashNum", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void without_KohlsCashNum() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\"\",\"pin\":\""
				+ testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateExpectedErrors("BALA1000", "Blank KohlsCashNumber
		// provided");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1000", "expected error");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Blank KohlsCashNumber provided.",
				"expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without pin", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty KohlsCash Pin in request\r\n Feature - KohlsCash LookUp")
	public void without_KohlsCashPIN() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateExpectedErrors("BALA1000", "Missing Required
		// Parameter pin");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1002", "expected error");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Invalid value passed for pin.",
				"expected error message");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without ID", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty ID in request\r\n Feature - KohlsCash LookUp")
	public void without_ID() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"\"," + "\"kohlsCashNum\":\""
				+ testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN")
				+ "\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1000", "expected error");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Blank ID provided.",
				"expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without kohlsCashNum and pin", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty KohlsCash Number and Pin in request\r\n Feature - KohlsCash LookUp")
	public void without_KohlsCashNum_Pin() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\","
				+ "\"kohlsCashNum\":\"\",\"pin\":\"\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1000", "expected error");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Blank KohlsCashNumber provided.",
				"expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without ID and pin", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty KohlsCash Pin and ID in request\r\n Feature - KohlsCash LookUp")
	public void without_ID_Pin() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"\"," + "\"kohlsCashNum\":\""
				+ testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1000", "expected error");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Blank ID provided.",
				"expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_kohlsCashNum and ID", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty KohlsCash Number and ID in request\r\n Feature - KohlsCash LookUp")
	public void without_KohlsCashNum_ID() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"\"," + "\"kohlsCashNum\":\"\",\"pin\":\""
				+ testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("BALA1000", "Blank ID provided.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without kohlsCashNum_ID and pin", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass empty KohlsCash Number, PIN and ID in request\r\n Feature - KohlsCash LookUp")
	public void without_KohlsCashNum_ID_Pin() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"\","
				+ "\"kohlsCashNum\":\"\",\"pin\":\"\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1000", "expected error");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Blank ID provided.",
				"expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_without kohlsCash Details", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I didn't pass KohlsCash Number, PIN and ID object in request\r\n Feature - KohlsCash LookUp")
	public void without_KohlsCash_Details() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_2 KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Two KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void twoKohlsCashLookup() {

		for (int i = 1; i <= 2; i++) {
			String[] arrKC = TestData.createKohlsCash(50);
			testData.put("kohlscashnum[" + i + "]", arrKC[0]);
			testData.put("kohlscashpin[" + i + "]", arrKC[1]);
		}

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\",\"kohlsCashNum\":\""
				+ testData.get("kohlscashnum[1]") + "\",\"pin\":\"" + testData.get("kohlscashpin[1]") + "\"},"
				+ "{\"ID\":\"2\",\"kohlsCashNum\":\"" + testData.get("kohlscashnum[2]") + "\",\"pin\":\""
				+ testData.get("kohlscashpin[2]") + "\"}]}}";
		// Validate Response
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for (int counter = 0; counter <= 1; counter++) {
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashNum", ".+",
					"kohlsCashNum should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].balance", ".+",
					"kohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.startDate", ".+",
					"KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.endDate", ".+",
					"KohlsCash endDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.code", ".+",
					"kohlsCash balance code should be available");
			validator.nodeEquals("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.description", "Kohls Cash",
					"kohlsCash balance description should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].ID", ".+", "ID should be available");
		}
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdapterOAPIResponse(strResponse, strResponseOAPI, CompareType.BALANCE);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_3 KC balance ", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Three KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void threeKohlsCashLookup() {

		for (int i = 1; i <= 3; i++) {
			String[] arrKC = TestData.createKohlsCash(50);
			testData.put("kohlscashnum[" + i + "]", arrKC[0]);
			testData.put("kohlscashpin[" + i + "]", arrKC[1]);
		}

		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[";
		for (int counter = 1; counter <= 2; counter++) {
			strPayload = strPayload + "{\"ID\":\"" + counter + "\"," + "\"kohlsCashNum\":\""
					+ testData.get("kohlscashnum[" + counter + "]") + "\",\"pin\":\""
					+ testData.get("kohlscashpin[" + counter + "]") + "\"},";
		}
		strPayload = strPayload + "{\"ID\":\"3\"," + "\"kohlsCashNum\":\"" + testData.get("kohlscashnum[3]")
				+ "\",\"pin\":\"" + testData.get("kohlscashpin[3]") + "\"}]}}";
		// Post the request
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for (int counter = 0; counter <= 2; counter++) {
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashNum", ".+",
					"kohlsCashNum should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].balance", ".+",
					"kohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.startDate", ".+",
					"KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.endDate", ".+",
					"KohlsCash endDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.code", ".+",
					"kohlsCash balance code should be available");
			validator.nodeEquals("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.description", "Kohls Cash",
					"kohlsCash balance description should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].ID", ".+", "ID should be available");
		}

		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdapterOAPIResponse(strResponse, strResponseOAPI, CompareType.BALANCE);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_4 KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Four KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void fourKohlsCashLookup() {

		for (int i = 1; i <= 4; i++) {
			String[] arrKC = TestData.createKohlsCash(50);
			testData.put("kohlscashnum[" + i + "]", arrKC[0]);
			testData.put("kohlscashpin[" + i + "]", arrKC[1]);
		}

		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[";
		for (int counter = 1; counter <= 3; counter++) {
			strPayload = strPayload + "{\"ID\":\"" + counter + "\"," + "\"kohlsCashNum\":\""
					+ testData.get("kohlscashnum[" + counter + "]") + "\",\"pin\":\""
					+ testData.get("kohlscashpin[" + counter + "]") + "\"},";
		}
		strPayload = strPayload + "{\"ID\":\"4\"," + "\"kohlsCashNum\":\"" + testData.get("kohlscashnum[4]")
				+ "\",\"pin\":\"" + testData.get("kohlscashpin[4]") + "\"}]}}";
		// Post the request
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for (int counter = 0; counter <= 3; counter++) {
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashNum", ".+",
					"kohlsCashNum should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].balance", ".+",
					"kohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.startDate", ".+",
					"KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.endDate", ".+",
					"KohlsCash endDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.code", ".+",
					"kohlsCash balance code should be available");
			validator.nodeEquals("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.description", "Kohls Cash",
					"kohlsCash balance description should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].ID", ".+", "ID should be available");
		}

		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdapterOAPIResponse(strResponse, strResponseOAPI, CompareType.BALANCE);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_verify whether user is able to check 24 KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Twenty Four KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void twentyFourKohlsCashLookup() {
		for (int i = 1; i <= 24; i++) {
			String[] arrKC = TestData.createKohlsCash(50);
			testData.put("kohlscashnum[" + i + "]", arrKC[0]);
			testData.put("kohlscashpin[" + i + "]", arrKC[1]);
		}

		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[";
		for (int counter = 1; counter <= 23; counter++) {
			strPayload = strPayload + "{\"ID\":\"" + counter + "\"," + "\"kohlsCashNum\":\""
					+ testData.get("kohlscashnum[" + counter + "]") + "\",\"pin\":\""
					+ testData.get("kohlscashpin[" + counter + "]") + "\"},";
		}

		strPayload = strPayload + "{\"ID\":\"24\"," + "\"kohlsCashNum\":\"" + testData.get("kohlscashnum[24]")
				+ "\",\"pin\":\"" + testData.get("kohlscashpin[24]") + "\"}]}}";
		// System.out.println(strPayload);
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for (int counter = 0; counter <= 23; counter++) {
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashNum", ".+",
					"kohlsCashNum should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].balance", ".+",
					"kohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.startDate", ".+",
					"KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.endDate", ".+",
					"KohlsCash endDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.code", ".+",
					"kohlsCash balance code should be available");
			validator.nodeEquals("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.description", "Kohls Cash",
					"kohlsCash balance description should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].ID", ".+", "ID should be available");
		}

		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdapterOAPIResponse(strResponse, strResponseOAPI, CompareType.BALANCE);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_verify whether user is able to check 25 KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Twenty Five KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void twentyFiveKohlsCashLookup() {
		for (int i = 1; i <= 25; i++) {
			String[] arrKC = TestData.createKohlsCash(50);
			testData.put("kohlscashnum[" + i + "]", arrKC[0]);
			testData.put("kohlscashpin[" + i + "]", arrKC[1]);
		}

		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[";
		for (int counter = 1; counter <= 24; counter++) {
			strPayload = strPayload + "{\"ID\":\"" + counter + "\"," + "\"kohlsCashNum\":\""
					+ testData.get("kohlscashnum[" + counter + "]") + "\",\"pin\":\""
					+ testData.get("kohlscashpin[" + counter + "]") + "\"},";
		}

		strPayload = strPayload + "{\"ID\":\"25\"," + "\"kohlsCashNum\":\"" + testData.get("kohlscashnum[25]")
				+ "\",\"pin\":\"" + testData.get("kohlscashpin[25]") + "\"}]}}";
		// System.out.println(strPayload);
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for (int counter = 0; counter <= 24; counter++) {
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashNum", ".+",
					"kohlsCashNum should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].balance", ".+",
					"kohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.startDate", ".+",
					"KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.endDate", ".+",
					"KohlsCash endDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.code", ".+",
					"kohlsCash balance code should be available");
			validator.nodeEquals("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.description", "Kohls Cash",
					"kohlsCash balance description should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].ID", ".+", "ID should be available");
		}

		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdapterOAPIResponse(strResponse, strResponseOAPI, CompareType.BALANCE);
		}
	}

	@DiscontinuedTest(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_verify whether user is able to check 26 KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Twenty Six KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void twentySixKohlsCashLookup() {
		for (int i = 1; i <= 26; i++) {
			String[] arrKC = TestData.createKohlsCash(50);
			testData.put("kohlscashnum[" + i + "]", arrKC[0]);
			testData.put("kohlscashpin[" + i + "]", arrKC[1]);
		}

		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[";
		for (int counter = 1; counter <= 25; counter++) {
			strPayload = strPayload + "{\"ID\":\"" + counter + "\"," + "\"kohlsCashNum\":\""
					+ testData.get("kohlscashnum[" + counter + "]") + "\",\"pin\":\""
					+ testData.get("kohlscashpin[" + counter + "]") + "\"},";
		}

		strPayload = strPayload + "{\"ID\":\"26\"," + "\"kohlsCashNum\":\"" + testData.get("kohlscashnum[26]")
				+ "\",\"pin\":\"" + testData.get("kohlscashpin[26]") + "\"}]}}";
		// System.out.println(strPayload);
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);
		// Validate Response
		validator = new ResponseValidator(strResponse);

		validator.validateExpectedErrors("BALA1002", "kohls cash lookup  exceeds the maximum ");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_expired KC balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Expired KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void with_Expired_KC_Balance() {

		// TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("EXPIRED_KC") + "\",\"pin\":\"6142\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.description", ".+",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// Some error 90xx must be validated
		// validator.validateExpectedErrors("BALA9006", "We're sorry, the Kohl's
		// Cash you entered is not valid. Please check the Redeem dates and try
		// again.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_withFuture date", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Future KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void with_Future_Data_KC_Balance() {

		// TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("FUTURE_DATE_KC") + "\",\"pin\":\"9551\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.description", ".+",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// Some error 90xx must be validated
		// validator.validateExpectedErrors("BALA9006", "We're sorry, the Kohl's
		// Cash you entered is not valid. Please check the Redeem dates and try
		// again.");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_invalid value for ID", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass Invalid ID value in request\r\n Feature - KohlsCash LookUp")
	public void with_Invalid_ID() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		String ID = "4g3186z48h4z8d4hg18r634h8de34h";
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"" + ID + "\"," + "\"kohlsCashNum\":\""
				+ testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN")
				+ "\"}]}}";
		// Post the request
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1002", "expected error");
		String error_msg = "Invalid ID: " + ID;
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", error_msg, "expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_invalid value for kohlsCashNum", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass Invalid KohlsCash Number value in request\r\n Feature - KohlsCash LookUp")
	public void with_Invalid_kohlsCashNum() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		String kc_num = "d31gf8gdre31ge8ge3rge38";
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\"" + kc_num
				+ "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}";
		// Post the request
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1002", "expected error");
		String error_msg = "Invalid KohlsCashNumber: " + kc_num;
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", error_msg, "expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_invalid value for pin", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper error message when I pass Invalid KohlsCash Pin value in request\r\n Feature - KohlsCash LookUp")
	public void with_Invalid_pin() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Post the request
		String kc_pin = "sf54sg4deg4dreg";
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + kc_pin + "\"}]}}";
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.code", "BALA1002", "expected error");
		// String error_msg="Invalid KohlsCashNumber: "+kc_pin;
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].error.message", "Invalid value passed for pin.",
				"expected error message");
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_All_Event", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass All Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void All_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("KOHLS_CASH_EVENT") + "\",\"pin\":\"" + testData.get("KOHLS_CASH_EVENT_PIN")
				+ "\"},{\"ID\":\"2\"," + "\"kohlsCashNum\":\"" + testData.get("MIC_EVENT") + "\",\"pin\":\""
				+ testData.get("MIC_EVENT_PIN") + "\"},{\"ID\":\"3\"," + "\"kohlsCashNum\":\""
				+ testData.get("MIC_REMODEL_EVENT") + "\",\"pin\":\"" + testData.get("MIC_REMODEL_EVENT_PIN")
				+ "\"},{\"ID\":\"4\"," + "\"kohlsCashNum\":\"" + testData.get("NEW_STORE_EVENT") + "\",\"pin\":\""
				+ testData.get("NEW_STORE_EVENT_PIN") + "\"},{\"ID\":\"5\"," + "\"kohlsCashNum\":\""
				+ testData.get("REMODEL_EVENT") + "\",\"pin\":\"" + testData.get("REMODEL_EVENT_PIN")
				+ "\"},{\"ID\":\"6\"," + "\"kohlsCashNum\":\"" + testData.get("TAX_FREE_EVENT") + "\",\"pin\":\""
				+ testData.get("TAX_FREE_EVENT_PIN") + "\"},{\"ID\":\"7\"," + "\"kohlsCashNum\":\""
				+ testData.get("BIRTHDAY_EVENT") + "\",\"pin\":\"" + testData.get("BIRTHDAY_EVENT_PIN")
				+ "\"},{\"ID\":\"8\"," + "\"kohlsCashNum\":\"" + testData.get("BOOSTER_EVENT") + "\",\"pin\":\""
				+ testData.get("BOOSTER_EVENT_PIN") + "\"},{\"ID\":\"9\"," + "\"kohlsCashNum\":\""
				+ testData.get("BRIDAL_EVENT") + "\",\"pin\":\"" + testData.get("BRIDAL_EVENT_PIN")
				+ "\"},{\"ID\":\"10\"," + "\"kohlsCashNum\":\"" + testData.get("DISCOVER_EVENT") + "\",\"pin\":\""
				+ testData.get("DISCOVER_EVENT_PIN") + "\"},{\"ID\":\"11\"," + "\"kohlsCashNum\":\""
				+ testData.get("EMAIL_EVENT") + "\",\"pin\":\"" + testData.get("EMAIL_EVENT_PIN")
				+ "\"},{\"ID\":\"12\"," + "\"kohlsCashNum\":\"" + testData.get("LOYALTY_EVENT") + "\",\"pin\":\""
				+ testData.get("LOYALTY_EVENT_PIN") + "\"},{\"ID\":\"13\"," + "\"kohlsCashNum\":\""
				+ testData.get("PAPERLESS_EVENT") + "\",\"pin\":\"" + testData.get("PAPERLESS_EVENT_PIN")
				+ "\"},{\"ID\":\"14\"," + "\"kohlsCashNum\":\"" + testData.get("PERSONALIZATION_EVENT")
				+ "\",\"pin\":\"" + testData.get("PERSONALIZATION_EVENT_PIN") + "\"},{\"ID\":\"15\","
				+ "\"kohlsCashNum\":\"" + testData.get("PROSPECT_EVENT") + "\",\"pin\":\""
				+ testData.get("PROSPECT_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for (int counter = 0; counter <= 14; counter++) {
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashNum", ".+",
					"kohlsCashNum should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].balance", ".+",
					"kohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.startDate", ".+",
					"KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].validDates.endDate", ".+",
					"KohlsCash endDate should be available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].kohlsCashType.code", ".+",
					"kohlsCash balance code should be available");
			// validator.nodeEquals("$.payload.kohlsCashCoupons["+counter+"].kohlsCashType.description",
			// "Kohls Cash", "kohlsCash balance description should be
			// available");
			validator.nodeMatches("$.payload.kohlsCashCoupons[" + counter + "].ID", ".+", "ID should be available");
		}

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Kohls_Cash_Event", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass KohlsCash_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Kohls_Cash_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("KOHLS_CASH_EVENT") + "\",\"pin\":\"" + testData.get("KOHLS_CASH_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Kohls Cash",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_MIC_Event", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass MIC_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void MIC_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("MIC_EVENT") + "\",\"pin\":\"" + testData.get("MIC_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "MIC",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_MIC-Remodel_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass MICRemodel_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void MIC_Remodel_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("MIC_REMODEL_EVENT") + "\",\"pin\":\"" + testData.get("MIC_REMODEL_EVENT_PIN")
				+ "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "MIC-Remodel",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_New_Store_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass NewStore_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void New_Store_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("NEW_STORE_EVENT") + "\",\"pin\":\"" + testData.get("NEW_STORE_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "New Store",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Remodel_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Remodel_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Remodel_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("REMODEL_EVENT") + "\",\"pin\":\"" + testData.get("REMODEL_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Remodel",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Tax_Free_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass TaxFree_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Tax_Free_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("TAX_FREE_EVENT") + "\",\"pin\":\"" + testData.get("TAX_FREE_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Tax Free",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Birthday_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass BirthDay_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Birthday_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("BIRTHDAY_EVENT") + "\",\"pin\":\"" + testData.get("BIRTHDAY_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Birthday",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Booster_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Booster_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Booster_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("BOOSTER_EVENT") + "\",\"pin\":\"" + testData.get("BOOSTER_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Booster",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Bridal_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Bridal_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Bridal_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("BRIDAL_EVENT") + "\",\"pin\":\"" + testData.get("BRIDAL_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Bridal",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Discover_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Discover_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Discover_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("DISCOVER_EVENT") + "\",\"pin\":\"" + testData.get("DISCOVER_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Discover",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Email_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Email_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Email_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("EMAIL_EVENT") + "\",\"pin\":\"" + testData.get("EMAIL_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Email",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Loyalty_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Loyalty_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Loyalty_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("LOYALTY_EVENT") + "\",\"pin\":\"" + testData.get("LOYALTY_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Loyalty",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Paperless_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Paperless_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Paperless_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("PAPERLESS_EVENT") + "\",\"pin\":\"" + testData.get("PAPERLESS_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Paperless",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Personalization_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Personalisation_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Personalization_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("PERSONALIZATION_EVENT") + "\",\"pin\":\"" + testData.get("PERSONALIZATION_EVENT_PIN")
				+ "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Personalization",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "dkc",
			"regression" }, enabled = true, priority = 6, testName = "KohlsCashLookup_Prospect_Event balance", description = "API Version - V1/KohlsCash\r\n TC Description - As a Kohls user I want to get proper response when I pass Prospect_Event KohlsCash Number in request\r\n Feature - KohlsCash LookUp")
	public void Prospect_Event() {

		// Post the request
		String strPayload = "{\"payload\":{\"kohlsCashCoupons\":[{\"ID\":\"1\"," + "\"kohlsCashNum\":\""
				+ testData.get("PROSPECT_EVENT") + "\",\"pin\":\"" + testData.get("PROSPECT_EVENT_PIN") + "\"}]}}";
		mapheader.put("User-Agent", "Platform");
		String strResponse = RestCall.postRequest(BALANCE_ADAPTER, strPayload, Server.Adapter, false, mapheader);
		System.out.println(strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashNum", ".+", "kohlsCashNum should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].balance", ".+", "kohlsCash balance should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.startDate", ".+",
				"KohlsCash startDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].validDates.endDate", ".+",
				"KohlsCash endDate should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].kohlsCashType.code", ".+",
				"kohlsCash balance code should be available");
		validator.nodeEquals("$.payload.kohlsCashCoupons[0].kohlsCashType.description", "Prospect",
				"kohlsCash balance description should be available");
		validator.nodeMatches("$.payload.kohlsCashCoupons[0].ID", ".+", "ID should be available");
		// validator.validateExpectedErrors("BALA1002", "Invalid value passed
		// for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");

		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(BALANCE_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}