package test.java.adapters.balance;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Kohls Cash")
@Stories({ "Kohls Cash Balance" })
public class KohlsCashBalance {

	ResponseValidator validator;


	@Test(groups = {"regression","functional", "errorhandling" }, enabled = true, priority = 6, testName = "Non Numeric Kohls Cash Number",
			description = "API Version - V1/balance\r\n TC Description - As a Kohls user I want to get proper error message when I pass non-numeric character as KohlsCash Number\r\n Feature - KohlsCash Balance")
	public void NonNumericKohlsCashNumber() {

		// Post the request
		String strURL = BALANCE_ADAPTER + "/ABCDEFGHILKJQWE/balance";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("BALA1002", "Invalid value passed for Invalid KohlsCashNumber: ABCDEFGHILKJQWE.");
		if (CompareOAPI) {

			// Post the request
			String strURLOAPI = BALANCE_OAPI + "/ABCDEFGHILKJQWE/balance";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = {"regression","functional", "errorhandling" }, enabled = true, priority = 6, testName = "Kohls Cash Number More Than 15 digit",
			description = "API Version - V1/balance\r\n TC Description - As a Kohls user I want to get proper error message when I pass more than 15 Character as KohlsCash Number\r\n Feature - KohlsCash Balance")
	public void KohlsCashNumberMorethan15digits() {

		// Post the request
		String strURL = BALANCE_ADAPTER + "/14277900194987245874/balance";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("BALA9004", "We're sorry, the Kohl's Cash or Rewards you entered is not valid.Please check the number and try again.");
		if (CompareOAPI) {

			// Post the request
			String strURLOAPI = BALANCE_OAPI + "/14277900194987245874/balance";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = {"regression","functional", "errorhandling" }, enabled = true, priority = 6, testName = "Kohls Cash Number Less Than 15 digit",
			description = "API Version - V1/balance\r\n TC Description - As a Kohls user I want to get proper error message when I pass less than 15 Character as KohlsCash Number\r\n Feature - KohlsCash Balance")
	public void KohlsCashNumberLessthan15digits() {

		// Post the request
		String strURL = BALANCE_ADAPTER + "/1427790019/balance";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("BALA9004", "We're sorry, the Kohl's Cash or Rewards you entered is not valid.Please check the number and try again.");
		if (CompareOAPI) {

			// Post the request
			String strURLOAPI = BALANCE_OAPI + "/1427790019/balance";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = {"regression","functional", "errorhandling" }, enabled = true, priority = 6, testName = "Alpha Numeric Kohls Cash Number",
			description = "API Version - V1/balance\r\n TC Description - As a Kohls user I want to get proper error message when I pass Alpha Numeric Character as KohlsCash Number\r\n Feature - KohlsCash Balance")
	public void AlphaNumericKohlsCashNumber() {

		// Post the request
		String strURL = BALANCE_ADAPTER + "/ABCDEFGHI123456/balance";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("BALA1002", "Invalid value passed for Invalid KohlsCashNumber: ABCDEFGHI123456.");
		if (CompareOAPI) {

			// Post the request
			String strURLOAPI = BALANCE_OAPI + "/ABCDEFGHI123456/balance";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

}