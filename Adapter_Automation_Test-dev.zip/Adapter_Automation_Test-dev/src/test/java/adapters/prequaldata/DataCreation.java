package test.java.adapters.prequaldata;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_BILL_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_LOYALITY_CREATE;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.strGroup;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Prequal")
@Stories({ "Data Creation" })
public class DataCreation {
	String[][] regArray =null; 
	int intTotalRowCount=0;
	ResponseValidator validator;

	@DataProvider(name = "prequal",parallel = true)
	public Object[][] getRegistryId() {
		InputStream ExcelFileToRead=null;
		XSSFSheet sheet=null;
		XSSFWorkbook wb=null;
		try {
			File excel = new File("Resource/Data/PrequalData.xlsx");
			
			if(excel.exists()){
//		   	ExcelFileToRead.close();
		   	ExcelFileToRead = new FileInputStream("Resource/Data/PrequalData.xlsx");
		   	wb = new XSSFWorkbook(ExcelFileToRead);
			// Select the Common_Data Sheet and add all values
			sheet = wb.getSheet("Sheet1");
			}
			else{
//				ExcelFileToRead.close();
		   		ExcelFileToRead = new FileInputStream("Resource/Data/PrequalProfiledata.xlsx");
		   		wb = new XSSFWorkbook(ExcelFileToRead);
				// Select the Common_Data Sheet and add all values
				sheet = wb.getSheet("Sheet1");
			}
						
			intTotalRowCount = sheet.getPhysicalNumberOfRows();
			System.out.println("Row:"+intTotalRowCount);
			regArray=new String[intTotalRowCount][9];
			int noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
			System.out.println("Columns :"+noOfColumns);
			
				for (int intRowCounter = 1; intRowCounter < intTotalRowCount; intRowCounter++) {
					
					Cell cell = sheet.getRow(intRowCounter).getCell(0);
					
					if(cell!=null){
					//-------------Getting First name from the sheet---------------
					cell = sheet.getRow(intRowCounter).getCell(0);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][0]=cell.getStringCellValue();
					//------------Getting Second Name from the sheet-------------
					cell = sheet.getRow(intRowCounter).getCell(1);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][1] =cell.getStringCellValue().trim();
					//------------Getting Middle name from the sheet-----------------
					cell = sheet.getRow(intRowCounter).getCell(2);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][2]=cell.getStringCellValue().trim();
					//-------------Getting Address from the sheet-----------
					cell = sheet.getRow(intRowCounter).getCell(3);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][3] =cell.getStringCellValue().trim();
					//----------------Getting city from the sheet-------------
					cell = sheet.getRow(intRowCounter).getCell(4);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][4] =cell.getStringCellValue().trim();
					//------------Getting state from the sheet-------------
					cell = sheet.getRow(intRowCounter).getCell(5);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][5] =cell.getStringCellValue().trim();
					//------------Getting Middle Name from the sheet-------------
					cell = sheet.getRow(intRowCounter).getCell(6);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][6] =cell.getStringCellValue().trim();
					//------------Getting Phone from the sheet-------------
					cell = sheet.getRow(intRowCounter).getCell(8);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][8] =cell.getStringCellValue().trim();
					//------------Getting DOB from the sheet-------------
				
					cell = sheet.getRow(intRowCounter).getCell(7);
//					cell.setCellType(Cell.CELL_TYPE_STRING);
					regArray[intRowCounter][7] =cell.getDateCellValue().toString();
					System.out.println("Formated Date " + regArray[intRowCounter][7]);
//					System.out.prinltn
					

					}
					else
						break;

					}
				 
				wb.close(); 
			}
			catch(Exception e){
				 
				
			}
		return regArray;
			
		
	}
	
	
	@Test(groups = { "prequaldata"}, enabled = true, priority = 0, 
			testName = "Create a new Profile",
			dataProvider="prequal",
			description = "Creates a new profile")
	public void createProfile(String strFirstName,String strLastName,String strAddress,String strCity,String strState,String strZipcode,String strMiddleName,String strDob,String strPhone) throws ParseException {		System.out.print("FirstName:"+strFirstName);
// 		strFirstName=Utilities.getRandomName();
// 		strLastName=Utilities.getRandomName();
		
		SimpleDateFormat dt = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
		Date date = dt.parse(strDob);
		SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
		strDob=dt1.format(date);
        System.out.println("New Date"+dt1.format(date));
//		System.out.println("Formated Date:"+date);
		String strPwd="Qwerty@1";
		String strEmail=strFirstName+strLastName+"@bh.exacttarget.com";
		
		//********************************Creating profile******************************* 
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ "{\"firstName\":\""+strFirstName+"\",\"middleName\":\""+strMiddleName+"\","
				+ "\"lastName\":\""+strLastName+"\"},\"password\":\""+strPwd+"\","
				+ "\"email\":\""+strEmail+"\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false,200);
		
		
		//********************************Sign in profile***************************************
		String strPayloadOAPI="";
		String strResponseOAPI="";
		String strSignInPayload="grant_type=password&userId="+strEmail+"&password="+strPwd;
		String strSignInResponse=RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strSignInPayload, Server.Adapter, false,200);
		validator= new ResponseValidator(strSignInResponse);
		validator.validateNoErrors();
		String strMessage=Utilities.getJsonNodeValue(strSignInResponse, "$..message");
		System.out.println("Message :"+strMessage);
		strMessage=strMessage.replace("[\"", "");
		strMessage=strMessage.replace("\"]", "");
		strMessage=strMessage.replace("\\", "");
		if(strMessage.equals("Invalid userId/password")||strMessage.equals("To sign in to your account, please reset your password using the Forgot password? link.")){
			strPwd="Qwerty#1";
			 strSignInPayload="grant_type=password&userId="+strEmail+"&password="+strPwd;
			 strSignInResponse=RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strSignInPayload, Server.Adapter, false,200);
			 strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + strEmail + "&password=" + strPwd;
				
			// Post the request
			 strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
		}
		else{
			strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + strEmail + "&password=" + strPwd;
		
			// Post the request
			 strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
		}
		validator= new ResponseValidator(strResponseOAPI);
		validator.validateNoErrors();
		String strToken=Utilities.getJsonNodeValue(strSignInResponse, "$.payload.response.signIn.access_token");
		String strTokenOapi=Utilities.getJsonNodeValue(strResponseOAPI, "$.access_token");
		String strloyaltyId=Utilities.getJsonNodeValue(strSignInResponse, "$.payload.response.profileInfo.loyaltyId");
		if(!strloyaltyId.matches("[0-9]+"))
		{
		//*************************************Updated Ship Address*********************************
//		String strFlatno=Utilities.getRandom().substring(11, 14);
		String strId=Utilities.getRandom().substring(8, 12);
//		String strPhone=Utilities.getNewPhoneNumber();
		
		strZipcode=strZipcode.substring(0,5);
 		String strShipAddressPayload="{\"payload\":{\"profile\":{\"shipAddress\":"
 				+ "{\"firstName\":\""+strFirstName+"\",\"lastName\":\""+strLastName+"\","
 				+ "\"addr1\":\""+strAddress+"\",\"city\":\""+strCity+"\""
 				+ ",\"state\":\""+strState+"\""
 				+ ",\"postalCode\":\""+strZipcode+"\","
 				+ "\"phoneNumber\":\""+strPhone+"\""
 				+ ",\"ID\":\""+strId+"\",\"preferredAddr\":\"true\","
 				+ "\"action\":\"add\"}}}}";
 		mapheader.clear();
 		mapheader.put("access_token", strToken);
 		String strShipAddressResponse=RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strShipAddressPayload, Server.Adapter, false,mapheader,200);
 		validator= new ResponseValidator(strShipAddressResponse);
		String strUpdateMessage=Utilities.getJsonNodeValue(strShipAddressResponse, "$..message");
 		strUpdateMessage=strUpdateMessage.replace("[\"", "");
 		strUpdateMessage=strUpdateMessage.replace("\"]", "");
// 		validator.validateNoErrors();
// 		validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Validating whether profile is updated");
 		String strBillAddressPayload="";
 		String strBillAddressResponse="";
 		if(strUpdateMessage.equals("Your ZIP Code spans across multiple counties.  Please provide a valid county.")){
 			String strOrdercalcPayload="{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\""
 							+testData.get("SKU_NORMAL")+"\",\"qty\":1,\"shippingMethod\":\"USSTD\"}],"
 							+ "\"billAddress\":{\"firstName\":\""+strFirstName+"\","
 							+ "\"lastName\":\""+strLastName+"\",\"addr1\":\""
 							+strAddress+"\",\"addr2\":\"\",\"city\":\""
 							+strCity+"\",\"state\":\""+strState+"\","
 							+ "\"postalCode\":\""+strZipcode+"\",\"phoneNumber\""
 							+ ":\""+strPhone+"\",\"countryCode\":\"US\"},"
 							+ "\"isBillAddressEqualtoShipAddress\":true,\"customerName\""
 							+ ":{\"firstName\":\""+strFirstName+"\",\"lastName\":"
 							+ "\""+strLastName+"\"},\"email\":\""+strEmail
 							+"\",\"shippingMethod\":\"USSTD\"}}}";
 			String strOrdercalcResponse=RestCall.postRequest(ORDERCALC_ADAPTER_V2, strOrdercalcPayload, Server.Adapter, false);
 			String strCountyId=Utilities.getJsonNodeValue(strOrdercalcResponse, "$.payload.order.shipAddress.possibleCountyValues[0].ID");
 			strShipAddressPayload="{\"payload\":{\"profile\":{\"shipAddress\":"
 	 				+ "{\"firstName\":\""+strFirstName+"\",\"lastName\":\""+strLastName+"\","
 	 				+ "\"addr1\":\""+strAddress+"\",\"city\":\""+strCity+"\""
 	 				+ ",\"state\":\""+strState+"\",\"county\":\""+strCountyId
 	 				+ "\",\"postalCode\":\""+strZipcode+"\","
 	 				+ "\"phoneNumber\":\""+strPhone+"\""
 	 				+ ",\"ID\":\""+strId+"\",\"preferredAddr\":\"true\","
 	 				+ "\"action\":\"add\"}}}}";
 	 		mapheader.clear();
 	 		mapheader.put("access_token", strToken);
 	 		strShipAddressResponse=RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strShipAddressPayload, Server.Adapter, false,mapheader,200);
 	 		validator= new ResponseValidator(strShipAddressResponse);
 	 		validator.validateNoErrors();
 	 	//*************************************Updated Bill Address*********************************
			
 			strBillAddressPayload="{\"payload\":{\"profile\":{\"billAddress\":{"
 					+ "\"firstName\":\""+strFirstName+"\""
 					+ ",\"lastName\":\""+strLastName+"\","
 					+ "\"addr1\":\""+strAddress+"\""
 					+ ",\"city\":\""+strCity+"\","
 					+ "\"state\":\""+strState+"\",\"county\":\""+strCountyId+"\",\"postalCode\":\""+strZipcode+"\""
 					+ ",\"phoneNumber\":\""+strPhone+"\"}}}}";
 			mapheader.clear();
 			mapheader.put("access_token", strToken);
 			strBillAddressResponse=RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strBillAddressPayload, Server.Adapter, false,mapheader,200);
 			validator= new ResponseValidator(strBillAddressResponse);
 			validator.validateNoErrors();
 			validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Validating whether profile is updated");
 		}
 		else{
		//*************************************Updated Bill Address*********************************
		
		strBillAddressPayload="{\"payload\":{\"profile\":{\"billAddress\":{"
				+ "\"firstName\":\""+strFirstName+"\""
				+ ",\"lastName\":\""+strLastName+"\","
				+ "\"addr1\":\""+strAddress+"\""
				+ ",\"city\":\""+strCity+"\","
				+ "\"state\":\""+strState+"\",\"postalCode\":\""+strZipcode+"\""
				+ ",\"phoneNumber\":\""+strPhone+"\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", strToken);
		strBillAddressResponse=RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strBillAddressPayload, Server.Adapter, false,mapheader,200);
		validator= new ResponseValidator(strBillAddressResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Validating whether profile is updated");
 		}
		
		//-------------------------------Creating loyalty profiles--------------------------------
		
		String strLoyaltyPayload="{\"payload\":{\"profile\":{\"customerName\": {\"firstName\": \"" 
				+ strFirstName + "\",\"lastName\": \"" 
				+ strLastName + "\" }, \"email\": \"" 
				+ strEmail + "\", \"birthday\": \"" 
				+ strDob+"\", \"address\": {\"addr1\": \"" 
				+ strAddress + "\",\"addr2\": \"" 
				+ "\",\"city\": \"" 
				+ strCity+ "\",\"state\": \"" 
				+ strState + "\",\"postalCode\":\"" 
				+ strZipcode + "\" },"
				+ "\"phone\":{\"phoneNumber\":\"" + strPhone
				+ "\",\"phoneNumberType\":\"Home\"},\"channel\":\"B\"}}}";

		// Post the request for Loyalty
		String strResponseLoyalty1 = RestCall.postRequest(PROFILE_LOYALITY_CREATE, strLoyaltyPayload, Server.OpenApi, false);
		validator= new ResponseValidator(strResponseLoyalty1);
	 	validator.validateNoErrors();
		String strLoyaltyId = Utilities.getJsonNodeValue(strResponseLoyalty1, "$.payload.profile.loyaltyId");
		//------------------------------------Update  profile with loyalty
		mapheader.clear();
		mapheader.put("access_token",strTokenOapi);
		
		String strUpdateUrl=PROFILE_OAPI+"/info";
		String strPayloadUpdate1="{\"payload\": {\"profile\": {\"customerName\": {\"firstName\": \""
				+strFirstName+"\",\"lastName\": \""
				+strLastName+"\"},\"email\": \""
				+strEmail+"\",\"password\": \"Qwerty#1\","
				+ "\"loyaltyId\": \""+strLoyaltyId+"\","
				+ "\"loyaltyPostalCode\": \"" 
				+ strZipcode + "\",\"birthday\": \""
				+ strDob+"\",\"lock\": \"false\","
				+ "\"phone\": {\"phoneNumber\": \"" 
				+strPhone+ "\",\"phoneNumberType\": \"Home\"}}}}";

		// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
		String strURLUpdateOAPI1 = RestCall.postRequest(strUpdateUrl,strPayloadUpdate1, Server.OpenApi,false, mapheader);
		validator= new ResponseValidator(strURLUpdateOAPI1);
	 	validator.validateNoErrors();
		}
	}
	
}
