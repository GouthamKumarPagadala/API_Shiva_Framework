package test.java.adapters.cart;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;

import java.util.HashMap;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Cart")
@Stories({ "Get Cart" })
public class GetCart {

	ResponseValidator						validator;
	public static HashMap<String, String>	mapheader	= new HashMap<String, String>();


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 3, testName = "Get Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateCart",
			description = "Gets a Users cart using invalid access token")
	public void InvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");

		// Post the request
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "ASFDKJ14623H");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 3, testName = "Get Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateCart",
			description = "Gets a Users cart using expired access token")
	public void ExpiredAccessToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");

		// Post the request
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors,errors.code,errors.message,errors.entity,errorCode,error,fault,fault.faultstring,fault.detail.errorcode", true);
		}
	}
}
