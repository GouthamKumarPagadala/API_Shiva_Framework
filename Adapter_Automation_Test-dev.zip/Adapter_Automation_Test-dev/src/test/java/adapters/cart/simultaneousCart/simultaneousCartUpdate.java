package test.java.adapters.cart.simultaneousCart;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Simultaneous Cart Update")
@Stories({ "Cart Update" })
public class simultaneousCartUpdate {
	

	String strOCBPaswd = "Ocb@1234";
	String strOCBEmail = "";
	
	@BeforeMethod(alwaysRun = true)
	public void setup(){
		strOCBEmail = Utilities.getNewEmailID();
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter_SCU'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_SCU");
	}
	
	ResponseValidator validator;
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add online Item to Cart and Update it to Bopus Item",
			description = "Verify whether the user is able to Add online Item to Cart and Update it to Bopus Item")
	public void OnlineItemToBopusItem() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
				+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add Bopus Item to Cart and Update it to Online Item",
			description = "Verify whether the user is able to Add Bopus Item to Cart and Update it to Online Item")
	public void BopusItemOCBToOnlineItem() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", true, testData.get("BOPUS_NORMAL_STORE"));

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
				+ "\"bopusItem\":\"false\",\"itemType\":\"BOPUS"
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", false, null);
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate","CartChanges-NAP148","DIE Changes" }, enabled = true, priority = 2, testName = "Add Bopus Item to Cart and Update its size",
			description = "Verify whether the user is able to Add Bopus Item to Cart and Update its size")
	public void AddBopusAndUpdateSize() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", true, testData.get("BOPUS_NORMAL_STORE"));

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
				+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+"\",\"itemType\":\"BOPUS"
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "3")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "3", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add Online Item to Cart and Update its color",
			description = "Verify whether the user is able to Add online Item to Cart and Update its color")
	public void AddOnlineItemAndUpdateColor() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("SKUCODE_NORMAL"), "1", false, null);

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKUCODE_CHANGE_COLOR"), "1")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("SKUCODE_CHANGE_COLOR"), "1", false, null);
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate","CartChanges-NAP148","DIE Changes"  }, enabled = true, priority = 2, testName = "Add Bopus Item to Cart and Update its Quantity",
			description = "Verify whether the user is able to Add Bopus Item to Cart and Update its Quantity")
	public void AddBopusAndUpdateQty() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
				+ "\"itemType\":\"BOPUS\",\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "4")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "4", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add Online Item to Cart and Update to bopus also change its Size",
			description = "Verify whether the user is able to Add online Item to Cart and Update to bopus also change its Size")
	public void AddOnlineUpdateToBopusAlongWithSize() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", false, null);

		// Update cart through Adapter
		// Update cart through Adapter
				strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
						+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
						+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_CHANGE_SIZE"), "1")
						+ "]}}}";
				mapheader.clear();
				mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_CHANGE_SIZE"), "1", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add Online Item to Cart and Update to bopus also change its Color",
			description = "Verify whether the user is able to Add online Item to Cart and Update to bopus also change its color")
	public void AddOnlineUpdateToBopusAlongWithColor() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", false, null);

		// Update cart through Adapter
		// Update cart through Adapter
				strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
						+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
						+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_CHANGE_COLOR"), "1")
						+ "]}}}";
				mapheader.clear();
				mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_CHANGE_COLOR"), "1", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add Online Item to Cart and Update to bopus also change its Qty",
			description = "Verify whether the user is able to Add online Item to Cart and Update to bopus also change its Qty")
	public void AddOnlineUpdateToBopusAlongWithQty() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", false, null);

		// Update cart through Adapter
		// Update cart through Adapter
				strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
						+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
						+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "3")
						+ "]}}}";
				mapheader.clear();
				mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "3", true, testData.get("BOPUS_NORMAL_STORE"));
	}

	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add Online Item to Cart and Update its color and Qty",
			description = "Verify whether the user is able to Add online Item to Cart and Update its color and Qty")
	public void AddOnlineItemAndUpdateQtyAndColor() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.validateCartResponse(testData.get("SKUCODE_NORMAL"), "1", false, null);

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKUCODE_CHANGE_COLOR"), "3")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("SKUCODE_CHANGE_COLOR"), "3", false, null);
	}

	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add online Item to Cart and Update it to Bopus Item also change its size and qty",
			description = "Verify whether the user is able to Add online Item to Cart and Update it to Bopus Item also change its size and qty")
	public void OnlineItemUpdateToBopusItemSizeAndQty() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
				+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_CHANGE_SIZE"), "2")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_CHANGE_SIZE"), "2", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add online Item and Bopus Item to Cart and Update Bopus Item to Online Item with giftItem=true",
			description = "Verify whether the user is able to Add online Item and Bopus Item to Cart and Update Bopus Item to Online Item with giftItem=true")
	public void MultiItemUpdateBopusToOnlineWithGift() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ ","+JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		String cartItemID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_NORMAL_SKU")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		String cartItemID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+cartItemID+"\","
				+ "\"bopusItem\":\"false\",\"giftItem\":\"true\",\"itemType\":\"BOPUS"
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		cartItemID = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_NORMAL_SKU")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		cartItemID1 = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		validator.validateMultiCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", false, null, cartItemID, cartItemID1, true);
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate","CartChanges-NAP148","DIE Changes"  }, enabled = true, priority = 2, testName = "Add online Item and Bopus Item to Cart and Update Bopus storeNum",
			description = "Verify whether the user is able to Add online Item and Bopus Item to Cart and Update Bopus StoreNum")
	public void MultiItemUpdateBopusStoreNum() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ ","+JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		String cartItemID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_NORMAL_SKU")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		String cartItemID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+cartItemID+"\","
				+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_CHANGE_STORE")+"\",\"itemType\":\"BOPUS"
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		cartItemID = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_NORMAL_SKU")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		cartItemID1 = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		validator.validateMultiCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", true, testData.get("BOPUS_CHANGE_STORE"), cartItemID, cartItemID1, false);
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate" }, enabled = true, priority = 2, testName = "Add online Item of same Product and Update Size and Color of A Sku",
			description = "Verify whether the user is able to Add online Item of same Product and Update Size and Color of A Sku")
	public void MultiItemofSameProductAndUpdateSizeColor() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_CHANGE_SIZE"), "1")
				+ ","+JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		String cartItemID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		String cartItemID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_CHANGE_SIZE")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+cartItemID+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKUCODE_CHANGE_BOTH"), "1")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		cartItemID = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_CHANGE_BOTH")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		cartItemID1 = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_CHANGE_SIZE")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		validator.validateMultiCartResponse(testData.get("SKUCODE_CHANGE_BOTH"), "1", false, testData.get("BOPUS_CHANGE_STORE"), cartItemID, cartItemID1, false);
	}
	
	@Test(groups = { "regression1", "SimultaneousCartUpdate","CartChanges-NAP148","DIE Changes"  }, enabled = true, priority = 2, testName = "Add online Item and Bopus Item to cart and Update Bopus Item to Online Item with Color and Qty",
			description = "Verify whether the user is able to Add online Item and Bopus Item to cart and Update Bopus Item to Online Item with Color and Qty")
	public void MultiItemUpdateBopusToOnlineWithQtyAndColor() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ ","+JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		String cartItemID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_NORMAL_SKU")+")].cartItemID");
		String cartItemID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+cartItemID+"\","
				+ "\"itemType\":\"BOPUS\",\"itemType\":\"BOPUS"
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_CHANGE_COLOR"), "3")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		cartItemID = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_CHANGE_COLOR")+")].cartItemID");
		cartItemID1 = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		validator.validateMultiCartResponse(testData.get("BOPUS_CHANGE_COLOR"), "3", false, testData.get("BOPUS_CHANGE_STORE"), cartItemID, cartItemID1, false);
	}

	@Test(groups = { "regression1", "SimultaneousCartUpdate","CartChanges-NAP148","DIE Changes"  }, enabled = true, priority = 2, testName = "Add online Item and Bopus Item to Cart and Update Bopus storeNum, change size and qty",
			description = "Verify whether the user is able to Add online Item and Bopus Item to Cart and Update Bopus StoreNum, change size and qty")
	public void MultiItemUpdateBopusStoreNumSizeQty() {

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("BOPUS_NORMAL_SKU"), "1", testData.get("BOPUS_NORMAL_STORE"))
				+ ","+JsonString.getCartJson("VALID_ADD", testData.get("SKUCODE_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		String cartItemID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_NORMAL_SKU")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		String cartItemID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+cartItemID+"\","
				+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_CHANGE_STORE")+"\",\"itemType\":\"BOPUS"
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_CHANGE_SIZE"), "3")
				+ "]}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_SCU"));
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		cartItemID = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("BOPUS_CHANGE_SIZE")+")].cartItemID");
		cartItemID = cartItemID.substring(2, cartItemID.length()-2);
		cartItemID1 = Utilities.getJsonNodeValue(strResponseUpdateCartAdapter, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKUCODE_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, cartItemID1.length()-2);
		validator.validateMultiCartResponse(testData.get("BOPUS_CHANGE_SIZE"), "3", true, testData.get("BOPUS_CHANGE_STORE"), cartItemID, cartItemID1, false);
	}

}
