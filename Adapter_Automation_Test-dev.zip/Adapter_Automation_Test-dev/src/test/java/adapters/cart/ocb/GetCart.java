package test.java.adapters.cart.ocb;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omni Channel Bag")
@Stories({ "OCB Get cart" })
public class GetCart {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart Persistent Cart",
			description = "Verify whether User able to Reterive persisted Cart bag details using Get Method")
	public void PersistentCart() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as others should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart Bopus Item",
			description = "In Webstore Relogin the user, Verify whether User able to Reterive persisted Cart bag details and the itemType is returned as BOPUS in Response")
	public void BopusItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "BOPUS", "Item type as BOPUS should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].storeAddress.storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.city", ".+", "store city should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.addr1", ".+", "store address should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.state", ".+", "store state should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.postalCode", ".+", "store postal code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.countryCode", ".+", "store countryCode should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.phoneNumber", ".+", "store phoneNumber should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].storeAddress.storeName", ".+", "store name should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart Gift Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and the cart items are not getting split in Response.")
	public void GiftItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("GIFT_TRUE", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "3", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].giftItem", "true", "gift item as true should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart GiftWrap Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and the cart items are not getting split in Response.")
	public void GiftWrapItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("GIFT_TRUE", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		
		// SiginIn to OpenAPI using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadOAPIUpdateCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" :[{\"cartItemID\":\""
				+ testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getCartJson("UPDATE_WITH_GIFT", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadOAPIUpdateCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "3", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].giftItem", "true", "gift item as true should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart registry Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and registry Item details are getting displayed in response")
	public void RegistryItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter")
				+ "\"},\"action\":\"add\"}]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].giftItem", "true", "gift item as true should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].registry.registryName", "Tests", "Registry name should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].registry.registryType", "wishlist", "Registry type should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].registry.registryID", "2522230", "Registry id should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].registry.shipToId", testData.get("shipping_id_adapter"), "Registry id should be present in the response");
		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart GWP Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and GWP Item details are getting displayed in response")
	public void GWPItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_GWP"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_GWP"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart PWP Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and GWP Item details are getting displayed in response")
	public void PWPItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_PWP"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_PWP"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart BOGO Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and BOGO Item details are getting displayed in response")
	public void BOGOItem() {

		// Create a new profile through OAPI b
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_BOGO"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_BOGO"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart Clearance Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and Clearance price details are getting displayed in response")
	public void ClearanceItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CLEARANCE"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CLEARANCE"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Get Cart Suppresed Item",
			description = "Verify whether User able to Reterive persisted Cart bag details and Clearance price details are getting displayed in response")
	public void SuppressedItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_SUPPRESSED"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		validator = new ResponseValidator(strResponseOAPIGetCart);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_SUPPRESSED"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as OTHERS should be present in the response");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

}
