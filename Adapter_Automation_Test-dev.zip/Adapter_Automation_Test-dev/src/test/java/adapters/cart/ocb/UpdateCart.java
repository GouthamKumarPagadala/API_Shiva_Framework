package test.java.adapters.cart.ocb;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;

import java.util.HashMap;

import org.apache.commons.codec.language.MatchRatingApproachEncoder;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omni Channel Bag")
@Stories({ "OCB Update cart" })
public class UpdateCart {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Action Add",
			description = "Verify add cart response gives a cartItemID for that sku in the response")
	public void NewItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "4", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		// validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as others should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
		if (CompareOAPI) {
		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart Action Add",
			description = "Verify add cart response gives a cartItemID for that sku in the response")
	public void SkuNotFound() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", "12345678", "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateExpectedErrors("CART3000", "SKU (12345678) not found.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Action Update With Same SKU",
			description = "Verify add cart response gives a cartItemID for that sku in the response")
	public void ActionUpdateWithSameSku() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\",\"cartItems\" :[{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "3", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		// validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as others should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Action Update With Same SKU",
			description = "Verify whether the item is not merged with the existing persistent cart if both are different skucodes")
	public void ActionUpdateWithDifferentSku() throws InterruptedException {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_GIFT_WRAP"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].qty", ".+", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as others should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[1].skuCode", testData.get("SKU_GIFT_WRAP"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].qty", ".+", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[1].itemType", "OTHERS", "Item type as others should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
		//Thread.sleep(100000);
		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "$.payload.cart.cartItems[0].itemMaxAvailableCount,$.payload.cart.cartItems[0].maxQuantityMessage", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Market Place item",
			description = "verify whether the itemType is returned as MarketPlace for the sku added in webstore")
	public void MarketPlaceItem() throws InterruptedException {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_MARKET_PLACE"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_MARKET_PLACE"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given qty should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "MARKETPLACE", "itemType should be MARKETPLACE in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", ".+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		//Thread.sleep(100000);
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart LTL item",
			description = "verify whether the itemType is returned as LTL for the sku added in webstore")
	public void LTLItem() throws InterruptedException {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_LTL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_LTL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given qty should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "LTL", "itemType should be MARKETPLACE in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", ".+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		//Thread.sleep(100000);
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Muliple Items",
			description = "Verify whether user able to update Multiple Cart using multiple CartItemID in Single call")
	public void MultipleItems() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ ","
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_GIFT_WRAP"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[1].cartItemID", "OAPI_CART_ITEM_ID1");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\",\"cartItems\" :[{\"cartItemID\":\""
				+ testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKU_NORMAL"), "3")
				+ ","
				+ "{\"cartItemID\":\""
				+ testData.get("OAPI_CART_ITEM_ID1")
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKU_GIFT_WRAP"), "4")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].qty", ".+", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[1].skuCode", testData.get("SKU_GIFT_WRAP"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[*].qty", ".*3.*", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		// validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "Item type as others should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Bopus To Ship",
			description = "Verify whether user is able to Update a bopus item to Normal itrm with cartItemID, action=Update, skuCode, qty, isBopusToShip=true,CartId")
	public void BopusToShip() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", "9961")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\",\"cartItems\" :[{\"cartItemID\":\""
				+ testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("BOPUS_TO_NORMAL", testData.get("SKU_BOPUS"), "1", "9961")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		// validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "BOPUS", "Item type as others should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Bopus Item",
			description = "Verify itemType is BOPUS after adding normal from webstore and bopus from adapter")
	public void BopusItem() throws InterruptedException {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", testData.get("BOPUS_STORE"))
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[1].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[1].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[1].itemType", "BOPUS", "storeNumber should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "OTHERS", "storeNumber should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		//Thread.sleep(100000);
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "payload..itemMaxAvailableCount,payload..maxQuantityMessage", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Bopus Item",
			description = "Verify itemType is BOPUS after adding normal from webstore and bopus from adapter")
	public void BopusItemMerged() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", testData.get("BOPUS_STORE"))
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "6", " Sku code should be merged in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		// validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[0].itemType", "BOPUS", "storeNumber should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Bopus As Gift And Non Gift",
			description = "Verify sku does not merged after adding bopus item as gift and as non gift item")
	public void BopusGiftNonGiftItem() throws InterruptedException {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_GIFT", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[1].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.cart.cartItems[1].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[1].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.storeAddressesCart();
		validator.nodeEquals("$.payload.cart.cartItems[1].itemType", "BOPUS", "storeNumber should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		//Thread.sleep(100000);
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Bopus As Gift And Non Gift",
			description = "Verify whether last added item getting displayed as a separate lineitem with giftItem=true and also ensure persisted cart item details getting displayed in response")
	public void GiftItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("GIFT_TRUE", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\",\"cartItems\" :[{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("UPDATE_WITH_GIFT", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "3", "First line item should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].giftItem", "true", "First line item should be gift item in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Action update",
			description = "Verify update cart response gives a cartItemID for that sku in the response")
	public void QtyChange() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\"cartItems\" :[{\"cartItemID\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "Update Cart Action Remove",
			description = "Verify system accepts cartID in updateCartRequest when action =remove")
	public void RemoverItem() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\"cartItems\" :[\"cartItemID\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("REMOVE_ACTION", testData.get("SKU_NORMAL"), "0")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	@Test(groups = { "regression","functional", "ocb", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart Invalid cartID",
			description = "Verify whether CART3003 Error getting displayed with 200 Response code when we provided cartID which is Does not match with existing cartID")
	public void InvalidCartID() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"1000271913\",\"cartItems\" :[{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateExpectedErrors("CART3003", "Cart ID 1000271913 provided is either invalid or not found in the database or is already a submitted order");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "regression","functional", "ocb", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart EmptyQtyValue",
			description = "Adds a new item to the cart with empty qty value and verify CART1000 error code is displayed in response")
	public void EmptyQtyValue() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateExpectedErrors("CART1000", "missing required parameter qty.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "regression","functional", "ocb", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart InvalidQtyParameter",
			description = "Adds a new item to the cart with Invalid qty Parameter and verify CART1002 error code is displayed in response")
	
	public void InvalidQtyParameter() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "ghk")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateExpectedErrors("CART1002", "invalid value passed for qty.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "regression","functional", "ocb", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart SkuOutOfInventory",
			description = "Adds a new item to the cart which is out of inventory and verify CART4000 error code is displayed in response")
	
	public void SkuOutOfInventory() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_OUTOFINVENTORY"), "1")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateExpectedErrors("CART4000", "sku ("+testData.get("SKU_OUTOFINVENTORY")+") out of inventory.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	@Test(groups = { "regression","functional", "ocb","errorhandling" }, enabled = true, priority = 2, testName = "Update Cart Sku Not Eligible For Bopus",
			description = "Verify whether CART3002 when the request with sku which is not eligible for bopus with bopus item true")
	public void skuNotEligibleBopus() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_NORMAL"), "3", testData.get("BOPUS_STORE"))
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateExpectedErrors("CART3002", "The SKU "+testData.get("SKU_NORMAL")+" is not eligible for BOPUS");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	
	@Test(groups = { "regression","functional", "ocb","errorhandling" }, enabled = true, priority = 2, testName = "Update Cart Wrong CartItem ID",
			description = "Verify the error CART3001 is displayed while passing cartId which does not match with persistent bag")
	public void WrongCartItemID() {

		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Ocb@1234";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				// Update cart through Adapter
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID") + "\",\"cartItems\" :[{\"cartItemID\":\"1441017392" 
						+ JsonString.getCartJson("UPDATE_ACTION", testData.get("SKU_NORMAL"), "3")
						+ "]}}}";
				String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseUpdateCartAdapter);
				validator.validateExpectedErrors("CART3001", "the sku "+testData.get("SKU_NORMAL")+", cartItemID 1441017392 provided does not match the existing cart");

				// GetCart from Adapter
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

				// Compare the Getcart from Adapter and OAPI
				if (CompareOAPI) {
				// GetCart response from OAPI
				mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
				String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
				}
	}

}
