package test.java.adapters.cart.ocbphase2;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.codec.language.MatchRatingApproachEncoder;
import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omni Channel Bag")
@Stories({ "OCB Update cart" })
public class UpdateCart {

	ResponseValidator validator;


	@Test(groups = { "ocbphase2", "regression1"}, enabled = true, priority = 2, testName = "Update Cart with single promocode Action Add",
			description = "Verify whether user able to add single promocode to the cart")
	public void SinglePromocode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlepromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlepromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlepromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlepromo");
				
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
		+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Multiple promocodes (Max 4) Action Add",
			description = "Verify whether user able to add multiple promocodes to the cart")
	public void MultiplePromoCodes() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");


	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with SUPC promocode Action Add",
			description = "Verify whether user able to add SUPC promocode to the cart")
	public void SUPCPromocode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_supcpromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_supcpromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_supcpromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_supcpromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_supcpromo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_supcpromo"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_supcpromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("SUPC6")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("SUPC6")+".*", "Given Promocode should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with ExpiredPromoCode PromoCode Action Add",
			description = "Verify whether user able to get proper error code (CART9121) & message when we are trying to add Expired PromoCode to the cart")
	public void ExpiredPromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_ExpPromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_ExpPromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_ExpPromo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_ExpPromo"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("Expired1")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART9121", "We're sorry, but the Promo Code you entered has expired. Please check the offer for details.");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
		
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Not Exists PromoCode Action Add",
			description = "Verify whether user able to get proper error code (CART9124) & message when we are trying to add PromoCode to the cart which is not exists in OE to the cart")
	public void NotExistsPromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_NotExisits");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_NotExisits"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_NotExisits");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_NotExisits"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\"ABC\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART9124", "The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code.");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 8, testName = "Update Cart with Reedemed SUPC PromoCode Action Add",
			description = "Verify whether user able to get proper error code (CART9121) & message when we are trying to add Reedemed SUPC PromoCode to the cart")
	
	public void RedeemedSUPC() {

		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
						
				// Updating single PromoCode to the cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("SUPC3")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				
				validator.validateExpectedErrors("CART9459", "The promocode "+testData.get("SUPC3")+" has exceeded the number of times it can be redeemed.");
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code",testData.get("SUPC3"), "Given Promocode should be present in the response");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with 5 PromoCode Action Add",
			description = "Verify whether user able to get proper error code (CART9131) & message when we are trying to add More than 5 PromoCode to the cart")
	public void TooManyPromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.error.code", "CART2001", "CART2001 Error code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.error.message", "Too many promo codes supplied.", "Too many promo codes supplied error message should be present in the response");
}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Updating peristed Cart with maximum of five promocode Action Add",
			description = "Verify whether user able to get proper error code & message when we are trying to add 2 PromoCode when peristed cart already having 3 promoCodes")
	public void peristedCartPromoCode() {


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		
		
		String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
				+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
				+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}"
				+"]}}}}}";

// Post the request for updateCart(ADD) using mapheader to OAPI
String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].error.code", ".*"+"CART9131"+".*", "Given Promocode should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].error.message", ".*"+"We're sorry, but you have reached the maximum number of Kohls.com Promo codes accepted per order. We are only able to accept 4 Promo code (s) per order. Please place your order or remove one of the Promo codes if you would like to apply a different Promo code."+".*", "Given Promocode should be present in the response");
		validator.validateExpectedErrors("CART9131", "We're sorry, but you have reached the maximum number of Kohls.com Promo codes accepted per order. We are only able to accept 4 Promo code (s) per order. Please place your order or remove one of the Promo codes if you would like to apply a different Promo code.");
        
			
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");


}

	@Test(groups = { "ocbphase2", "regression1"  , "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with single KohlsCash Action Add",
			description = "Verify whether user able to add single Kohls to the cart")
	public void SingleKohlsCash() {
		
		String arr[]=TestData.createKohlsCash(150);
		testData.put("kohlscash_single", arr[0]);
		testData.put("kohlscash_single_pin", arr[1]);
		


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlekohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "3")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlekohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlekohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "3", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlekohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));				// Update cart through Adapter
		
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "3", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Multiple KohlsCash Action Add",
			description = "Verify whether user able to add Multiple Kohls (Max 10) to the cart")
	public void MultipleKohlsCash() {
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
//		String arr2[]=TestData.createKohlsCash(10);
//		String arr3[]=TestData.createKohlsCash(10);
//		String arr4[]=TestData.createKohlsCash(10);
//		String arr5[]=TestData.createKohlsCash(10);
//		String arr6[]=TestData.createKohlsCash(10);
//		String arr7[]=TestData.createKohlsCash(10);
//		String arr8[]=TestData.createKohlsCash(10);
		String arr9[]=TestData.createKohlsCash(10);
		
		testData.put("kohlscash_multiple", arr[0]);
		testData.put("kohlscash_multiple1", arr1[0]);
		testData.put("kohlscash_multiple9", arr9[0]);
		
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multiplekohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplekohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multiplekohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multiplekohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multiplekohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplekohlscash"));				// Update cart through Adapter

		
		String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multiplekohlscash")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
				+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr4[0]+"\",\"pin\":\""+arr4[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr5[0]+"\",\"pin\":\""+arr5[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr6[0]+"\",\"pin\":\""+arr6[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr7[0]+"\",\"pin\":\""+arr7[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr8[0]+"\",\"pin\":\""+arr8[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"add\"}"+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr2[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr3[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr4[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr5[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr6[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr7[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr8[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr9[0]+".*", "Given kohlsCash should be present in the response");

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Future begin date kohlsCash Action Add",
			description = "Verify whether user able to add  Future begin date kohlsCash")
	public void futureBeginDateKohlsCash() {

		//String arr[]=TestData.createKohlsCash(10);


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+testData.get("OCB_FUTURE_KOHLS_CASH")+"\",\"pin\":\""+testData.get("OCB_FUTURE_KC_PIN")+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART9908", "We're sorry! You cannot use your Kohl's Cash to complete this order. Please check the redeem dates.");

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Expired kohlsCash Action Add",
			description = "Verify whether user able to get proper error code & message when we are trying to add expired kohls to the cart")
	public void ExpiredKohlsCash() {

	//	String arr[]=TestData.createKohlsCash(10);


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_expiredkohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_expiredkohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+testData.get("OCB_EXPIRED_KOHLS_CASH")+"\",\"pin\":\""+testData.get("OCB_EXPIRED_KC_PIN")+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART9908", "we're sorry! you cannot use your kohl's cash to complete this order. please check the redeem dates.");


	}
			
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Reedemed KohlsCash Action Add",
			description = "Verify whether user able to get proper error code (CART9012) & message when we are trying to add Reedemed KohlsCash to the cart which is Not Existis in DB")
	public void RedeemedKohlsCash() {

		//String arr[]=TestData.createKohlsCash(10);


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+testData.get("OCB_REDEEMED_KOHLS_CASH")+"\",\"pin\":\""+testData.get("OCB_REDEEMED_KC_PIN")+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
//		validator.validateExpectedErrors("CART9012", "The Kohls cash coupon  you entered \u2018 doesnâ€™t \u2019 have any remaining balance");
		validator.validateExpectedErrors("CART9012", "we're sorry, the kohl's cash or rewards number you entered has no remaining balance. please check the number and try again.");

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Morethan 3 KohlsCash Action Add",
			description = "Verify whether user able to get proper error code (CART2001) & message in response when we are trying to add morethan 3 KohlsCash")
	public void MoreThanLimitKohlsCash() {
		
		
		String kohlsCash[] = TestData.createKohlsCash(10,kohlsCashLim+1);
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter

		
		String strPayloadAddCart1 =  Utilities.PayloadPaymentTypetoCart(kohlsCash, null, "add");

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART2001", "Too many Kohl's Cash supplied.");
	}	
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with kohlsCash when peristed Cart already having some kohls cash Action Add",
			description = "Verify whether user able to get proper error code & message in response when we are trying to add 7 KohlsCash which cart is already having 5 kohls Cash")
	public void peristedCartKohlsCash() {
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
//		String arr2[]=TestData.createKohlsCash(10);
//		String arr3[]=TestData.createKohlsCash(10);
//		String arr4[]=TestData.createKohlsCash(10);
//		String arr5[]=TestData.createKohlsCash(10);
//		String arr6[]=TestData.createKohlsCash(10);
//		String arr7[]=TestData.createKohlsCash(10);
		String arr8[]=TestData.createKohlsCash(10);
		String arr9[]=TestData.createKohlsCash(10);
		
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter

		
		String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
				+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"
//				+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr4[0]+"\",\"pin\":\""+arr4[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr5[0]+"\",\"pin\":\""+arr5[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr6[0]+"\",\"pin\":\""+arr6[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr7[0]+"\",\"pin\":\""+arr7[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr8[0]+"\",\"pin\":\""+arr8[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"add\"}"+
					+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		
		String strPayloadAddCart2 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
//				+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr4[0]+"\",\"pin\":\""+arr4[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr5[0]+"\",\"pin\":\""+arr5[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr6[0]+"\",\"pin\":\""+arr6[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr7[0]+"\",\"pin\":\""+arr7[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr8[0]+"\",\"pin\":\""+arr8[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"add\"}"+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr2[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr3[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr4[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr5[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr6[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr7[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr8[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr9[0]+".*", "Given kohlsCash should be present in the response");
		validator.validateExpectedErrors("CART9909", "Orders are limited to 3 Kohl's Cash. To create space for another, consider removing atleast one of the existing Kohl's Cash.");
		
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with invalid kohlsCash Action Add",
			description = "Verify whether user able to get proper error code (CART1002) & message when we are trying to add invalid kohls cash to the cart")
	public void invalidKohlsCash() {

		//String arr[]=TestData.createKohlsCash(10);


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\"14578785148d648d4sa\",\"pin\":\"1234\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART1002", "Invalid value passed for kohlscashNum.");

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with single Promocode and single kohlsCash Action Add",
			description = "Verify whether user able to add single Promocode and single kohlsCash to the cart")
	public void promoKohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_promokc", arr[0]);
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlepromokohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromokohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlepromokohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlepromokohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlepromokohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromokohlscash"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlepromokohlscash")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]},"
				+"\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}"
				+"]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Test(groups = { "ocbphase2", "regression1"  , "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with Multi Promocode and Multi kohlsCash Action Add",
			description = "Verify whether user able to add Multi Promocode and Multi kohlsCash to the cart")
	public void multiPromoCodeKohlsCash() {


		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_multipromokc", arr[0]);
		testData.put("kohlscash_multipromokc1", arr1[0]);
		// Create a new profile through OAPI/
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multiplepromokohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromokohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multiplepromokohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multiplepromokohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multiplepromokohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromokohlscash"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multiplepromokohlscash")+"\",\"paymentTypes\":"
				+ "{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]},"
				+"\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"
				+"]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		//validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Multi Promocode and Multi kohlsCash which is contains both valid and invalid  Action Add",
			description = "Verify whether user able to get proper error code (CART9124,CART9004) and  invalid message when we are trying to add Multi promoCode and Multi kohlsCash which is contains both valid and invali")
	public void invalidMultiPromoCodeKohlsCash() {


		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":"
				+ "{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"},"
						+ "{\"code\":\"55455ds4c5454d\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]},"
				+"\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\"5s45d3fs1fsdfsfs45434\",\"pin\":\"1234\",\"action\":\"add\"},"
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"
				+"]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].error.code", ".*"+"CART9124"+".*", "CART9124 error code should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].error.message", ".*"+"The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code."+".*", "Given Promocode error message should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].error.code",".*"+ "CART1002"+".*", "CART1002 error code should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].error.message",".*"+ "Invalid value passed for kohlscashNum."+".*","KC error messageshould be there");
		}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Removing Single promocode from cart with action=remove",
			description = "Verify whether user able to Remove single promocode from the cart")
	
	public void RemovePromoCode() {

		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
						
				// Updating single PromoCode to the cart through Adapter
						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";
						String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
						
						String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"remove\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart2);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes","{promoCode=[]}", "Given Promocode should be present in the response");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Removing Single Kohls from cart with action=remove",
			description = "Verify whether user able to Remove single promocode from the cart")
	public void RemoveKohlsCash() {

		String arr[]=TestData.createKohlsCash(10);


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
			String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"remove\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher", "[]", "Given KohlsCash should not be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}

		@Test(groups = { "ocbphase2", "regression1"  , "regression1" }, enabled = true, priority = 2, testName = "Removing Multiple promocode from cart with action=remove",
			description = "Verify whether user able to Remove Multiple promocode from the cart")
	public void RemoveMultiplePromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";
		
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");				
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				
				String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"remove\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", testData.get("OCB_Promocode1"), "Given Promocode should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", testData.get("OCB_Promocode2"), "Given Promocode should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
			
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");


	}
	
	@Test(groups = { "ocbphase2", "regression1"  }, enabled = true, priority = 2, testName = "Removing Multiple Kohls from cart with action=remove",
			description = "Verify whether user able to Remove Multiple promocode from the cart")
	public void RemoveMultipleKohlsCash() {
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
//		String arr2[]=TestData.createKohlsCash(10);
//		String arr3[]=TestData.createKohlsCash(10);
//		String arr4[]=TestData.createKohlsCash(10);
//		String arr5[]=TestData.createKohlsCash(10);
//		String arr6[]=TestData.createKohlsCash(10);
//		String arr7[]=TestData.createKohlsCash(10);
//		String arr8[]=TestData.createKohlsCash(10);
		String arr9[]=TestData.createKohlsCash(10);
		
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter

		
		String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
				+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr4[0]+"\",\"pin\":\""+arr4[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr5[0]+"\",\"pin\":\""+arr5[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr6[0]+"\",\"pin\":\""+arr6[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr7[0]+"\",\"pin\":\""+arr7[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr8[0]+"\",\"pin\":\""+arr8[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"add\"}"+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");		
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr9[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr7[0]+".*", "Given KohlsCash should be present in the response");
		
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		String strPayloadAddCart2 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
				+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"remove\"},"
				+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"remove\"},"
//				+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr4[0]+"\",\"pin\":\""+arr4[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr5[0]+"\",\"pin\":\""+arr5[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr6[0]+"\",\"pin\":\""+arr6[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr7[0]+"\",\"pin\":\""+arr7[1]+"\",\"action\":\"add\"},"
//				+"{\"kohlsCashNum\":\""+arr8[0]+"\",\"pin\":\""+arr8[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"remove\"}"+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		
		validator = new ResponseValidator(strResponseAddCart2);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr[0], "Given kohlsCash should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr1[0], "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr2[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr3[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr4[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr5[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr6[0]+".*", "Given kohlsCash should be present in the response");
////		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr7[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr8[0]+".*", "Given kohlsCash should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr9[0], "Given kohlsCash should be present in the response");
		
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

	}
	
	
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Add_Existed_KohlsCash",
			description = "As a Kohl's user verify in adapter add an already existing kohlsCash to the same cart and in response verify whether error (CART9014) details are returned.")
	public void Add_Existed_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given kohlsCash should be present in the response");
		
		String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		
		validator = new ResponseValidator(strResponseAddCart2);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART9014", "We're sorry, you have already entered this Kohl's Cash or Rewards Number. Please enter a different Kohl's Cash or Rewards number.");

	}
	@Test(groups = { "ocbphase2", "regression1", "regression1" }, enabled = true, priority = 2, testName = "Add_Existed_PromoCode",
			description = "As a Kohl's user verify in adapter add an already existing Promocode to the same cart and in response verify whether error (CART9123) details are returned.")
	public void Add_Existed_PromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}"
						+ "]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		
		String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
				+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}"
				+ "]}}}}}";
		
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		
		validator = new ResponseValidator(strResponseAddCart2);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateExpectedErrors("CART9123", "we're sorry, but you have already entered that promo code. please enter a different code or complete your order.");

	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Add_PromoCode_with_Space",
			description = "As a Kohl's user verify in adapter add an Promocode with space to the  cart and in response verify whether promocode is returned without any errors.")
	public void Add_PromoCode_with_Space() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\" "+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}"
						+ "]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		
		validator = new ResponseValidator(strResponseAddCart);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");

	}
	@Test(groups = { "ocbphase2", "regression1"  , "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with InvalidKohlsCashPin",
			description = "Verify whether user able to get proper error code (CART9011) & message when we are trying to add invalid kohls cash pin to the cart")
	public void InvalidKohlsCashPin() {

		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\"1234\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART9011", "we're sorry, but the kohl's cash & rewards/pin number does not match our records. please check the number and try again.");

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "EmptyCart_AddPromoCode_KohlsCash",
			description = "As a Kohl's user verify in adapter add promocode and kohlsCash to the cart and in response verify whether error (CART9912, CART9910) details are returned.")
	public void EmptyCart_AddPromoCode_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				
				String strResponseCart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseCart);
				Utilities.setTestData(strResponseCart, "$.payload.cart.cartID", "OAPICART_ID");
				
				// Update cart through Adapter
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]},\"kohlsCash\":{\"voucher\":["						
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
		
				String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);

				
		validator = new ResponseValidator(strResponseAddCart);
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.error.code", "CART9912", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.error.message", "The promo code(s) cannot be saved on an empty shopping bag.", "Given Promocode message should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.error.code","CART9910", "Given KohlsCash should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.error.message","The Kohl's cash cannot be saved in an empty shopping bag.","KC error messageshould be there");		
		
//		validator.validateNoErrors();
		
//		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode5")+".*", "Given Promocode should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
//			
//		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
//		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
//		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
//		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");


	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Removing promocode from cart with action=remove",
			description = "As a Kohl's user verify in adapter remove one promocode along with add another promocode from the cart which already persist with 4 promocode and in response verify whether the promocode is deleted and replaced with another promocode")
	public void RemovePromoCode_AddPromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";
		
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");				
//				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
//				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
//				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
//				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				
				
				String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode5")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
//		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

	}
		@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Add_Promo_Kohlscash_Item Action Add",
			description = "As a Kohl's user verify in adapter add promocode along with item to the cart and in response verify whether promocode and items are returned")
	public void Add_Promo_Kohlscash_Item() {
		
		String arr[]=TestData.createKohlsCash(10);
	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"action\": \"merge\", \"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\"}"
						+ "]},\"kohlsCash\":{\"voucher\":["						
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");		
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Add_Promo_Kohlscash_Remove_Item Action Add",
			description = "As a Kohl's user verify in adapter add promocode along with removing item to the cart and in response verify whether promocode and items are returned")
	public void Add_Promo_Kohlscash_Remove_Item() {
		
		String arr[]=TestData.createKohlsCash(10);
//		String arr1[]=TestData.createKohlsCash(10);
//		String arr2[]=TestData.createKohlsCash(10);
//		String arr3[]=TestData.createKohlsCash(10);
//		String arr4[]=TestData.createKohlsCash(10);
//		String arr5[]=TestData.createKohlsCash(10);
//		String arr6[]=TestData.createKohlsCash(10);
//		String arr7[]=TestData.createKohlsCash(10);
//		String arr8[]=TestData.createKohlsCash(10);
//		String arr9[]=TestData.createKohlsCash(10);
//		String arr10[]=TestData.createKohlsCash(10);
	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "," + JsonString.getCartJson("VALID_ADD", testData.get("SKU_OFFERS"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID");
				
				validator.nodeMatches("$.payload.cart.cartItems[*].skuCode", ".*"+ testData.get("SKU_NORMAL")+".*", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[*].skuCode", ".*"+ testData.get("SKU_OFFERS")+".*", "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"action\": \"merge\", \"cartItems\" :["
						+ JsonString.getCartJson("VALID_REMOVE", testData.get("SKU_NORMAL"),"0")
						+ ",\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID") + "\"}],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}"
						+ "]},\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
		
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_OFFERS"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Max_Promo_KohlsCash_Negative Action Add",
			description = "As a Kohl's user verify in adapter add 2 promocode and 2 kohlsCash to the cart which already having 3 promocodes and 2 kohlsCash in the cart and in response verify whether error details are returned")
	public void Max_Promo_KohlsCash_Negative() {
		
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
//		String arr2[]=TestData.createKohlsCash(10);
//		String arr3[]=TestData.createKohlsCash(10);
//		String arr4[]=TestData.createKohlsCash(10);
//		String arr5[]=TestData.createKohlsCash(10);
//		String arr6[]=TestData.createKohlsCash(10);
		String arr7[]=TestData.createKohlsCash(10);
		String arr8[]=TestData.createKohlsCash(10);
//		String arr9[]=TestData.createKohlsCash(10);
		String arr10[]=TestData.createKohlsCash(10);
	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
									+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
									+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]},\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
//									+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"},"
//									+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
//									+"{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"},"
//									+"{\"kohlsCashNum\":\""+arr4[0]+"\",\"pin\":\""+arr4[1]+"\",\"action\":\"add\"},"
//									+"{\"kohlsCashNum\":\""+arr5[0]+"\",\"pin\":\""+arr5[1]+"\",\"action\":\"add\"},"
//									+"{\"kohlsCashNum\":\""+arr6[0]+"\",\"pin\":\""+arr6[1]+"\",\"action\":\"add\"},"
									+"{\"kohlsCashNum\":\""+arr7[0]+"\",\"pin\":\""+arr7[1]+"\",\"action\":\"add\"}"+"]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]},\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr8[0]+"\",\"pin\":\""+arr8[1]+"\",\"action\":\"add\"},"
//						+"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"add\"},"
						+"{\"kohlsCashNum\":\""+arr10[0]+"\",\"pin\":\""+arr10[1]+"\",\"action\":\"add\"}"+"]}}}}}";
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given kohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
	//	validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".* arr1[0].*", "Given KohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr2[0], "Given KohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr3[0], "Given KohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr4[0], "Given KohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr5[0], "Given KohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr6[0], "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr7[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr8[0]+".*", "Given KohlsCash should be present in the response");
//		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", arr9[0], "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr10[0]+".*", "Given KohlsCash should be present in the response");
		
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].error.code", "CART9131", "Error Code should be displayed in response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].error.message", "We're sorry, but you have reached the maximum number of Kohls.com Promo Codes accepted per order. We are only able to accept 4 Promo Code (s) per order. Please place your order or remove one of the Promo Codes if you would like to apply a different Promo Code.", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].error.code", "CART9909", "Error Code should be displayed in response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].error.message", "Orders are limited to 3 Kohl's Cash. To create space for another, consider removing atleast one of the existing Kohl's Cash.", "Error message should be present in the response");
		
		
//		Have to add error
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Merge_PromoCode Action Merge",
			description = "As a Kohl's user verify in adapter merge single promocode to the cart and in response verify promocode is returned")
	public void Merge_PromoCode() {	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"action\": \"merge\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\"}]}}}}}";
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Merge_KohlsCash Action Merge",
			description = "As a Kohl's user verify in adapter merge single kohlsCash to the cart and in response verify kohlsCash is returned")
	public void Merge_KohlsCash() {
		
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				
				validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\"}"+"]}}}}}";
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1"  , "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with Merge_Multiple_PromoCode_KohlsCash Action Merge",
			description = "As a Kohl's user verify in adapter merge multiple promocode and kohlsCash to the cart and in response verify whether the promocode and kohlsCash details are returned")
	public void Merge_Multiple_PromoCode_KohlsCash() {
		
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]},\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"action\": \"merge\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\"}]},\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\"}"+"]}}}}}";
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1"  , "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with Merge_Positive Action Merge",
			description = "As a Kohl's user verify in adapter merge 1 promocode and 2 kohlsCash to the cart which already having 3 promocodes and 8 kohlsCash in the cart and in response verify whether promocode and kohlsCash details are merged")
	public void Merge_Positive() {
		
		String kohlsCash[] = TestData.createKohlsCash(10,kohlsCashLim-1);
		String kohlsCash1[] = TestData.createKohlsCash(10,1); 
		String promoCodes[] = {testData.get("OCB_Promocode"),testData.get("OCB_Promocode1"),testData.get("OCB_Promocode2")};
		String promoCodes1[] = {testData.get("OCB_Promocode4"),testData.get("OCB_Promocode3")};
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
						
				String strPayloadAddCart = Utilities.PayloadPaymentSkuTypetoCart(kohlsCash, promoCodes, testData.get("SKU_NORMAL"), "1", "add");
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.validatePaymentCart(promoCodes, kohlsCash);
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
				String strPayloadAddCart1 =  Utilities.PayloadPaymentTypetoCart(kohlsCash1, promoCodes1, "merge");
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validatePaymentCart(promoCodes1, kohlsCash1);
		validator.validatePaymentCart(null, kohlsCash);
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Merge_Positive_Max Action Merge",
			description = "As a Kohl's user verify in adapter merge 2 promocode and 2 kohlsCash to the cart which already having 4 promocodes and 10 kohlsCash in the cart and in response verify whether promocode and kohlsCash details are removed automatically from the cart")
	public void Merge_Positive_Max() {
		
		String kohlsCash[] = TestData.createKohlsCash(10,kohlsCashLim);
		String kohlsCash1[] = TestData.createKohlsCash(10,1); 
		String promoCode[] = {testData.get("OCB_Promocode"),testData.get("OCB_Promocode1"),testData.get("OCB_Promocode2"),testData.get("OCB_Promocode3")};
		String promoCodes1[] = {testData.get("OCB_Promocode4"),testData.get("OCB_Promocode5")};
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = Utilities.PayloadPaymentSkuTypetoCart(kohlsCash, promoCode, testData.get("SKU_NORMAL"), "1", "add");
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				
				validator.validatePaymentCart(promoCode, kohlsCash);
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = Utilities.PayloadPaymentTypetoCart(kohlsCash1, promoCodes1, "merge");
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validatePaymentCart(promoCodes1, kohlsCash1);
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Merge_Positive_Exceeds Action Merge",
			description = "As a Kohl's user verify in adapter merge 2 promocode and 2 kohlsCash to the cart which already having 3 promocodes and 9 kohlsCash in the cart and in response verify whether promocode and kohlsCash details are removed automatically from the cart")
	public void Merge_Positive_Exceeds() {
		
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		String arr2[]=TestData.createKohlsCash(10);
		String arr3[]=TestData.createKohlsCash(10);
		String kohlsCash[] = TestData.createKohlsCash(10,kohlsCashLim-1);
		String kohlsCash1[] = TestData.createKohlsCash(10,2); 
		String promoCode[] = {testData.get("OCB_Promocode"),testData.get("OCB_Promocode1"),testData.get("OCB_Promocode2")};
		String promoCodes1[] = {testData.get("OCB_Promocode4"),testData.get("OCB_Promocode3")};
		
	

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = Utilities.PayloadPaymentSkuTypetoCart(kohlsCash, promoCode,testData.get("SKU_NORMAL"), "1", "add");
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.validatePaymentCart(promoCode, kohlsCash);
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));				// Update cart through Adapter
		
				String strPayloadAddCart1 = Utilities.PayloadPaymentTypetoCart(kohlsCash1, promoCodes1, "merge");
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validatePaymentCart(promoCodes1, kohlsCash1);
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}

	
	
/*Discontinued TestCases*/
	
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with Endless Aisle PromoCode Action Add",
			description = "Verify whether user able to add channel based Endless Aisle PromoCode to the cart with channel=endless_Aisle")
	public void EndlessAislePromoCode() {

		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_channelpromo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelpromo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_channelpromo");
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_channelpromo");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_channelpromo");
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelpromo"));
						
				// Updating single PromoCode to the cart through Adapter
						String strURL = CART_ADAPTER +"?channel=endless_Aisle";
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_channelpromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("Endless_Aisle")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(strURL, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("Endless_Aisle"), "Given Promocode should be present in the response");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Eboutique PromoCode Action Add",
			description = "Verify whether user able to add channel based Eboutique PromoCode to the cart with channel=Eboutique")
	public void EboutiquePromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_EboutiquePromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_EboutiquePromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_EboutiquePromo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_EboutiquePromo"));
				
		// Updating single PromoCode to the cart through Adapter
				String strURL = CART_ADAPTER +"?channel=Eboutique";
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("Eboutique")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(strURL, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("Eboutique"), "Given Promocode should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with channelX PromoCode Action Add",
			description = "Verify whether user able to add channel based channelX PromoCode to the cart with channel=channelX")
	public void ChannelXpromoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_channelXPromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelXPromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_channelXPromo");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelXPromo"));
				
		// Updating single PromoCode to the cart through Adapter
				String strURL = CART_ADAPTER +"?channel=channelx";
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("ChannelX")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(strURL, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("ChannelX"), "Given Promocode should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with channelY PromoCode Action Add",
			description = "Verify whether user able to add channel based channelY PromoCode to the cart with channel=channelY")
	public void ChannelYpromoCode() {

		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_channelYPromo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelYPromo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_channelYPromo");
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelYPromo"));
						
				// Updating single PromoCode to the cart through Adapter
						
						String strURL = CART_ADAPTER +"?channel=channely";
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("ChannelY")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(strURL, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("ChannelY"), "Given Promocode should be present in the response");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "AddPromoCodeInChannelX_RemovePromoCodeInChannelY",
			description = "As a Kohl's user verify in adapter remove promocode from the cart which is added from different channel and in response verify whether promocode is removed.")
	public void AddPromoCodeInChannelX_RemovePromoCodeInChannelY() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						
				String strURL1 = CART_ADAPTER +"?channel=channelx";
				
				// Update cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";
		
				String strResponseAddCart1 = RestCall.postRequest(strURL1, strPayloadAddCart1, Server.Adapter, true, mapheader);

				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				
				String strURL2 = CART_ADAPTER +"?channel=channely";
				
				String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"remove\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(strURL2, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes", "{promoCode=[]}", "Promocode should not present in the response");
			
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");


	}

	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Removing Multiple promocode and kohlsCash from cart with action=remove",
			description = "As a Kohl's user verify in adapter remove multiple promocode and kohlsCash (contains some Invalid PromoCode/KohlsCash in request which is does not match with existing Cart items) from the cart and in response verify whether multiple promocode and kohlsCash is removed.")
	public void RemoveMultiplePromoCodeAndKohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		String arr2[]=TestData.createKohlsCash(10);
		String arr3[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]},\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";
		
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);

				String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"remove\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode5")+"\",\"action\":\"remove\"}]},\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"remove\"},"
										+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"remove\"}"+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart2);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr1[0], "Given kohlsCash should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Removed kohlsCash should not present in the response");
		
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");


	}

	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = false, priority = 2, testName = "Update Cart with Future begin date PromoCode Action Add",
			description = "Verify whether user able to get proper error code (CART2002) & message when we are trying to add Future begin date PromoCode to the cart")
	public void futureBeginDatePromocode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_FuturePromo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_FuturePromo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_FuturePromo");
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_FuturePromo"));
						
				// Updating single PromoCode to the cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("FuturePromo")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.validateExpectedErrors("CART2002", "The promoCode provided is currently not active.");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		
	}

	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Endless Aisle PromoCode Action Add",
			description = "Verify whether user able to add channel based Endless Aisle PromoCode to the cart with channel=endless_Aisle")
	public void MultiChannelPromoCode() {

		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multichannelpromo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multichannelpromo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multichannelpromo");
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multichannelpromo");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multichannelpromo");
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multichannelpromo"));
						
				// Updating single PromoCode to the cart through Adapter
						String strURL = CART_ADAPTER +"?channel=endless_Aisle";
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multichannelpromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("Endless_Aisle")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(strURL, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("Endless_Aisle"), "Given Promocode should be present in the response");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			}

	@DiscontinuedTest(groups = { "ocbphase2", "regression1"  , "regression1"  }, enabled = true, priority = 2, testName = "Update Cart with channel based PromoCode Action Add",
			description = "Verify whether user able to get proper error code (CART9911) & message when we are trying to add channel based PromoCode with channel=mobile")
	public void InvalidChannelPromoCode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_ChannelPromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_ChannelPromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		

// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_ChannelPromo");
		
		//Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_ChannelPromo"));
		
// Updating single PromoCode to the cart through Adapter
		
		String strURL = CART_ADAPTER +"?channel=channely";

String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("Endless_Aisle")+"\",\"action\":\"add\"}]}}}}}";

// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
String strResponseAddCart1 = RestCall.postRequest(strURL, strPayloadAddCart1, Server.Adapter, true, mapheader);
validator = new ResponseValidator(strResponseAddCart1);
validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
validator.validateExpectedErrors("CART9911", "The Promo Code you entered cannot be applied on the channely.");

//Validating CartItem Details 
validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

}

	@Test(groups = { "OMP-48"}, enabled = true, priority = 2, testName = "Update Cart with single promocode Action Add",
			description = "Verify whether user able to add single promocode to the cart")
	public void SystemIntiatedPromo_KillSwitchFalse() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_systemIntiated");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_systemIntiated"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_systemIntiated");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_systemIntiated");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_systemIntiated");
				
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_systemIntiated"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_systemIntiated")
		+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeNotEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", null, "System Intiated should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	
	//ocb phase 2 wallet
	
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Morethan 3 KohlsCash Action Add",
			description = "Verify whether user able to get proper error code (CART2001) & message in response when we are trying to add morethan 3 KohlsCash")
	public void OC_MoreThanThreeKohlsCash_Wallet() {
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		String arr9[]=TestData.createKohlsCash(10);
		String arr10[]=TestData.createKohlsCash(10);
		
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		
		String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
				+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"},"
                +"{\"kohlsCashNum\":\""+arr9[0]+"\",\"pin\":\""+arr9[1]+"\",\"action\":\"add\"},"
				+"{\"kohlsCashNum\":\""+arr10[0]+"\",\"pin\":\""+arr10[1]+"\",\"action\":\"add\"}"+"]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART2001", "Too many Kohl's Cash supplied.");
		
		//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				validator = new ResponseValidator(strResponsewallet);
				validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr9[0]+".*", "Given kohlscash should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr10[0]+".*", "Given kohlscash should be present in the response");
	}	
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "Update Cart with Morethan 3 KohlsCash Action Add",
			description = "Verify whether user able to get proper error code (CART2001) & message in response when we are trying to add morethan 3 KohlsCash")
	public void OC_MoreThanFourPromo_Wallet() {
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		
		String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{"
				+ "\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
				+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
				+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
				+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\",\"action\":\"add\"},"
				+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.validateExpectedErrors("CART2001", "Too many promo codes supplied.");
		
		//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				validator = new ResponseValidator(strResponsewallet);
				validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
	}	

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add multiple KohlsCash to wallet")
	
	public void OC_UpdateCartKohlsCash_Wallet() {
		
		//Creating KohlsCash 
				String arr[]=TestData.createKohlsCash(10);
				String arr1[]=TestData.createKohlsCash(10);
				String arr2[]=TestData.createKohlsCash(10);
				String arr3[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
								"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
											+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
													+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"
													+ "]}}}}}";
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

				
				String strPayloadAddCart2 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
						"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\",\"action\":\"add\"},"
											+ "{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\",\"action\":\"add\"}"
											+ "]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart2 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart2, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart2);
				validator.validateExpectedErrors("CART9909", "Orders are limited to 3 Kohl's Cash. To create space for another, consider removing atleast one of the existing Kohl's Cash.");
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr3[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr3[0]+".*", "Given kohlscash should be present in the response");
		
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Expired kohlsCash to wallet")
	
	public void OC_ExpiredKohlsCash_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
								"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
											+"{\"kohlsCashNum\":\""+ testData.get("OCB_EXPIRED_KOHLS_CASH")+"\",\"pin\":\""+testData.get("OCB_EXPIRED_KC_PIN")+"\",\"action\":\"add\"}"
													+ "]}}}}}";
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateExpectedErrors("CART9908", "We're sorry! You cannot use your Kohl's Cash to complete this order. Please check the redeem dates.");
				
		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeNotEquals("$.currentWalletItems[*].id", ".*"+testData.get("OCB_EXPIRED_KOHLS_CASH")+".*", "Expired KohlsCash should not be added to the Wallet.");
		
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// GetCart response from OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Redeemed kohlsCash to wallet")
	
	public void OC_RedeemedKohlsCash_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
								"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
											+"{\"kohlsCashNum\":\""+ testData.get("OCB_REDEEMED_KOHLS_CASH")+"\",\"pin\":\""+testData.get("OCB_REDEEMED_KC_PIN")+"\",\"action\":\"add\"}"
													+ "]}}}}}";
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateExpectedErrors("CART9012", "We're sorry, the Kohl's Cash or Rewards Number you entered has no remaining balance. Please check the number and try again.");
				
		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+testData.get("OCB_REDEEMED_KOHLS_CASH")+".*", "Expired KohlsCash should not be added to the Wallet.");
		
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// GetCart response from OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Pending kohlsCash to wallet")
	
	public void OC_PendingKohlsCash_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
								"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
											+"{\"kohlsCashNum\":\""+ testData.get("OCB_FUTURE_KOHLS_CASH")+"\",\"pin\":\""+testData.get("OCB_FUTURE_KC_PIN")+"\",\"action\":\"add\"}"
													+ "]}}}}}";
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateExpectedErrors("CART9908", "We're sorry! You cannot use your Kohl's Cash to complete this order. Please check the redeem dates.");
				
		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeNotEquals("$.currentWalletItems[*].id", ".*"+testData.get("OCB_FUTURE_KOHLS_CASH")+".*", "Pending KohlsCash should not be added to Wallet");
		
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// GetCart response from OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Expired PromoCode to wallet")
	
	public void OC_ExpiredPromocode() {
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				
				// Update cart through Adapter
				mapheader.clear();
				mapheader.put("Wallet_token", testData.get("walletToken"));
				mapheader.put("X-Wallet-Id", testData.get("walletId"));
				mapheader.put("X-Add-To-Wallet", "true");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				mapheader.put("Accept", "application/json");
				
				// Updating single PromoCode to the cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\","
						+ "\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("Expired2")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.validateExpectedErrors("CART9121", "We're sorry, but the Promo Code you entered has expired. Please check the offer for details.");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				
				
				//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				validator = new ResponseValidator(strResponsewallet);
				validator.nodeNotEquals("$.currentWalletItems[*].promoCode", ".*"+testData.get("Expired2")+".*", "Expired Promo should not be added to Wallet");
				
	}

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Future PromoCode to wallet")
	
	public void OC_FuturePromocode() {
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				
				// Update cart through Adapter
				mapheader.clear();
				mapheader.put("Wallet_token", testData.get("walletToken"));
				mapheader.put("X-Wallet-Id", testData.get("walletId"));
				mapheader.put("X-Add-To-Wallet", "true");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				mapheader.put("Accept", "application/json");
				
				// Updating single PromoCode to the cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\","
						+ "\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("FuturePromo")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				//validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.validateExpectedErrors("CART9121", "We're sorry, but the Promo Code you entered is not currently valid.  Please double-check the offer dates, and try again.");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				
				
				//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				validator = new ResponseValidator(strResponsewallet);
				validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("FuturePromo")+".*", "Future Promo should be added to Wallet");
				
	}

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Future PromoCode to wallet")
	
	public void OC_PromocodeWithoutOptionlaHeadersXWalletID() {
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				
				// Update cart through Adapter
				mapheader.clear();
				mapheader.put("Wallet_token", testData.get("walletToken"));
				//mapheader.put("X-Wallet-Id", testData.get("walletId"));
				mapheader.put("X-Add-To-Wallet", "true");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				mapheader.put("Accept", "application/json");
				
				// Updating single PromoCode to the cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\","
						+ "\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
								
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				
				//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				strResponsewallet.toString();
				Assert.assertTrue(!strResponsewallet.matches(".*"+testData.get("OCB_Promocode")+".*"),"Expected : '" +testData.get("OCB_Promocode")+ " should not be added to wallet'... Actual : '" + testData.get("OCB_Promocode") + " found in wallet'");
	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Future PromoCode to wallet")
	
	public void OC_PromocodeWithoutOptionlaHeadersXWalletToken() {
		
		String arr[]=TestData.createKohlsCash(10);
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				
				// Update cart through Adapter
				mapheader.clear();
				//mapheader.put("Wallet_token", testData.get("walletToken"));
				mapheader.put("X-Wallet-Id", testData.get("walletId"));
				mapheader.put("X-Add-To-Wallet", "true");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				mapheader.put("Accept", "application/json");
				
				// Updating single PromoCode to the cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}"+"]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
								
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				
				//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				strResponsewallet.toString();
				Assert.assertTrue(!strResponsewallet.matches(".*"+arr[0]+".*"),"Expected : 'KohlsCash " +arr[0]+ " should not be added to wallet'... Actual : ' KohlsCash " + arr[0] + " found in wallet'");
	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Future PromoCode to wallet")
	
	public void OC_PromocodeWithoutOptionlaHeadersXAddToWallet() {
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				
				// Update cart through Adapter
				mapheader.clear();
				mapheader.put("Wallet_token", testData.get("walletToken"));
				mapheader.put("X-Wallet-Id", testData.get("walletId"));
				//mapheader.put("X-Add-To-Wallet", "true");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				mapheader.put("Accept", "application/json");
				
				// Updating single PromoCode to the cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\","
						+ "\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
								
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				
				//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				strResponsewallet.toString();
				Assert.assertTrue(!strResponsewallet.matches(".*"+testData.get("OCB_Promocode")+".*"),"Expected : '" +testData.get("OCB_Promocode")+ " should not be added to wallet'... Actual : '" + testData.get("OCB_Promocode") + " found in wallet'");
	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB Cart with multiple KohlsCash",
			description = "Verify whether User is able to do add Future PromoCode to wallet")
	
	public void OC_PromocodeWithoutOptionlaHeadersXWalletIDFalse() {
		
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				
				// Update cart through Adapter
				mapheader.clear();
				mapheader.put("Wallet_token", testData.get("walletToken"));
				mapheader.put("X-Wallet-Id", testData.get("walletId"));
				mapheader.put("X-Add-To-Wallet", "false");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
				mapheader.put("Accept", "application/json");
				
				// Updating single PromoCode to the cart through Adapter
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\","
						+ "\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
								
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				
				//get wallet and see promocode
				String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

				// Get wallet response
				mapheader.clear();
				mapheader.put("token", testData.get("walletToken"));
				
				String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
				
				strResponsewallet.toString();
				Assert.assertTrue(!strResponsewallet.matches(".*"+testData.get("OCB_Promocode")+".*"),"Expected : '" +testData.get("OCB_Promocode")+ " should not be added to wallet'... Actual : '" + testData.get("OCB_Promocode") + " found in wallet'");
	}
}
