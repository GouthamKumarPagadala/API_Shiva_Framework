package test.java.adapters.cart.ocbphase2;
import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.util.HashMap;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Cart")
@Stories({ "Get Cart" })
public class GetCart 
{
	
	ResponseValidator validator;
	
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with single promocode Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",
			description = "Verify whether user able to get single promocode from cart")
	public void SinglePromocode() throws Exception {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			Thread.sleep(180000);
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with multiple promocode Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.MultiplePromoCodes",
			description = "Verify whether user able to get single promocode from cart")
	public void MultiplePromoCodes() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");	
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with supc promocode Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SUPCPromocode",
			description = "Verify whether user able to get single promocode from cart")
	public void SUPCpromocode() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_supcpromo"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("SUPC6"), "Given Promocode should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_supcpromo"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
		@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with single kohlscash Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SingleKohlsCash",
			description = "Verify whether user able to get single promocode from cart")
	public void SingleKohlsCash() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", testData.get("kohlscash_single"), "Given KohlsCash should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with multiple kohlscash Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.MultipleKohlsCash",
			description = "Verify whether user able to get single promocode from cart")
	public void MultipleKohlsCash() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplekohlscash"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ testData.get("kohlscash_multiple")+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ testData.get("kohlscash_multiple1")+".*", "Given kohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ testData.get("kohlscash_multiple9")+".*", "Given kohlsCash should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplekohlscash"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with single promokohlscash Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.promoKohlsCash",
			description = "Verify whether user able to get single promocode from cart")
	public void promoKohlsCash() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromokohlscash"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", testData.get("kohlscash_promokc"), "Given KohlsCash should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromokohlscash"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with multiple promokohlscash Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.multiPromoCodeKohlsCash",
			description = "Verify whether user able to get single promocode from cart")
	public void multiPromoCodeKohlsCash() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromokohlscash"));
		
		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ testData.get("kohlscash_multipromokc")+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ testData.get("kohlscash_multipromokc1")+".*", "Given KohlsCash should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromokohlscash"));
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	
	
	
	/*Discontinued TestCases*/
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with Endlessaisle promocode Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.EndlessAislePromoCode",
			description = "Verify whether user able to get single promocode from cart with different channel")
	public void multiChannelPomoCode() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multichannelpromo"));
	
		String strURL = CART_ADAPTER +"?channel=channelx";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode","[]", "Given Promocode should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multichannelpromo"));
			String strUrloapi = CART_OAPI +"?channel=channelx";
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strUrloapi, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multichannelpromo"));
	
		String strURL1 = CART_ADAPTER +"?channel=endless_Aisle";
		String strResponse1 = RestCall.getRequest(strURL1, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode","[]", "Given Promocode should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multichannelpromo"));
			String strUrloapi1 = CART_OAPI +"?channel=endless_Aisle";
			
			// Get the request
			String strResponseOAPI1 = RestCall.getRequest(strUrloapi1, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse1, strResponseOAPI1, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
		
	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "GetCart with Endlessaisle promocode Action Add",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.EndlessAislePromoCode",
			description = "Verify whether user able to get single promocode from cart")
	public void EndlessAislePromoCode() {
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelpromo"));
	
		String strURL = CART_ADAPTER +"?channel=endless_Aisle";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("Endless_Aisle"), "Given Promocode should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelpromo"));
			String strUrloapi=CART_OAPI+"?channel=endless_Aisle";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strUrloapi, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
}
	
}