package test.java.adapters.cart;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.strGroup;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Features("Cart")
@Stories({ "Update Cart" })
public class UpdateCart {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Adds a new item to the cart with empty qty value")
	public void EmptyQtyValue() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CART1000", "Missing Required Parameter Qty.");
		// validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Adds a new item to the cart with skucode not found")
	public void SKUNotFound() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NOT_FOUND"), "1")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.cart.cartItems[*].skuCode",".*"+ testData.get("SKU_NOT_FOUND")+".*", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[*].error.code", ".*CART3000.*", "CART3000 error code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[*].error.message", ".*[SKU (" + testData.get("SKU_NOT_FOUND")+ ") not found.].*", "SKU NOt Found error message should be present in the response");
		
		// Compare Open AP
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Adds a new item to the cart with zero qty value")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("KOP-437") })
	public void ZeroQtyValue() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "0")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CART1002", "invalid value passed for qty.");
		// validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		// err_cart_invalid_quantity
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Adds a new item to the cart with invalid action")
	public void InvalidValueForAction() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("CART_INVALID_ACTION", testData.get("SKU_NORMAL"), "3")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.cart.cartItems[*].skuCode", ".*"+testData.get("SKU_NORMAL")+".*", "Given Sku code should be present in the response");
		// validator.validateExpectedErrors("CART1002", "Invalid value passed for Action.");
		validator.nodeMatches("$.payload.cart.cartItems[*].error.code", ".*CART1002.*", "CART1002 error code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[*].error.message", ".*Invalid value passed for Action..*", "Invalid value passed for Action error message should be present in the response");

		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 2, testName = "Update Cart", 
			description = "Updating the qty for existing cart Item")
	public void ActionAsUpdateWithQty() {
//		
		TestData.getRunTimeData("SKU_CODE", false);
		String strEmail = Utilities.getNewEmailID();
		Utilities.createProfile(strEmail,"Qwerty@123", Server.Adapter);
		Utilities.signInProfile(strEmail,"Qwerty@123", Server.Adapter, "access_token_adapter_REG");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter_REG"));
		
		String strPayload1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("RUNTIME_SKU_CODE"), "3")
				+ "]}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(CART_ADAPTER, strPayload1, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponse1, "$.payload.cart.cartItems[0].cartItemID", "CART_ITEM_ID");
		Utilities.setTestData(strResponse1, "$.payload.cart.cartID", "CART_ID");

		
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartID\": \""
				+ testData.get("CART_ID")
				+ "\",\"cartItems\" :["
				+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("CART_ITEM_ID"), testData.get("RUNTIME_SKU_CODE"), "4")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "4", "Updated qty should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			
			Utilities.createProfile(testData.get("OAPI_EMAIL_ID_REG"),testData.get("OAPI_EMAIL_PSWD_REG"), Server.OpenApi);
			Utilities.signInProfile(testData.get("OAPI_EMAIL_ID_REG"),testData.get("OAPI_EMAIL_PSWD_REG"), Server.OpenApi, "access_token_oapi_REG");
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_oapi_REG"));
			
			

			// Post the request
			String strResponseOapi1 = RestCall.postRequest(CART_OAPI, strPayload1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOapi1, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseOapi1, "$.payload.cart.cartID", "OAPICART_ID");
			
			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"cart\":{\"cartID\": \""
					+ testData.get("OAPICART_ID")
					+ "\",\"cartItems\" :["
					+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("OAPI_CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
					+ "]}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayloadOAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateCart",
			description = "Updating the qty for existing cart Item")

	public void ActionAsUpdateWithEmptyCartID() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartID\": \"\",\"cartItems\" :["
				+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("OAPI_CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.error.code", "CART1000", "CART1000 error code should be present in the response");
		validator.nodeEquals("$.payload.cart.error.message", "Missing Required Parameter cartID.", "Missing Required Parameter cartID error message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"cart\":{\"cartID\": \"\",\"cartItems\" :["
					+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("OAPI_CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
					+ "]}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating cart with Invalid access token")
	public void InvalidAccessToken() {

		mapheader.put("access_token", "8mQvasdfglaiPGEZSeqyUBuGBhwH");
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartID\": \""
				+ testData.get("CART_ID")
				+ "\",\"cartItems\" :["
				+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
				+ "]}}}";

		// Post the request
		// String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader, 200);
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "8mQvasdfglaiPGEZSeqyUBuGBhwH");
			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"cart\":{\"cartID\": \"\",\"cartItems\" :["
					+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("OAPI_CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
					+ "]}}}";
			// Post the request

			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating with expired access token")
	public void ExpiredAccessToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartID\": \""
				+ testData.get("CART_ID")
				+ "\",\"cartItems\" :["
				+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
				+ "]}}}";

		// Post the request

		// String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.ExpiredAccessToken, true);
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"cart\":{\"cartID\": \"\",\"cartItems\" :["
					+ JsonString.getOCBCartJson("UPDATE_ACTION", testData.get("OAPI_CART_ITEM_ID"), testData.get("SKU_NORMAL"), "4")
					+ "]}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity,fault.fault", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating with expired access token")
	public void EmptyAction() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartID\": \"\",\"cartItems\" :["
				+ JsonString.getCartJson("EMPTY_ACTION", testData.get("SKU_NORMAL"), "4")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.cart.cartItems[*].skuCode",".*"+ testData.get("SKU_NORMAL")+".*", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[*].error.code", ".*CART1002.*", "CART1002 error code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[*].error.message", ".*Invalid value passed for Action..*", "Invalid value passed for Action error message should be present in the response");

		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID", true);
		}
	}
}