package test.java.adapters.store.geofence;

import static main.java.common.GlobalVariables.GEOFENCE_STORES_ADAPTERS;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.Utilities;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("geofence")
@Stories({ "GetAll stores" })
public class getAllStores {
	
	ResponseValidator validator;
	@Test(groups = { "regression","functional", "geofence", "errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - All Stores",
			
			description = "Verify whether all the stores in the quadrants are getting displayed & Verify whether the added stores in the quadrants are getting displayed in the response")
	public void getAllStoresInQuadrants() {

		// Post the request
		String strResponse = RestCall.getRequest(GEOFENCE_STORES_ADAPTERS, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateResponseHeaders("EXPIRES_GT_CURRENT_DATE", "Expires header date should be greter than current date");
		validator.validateStoreLatLong("Validate each store is within the lat/long quadrants");
		
		//delete store if already exist
		
	}
	
	/*@Test(groups = { "regression","functional", "geofence" }, enabled = true, priority = 7, testName = "GeoFence - Deleted Store Removed",
			dependsOnMethods="test.java.adapters.store.geofence.deleteStores.deleteStoreGeoFence",
			description = "Verify whether the deleted stores in the quadrants are getting removed in the response")
	public void verifyDeletedStore() {
		// Post the request
		String strResponse = RestCall.getRequest(GEOFENCE_STORES_ADAPTERS, Server.Adapter, false);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray quadrants = JsonPath.read(strResponse, "$.quadrants");
		int strSize=quadrants.size();
		Assert.assertEquals(strSize, 20);
		JSONArray storeIds = JsonPath.read(strResponse, "$..id");
		
		for(int i=0;i<strSize;i++)
		{
			validator.nodeMatches("$.quadrants["+i+"].leftLat", ".+", "Left latitude for the quadrant should be displayed");
			validator.nodeMatches("$.quadrants["+i+"].leftLon", ".+", "Left longitude for the quadrant should be displayed");
			validator.nodeMatches("$.quadrants["+i+"].rightLat", ".+", "Right latitude for the quadrant should be displayed");
			validator.nodeMatches("$.quadrants["+i+"].rightLon", ".+", "Right longitude for the quadrant should be displayed");
		}
		
		for(int i=0;i<storeIds.size();i++)
		{
			String storeNum = (String) storeIds.get(i);
			Assert.assertNotEquals(storeNum, testData.get("GEO_STORE_NUM"));
			
		}
		
		
	}*/
	
	@DiscontinuedTest(groups = { "regression","functional", "geofence","errorhandling" }, enabled = false, priority = 2, testName = "GeoFence - Deleting Stores - Invalid Url For Delete Stores",
			description = "Verify proper error message is getting displayed when we pass invalid url")
	public void invalidUrlForGetAllStore() {

		String strURL = GEOFENCE_STORES_ADAPTERS + testData.get("GEO_STORE_NUM");
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0002", "We encountered issue processing your request, please try again later");
		
			}

}
