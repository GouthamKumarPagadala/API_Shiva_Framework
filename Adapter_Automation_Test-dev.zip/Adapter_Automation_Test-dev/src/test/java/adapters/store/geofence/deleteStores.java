package test.java.adapters.store.geofence;

import static main.java.common.GlobalVariables.GEOFENCE_STORES_ADAPTERS;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import static main.java.common.TestData.mapheader;
@Features("geofence")
@Stories({ "Delete stores" })
public class deleteStores {
	
	ResponseValidator validator;
	
	//As per NAP-312 R17.7 requirement,Post and delete methods will not work with Locations API;Removed from regression suite.
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 5, testName = "GeoFence - Deleting Stores - Invalid Store Number ",
			description = "Verify whether a error message while passing invalid store in the request")
	public void invalidStoreNum() {

		String strURL = GEOFENCE_STORES_ADAPTERS+"/213fds";
		
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Invalid Store Number. ");
						
	}
	
	@DiscontinuedTest(groups = {"functional", "geofence","errorhandling" }, enabled = true, priority = 5, testName = "GeoFence - Deleting Stores - Store Already Deleted",
			dependsOnMethods="deleteStoreGeoFence",
			description = "Verify whether a error message while passing store which is already deleted in the request")
	public void storeNumAlreadyDeleted() {

		String strURL = GEOFENCE_STORES_ADAPTERS+"/1045";
		
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("missing_store", "Store doesnt exist. Cannot remove.");
						
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Deleting Stores - Invalid LocationAuth",
			description = "Verify proper error message is getting displayed when we pass invalid LocationAuth in the header")
	public void invalidLocationAuth() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		mapheader.put("LocationAuth", "adfaf123123213");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_auth", "Invalid authentication.");
		
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Deleting Stores - Missing LocationAuth",
			description = "Verify proper error message is getting displayed when we pass missing LocationAuth in the header")
	public void invalidMissingLocationAuth() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/545";
		
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("missing_auth", "Authentication is missing.");
		
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = false, priority = 2, testName = "GeoFence - Deleting Stores - Invalid Url For Delete Stores",
			description = "Verify proper error message is getting displayed when we pass invalid url")
	public void invalidUrlForDeleteStore() {

		String strURL = GEOFENCE_STORES_ADAPTERS + testData.get("GEO_STORE_NUM");
		
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0002", "We encountered issue processing your request, please try again later");
		
			}
	
	@DiscontinuedTest(groups = { "functional", "geofence", "errorhandling" }, enabled = true, priority = 5, testName = "GeoFence - Deleting Store",dependsOnMethods={"test.java.adapters.store.geofence.addStores.existingStore","test.java.adapters.store.geofence.getAllStores.getAllStoresInQuadrants"},
			description = "Verify whether a particular store can be added using Geo Coordinates")
	public void deleteStoreGeoFence() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false,202);
		System.out.println("Deleted" +strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		//validator.nodeEquals("$.message", "Deleted store "+testData.get("GEO_STORE_NUM")+" successfully.", "Stores Geo Co-ordintaes added to quadrant");
		
	}

}