package test.java.adapters.store.geofence;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.GEOFENCE_STORES_ADAPTERS;
import static main.java.common.GlobalVariables.STORESBYOPENSEARCH_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import test.java.adapters.Config;
import static main.java.common.TestData.mapheader;

@Features("geofence")
@Stories({ "Adding stores" })


public class addStores {
	
	@BeforeClass(alwaysRun=true)
	public void testSetup() {
		
		new TestData().createLocationAuth();
		
	}
	ResponseValidator validator;
	//As per NAP-312 R17.7 requirement,Post and delete methods will not work with Locations API;Removed from regression suite.
	@DiscontinuedTest(groups = { "functional", "geofence", "errorhandling" }, enabled = true, priority = 1, testName = "GeoFence - Adding Stores",
			dependsOnMethods="test.java.adapters.store.geofence.getAllStores.getAllStoresInQuadrants",
			description = "Verify whether a particular store can be added using Geo Coordinates")
	public void addStoreGeoFence() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\":\""+testData.get("GEO_LATITUDE")+"\", \"longitude\" : \""+testData.get("GEO_LONGITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.message", "Added store "+testData.get("GEO_STORE_NUM")+" successfully.", "Stores Geo Co-ordintaes added to quadrant");
		
	}
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 3, testName = "GeoFence - Existing Store",dependsOnMethods={"test.java.adapters.store.geofence.getAllStores.getAllStoresInQuadrants","addStoreGeoFence"},
			description = "Verify whether a particular store can be added using Geo Coordinates")
	public void existingStore() {
//		
		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\":\""+testData.get("STORE_LATITUDE")+"\", \"longitude\" : \""+testData.get("STORE_LONGITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateExpectedErrors("duplicate_store", "Store already exists. Cannot add again.");
		
	}
	
	
	@DiscontinuedTest(groups = {"functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Missing Latitude",
			description = "Verify proper error message is getting displayed by not passing latitude in the request")
	public void missingLatitude() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"longitude\" : \""+testData.get("GEO_LONGITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing mandatory input, Store latitude. ");
		
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Missing Longitude",
			description = "Verify proper error message is getting displayed by not passing longitude in the request")
	public void missingLongitude() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\" : \""+testData.get("GEO_LATITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing mandatory input, Store longitude. ");
		
		
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Invalid Param Latitude",
			description = "Verify proper error message is getting displayed when we pass invalid param latitude.")
	public void invalidParamLatitude() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"lattude\" : \""+testData.get("GEO_LATITUDE")+"\",\"longitude\":\""+testData.get("GEO_LONGITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing mandatory input, Store latitude. ");
				
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Invalid Param Longitude",
			description = "Verify proper error message is getting displayed when we pass invalid param longitude.")
	public void invalidParamLongitude() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\" : \""+testData.get("GEO_LATITUDE")+"\",\"longtude\":\""+testData.get("GEO_LONGITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing mandatory input, Store longitude. ");
		
	}

	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Invalid Value For Latitude",
			description = "Verify proper error message is getting displayed when we pass invalid value for latitude.")
	public void invalidValueForLatitude() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\" : \"abc123\",\"longitude\":\""+testData.get("GEO_LONGITUDE")+"\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "invalid store latitude. ");
		
		
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Invalid Value For Longitude",
			description = "Verify proper error message is getting displayed when we pass invalid value for longitude.")
	public void invalidValueForLongitude() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\" : \""+testData.get("GEO_LATITUDE")+"\",\"longitude\":\"abc123\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "invalid store longitude. ");
		
		// Compare Open API
		/*if (CompareOAPI) {
			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}*/
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = false, priority = 2, testName = "GeoFence - Adding Stores - Invalid Url For Add Stores",
			description = "Verify proper error message is getting displayed when we pass invalid url")
	public void invalidUrlForAddStore() {

		String strURL = GEOFENCE_STORES_ADAPTERS + testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\" : \""+testData.get("GEO_LATITUDE")+"\",\"longitude\":\"abc123\"}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0002", "We encountered issue processing your request, please try again later");
		
		// Compare Open API
		/*if (CompareOAPI) {
			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}*/
	}
	
	@DiscontinuedTest(groups = { "functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Invalid LocationAuth",
			description = "Verify proper error message is getting displayed when we pass invalid LocationAuth in the header")
	public void invalidValueForLocationAuth() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		String strPayload="{\"latitude\" : \""+testData.get("GEO_LATITUDE")+"\",\"longitude\":\""+testData.get("GEO_LONGITUDE")+"\"}";
		// Post the request
		mapheader.put("LocationAuth", "adfaf123123213");
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_auth", "Invalid authentication.");
		
	}
	
	@DiscontinuedTest(groups = {"functional", "geofence","errorhandling" }, enabled = true, priority = 2, testName = "GeoFence - Adding Stores - Missing LocationAuth",
			description = "Verify proper error message is getting displayed when we pass missing LocationAuth in the header")
	public void MissingLocationAuth() {

		String strURL = GEOFENCE_STORES_ADAPTERS +"/545";
		String strPayload="{\"latitude\" : \""+testData.get("GEO_LATITUDE")+"\",\"longitude\":\""+testData.get("GEO_LONGITUDE")+"\"}";
		
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("missing_auth", "Authentication is missing.");
		
	}

}