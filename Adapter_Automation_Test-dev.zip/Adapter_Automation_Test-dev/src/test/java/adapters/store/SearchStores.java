package test.java.adapters.store;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.STORESBYOPENSEARCH_ADAPTER;
import static main.java.common.GlobalVariables.STORESBYOPENSEARCH_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Store")
@Stories({ "Store Locator" })
public class SearchStores {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores PostalCode",
			description = "Checking the stores near by the radius and postalCode")
	public void postalCodeRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores StateCity",
			description = "Checking the stores near by the state and city")
	public void stateCityRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radius=25&state=" + testData.get("STORE_STATE") + "&city=" + testData.get("STORE_CITY");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radius=25&state=" + testData.get("STORE_STATE") + "&city=" + testData.get("STORE_CITY");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores LatitudeLongitudeRadius",
			description = "Checking the stores near by the radius latitude and longitude")
	public void longtitudeLatitudeRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25&latitude=" + testData.get("STORE_LATITUDE") + "&longitude=" + testData.get("STORE_LONGITUDE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25&latitude=" + testData.get("STORE_LATITUDE") + "&longitude=" + testData.get("STORE_LONGITUDE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores OpenSearch",
			description = "Checking the stores near by the open search")
	public void openSearchRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "53092&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "53092&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores Address",
			description = "Checking the stores near by the address")
	public void address() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "53092";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "53092";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores LangitudeLatitude",
			description = "Checking the stores near by the latitude and longitude")
	public void longitudeLatitude() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&latitude=" + testData.get("STORE_LATITUDE") + "&longitude=" + testData.get("STORE_LONGITUDE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&latitude=" + testData.get("STORE_LATITUDE") + "&longitude=" + testData.get("STORE_LONGITUDE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression1","functional" }, enabled = true, priority = 7, testName = "Stores LongitudeLatitudeZeroSearchResult",
			description = "Checking the stores near by the longitude latitude as zero")
	public void longitudeLatitudeZeroSearchResult() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&latitude=0&longitude=0";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.count", "0", "Count should be zero");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&latitude=0&longitude=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores AddressRadius",
			description = "Checking the stores near by the radius and address")
	public void addressRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "53092&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "53092&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 7, testName = "Stores MissingMandatoryLongitude",
			description = "Checking the stores near by without passing Longitude")
	public void missingMandatoryLongitude() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radius=25&latitude=" + testData.get("STORE_LATITUDE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("STORE1000", "Missing Required Parameter longitude.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radius=25&latitude=" + testData.get("STORE_LATITUDE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 7, testName = "Stores MissingMandatoryLatitude",
			description = "Checking the stores near by without passing Latitude")
	public void missingMandatoryLatitude() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radius=25&longitude=" + testData.get("STORE_LONGITUDE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("STORE1000", "Missing Required Parameter latitude.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radius=25&longitude=" + testData.get("STORE_LONGITUDE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores CityPostalCodeRadius",
			description = "Checking the stores near by the city radius and postalCode")
	public void cityPostalCodeRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25&city=" + testData.get("STORE_CITY") + "&state=" + testData.get("STORE_STATE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25&city=" + testData.get("STORE_CITY") + "&state=" + testData.get("STORE_STATE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 7, testName = "Stores StateCityPostalCode",
			description = "Checking the stores near by the state city and postalCode")
	public void stateCityPostalCode() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radius=25&city=" + testData.get("STORE_CITY") + "&postalCode=" + testData.get("STORE_POSTAL_CODE") + "&state=" + testData.get("STORE_STATE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radius=25&city=" + testData.get("STORE_CITY") + "&postalCode=" + testData.get("STORE_POSTAL_CODE") + "&state=" + testData.get("STORE_STATE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Stores AddrCityStatePostCodeLatLong",
			description = "Checking the stores near by the address city state latitude longitude and postalCode")
	public void addrCityStatePostCodeLatLong() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&city=" + testData.get("STORE_CITY") + "&state=" + testData.get("STORE_STATE") + "&postalCode=" + testData.get("STORE_POSTAL_CODE") + "&latitude=" + testData.get("STORE_LATITUDE") + "&longitude=" + testData.get("STORE_LONGITUDE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI  + "&city=" + testData.get("STORE_CITY") + "&state=" + testData.get("STORE_STATE") + "&postalCode=" + testData.get("STORE_POSTAL_CODE") + "&latitude=" + testData.get("STORE_LATITUDE") + "&longitude=" + testData.get("STORE_LONGITUDE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Stores PostalCode",
			description = "Checking the stores near by the postalCode")
	public void postalCode() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Stores InvalidParamAddreess",
			description = "Checking the stores near by  passing invalid address parameter")
	public void invalidParamAddreess() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&addreess=" + testData.get("STORE_LONGITUDE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("STORE1001", "addreess is not a valid parameter.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&addreess=" + testData.get("STORE_LONGITUDE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Stores InvalidParamRadiuus",
			description = "Checking the stores near by invalid parameter radius")
	public void invalidParamRadiuus() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radiuus=" + testData.get("STORE_LONGITUDE") + "&postalCode=" + testData.get("STORE_POSTAL_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("STORE1001", "radiuus is not a valid parameter.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radiuus=" + testData.get("STORE_LONGITUDE") + "&postalCode=" + testData.get("STORE_POSTAL_CODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Stores InvalidParamCity1",
			description = "Checking the stores near by passsing invalid parameter city")
	public void invalidParamCity1() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&city1=" + testData.get("STORE_LONGITUDE") + "&postalCode=" + testData.get("STORE_POSTAL_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("STORE1001", "city1 is not a valid parameter.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&city1=" + testData.get("STORE_LONGITUDE") + "&postalCode=" + testData.get("STORE_POSTAL_CODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Stores InvalidParamStaate",
			description = "Checking the stores near by passing invalid parameter state")

	public void invalidParamStaate() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=10" + "&staate=" + testData.get("STORE_STATE") + "&city=" + testData.get("STORE_CITY");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("STORE1001", "staate is not a valid parameter.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=10" + "&staate=" + testData.get("STORE_STATE") + "&city=" + testData.get("STORE_CITY");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Stores openSearchRadiusZeroSearchResult",
			description = "Checking the stores near by radius as zero")
	public void openSearchRadiusZeroSearchResult() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=0";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		validator.validateExpectedErrors("STORE1002", "Invalid value passed for radius.");
		// validator.nodeEquals("$.count", "0", "Count should be zero");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.code,errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Stores OpenSearchCityState",
			description = "Checking the stores near by city and state")
	public void openSearchCityState() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radius=25" + "&city=" + testData.get("STORE_CITY") + "&state=" + testData.get("STORE_STATE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radius=25" + "&city=" + testData.get("STORE_CITY") + "&state=" + testData.get("STORE_STATE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Stores OpenSearchPostCodeRadius",
			description = "Checking the stores near by the radius and postalCode")
	public void openSearchPostCodeRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Stores AddrStateCityPostCodeRadius",
			description = "Checking the stores near by the address city state radius and postalCode")
	public void addrStateCityPostCodeRadius() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Stores AddrStateCity",
			description = "Checking the stores near by the address city and state")
	public void addrStateCity() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + "&radius=25"+ "&state=" + testData.get("STORE_STATE") + "&city=" + testData.get("STORE_CITY");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + "&radius=25" + "&state=" + testData.get("STORE_STATE") + "&city=" + testData.get("STORE_CITY");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}