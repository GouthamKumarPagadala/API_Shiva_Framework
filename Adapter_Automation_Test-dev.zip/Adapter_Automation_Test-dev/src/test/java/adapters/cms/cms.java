package test.java.adapters.cms;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.GlobalVariables.CMS_ADAPTER;
import static main.java.common.GlobalVariables.CMS_SKAVA;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("CMS")
@Stories({ "CMS" })
public class cms {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 7, testName = "cmsContent [homepage]",
			description = "Checking the page details")
	public void Home() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store Name should be present in the response");
		validator.nodeEquals("$.payload.poolName", "nativehome", "Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success", "Response Message should be available in the response");
		validator.nodeMatches("$.payload.entries[0]", ".+", "Entries should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CMS_SKAVA + "&pageName=" + testData.get("SKAVA_PAGE_NAME");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.Skava, false);
			String strResponseSkava = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseSkava, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 7, testName = "cmsContent [Helpcontactus]",
			description = "Checking the page details")
	public void HelpContactUs() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store Name should be present in the response");
		// validator.nodeEquals("$.payload.poolName", testData.get("CMS_PAGE_NAME"), "Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success", "Response Message should be available in the response");
		validator.nodeMatches("$.payload.responseCode", "0", "Response Code should be available in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CMS_SKAVA + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME1");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.Skava, false);
			String strResponseSkava = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseSkava, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 7, testName = "cmsContent [Loyaltyhelp]",
			description = "Checking the page details")
	public void LoyaltyHelp() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store Name should be present in the response");
		// validator.nodeEquals("$.payload.poolName", testData.get("CMS_PAGE_NAME"), "Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success", "Response Message should be available in the response");
		validator.nodeMatches("$.payload.responseCode", "0", "Response Code should be available in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CMS_SKAVA + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME2");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.Skava, false);
			String strResponseSkava = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseSkava, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 7, testName = "cmsContent [Invalidpage]",
			description = "Checking the page details")
	public void InvalidPage() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=fsdf545";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store Name should be present in the response");
		// validator.nodeEquals("$.payload.poolName", testData.get("CMS_PAGE_NAME"), "Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success", "Response Message should be available in the response");
		validator.nodeMatches("$.payload.responseCode", "0", "Response Code should be available in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CMS_SKAVA + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=fsdf545";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.Skava, false);
			String strResponseSkava = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseSkava, "", true);
		}
	}
	
	@Test(groups = {"msm2035" }, enabled = true, priority = 7, testName = "cmsContent [homepage]",
			description = "Checking the page details")
	public void R9_Cms_AppMessage() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN_R9") + "&pageName=" + testData.get("CMS_PAGE_NAME_R9");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store Name should be present in the response");
		validator.nodeEquals("$.payload.entryResponse[0].poolName", "appmessages", "Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success", "Response Message should be available in the response");
		validator.nodeMatches("$.payload.entryResponse[0].entries[0]", ".+", "Entries should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CMS_SKAVA + "&pageName=" + testData.get("CMS_PAGE_NAME_R9");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.Skava, false);
			String strResponseSkava = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseSkava, "", true);
		}
	}

}