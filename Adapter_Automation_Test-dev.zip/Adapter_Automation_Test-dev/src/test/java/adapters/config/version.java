package test.java.adapters.config;

import static main.java.common.GlobalVariables.ADAPTER_VERSION;

import org.testng.annotations.Test;
import static main.java.common.TestData.testData;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("Config")
@Stories({ "Version" })
public class version {
	
ResponseValidator validator;
	
@Test(groups = {"config","regression","smoke"}, enabled = true, priority = 17, testName = "Adapter Version",
 			description = "Build veriosn for Adapters")
 	public void ConfigProperties() {
 
 		String strURL = ADAPTER_VERSION;
 
 		// Post the request for config adapter
 		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
 		Utilities.getEnabledFeatures(strResponse);
 		validator = new ResponseValidator(strResponse);
 		validator.nodeEquals("$.payload.buildinfo.NODE_NAME", testData.get("NODE_NAME"), "NODE_NAME should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.JOB_URL", ".+", "JOB_URL should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.GIT_COMMIT", ".+", "GIT_COMMIT should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.GIT_URL",  ".+", "GIT_URL should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.JOB_NAME", ".+", "JOB_NAME should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.BUILD_TIMESTAMP",  ".+","BUILD_TIMESTAMP should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.GIT_PREVIOUS_SUCCESSFUL_COMMIT", ".+","GIT_PREVIOUS_SUCCESSFUL_COMMIT should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.GIT_BRANCH",  ".+", "GIT_BRANCH should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.GIT_PREVIOUS_COMMIT",  ".+","GIT_PREVIOUS_COMMIT should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.ENVIRONMENT", ".+", "ENVIRONMENT should be present in the response");
 		validator.nodeMatches("$.payload.buildinfo.BUILD_USER", ".+","BUILD_USER should be present in the response");
 	}
 }