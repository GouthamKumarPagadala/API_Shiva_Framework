package test.java.adapters.config;

import static main.java.common.GlobalVariables.CONFIG_IPAD;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;

public class Ipad {

	ResponseValidator validator;
	
	@Test(groups = {"config", "IPAD"}, enabled = true, priority = 17, testName = "Adapter Ipad Configuration",
	 			description = "Build Ipad Config for Adapters")
	 	public void ConfigIpad() {
	 
	 		String strURL = CONFIG_IPAD;
	 
	 		// Post the request for config adapter
	 		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
	 		Utilities.getEnabledFeatures(strResponse);
	 		validator = new ResponseValidator(strResponse);
	 		validator.nodeMatches("$.payload.config.appAndroidVersion", ".+", "appAndroidVersion should be present in the response");
	 		validator.nodeMatches("$.payload.config.crashlyticsURL", ".+", "crashlyticsURL should be present in the response");
	 		validator.nodeMatches("$.payload.config.storeRadius", ".+", "storeRadius should be present in the response");
	 		validator.nodeMatches("$.payload.config.configFileVersion", ".+", "configFileVersion should be present in the response");
	 		validator.nodeMatches("$.payload.config.twitter_page", ".+", "twitter_page should be present in the response");
	 		validator.nodeMatches("$.payload.config.facebook_page", ".+", "facebook_page should be present in the response");
	 		validator.nodeMatches("$.payload.config.appDisplayName", ".+", "appDisplayName should be present in the response");
	 		validator.nodeMatches("$.payload.config.signinTimeout", ".+", "signinTimeout should be present in the response");
	 		validator.nodeMatches("$.payload.config.idleTimeout", ".+", "idleTimeout should be present in the response");
	 		validator.nodeMatches("$.payload.config.appIOSVersion", ".+", "appIOSVersion should be present in the response");
	 		validator.nodeMatches("$.payload.config.specificOfferListName", ".+", "specificOfferListName should be present in the response");
	 		validator.nodeMatches("$.payload.config.isProd", ".+", "isProd should be present in the response");
	 		validator.nodeMatches("$.payload.config.networktimeout", ".+", "networktimeout should be present in the response");
	 		validator.nodeMatches("$.payload.config.appMode", ".+", "appMode should be present in the response");
	 	}
}
