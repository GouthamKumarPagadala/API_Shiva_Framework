package test.java.adapters.config;

import static main.java.common.GlobalVariables.CONFIG_ADAPTER;
//import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;

public class Config {
	
	ResponseValidator validator;
	
	@Test(groups = {"Config"}, enabled = true, priority = 17, testName = "ConfigProperties",
			description = "Clinet configuration for Adapter calls")
	public void ConfigProperties() {

		String strURL = CONFIG_ADAPTER;

		// Post the request for config adapter
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		Utilities.getEnabledFeatures(strResponse);
		//Utilities.validateFeatures(strResponse);

		// Post the request for messages.log
		// String strResponseMessagesLog = RestCall.simpleGetRequest(MESSAGES_LOG, Server.Adapter, false);
		// Utilities.getMFPVersion(strResponseMessagesLog);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.config.appAndroidVersion", "7.+", "appAndroidVersion should be greater than 7.6 and above");
		validator.nodeMatches("$.payload.config.appIOSVersion", "7.+", "appIOSVersion should be greater than 7.0 and above");
		validator.nodeEquals("$.payload.config.visualSearchMinorPoll", "1", "visualSearchMinorPoll should be greater than 1 sec");
		validator.nodeEquals("$.payload.config.krj", "PASSWORD", "TBD");
		validator.nodeMatches("$.payload.config.lastForceUpgradeAndroidVersion", "7.+", "Last force upgrade Android version should be greater than or equal to 7.6.48");
		validator.nodeEquals("$.payload.config.lnrItemImageURL", "http://simages.kohls.com/is/image/kohls/", "lnrItemImageURL url should be present");
		validator.nodeEquals("$.payload.config.isDigbyEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.WalletandLoyaltyBaseURL", "https://kohlsdev002.km.sl.edst.ibm.com/wallet/v1/", "WalletandLoyaltyBaseURL should be present");
		validator.nodeEquals("$.payload.config.LoyaltyEnrollmentScanningUrl", "http://2d-co.de/70605596023", "LoyaltyEnrollmentScanningUrl should be present");
		validator.nodeEquals("$.payload.config.CustomerCarePhone", "(855)564-5705", "TBD");
		validator.nodeEquals("$.payload.config.isApplePayKCCEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.addToBlackFridayBackgroundColor", "#000000", "TBD");
		validator.nodeEquals("$.payload.config.specificOfferListUrl", "http://kregistry.skavaone.com/kohls/createOrGetUser?", "TBD");
		validator.nodeEquals("$.payload.config.VisualSearchMaxTimeAllowedForSearch", "20", "TBD");
		validator.nodeEquals("$.payload.config.secret", "nVBjwya0aULi0Cek", "TBD");
		validator.nodeEquals("$.payload.config.headerApikey", "rhU37ZEQOG9TcsnqWozHjL6dRahWICmh", "TBD");
		validator.nodeEquals("$.payload.config.FeatureDeeplinkingEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.NewPaymentPreference", "Kohls Charge,Amex,Visa,Master Card,Discover", "TBD");
		validator.nodeEquals("$.payload.config.signInRefreshInterval", "5", "TBD");
		validator.nodeEquals("$.payload.config.clearCacheData", "false", "TBD");
		validator.nodeEquals("$.payload.config.facebook_page", "http://www.facebook.com/kohls", "TBD");
		validator.nodeEquals("$.payload.config.saltValue", "TUZhbGxz", "TBD");
		validator.nodeEquals("$.payload.config.FeatureLoyaltyPassEnabled", "false", "TBD");
		validator.nodeEquals("$.payload.config.TypeaheadUrl", "http://www.kohls.com/typeahead/", "TBD");
		validator.nodeEquals("$.payload.config.specificOfferPDPBackgroundColor", "#000000", "TBD");
		validator.nodeEquals("$.payload.config.AddToRegistryUrl", "http://kregistry.skavaone.com/registry/addItemsToList?", "TBD");
		validator.nodeEquals("$.payload.config.walletPriceURL", "https://kohlsdev002.km.sl.edst.ibm.com/wallet/v1/wallet/id/", "TBD");
		validator.nodeEquals("$.payload.config.domainName", "kregistry.skavaone.com", "TBD");
		validator.nodeEquals("$.payload.config.forseeFeedbackURL", "http://www.foresee.com", "TBD");
		validator.nodeEquals("$.payload.config.appAndroidVersionCode", "BLACK FRIDAY PRICE PREVIEW", "TBD");
		validator.nodeEquals("$.payload.config.specificOfferPDPPriceDisplayName", "true", "TBD");
		validator.nodeEquals("$.payload.config.FeatureBOPUSEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.alertUpgradeInterval", "86400", "TBD");
		validator.nodeEquals("$.payload.config.appIOSURL", "http://itunes.apple.com/app/kohls/id472014516?mt=8", "TBD");
		validator.nodeEquals("$.payload.config.forsee_DefaultLaunchCount", "3", "TBD");
		validator.nodeEquals("$.payload.config.VXO_PROFILE_ID", "kohlsAppProfile", "TBD");
		validator.nodeEquals("$.payload.config.CreateLoyaltyProfile", "3", "TBD");
		validator.nodeEquals("$.payload.config.forsee_DefaultLaunchCount", "https://kohlsdev002.km.sl.edst.ibm.com/wallet/v1/loyalty/profiles?channel=D", "TBD");
		validator.nodeEquals("$.payload.config.featureVXOEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.FeatureQnAEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.TodaysDealsUrl", "http://mobileapp.kohls.com/skavastream/studio/reader/prod/todaysdeals", "TBD");
		validator.nodeEquals("$.payload.config.FeatureOCBEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.isFindInStoreEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.AddToListUrl", "http://kregistry.skavaone.com/kohls/addItemsToList?", "TBD");
		validator.nodeEquals("$.payload.config.defaultShippingMethod", "USSTD", "TBD");
		validator.nodeEquals("$.payload.config.baseUrlRegistry", "https://kregistry.skavaone.com/registry/", "TBD");
		validator.nodeEquals("$.payload.config.isOmnitureEnabled", "true", "TBD");
		validator.nodeEquals("$.payload.config.VXOEndpoint", "https://sandbox.secure.checkout.visa.com", "TBD");
		validator.nodeEquals("$.payload.config.omnitureURL", "https://my.omniture.com/login/", "TBD");
		validator.nodeEquals("$.payload.config.ApplePayDefaultCardType", "VISA", "TBD");
		validator.nodeMatches("$.payload.config.FeatureTaxComplianceEnabled", "true|false", "FeatureTaxComplianceEnabled should be in display");
		
	}


}
