package test.java.adapters.config;

import static main.java.common.GlobalVariables.CONFIG_MONETIZATION;
import static main.java.common.GlobalVariables.CONFIG_MONETIZATION_INVALIDURL;
//import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Monetization")
@Stories({ "Config" })
public class Monitization {
	
ResponseValidator validator;
	
	@Test(groups = {"Config","monetization","regression"}, enabled = true, priority = 17, testName = "ConfigMonetization",
			description = "Adapter Monetization configuration")
	public void ConfigMonetization() {

		String strURL = CONFIG_MONETIZATION ;

		// Post the request for config adapter
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);
		Utilities.getEnabledFeatures(strResponse);

		// Post the request for messages.log
		// String strResponseMessagesLog = RestCall.simpleGetRequest(MESSAGES_LOG, Server.Adapter, false);
		// Utilities.getMFPVersion(strResponseMessagesLog);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		validator.nodeEquals("$.payload.channel", "mobileapp", "Channel should be mobileapp");
		validator.nodeEquals("$.payload.env", "test", "Environment should be test");
		validator.nodeEquals("$.payload.networkId", "17763952", "Network ID should be17763952.");
		
		/*Madhu 3/22/2016: Added home page,PMP, PDP, COL,Search, Zero search, oc, Store locator, deals  validation
		 * Requirment ref :https://confluence.globallogic.com/display/Kohls/Monetization+-+Google+DFP*/
		
		validator.nodeEquals("$.payload.home.adUnit", "/homepage", "Adunit is Home page");
		validator.nodeMatches("$.payload.home.isEnabled", "true|false", "Value should be true or false");
		validator.nodeEquals("$.payload.home.size", "[\"banner\"]", "Size should be Banner");
		validator.nodeEquals("$.payload.home.dimensions", "[[320,50]]", "Dimention should be 320, 50 in home page");
		validator.nodeEquals("$.payload.home.pos", "[\"middle\"]", "Ad should be displayed in the middle of home page");
		validator.nodeEquals("$.payload.home.pgtype", "home", "Page type should be Home");
		
		validator.nodeEquals("$.payload.pmp.isEnabled", "true", "Adunit is PMP");
		validator.nodeEquals("$.payload.pmp.size", "[\"banner\"]", "Type of add is Banner");
		validator.nodeEquals("$.payload.pmp.dimensions", "[[320,50]]", "Dimention should be 320, 50 in PMP page");
		validator.nodeEquals("$.payload.pmp.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of PMP");
		validator.nodeEquals("$.payload.pmp.pgtype", "pmp", "Page type should be PMP");
		
		validator.nodeEquals("$.payload.col.isEnabled", "true", "Adunit is in collection page");
		validator.nodeEquals("$.payload.col.size", "[\"banner\"]", "Type of add is Banner in collection page");
		validator.nodeEquals("$.payload.col.dimensions", "[[320,50]]", "Dimention should be 320, 50 in collection page");
		validator.nodeEquals("$.payload.col.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of collection page");
		validator.nodeEquals("$.payload.col.pgtype", "col", "Page type should be Collection");
		
		validator.nodeEquals("$.payload.pdp.isEnabled", "true", "Adunit is in PDP page");
		validator.nodeEquals("$.payload.pdp.size", "[\"banner\"]", "Type of add is Banner in PDP page");
		validator.nodeEquals("$.payload.pdp.dimensions", "[[320,50]]", "Dimention should be 320, 50 in PDP page");
		validator.nodeEquals("$.payload.pdp.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of PDP page");
		validator.nodeEquals("$.payload.pdp.pgtype", "pdp", "Page type should be PDP");
					
		validator.nodeEquals("$.payload.search.isEnabled", "true", "Adunit in search bar page");
		validator.nodeEquals("$.payload.search.size", "[\"banner\"]", "Type of add is Banner in Search bar");
		validator.nodeEquals("$.payload.search.dimensions", "[[320,50]]", "Dimention should be 320, 50 in search page");
		validator.nodeEquals("$.payload.search.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of Search page");
		validator.nodeEquals("$.payload.search.pgtype", "search", "Page type should be search page");

		validator.nodeEquals("$.payload.zerosearch.adUnit", "/zerosearch", "Adunit in search bar page when search result is zero");
		validator.nodeEquals("$.payload.zerosearch.size", "[\"banner\"]", "Type of ad is Banner in Search bar");
		validator.nodeEquals("$.payload.zerosearch.dimensions", "[[320,50]]", "Dimention should be 320, 50 in zero search page");
		validator.nodeEquals("$.payload.zerosearch.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of zero Search page");
		validator.nodeEquals("$.payload.zerosearch.pgtype", "zerosearch", "When the user searches for any product and zero product found");

		validator.nodeEquals("$.payload.oc.adUnit", "/order_confirmation", "Adunit in order confirmation page");
		validator.nodeMatches("$.payload.oc.isEnabled", "true|false", "Value should be true or false");
		validator.nodeEquals("$.payload.oc.size", "[\"banner\"]", "Type of ad is Banner in confirmation page");
		validator.nodeEquals("$.payload.oc.dimensions", "[[320,50]]", "Dimention should be 320, 50 in order confirmation page");
		validator.nodeEquals("$.payload.oc.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of confirmation page");
		validator.nodeEquals("$.payload.oc.pgtype", "oc", "Page type should be oc");
			
		validator.nodeEquals("$.payload.store_locator.adUnit", "/store_locator", "Adunit in store locator page");
		validator.nodeMatches("$.payload.store_locator.isEnabled", "true|false", "Value should be true or false");
		validator.nodeEquals("$.payload.store_locator.size", "[\"banner\"]", "Type of ad is Banner in store locator page");
		validator.nodeEquals("$.payload.store_locator.dimensions", "[[320,50]]", "Dimention should be 320, 50 in order confirmation page");
		validator.nodeEquals("$.payload.store_locator.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of confirmation page");
		validator.nodeEquals("$.payload.store_locator.pgtype", "store_locator", "Page type should be store_locator");
		
		validator.nodeEquals("$.payload.deals.adUnit", "/ROS", "Adunit in ros");
		validator.nodeMatches("$.payload.deals.isEnabled", "true|false", "Value should be true or false");
		validator.nodeEquals("$.payload.deals.dimensions", "[[320,50]]", "Dimention should be 320, 50 in deals page");
		validator.nodeEquals("$.payload.deals.pos", "[\"middle\"]", "Ad should be displayed at the middle of the page");
		validator.nodeEquals("$.payload.deals.pgtype", "sevent", "Page type should be sevent");
		validator.nodeEquals("$.payload.deals.pgname", "coupons-deals.jsp","Page name should be pgname");
						
	}

	@DiscontinuedTest(groups = {"Config","monetization", "errorhandling"}, enabled = false, priority = 17, testName = "ConfigMonetization using invalidUrl",
			description = "Validate error code ERR0002 by passing Invalid Url")
	public void ConfigMonetization_Error_Validation() {

		String strURL = CONFIG_MONETIZATION_INVALIDURL ;

		// Post the request for config adapter
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0002", "We encountered issue processing your request, please try again later");
		
}
}


