/**
 * 
 */
/**
 * @author TKMACZT
 *
 */
package test.java.adapters.iPad;