package test.java.adapters.iPad;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.CUSTOMER_ADAPTER;
import static main.java.common.GlobalVariables.CUSTOMER_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Customer")
@Stories({ "Customer" })

public class CustomerLookUp {

	
	ResponseValidator validator;
	
	@Test(groups = { "ipad_customerlookup","IPK","ipadkiosk","PopulateLoyaltyid-NAP-135","loyalty"}, enabled = true, priority = 0, testName = "CustomerLookUpValid",
			description = "Customer Look up with valid internal token + ZipCode")
	public void CustomerLookUpValid() {
		
		// Create the Json Request
		String strPayload = "{\"payload\": {\"action\": \"lookupby_intKCC_zip\",\"lookupBy\": \"internalToken:843676441901,zipCode:35630\" }}";

		// Post the request
		String strResponse = RestCall.postRequest(CUSTOMER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.customers[0].email.kohlsCharge", ".+", "kohlsCharge email should be present in the response");
		validator.nodeMatches("$.payload.customers[0].customerName.kohlsCharge.firstName", ".+", "kohlsCharge firstName should be present in the response");
		validator.nodeMatches("$.payload.customers[0].customerName.kohlsCharge.lastName", ".+", "kohlsCharge lastName should be present in the response");
		validator.nodeMatches("$.payload.customers[0].phoneNumber.kohlsCharge[0].number", "[0-9]+", "kohlsCharge number should be present in the response");
		validator.nodeMatches("$.payload.customers[0].address.kohlsCharge.postalCode", "[0-9]+", "kohlsCharge postalCode should be present in the response");
		validator.nodeMatches("$.payload.customers[0].address.kohlsCharge.addr1", ".+", "kohlsCharge addr1 should be present in the response");
		validator.nodeMatches("$.payload.customers[0].address.kohlsCharge.state", ".+", "kohlsCharge state should be present in the response");
		validator.nodeMatches("$.payload.customers[0].address.kohlsCharge.city", ".+", "kohlsCharge city should be present in the response");
		validator.nodeMatches("$.payload.customers[0].address.kohlsCharge.country", ".+", "kohlsCharge country should be present in the response");
		validator.nodeMatches("$.payload.customers[0].loyaltyId",".+", "loyaltyId should be present in the response");
		
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request
			String strPayloadOAPI = "{\"payload\":{\"action\":\"lookupby_intKCC_zip\",\"lookupBy\":\"internalToken:843826464501,zipCode:60606\"}}";
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CUSTOMER_OAPI, strPayloadOAPI, Server.OpenApi, false);

		// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "ipad_customerlookup",  "IPK","PopulateLoyaltyid-NAP-135","loyalty"}, enabled = true, priority = 0, testName = "Customer Look up with invalid zipCode which is does not match with KCC",
			description = "Customer Look up with invalid zipCode which is does not match with KCC")
	public void CustomerLookUpInvalidMatchZipcode() {
		
		// Create the Json Request
		String strPayload = "{\"payload\": {\"action\": \"lookupby_intKCC_zip\",\"lookupBy\": \"internalToken:912873987123983,zipCode:95035\"}}";

		// Post the request
		String strResponse = RestCall.postRequest(CUSTOMER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CUST1005", "The Kohl's Charge Card could not be found in the system");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request
			String strPayloadOAPI = "{\"payload\":{\"action\":\"lookupby_intKCC_zip\",\"lookupBy\":\"internalToken:912873987123983,zipCode:95035\"}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CUSTOMER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "ipad_customerlookup",  "IPK","PopulateLoyaltyid-NAP-135","loyalty"}, enabled = true, priority = 0, testName = "Customer Look up with zipCode and without Internal token",
			description = "Customer Look up with zipCode and without Internal token")
	public void CustomerLookUpWithoutToken() {
		
		// Create the Json Request
		String strPayload = "{\"payload\": {\"action\": \"lookupby_intKCC_zip\",\"lookupBy\": \"internalToken:,zipCode:95035\"}}";

		// Post the request
		String strResponse = RestCall.postRequest(CUSTOMER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CUST1002", "Invalid value passed for internalToken");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request
			String strPayloadOAPI = "{\"payload\":{\"action\":\"lookupby_intKCC_zip\",\"lookupBy\":\"internalToken:,zipCode:95035\"}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CUSTOMER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "ipad_customerlookup",  "IPK","PopulateLoyaltyid-NAP-135","loyalty"}, enabled = true, priority = 0, testName = "Customer Look up with internal token and without zipCode",
			description = "Customer Look up with internal token and without zipCode")
	public void CustomerLookUpWithoutZipcode() {
		
		// Create the Json Request
		String strPayload = "{\"payload\": {\"action\": \"lookupby_intKCC_zip\",\"lookupBy\": \"internalToken:912873987123983,zipCode:\"}}";

		// Post the request
		String strResponse = RestCall.postRequest(CUSTOMER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CUST1002", "Invalid value passed for zipCode");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request
			String strPayloadOAPI = "{\"payload\":{\"action\":\"lookupby_intKCC_zip\",\"lookupBy\":\"internalToken:912873987123983,zipCode:\"}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CUSTOMER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "ipad_customerlookup",  "IPK","PopulateLoyaltyid-NAP-135","loyalty"}, enabled = true, priority = 0, testName = "Customer Look up with invalid internal token",
			description = "Customer Look up with invalid internal token")
	public void CustomerLookUpInvalidToken() {
		
		// Create the Json Request
		String strPayload = "{\"payload\": {\"action\": \"lookupby_intKCC_zip\",\"lookupBy\": \"internalToken:912873fdf987123983,zipCode:95035\"}}";

		// Post the request
		String strResponse = RestCall.postRequest(CUSTOMER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CUST1002", "Invalid value passed for internalToken");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request
			String strPayloadOAPI = "{\"payload\":{\"action\":\"lookupby_intKCC_zip\",\"lookupBy\":\"internalToken:912873fdf987123983,zipCode:95035\"}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CUSTOMER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "ipad_customerlookup",  "IPK","PopulateLoyaltyid-NAP-135","loyalty"}, enabled = true, priority = 0, testName = "Customer Look up with invalid zipcode",
			description = "Customer Look up with invalid zipcode")
	public void CustomerLookUpInvalidZipcode() {
		
		// Create the Json Request
		String strPayload = "{\"payload\": {\"action\": \"lookupby_intKCC_zip\",\"lookupBy\": \"internalToken:912873987123983,zipCode:950fd35\"}}";

		// Post the request
		String strResponse = RestCall.postRequest(CUSTOMER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CUST1002", "Invalid value passed for zipCode");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request
			String strPayloadOAPI = "{\"payload\":{\"action\":\"lookupby_intKCC_zip\",\"lookupBy\":\"internalToken:912873987123983,zipCode:950fd35\"}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CUSTOMER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
}
