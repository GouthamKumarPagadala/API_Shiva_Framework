package test.java.adapters.iPad;

import static main.java.common.GlobalVariables.CONTENT_ADAPTER;
import static main.java.common.GlobalVariables.CONTENT_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("IPAD")
@Stories({ "Content" })

public class content {

ResponseValidator validator;
	
	@Test(groups = { "ipad_content","IPK" }, enabled = true, priority = 12, testName = "Content",
			description = "Kohls application user should get the response With all the valid parameters")
	public void Content() {

		String strURL = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=stage&previewdate=" + testData.get("PREVIEW_DATE");
		
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.module", "screensaver", "module should not be a null");
		validator.nodeMatches("$.payload.data..time", ".+", "module should not be a null");
		for(int i =1;i<=4;i++){
		validator.nodeEquals("$.payload.data["+i+"].type", "image", "Should contain Type");
		validator.nodeNotEquals("$.payload.data["+i+"].url", null, "Should not be Null");
		}
		//validator.nodeMatches("$.contentResponse.payload.properties.property.key", null, "key should not be a null");
		//validator.nodeMatches("$.contentResponse.payload.properties.property.value", null, "value should not be a null");
		
		// Compare Open API
		/*if (CompareOAPI) {
			String strURLOAPI = CONTENT_OAPI + "channel=ipadpro&environment=stage&previewdate=YYYY-MM-DD_HH:MI:SS";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}*/
	}
	@Test(groups = { "ipad_content","IPK" }, enabled = true, priority = 12, testName = "Content",
			description = "Kohls application user should get the response With all the valid parameters")
	public void ContentWithoutEnvDate() {

		String strURL = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=stage";
		
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.module", "screensaver", "module should not be a null");
		validator.nodeMatches("$.payload.data..time", ".+", "module should not be a null");
		for(int i =1;i<=4;i++){
		validator.nodeEquals("$.payload.data["+i+"].type", "image", "Should contain Type");
		validator.nodeNotEquals("$.payload.data["+i+"].url", null, "Should not be Null");
		}
		//validator.nodeMatches("$.contentResponse.payload.properties.property.key", null, "key should not be a null");
		//validator.nodeMatches("$.contentResponse.payload.properties.property.value", null, "value should not be a null");
		
		// Compare Open API
		/*if (CompareOAPI) {
			String strURLOAPI = CONTENT_OAPI + "channel=ipadpro&environment=stage&previewdate=YYYY-MM-DD_HH:MI:SS";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}*/
	}
	
	@Test(groups = { "ipadkiosk" }, enabled = true, priority = 12, testName = "Content",
			description = "Kohls application user should get the response With all the valid parameters")
	public void Content_prod() {

		String strURL = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=production";
		
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.module", "screensaver", "module should not be a null");
		validator.nodeMatches("$.payload.data..time", ".+", "module should not be a null");
		for(int i =1;i<=4;i++){
		validator.nodeEquals("$.payload.data["+i+"].type", "image", "Should contain Type");
		validator.nodeNotEquals("$.payload.data["+i+"].url", null, "Should not be Null");
		validator.nodeMatches("$.payload.data["+i+"].url",".+", "Should not be Null");

		}
}}

