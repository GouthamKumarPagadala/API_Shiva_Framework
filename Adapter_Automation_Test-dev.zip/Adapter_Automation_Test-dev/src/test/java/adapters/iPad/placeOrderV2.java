package test.java.adapters.iPad;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("IPAD")                                                                                                           
@Stories({ "Place Order V2" })

public class placeOrderV2 {

	
	@BeforeMethod(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Pass@123";
				Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi_ipad");
						
				
				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter_ipad");
	}
	
	ResponseValidator validator;

	@Test(groups = { "ipad_placeorder","IPK","ipadkiosk" }, enabled = true, priority = 2, testName = "Bopus Item +Visa Credit Card",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_Bopus_Visa() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs                         
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_VISA")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
//		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Registry Item + Master Card",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_Registry_Master() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs                  
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		
		// Update ShipAddress
				String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
						+ JsonString.getBillAddressJson("UPDATE")
						+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);

				Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");
				
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter")
				+ "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";

		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\": [{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}"
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Normal Item + Amex Card",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_Normal_Amex() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs                        
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Normal Item + Kohls Charge Card ",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_Normal_KCC() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs                        
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_KOHLS_CARD")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Gift Item + Discover Credit Card",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_GiftItem_Discover() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs                        
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("GIFT_TRUE", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"giftItem\":true,\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_DISCOVER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].giftItem", "true", "giftItem should be present as true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Normal Item + Amex + Kohls Gift Card + PromoCode",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_Normal_Amex_GC_PromoCode() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs   
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")
		+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("PROMOCODE")+"\",\"action\":\"add\"}]}}}}}";
		
		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		
		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");
	
		
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Normal Item  + Visa without nameOnCard, Amount & securityCode ",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_Normal_VisaWithoutNameOnCard_Amount_SecurityCode() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   //clear any headers set by previous TCs                     
		 mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Unregistered User",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_registeredUser() {

		 
		// Update cart through Adapter
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_VISA")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOrderCalc, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseOrderCalcAdapter, strResponseOAPI, "payload.order.orderNumber", true);
	}
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "With Invalid PaymentMethod (pinpe)",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as pinpe")
	public void PlaceOrderV2_InvalidPaymentMethod() {

		 
		
		// Update cart through OAPI
		//mapheader.clear();   // clear any headers set by previous TCs                         // mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"pinpe\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for paymentMethod.");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "With PaymentMethod as Special Charcters (12*!&)",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as 12*!&")
	public void PlaceOrderV2_PaymentMethodAsSpecialCharacters() {

		 
		
		// Update cart through OAPI
		//mapheader.clear();   // clear any headers set by previous TCs                         // mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"12*!&\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for paymentMethod.");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "With PaymentMethod as empty tag",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as empty")
	public void PlaceOrderV2_EmptyPaymentMethod() {

		 
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs                        
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		mapheader.clear();  
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for paymentMethod.");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("access_token_oapi_ipad"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
	}
	
	@Test(groups = { "ipad_placeorder", "IPK" }, enabled = true, priority = 2, testName = "Unregistered User",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void PlaceOrderV2_EndlessASile_FreeShipping() {

		 
		// Update cart through Adapter
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("TOKEN_VISA")
				+ "]}}}}";
		String strurl = PLACEORDERV2_ADAPTER+"&channel=endless_aisle"; 
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(strurl, strPayloadOrderCalc, Server.Adapter, false);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		if (CompareOAPI) {
			
			String strurloapi = PLACEORDERV2_OAPI+"&channel=endless_aisle"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strurloapi, strPayloadOrderCalc, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseOrderCalcAdapter, strResponseOAPI, "payload.order.orderNumber", true);
	}
	}
}