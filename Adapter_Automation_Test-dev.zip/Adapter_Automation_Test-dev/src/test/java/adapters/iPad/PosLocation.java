package test.java.adapters.iPad;

import static main.java.common.GlobalVariables.POSLOCATION_ADAPTER;
import static main.java.common.GlobalVariables.CONTENT_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("IPAD")
@Stories({ "POS LOCATION" })

public class PosLocation {

  ResponseValidator validator;
	
	@Test(groups = { "ipad_poslocation","IPK","ipadkiosk" }, enabled = true, priority = 12, testName = "Content",
			description = "Kohls application user should get the response With all the valid parameters")
	public void Content_Edeyme() {

		String strURL = POSLOCATION_ADAPTER;	 
		
	//	mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidtaePosLocationResponse();
		
	}
}