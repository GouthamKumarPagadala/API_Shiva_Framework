package test.java.adapters.iPad;



import static main.java.common.GlobalVariables.CONFIG_IPAD;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;

public class iPadConfig {

	ResponseValidator validator;
	
	@Test(groups = {"IPK","ipadkiosk"}, enabled = true, priority = 1, testName = "Adapter Ipad Configuration",
	 			description = "Client iPad and Kisosk config file.")
	 	public void ConfigIpad() {
	 
	 		String strURL = CONFIG_IPAD;
	 
	 		// Post the request for config adapter
	 		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
	 		Utilities.getEnabledFeatures(strResponse);
	 		validator = new ResponseValidator(strResponse);
	 		validator.nodeMatches("$.payload.config.appAndroidVersion", ".+", "appAndroidVersion should be present in the response");
	 		validator.nodeMatches("$.payload.config.crashlyticsURL", ".+", "crashlyticsURL should be present in the response");
	 		validator.nodeEquals("$.payload.config.storeRadius", "50", "storeRadius should be 50 in the response");
	 		validator.nodeMatches("$.payload.config.configFileVersion", ".+", "configFileVersion should be present in the response");
	 		validator.nodeEquals("$.payload.config.twitter_page", "http://twitter.com/#!/Kohls_Official", "twitter_page should be present in the response");
	 		validator.nodeEquals("$.payload.config.facebook_page", "http://www.facebook.com/kohls", "facebook_page should be present in the response");
	 		validator.nodeEquals("$.payload.config.appDisplayName", "Kohl's", "appDisplayName should be present in the response");
	 		validator.nodeEquals("$.payload.config.signinTimeout", "43200000", "signinTimeout should be present in the response");
	 		validator.nodeEquals("$.payload.config.idleTimeout", "420", "idleTimeout should be present in the response");
	 		validator.nodeMatches("$.payload.config.appIOSVersion", ".+", "appIOSVersion should be present in the response");
	 		validator.nodeMatches("$.payload.config.specificOfferListName", ".+", "specificOfferListName should be present in the response");
	 		validator.nodeMatches("$.payload.config.isProd", ".+", "isProd should be present in the response");
	 		validator.nodeEquals("$.payload.config.networktimeout", "30000", "networktimeout should be present in the response");
	 		validator.nodeMatches("$.payload.config.appMode", ".+", "appMode should be present in the response");
	 	}
}
