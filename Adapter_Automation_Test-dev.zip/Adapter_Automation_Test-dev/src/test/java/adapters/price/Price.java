package test.java.adapters.price;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PRICE_SKU_ADAPTER;
import static main.java.common.GlobalVariables.PRICE_SKU_OAPI;
import static main.java.common.GlobalVariables.PRICE_WEB_ADAPTER;
import static main.java.common.GlobalVariables.PRICE_WEB_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Price")
@Stories({ "Price Check" })
public class Price {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 9, testName = "Invalid Sku",
			description = "Checking error code while passing invalid skuCode")
	public void InvalidPricebySku() {

		String strURL = PRICE_SKU_ADAPTER + "/rew2432";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PRICE1002", "Invalid value passed for skucode.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/rew2432";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 9, testName = "PricebySku_salepricenull",
			description = "Checking whether SalePricestatus value is null in the response")
	public void Get_Price_of_Sku_whose_saleprice_null() {

		String strURL = PRICE_SKU_ADAPTER + "/"+testData.get("SKU_SALEPRICENULL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice").toString();
		if(salePrice=="null")
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should be null in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("SKU_SALEPRICENULL");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 9, testName = "PricebySku_salepricesale",
			description = "Checking whether SalePricestatus value is sale in the response")
	public void Get_Price_of_Sku_whose_saleprice_sale() {

		String strURL = PRICE_SKU_ADAPTER + "/"+testData.get("SKU_SALEPRICESALE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice");
		if(salePrice!="null")
		{
		validator.nodeNotEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should not be null in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("SKU_SALEPRICESALE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 9, testName = "PricebySku_salepricesale",
			description = "Checking whether SalePricestatus value is CLEARANCE in the response")
	public void Get_Price_of_Sku_whose_saleprice_clearance() {

		String strURL = PRICE_SKU_ADAPTER + "/"+testData.get("SKU_SALEPRICECLEARANCE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice");
		if(salePrice!="null")
		{
		validator.nodeNotEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should not be null in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("SKU_SALEPRICECLEARANCE");
			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 9, testName = "PricebyWebID_salepricenull",
			description = "Checking whether SalePricestatus value is null in the response")
	public void Get_Price_by_WebID_whose_saleprice_is_null() {

		String strURL = PRICE_WEB_ADAPTER + "/"+testData.get("WEBID_SALEPRICENULL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice").toString();
		if(salePrice=="null")
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should be null in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			
			// Create the Json Request for create profile
			String strURLOAPI = PRICE_WEB_OAPI + "/"+testData.get("WEBID_SALEPRICENULL");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 9, testName = "PricebywebID_salepricesale",
			description = "Checking whether SalePricestatus value is sale in the response")
	public void Get_Price_by_webId_whose_saleprice_is_sale() {

		String strURL = PRICE_WEB_ADAPTER + "/"+testData.get("WEBID_SALEPRICESALE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice");
		if(salePrice!="null")
		{
		validator.nodeNotEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should not be null in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_WEB_OAPI + "/"+testData.get("WEBID_SALEPRICESALE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 9, testName = "PricebywebID_salepricesale",
			description = "Checking whether SalePricestatus value is clearance in the response")
	public void Get_Price_by_webId_whose_saleprice_is_clearance() {

		String strURL = PRICE_WEB_ADAPTER + "/"+testData.get("WEBID_SALEPRICECLEARANCE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice");
		if(salePrice!="null")
		{
		validator.nodeNotEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should not be null in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_WEB_OAPI + "/"+testData.get("WEBID_SALEPRICECLEARANCE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "SuppressedPricing","regression","smokeTest","SmartSuppressedPricing-NAP126" }, enabled = true, priority = 9, testName = "Get_Price_By_Sku_Suppressed",
			description = "\n TC Description -Get price by Skucode \n Feature - validate SmartSuppressedPricing,<br /> SuppressedPricingText")
	
	public void Get_Price_By_Sku_Suppressed() {

		String strURL = PRICE_SKU_ADAPTER + "/"+testData.get("SKU_SUPPRESSED");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validateSmartSuppressedPricing(strResponse);
		String isSuppressed = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].isSuppressed").toString();
		if(isSuppressed.equalsIgnoreCase("true"))
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed Text should be FOR PRICE, ADD TO BAG for suppressed price sku's");
		}else{
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","null","Suppressed Text should be null for Non suppressed price sku's");
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].salePrice","null","salePrice Text should be null for Non suppressed price sku's");
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].promotion","null","promotion should be null for Non suppressed price sku's");
			
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("SKU_SUPPRESSED");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "SuppressedPricing" }, enabled = true, priority = 9, testName = "Get_Price_By_Sku_NONSuppressed",
			description = "\n TC Description -Get price by Skucode \n Feature - validate SuppressedPricing")
	public void Get_Price_By_Sku_NONSuppressed() {

		String strURL = PRICE_SKU_ADAPTER + "/"+testData.get("SKU_NONSUPPRESSED");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		String isSuppressed = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].isSuppressed").toString();
		if(isSuppressed.equalsIgnoreCase("true"))
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed Text should be FOR PRICE, ADD TO BAG for suppressed price sku's");
		}else{
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","null","Suppressed Text should be null for Non suppressed price sku's");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("SKU_NONSUPPRESSED");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "SuppressedPricing" }, enabled = true, priority = 9, testName = "Get_Price_By_Sku_NONSuppressed",
			description = "\n TC Description -Get price by WebId \n Feature - validate SuppressedPricing")
	public void Get_Price_By_WebID_NONSuppressed() {

		String strURL = PRICE_WEB_ADAPTER + "/"+testData.get("WEBID_NONSUPPRESSED");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		String isSuppressed = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].isSuppressed").toString();
		if(isSuppressed.equalsIgnoreCase("true"))
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed Text should be FOR PRICE, ADD TO BAG for suppressed price sku's");
		}else{
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","null","Suppressed Text should be null for Non suppressed price sku's");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("WEBID_NONSUPPRESSED");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "SuppressedPricing","regression","SmartSuppressedPricing-NAP126" }, enabled = true, priority = 9, testName = "Get_Price_By_Sku_NONSuppressed",
			description = "\n TC Description -Get price by WebId \n Feature - validate SmartSuppressedPricing,<br /> SuppressedPricingText")
	public void Get_Price_By_WebID_Suppressed() {

		String strURL = PRICE_WEB_ADAPTER + "/"+testData.get("WEBID_SMARTSUPPRESSED");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validateSmartSuppressedPricing(strResponse);
		String isSuppressed = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].isSuppressed").toString();
		if(isSuppressed.equalsIgnoreCase("true"))
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed Text should be FOR PRICE, ADD TO BAG for suppressed price sku's");
		}else{
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","null","Suppressed Text should be null for Non suppressed price sku's");
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].salePrice","null","salePrice Text should be null for Non suppressed price sku's");
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].promotion","null","promotion should be null for Non suppressed price sku's");
			
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/"+testData.get("WEBID_SMARTSUPPRESSED");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 9, testName = "Invalid WebId",
			description = "Checking error code while passing invalid webId")
	public void InvalidPricebyWeb() {

		String strURL = PRICE_WEB_ADAPTER + "/rew2432";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PRICE2000", "No pricing information available.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_WEB_OAPI + "/rew2432";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 9, testName = "Not Found Sku",
			description = "Checking error code while passing not found skuCode")
	public void NotFoundPricebySku() {

		String strURL = PRICE_SKU_ADAPTER + "/10000001";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PRICE2000", "No pricing information available.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = PRICE_SKU_OAPI + "/10000001";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	//added for SmartSuppressedPricing NAP-126
	public void validateSmartSuppressedPricing(String response){
				
				String promotion=Utilities.getJsonNodeValue(response, "$.payload.products[0].stores[0].prices[0].promotion");
					   	        String saleprice=Utilities.getJsonNodeValue(response,"$.payload.products[0].stores[0].prices[0].salePrice");
	   	 	if(promotion.equals("null")&&saleprice.equals("null"))
			{
				validator.nodeMatches("$.payload.products[0].stores[0].prices[0].isSuppressed","false|true|null","isSuppressed should be false");
			}
	   	 	
			}

}
