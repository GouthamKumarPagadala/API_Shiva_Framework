package test.java.adapters.cache;

import static main.java.common.GlobalVariables.CATEGORY_V2_ADAPTER;
import static main.java.common.GlobalVariables.CONTENT_ADAPTER;
import static main.java.common.GlobalVariables.DELETE_CACHESTATUS_ADAPTER;
import static main.java.common.GlobalVariables.GET_CACHESTATUS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Cache")
@Stories({ "Content" })

public class Content {

ResponseValidator validator;
	
	@Test(groups = {"ipad_cache", "IPK","ipadkiosk" }, enabled = true, priority = 12, testName = "Get Cache Flush status",
			description = "Checking the service meta data information")
	public void getCacheFlushStatus() {
			
		// Post the request
		String strResponse1 = RestCall.getRequest(GET_CACHESTATUS_ADAPTER, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.content", "[0-9]+", "Verifying content is not null");
		Utilities.setTestData(strResponse1, "$.payload.content", "CONTENT_CACHE_NUMBER");
		
	}	
	@Test(groups = { "ipad_cache", "IPK","ipadkiosk" }, enabled = true, priority = 17, testName = "DeleteCacheFlushStatus",
			description = "", dependsOnMethods = "getCacheFlushStatus")
	public void DeleteCacheFlushStatus() throws Exception {
		
		String strURL = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=stage&previewdate=" + testData.get("PREVIEW_DATE");
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateResponseHeaders("EXPIRES_GT_CURRENT_DATE", "Expires header date should be greter than current date");
		testData.put("EXPIRES_DATE_HEADER", testData.get("EXPIRES_DATE_RESPONSE_HEADER"));
		
		String strURL1 = DELETE_CACHESTATUS_ADAPTER + "content";
		// Post the request
		String strResponse1 = RestCall.deleteRequest(strURL1, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Cache request received.", "Cache request received message should be present in the response");
		
		Thread.sleep(10000);
		String strURL2 = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=stage&previewdate=" + testData.get("PREVIEW_DATE");
		
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse2 = RestCall.getRequest(strURL2, Server.Adapter, false, mapheader);
				
		// Validate Response
		validator = new ResponseValidator(strResponse2);
		validator.validateNoErrors();
		validator.validateResponseHeaders("EXPIRES_GT_CURRENT_DATE", "Expires header date should be greater than current date");
		testData.put("EXPIRES_DATE_HEADER1", testData.get("EXPIRES_DATE_RESPONSE_HEADER"));
		
		Assert.assertNotEquals(testData.get("EXPIRES_DATE_HEADER"), testData.get("EXPIRES_DATE_HEADER1"), "Verifying whether the expires header is not same once the product count cache is flushed/deleted");
	}
	@Test(groups = {"ipad_cache", "IPK","ipadkiosk" }, enabled = true, priority = 12, testName = "Get Cache Flush status",
			description = "Checking the service meta data information", dependsOnMethods = "DeleteCacheFlushStatus")
	public void getCacheFlushStatus1() {
		
		// Post the request
		String strResponse = RestCall.getRequest(GET_CACHESTATUS_ADAPTER, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.content", "[0-9]+", "Verifying content is not null");
		Utilities.setTestData(strResponse, "$.payload.content", "CONTENT_CACHE_NUMBER1");
		
		Assert.assertNotEquals(testData.get("CONTENT_CACHE_NUMBER"), testData.get("CONTENT_CACHE_NUMBER1"), "Verifying whether the content cache number is not same after flushing/deleting the cache");
	}
}
