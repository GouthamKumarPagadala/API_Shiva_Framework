package test.java.adapters.offer;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.OFFERCODE_ADAPTER;
import static main.java.common.GlobalVariables.OFFERCODE_OAPI;

import static main.java.common.GlobalVariables.OFFERTYPE_ADAPTER;
import static main.java.common.GlobalVariables.OFFERID_ADAPTER;
import static main.java.common.GlobalVariables.OFFERID_OAPI;
import static main.java.common.GlobalVariables.OFFER_PRODUCTID_ADAPTER;
import static main.java.common.GlobalVariables.OFFER_PRODUCTID_OAPI;
import static main.java.common.GlobalVariables.OFFERTYPE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Offer")
@Stories({ "Offers" })
public class Offer {

	ResponseValidator validator;


	@Test(groups = { "regression","functional","errorhandling","offerLookup-NAP48" }, enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details by using Invalid OfferID")
	public void ByInvalidOfferId() {

		// End point url to be passed in the request
		String strURL = OFFERID_ADAPTER + "fdsf1546";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.offers[0].id", "fdsf1546", "Given OfferID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].errors[0].code", "OFFER1002-1", "OFFER1002-1 error code should be present in the response");
		validator.nodeMatches("$.payload.offers[0].errors[0].message", "Invalid value passed for offerId.", "Invalid value passed for offerId error message should be present in the response");
		
		/*
		 * offer unification
		 */
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + "fdsf1546";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	
	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details with error response by using empty OfferID")
	public void ByEmptyOfferId() {

		// Post the request
		String strResponse = RestCall.getRequest(OFFERID_ADAPTER, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1000-1", "One of offerId or offercode is required.");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.getRequest(OFFERID_OAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}
	
	@Test(groups = { "regression","functional","errorhandling","offerLookup-NAP48" }, enabled = true, priority = 11, testName = "Offers By OfferCode",
			description = "Checking the Offer error Details By using Invalid OfferCode")
	public void ByOfferCodeInvalidOfferCode() {

		// End point URL to be passed in the request
		String strURL = OFFERCODE_ADAPTER + "WAL03FDSF";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.offers[0].code", "WAL03FDSF", "Given OfferCode should be present in the response");
		validator.nodeMatches("$.payload.offers[0].errors[0].code", "OFFER3000-1", "OFFER3000-1 error code should be present in the response");
		validator.nodeMatches("$.payload.offers[0].errors[0].message", "The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code.", "The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code error message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = OFFERCODE_OAPI + "WAL03FDSF";
			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = {"regression", "offerLookup-NAP48" }, enabled = true, priority = 11, testName = "Offers By OfferExpiredCode",
			description = "Checking the Offer error Details By using Expired OfferCode")
	public void ByOfferCodeExpiredOfferCode()
	{
		// End point URL to be passed in the request
		String strURL = OFFERCODE_ADAPTER + "11JUN";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.offers[0].code", "11JUN", "Given OfferCode should be present in the response");
		validator.nodeMatches("$.payload.offers[0].errors[0].code", "OFFER3000-3", "OFFER3000-3 error code should be present in the response");
		validator.nodeMatches("$.payload.offers[0].errors[0].message", "We're sorry, but the Promo Code you entered has expired. Please check the offer for details.", "We're sorry, but the Promo Code you entered has expired. Please check the offer for details error message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = OFFERCODE_OAPI + "11JUN";
			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details with error response by using empty OfferID")
	public void ByEmptyOfferCode() {

		// End point URL to be passed in the request
		String strURL = OFFERCODE_ADAPTER;

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1000-1", "One of offerId or offercode is required.");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = OFFERCODE_OAPI;
			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 12, testName = "Offers By ProductId",
			description = "Checking the Offer Details By using ProductId")
	public void ByProductIdInvalidProductID() {

		// End point URL to be passed in the request
		String strURL = OFFER_PRODUCTID_ADAPTER + "13478";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.products[0].id", "13478", "Given productId should be present in the response");
		validator.nodeMatches("$.payload.products[0].offerErrors[0].code", "OFFER2000-4", "OFFER2000-4 error code should be present in the response");
		validator.nodeMatches("$.payload.products[0].offerErrors[0].message", "ProductID Not Found.", "ProductID Not Found error message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + "13478";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

/*
 * OFFER UNIFICATION
 */
	@Test(groups = { "offerunification","offerLookup-NAP48","regression"}, enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details  by using valid OfferID")
	public void ByValidOfferId() {

		// End point url to be passed in the request
		String strURL = OFFERID_ADAPTER + testData.get("OFFER_UNI_OFFER_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.offers[0].id", testData.get("OFFER_UNI_OFFER_ID"), "Offer ID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].pin", ".*", "Offer PIN should be present in the response");
		validator.nodeNotEquals("$.payload.offers[0].offerEffectiveDate.begDate", "null", "Offer BEGDATE should not be null in the response");
		validator.nodeNotEquals("$.payload.offers[0].offerEffectiveDate.endDate", "null", "Offer ENDDATE should not be null in the response");
		validator.nodeMatches("$.payload.offers[0].code",testData.get("OFFER_UNI_OFFER_CODE"), "Offer CODE should be present in the response");
		/*
		 * offer unification
		 */
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + testData.get("OFFER_UNI_OFFER_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "offerunification","offerLookup-NAP48", }, enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details by using valid CODE")
	public void ByValidOfferCode() {

		// End point url to be passed in the request
		String strURL = OFFERCODE_ADAPTER + testData.get("OFFER_UNI_OFFER_CODE");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.offers[0].id", ".*", "Offer ID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].pin", ".*", "Offer PIN should be present in the response");
		validator.nodeNotEquals("$.payload.offers[0].offerEffectiveDate.begDate", "null", "Offer BEGDATE should not be null in the response");
		validator.nodeNotEquals("$.payload.offers[0].offerEffectiveDate.endDate", "null", "Offer ENDDATE should not be null in the response");
		validator.nodeEquals("$.payload.offers[0].code", testData.get("OFFER_UNI_OFFER_CODE"), "Offer CODE should be present in the response");
		/*
		 * offer unification
		 */
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERCODE_OAPI + testData.get("OFFER_UNI_OFFER_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = {"offerunification","offerLookup-NAP48" }, enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details by using Invalid OfferType")
	public void ByValidOfferType() {

		// End point url to be passed in the request
		String strURL = OFFERTYPE_ADAPTER + "TLD";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.offers[*].id", ".*", "Offer ID should be present in the response");
		validator.nodeMatches("$.payload.offers[*].pin", ".*", "Offer PIN should be present in the response");
		validator.nodeMatches("$.payload.offers[*].storeOfferEffectiveDate.storeStartDate", ".*", "Offer STORESTARTDATE should be present in the response");
		validator.nodeMatches("$.payload.offers[*].storeOfferEffectiveDate.storeEndDate", ".*", "Offer STOREENDDATE should be present in the response");
		validator.nodeNotEquals("$.payload.offers[0].offerEffectiveDate.begDate", "null", "Offer BEGDATE should not be null in the response");
		validator.nodeNotEquals("$.payload.offers[0].offerEffectiveDate.endDate", "null", "Offer ENDDATE should not be null in the response");
		validator.nodeMatches("$.payload.offers[*].code", ".*", "Offer CODE should be present in the response");
		
		JSONArray offerArray = JsonPath.read(strResponse, "$.payload.offers..id");
		int offerArraySize = offerArray.size();
		
		for (int i = 0; i < offerArraySize; i++) {
				validator.nodeMatches("$.payload.offers["+i+"].channels[*].value", ".*store.*", "Offer CODE should be present in the response");
		}
		
		
		
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERTYPE_OAPI + "TLD";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

}