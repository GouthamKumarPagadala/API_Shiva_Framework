package test.java.adapters.order.applepay;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_OAPI;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("ApplePay")
@Stories({ "Retrieve Order" })
public class RetrieveOrder {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order Invalid orderId",
			description = "Checking the Order Details By using invalid order Id ")
	public void InvalidOrderId() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/552146321359?postalCode=" + testData.get("WI_BILLING_POSTAL_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9252", "This Order Number does not exist. Please double-check the number you entered and try again. If you continue to have problems, please call Customer Service toll free at 1-866-887-8884.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/552146321359?postalCode=" + testData.get("WI_BILLING_POSTAL_CODE");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order Invalid postalCode",
			dependsOnMethods = "test.java.adapters.order.applepay.PlaceOrder.applepayPlaceOrder", description = "Checking the Order Details By using invalid postal code ")
	public void InvalidPostalCode() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("applepay_order_number_adapter") + "?postalCode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9253", "This ZIP Code does not match the Order Number.  Please double-check the ZIP Code you've entered and try again.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("applepay_order_number_oapi") + "?postalCode=95035";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order Invalid postalCode and orderId",
			description = "Checking the Order Details By using invalid postal code ")
	public void InvalidPC_AndOrderId() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/552146321359?postalCode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9252", "this order number does not exist. please double-check the number you entered and try again. if you continue to have problems, please call customer service toll free at 1-866-887-8884.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/552146321359?postalCode=95035";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

}
