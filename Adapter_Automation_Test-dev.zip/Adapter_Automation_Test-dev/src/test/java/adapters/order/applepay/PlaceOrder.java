package test.java.adapters.order.applepay;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;
import test.java.adapters.smoke.SmokeTest;

@Features("ApplePay")
@Stories({ "Place Order" })
public class PlaceOrder {

	ResponseValidator validator;

	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout", "errorhandling" }, enabled = true, priority = 7, testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay")
	@Severity(SeverityLevel.BLOCKER)

	public void applepayPlaceOrder() {

	//	TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateCustomerInfo();
			
			// Set orderNumber from response in test data
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_adapter");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE");


		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_oapi");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE1");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay")
	@Severity(SeverityLevel.BLOCKER)

	public void BillShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Invalid Sku",
			description = "Verify whether the error is getting if we pass the wrong SKUCode")
	@Severity(SeverityLevel.BLOCKER)

	public void InvalidSku() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", "949161756", "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3000", "sku (949161756) not found.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", "949161756", "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Invalid paymentDetails",
			description = "Verify whether correct error is getting displayed when paymentDetails is given anything other than APPLEPAY in PlaceOrder request")
	@Severity(SeverityLevel.BLOCKER)

	public void InvalidPaymentDetails() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"VISA\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0002", "We encountered issue processing your request, please try again later");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VISA\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Without City State PostalCode",
			description = "Verify whether correct error is getting when passing the PlaceOrder request with paymentDetails=APPLEPAY and without city,state,postalCode of shipAddress")
	@Severity(SeverityLevel.BLOCKER)

	public void withoutCityStatePC() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("EMPTY_CITY_STATE_PC") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter City.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("EMPTY_CITY_STATE_PC") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Negative Qty",
			description = "Verify whether the Correct error  is getting in response if we pass theplace Order request with negative quantity")
	@Severity(SeverityLevel.BLOCKER)

	public void NegativeQty() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "-1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Qty.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "-1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Missing BillAddress",
			description = "Verify whether the error is getting displayed if we pass the request without billing address")
	@Severity(SeverityLevel.BLOCKER)

	public void withoutBillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"fasle\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Billing Address.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Missing CustomerDetails",
			description = "Verify whether the error is getting displayed when the request is passed without Customer Name,fnmae,lname and email")
	@Severity(SeverityLevel.BLOCKER)

	public void withoutCustomerDetails() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":{"
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Customer Name.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":{"
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" ,"errorhandling"}, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Missing Shipping Address",
			description = "Verify whether error is getting if we pass the request without shipping address")
	@Severity(SeverityLevel.BLOCKER)

	public void withoutShippingAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Shipping Address.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Missing Shipping Method",
			description = "Verify whether correct error is getting displayed when the request is passed without shipping method")
	@Severity(SeverityLevel.BLOCKER)

	public void withoutShippingMethod() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_APPLEPAY", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Shipping Method.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_APPLEPAY", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Multiple ShipAddres",
			description = "Verify whether correct error is getting displayed when the request is passed without shipping method")
	@Severity(SeverityLevel.BLOCKER)

	public void MultipleShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("DUPLICATE") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR2700", "Invalid JSON: Unrecognized field shipAddress");

		// Set orderNumber from response in test data
		// .setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("DUPLICATE") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Without City State and Postal Code",
			description = "Verify whether error is getting when passing the request without passing city,state and postal code in Billing address in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void WithoutCityStateAndPC() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("EMPTY_CITY_STATE_PC") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter City.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("EMPTY_CITY_STATE_PC") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Without Bill And Ship Address",
			description = "Verify whether error is getting displayed if we pass the PlaceOrder request without shipping and billing address")
	@Severity(SeverityLevel.BLOCKER)

	public void WithoutBillShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "]"
				+ ", \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter shipping Address.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "]"
					+ " ,\"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Without Payment token",
			description = "Verify whether error is getting when passing the request without passing city,state and postal code in Billing address in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void WithoutPaymentToken() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}]"
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Payment Token.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "]}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder ShipAddress Not As Same",
			description = "Verify whether the PlaceOrder is getting successful if we Pass the shipping address in the request which is not same as The shipping address in Passbook")
	@Severity(SeverityLevel.BLOCKER)

	public void ShipAddressNotSame() {

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":false,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI")
					+ "\"},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":false,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Qty Exceeds",
			description = "Verify whether Correct error code is getting if we use quantity more than the available quantity of the item")
	@Severity(SeverityLevel.BLOCKER)

	public void QtyExceeds() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1000") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9456", "The quantity specified exceeds the available quantity.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1000") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With Wrong shipAddress",
			description = "Verify whether correct error is getting if we pass wrong shipping address to the request")
	@Severity(SeverityLevel.BLOCKER)

	public void WrongCombinationOfAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("ANOTHER_CITY_POSTALCODE") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9277", "According to our system, the City, State and ZIP Code combination you've entered has an error. Please enter a valid City, State and ZIP Code combination.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shippingMethod\":\"USSTD\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("ANOTHER_CITY_POSTALCODE") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With Wrong billAddress",
			description = "Verify whether correct error is getting successful if we pass wrong billing address to the request")
	@Severity(SeverityLevel.BLOCKER)

	public void WrongCombinationOfBillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("ANOTHER_CITY_POSTALCODE") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9277", "According to our system, the City, State and ZIP Code combination you've entered has an error. Please enter a valid City, State and ZIP Code combination.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("ANOTHER_CITY_POSTALCODE") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder Alphanumeric Sku",
			description = "Verify whether the error is getting displayed if we pass Alpha Numeric value for Skucode")
	@Severity(SeverityLevel.BLOCKER)

	public void AlphaNumericSku() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", "89570286A", "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3000", "sku (89570286a) not found.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", "89570286A", "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling","opm46"}, enabled = true, priority = 9, testName = "ApplePay PlaceOrder MultiCountyZipCode",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY while passing the request with  postal code span across multiple counties")
	@Severity(SeverityLevel.BLOCKER)

	public void MultiCountyZipCode_BillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateCustomerInfo();

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shippingMethod\":\"USSTD\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling","opm46"}, enabled = true, priority = 9, testName = "ApplePay PlaceOrder MultiCountyZipCode",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY while passing the request with  postal code span across multiple counties")
	@Severity(SeverityLevel.BLOCKER)

	public void MultiCountyZipCode_ShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9280", "your zip code spans multiple counties.  please select your county.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shippingMethod\":\"USSTD\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling","opm46"}, enabled = true, priority = 9, testName = "ApplePay PlaceOrder MultiCountyZipCode",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY while passing the request with  postal code span across multiple counties")
	@Severity(SeverityLevel.BLOCKER)

	public void MultiCountyZipCode_BothShipandBillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9280", "your zip code spans multiple counties.  please select your county.");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shippingMethod\":\"USSTD\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APPLEPAY_TOKEN_OAPI") + "}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
			// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder with KohlsCash And Promocode",
			description = "Verify whether the Place Order is successful if we pass Kohls Cash and promo code in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void KohlsCashAndPromoCode() {

		String arr[]=TestData.createKohlsCash(10);
		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("APPLEPAY_SKU") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("APPLEPAY_SKU"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("APPLEPAY_SKU") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"paymentToken\":\"" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN_OAPI")
					+ "\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan1223@gmail.com.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID,payload.order.paymentTypes.creditCards.cardNum,payload.order.paymentTypes.kohlsCash.balance", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With KohlsCash")
	// dependsOnMethods="test.java.adapters.smoke.SmokeTest.KohlsCashBalance",description = "Verify whether the Place Order is successful if we pass Kohls Cash as a Payment Type in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void KohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		// Post the requestSKU_APPLEPAY
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"paymentToken\":\"" + testData.get("APAY_KOHLSCASH_TOKEN_OAPI")
					+ "\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With PromoCode",
			description = "Verify whether the Place Order is successful if we pass Promocode in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void Promocode() {								

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_LESS_THAN_TEN_DOLLAR") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\"" +testData.get("PROMOCODE")+ "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_LESS_THAN_TEN_DOLLAR") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"paymentToken\":\"" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN_OAPI")
					+ "\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With InvalidPromoCode",
			description = "Verify whether error is getting in the response if we pass wrong Promocode  in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void InvalidPromocode() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":"
				+ "{\"cartItems\":[{\"skuCode\":\"" + testData.get("APPLEPAY_SKU") + "\","
				+ "\"qty\":1,\"giftWrapItem\":false,"
				+ "\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},"
				+ "\"shippingMethod\":\"USSTD\"}],"
				+ "\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],"
				+ "\"paymentDetails\":\"APPLEPAY\","
				+ "\"promoCodes\":[{\"code\":\"SAL1021\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN") + "},"
				+ "\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},"
				+ "\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},"
				+ "\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9124", "The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code.");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("APPLEPAY_SKU") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"cardNum\":\"4059557030007612\",\"nameOnCard\":\"\",\"type\":\"Visa\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\"SoAolL10\"}],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI")
					+ "\"},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With Invalid kohls Cash Number",
			description = "Verify whether error is getting in the response if we pass wrong Voucher Number  for Kohls Cash in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void InvalidKohlsCashNumber() {

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"1427790338106050\",\"pin\":\"1234\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for kohlsCashNum.");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"1427790338106050\",\"pin\":\"6849\"}],\"paymentToken\":\"" + testData.get("APAY_KOHLSCASH_TOKEN_OAPI")
					+ "\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With Invalid kohls Cash Pin",
			description = "Verify whether error is getting in the response if we pass wrong Voucher Pin  for Kohls Cash in the request")
	@Severity(SeverityLevel.BLOCKER)

	public void InvalidKohlsCashPin() {

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"142779033810605\",\"pin\":\"1234\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"county\":\"00\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9011", "We're sorry, but the Kohl's Cash & Rewards/PIN number does not match our records. Please check the number and try again.");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"142779033810605\",\"pin\":\"6849\"}],\"paymentToken\":\"" + testData.get("APAY_KOHLSCASH_TOKEN_OAPI")
					+ "\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "PlaceOrderRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do OrderCalc with RegistryItem paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

	
	public void ApplePayPlaceOrderWithRegistryAndBopusKohlscashGuestUser() {
		
		String arr[]=TestData.createKohlsCash(10);
		
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":["
				+  JsonString.getCartJson("REGISTRY", testData.get("SKU_APPLEPAY"), "2") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"},"
				+ JsonString.getBopusCartJson("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],"
				+ "\"paymentDetails\":\"APPLEPAY\","
				+"\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],"
				+ "\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		        + "},"
		        + "\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},"
		        + "\"isBillAddressEqualtoShipAddress\":true,"
		        + "\"shipAddress\":{\"firstName\":\"Subha\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},"
		        + "\"customerName\": " + JsonString.getCustomerNameJson("VALID") + ","
		        + "\"email\":\"shan123@gmail.com.com\""
		        + "}}}";
	
	String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validateshipAddress();
	//validator.validateshipAddressRegistrySku();
	validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
	validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
	validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
	validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

	
}
	
	@Test(groups = { "PlaceOrderRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do OrderCalc with RegistryItem paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

	
	public void ApplePayPlaceOrderWithBopusAndRegistryPromoGuestUser() {
		
		String arr[]=TestData.createKohlsCash(10);
		
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":["
				+ JsonString.getBopusCartJson("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", testData.get("BOPUS_STORE"))
				+ ","+ JsonString.getCartJson("REGISTRY", testData.get("SKU_APPLEPAY"), "2") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"}"
				+ "],"
				+ "\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],"
				+ "\"paymentDetails\":\"APPLEPAY\","
				+"\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],"
				+ "\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		        + "},"
		        + "\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},"
		        + "\"isBillAddressEqualtoShipAddress\":true,"
		        + "\"shipAddress\":{\"firstName\":\"Subha\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},"
		        + "\"customerName\": " + JsonString.getCustomerNameJson("VALID") + ","
		        + "\"email\":\"shan123@gmail.com.com\""
		        + "}}}";
	
	String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validateshipAddress();
	//validator.validateshipAddressRegistrySku();
	validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
	validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
	validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
	validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

	
}
	
	@Test(groups = { "PlaceOrderRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do OrderCalc with RegistryItem paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

	
	public void ApplePayPlaceOrderWithRegistryAndNormalItemGuestUser() {
		
		String arr[]=TestData.createKohlsCash(30);
		
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":["
				+  JsonString.getCartJson("REGISTRY", testData.get("SKU_APPLEPAY"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"},"
				+ JsonString.getBopusCartJson("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],"
				+ "\"paymentDetails\":\"APPLEPAY\","
				+"\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],"
				+ "\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		        + "},"
		        + "\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},"
		        + "\"isBillAddressEqualtoShipAddress\":true,"
		        + "\"shipAddress\":{\"firstName\":\"Subha\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},"
		        + "\"customerName\": " + JsonString.getCustomerNameJson("VALID") + ","
		        + "\"email\":\"shan123@gmail.com.com\""
		        + "}}}";
	
	String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validateshipAddress();
	validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
	validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
	validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
	validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

	
}
	
	@Test(groups = { "PlaceOrderRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do OrderCalc with RegistryItem paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

	
	public void ApplePayPlaceOrderWithRegistryGuestUserWithGiftcard() {
		
		String arr[]=TestData.createKohlsCash(25);
		
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":["
				+  JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"}"
				+ "],"
				+ "\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],"
				+ "\"paymentDetails\":\"APPLEPAY\","
				+ "\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],"
				+ "\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		        + "},"
		        + "\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},"
		        + "\"isBillAddressEqualtoShipAddress\":true,"
		        + "\"customerName\": " + JsonString.getCustomerNameJson("VALID") + ","
		        + "\"email\":\"shan123@gmail.com.com\""
		        + "}}}";
	
	String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validateshipAddressRegistrySku();
	validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
	validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
	validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
	validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

	
}
		
	@Test(groups = { "PlaceOrderRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do OrderCalc with RegistryItem paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

	
	public void ApplePayPlaceOrderWithRegistryGuestUser() {
		
		String arr[]=TestData.createKohlsCash(25);
		
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":["
				+  JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"}"
				+ "],"
				+ "\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],"
				+ "\"paymentDetails\":\"APPLEPAY\","
				+"\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],"
				+ "\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		        + "},"
		        + "\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},"
		        + "\"isBillAddressEqualtoShipAddress\":true,"
		        + "\"shipAddress\":{\"firstName\":\"Subha\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},"
		        + "\"customerName\": " + JsonString.getCustomerNameJson("VALID") + ","
		        + "\"email\":\"shan123@gmail.com.com\""
		        + "}}}";
	
	String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validateshipAddressRegistrySku();
	validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
	validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
	validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
	validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

	
}
	
	

	

}
