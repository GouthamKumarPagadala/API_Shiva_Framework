package test.java.adapters.order.applepay;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("ApplePay")
@Stories({ "Order Calc" })
public class OrderCalc {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Incorrect PaymentDetails",
			description = "Verify whether correct error is returned when paymentDetails is given anything other than APPLEPAY")
	public void IncorrectPaymentDetails() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"VISA\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for paymentDetails.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling","opm46"}, enabled = true, priority = 7, testName = "ApplePay OrderCalc Zip Spans Over Multi Counties",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY while passing the request with  postal code span across multiple counties")
	public void MultiCountiesZip_shipaddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9280", "Your ZIP Code spans multiple counties.  Please select your county.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling","opm46" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Zip Spans Over Multi Counties",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY while passing the request with  postal code span across multiple counties")
	public void MultiCountiesZip_BillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling","opm46"  }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Zip Spans Over Multi Counties",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY while passing the request with  postal code span across multiple counties")
	public void MultiCountiesZip_BothShipaddressandBillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("MULTI_COUNTY") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9280", "Your ZIP Code spans multiple counties.  Please select your county.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Sku Out Of Stock",
			description = "Verify whether proper error code is getting displayed while passing the request with paymentDetails=APPLEPAY and skuCode which is out of stock")
	public void SkuOutOfStock() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_OUT_OF_STOCK"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER4000", "SKU (" + testData.get("SKU_CODE_OUT_OF_STOCK") + ") out of inventory.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Without Shipping Method",
			description = "Verify whether orderCalc is successful while passing the request with paymentDetails=APPLEPAY without shippingMethod")
	public void outShippingMethod() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_APPLEPAY", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc order Total Difference",
			description = "Verify whether orderTotal is changed while passing paymentDetails=APPLEPAY and different shipping address in the request")
	public void OrderTotalDifference() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_APPLEPAY", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		Utilities.setTestData(strResponse, "payload.order.totals.orderTotal", "order_total_adapter");

		String strPayloadDiffShipAddr = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_APPLEPAY", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponseNew = RestCall.postRequest(ORDERCALC_ADAPTER, strPayloadDiffShipAddr, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponseNew);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		Utilities.setTestData(strResponse, "payload.order.totals.orderTotal", "order_total_adapter1");

		// Comparing the order total from two different shipAddress
		Assert.assertNotEquals("order_total_adapter", "order_total_adapter1");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Get the request
			String strResponseOAPINew = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
			Utilities.compareAdaterOpenApiResponse(strResponseNew, strResponseOAPINew, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Without City State And PostalCode",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY and without city,state,postalCode of shipAddress")
	public void WithoutCityStatePostalCode() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("EMPTY_CITY_STATE_PC") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter City.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Verify whether the user is able to do orderCalc with cartItems(Normal) + shipAddress and paymentDetais=APPLEPAY")
	public void ShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With Only city state postal code",
			description = "Verify whether place order is successful while doing orderCalc with cartItems(Normal) +billAddress+ isBillAddressEqualtoShipAddress=true+shipping address only with city, state and postal codeand paymentDetais=APPLEPAY")
	public void OnlyCityStatePostalCode() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("ONLY_CITY_STATE_PC") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With Only city state postal code Bill and Ship Address",
			description = "Verify whether place order is successful while doing orderCalc with cartItems(Normal) +billAddress+ isBillAddressEqualtoShipAddress=true+shipping address only with city, state and postal codeand paymentDetais=APPLEPAY")
	public void OnlyCityStatePostalCodeBillShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("ONLY_CITY_STATE_PC") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With Only city state postal code Bill Address",
			description = "Verify whether place order is successful while doing orderCalc with cartItems(Normal) +billAddress+ isBillAddressEqualtoShipAddress=true+shipping address only with city, state and postal codeand paymentDetais=APPLEPAY")
	public void OnlyCityStatePostalCodeBillAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("ONLY_CITY_STATE_PC") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Negative Quantity",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY and passing negative quantities in OrderCalc request")
	public void NegativeQuantity() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "-2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Qty.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc Without Bill And Ship Address",
			description = "Verify whether correct error is returned with paymentDetails=APPLEPAY and passing the OrderCalc request without shipping and billing address tag")
	public void WithoutBillShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "]"
				+ ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Address.");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With Repeated ShipAddresss",
			description = "Verify whether OrderCalc is successful with paymentDetails=APPLEPAY and passing the OrderCalc request with repeated shipping address")
	public void RepeatedShipAddress() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay","ApplePayCheckout","errorhandling"}, enabled = true, priority = 7, testName = "ApplePay OrderCalc With Quantity exceeds",
			description = "Verify whether correct error is returned when the quantity exceeds the available stock")
	public void QtyExceeds() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "1000") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9456", "The quantity specified exceeds the available quantity.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With Promocode",
			description = "Verify whether the OrderCalc is successful if we pass promocode  in the request")
	public void PromoCode() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE_MULTISHIP") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS_MULTISHIP") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\","
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "Promocode should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With KohlsCash",
			description = "Verify whether the OrderCalc is successful if we pass Kohls Cash  in the request")
	public void KohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE_MULTISHIP") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		// validator.nodeEquals("$.payload.order.paymentTypes[0].promoCodes.code",testData.get("PROMOCODE"), "Promocode should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With KohlsCash and promoCode",
			description = "Verify whether the OrderCalc is successful if we pass Kohls Cash  in the request")
	public void KohlsCashPromoCode() {

		String arr[]=TestData.createKohlsCash(10);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
//		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "Promocode should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

}
