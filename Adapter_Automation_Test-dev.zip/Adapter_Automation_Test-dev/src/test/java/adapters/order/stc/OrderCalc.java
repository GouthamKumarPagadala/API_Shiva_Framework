package test.java.adapters.order.stc;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "Order Calculation" })

public class OrderCalc {
	
	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Pass@123";
				Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, Utilities.urlEncodeString(strPaswd), Server.OpenApi, "Access_Tkn_Reg_oapi");
				
				
				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strEmail, Utilities.urlEncodeString(strPaswd), Server.Adapter, "Access_Tkn_Reg_Adapter");
	}
	
	ResponseValidator validator;
	

	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_CA",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to california and with payment type VISA")
	public void OrderCalc_Unregistered_EWaste_CA() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_CT",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to connecticut and with payment type Master and promoCode")
	public void OrderCalc_Unregistered_EWaste_CT() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Connecticut", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_RI",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to road island and with payment type Discover and kohls Cash")
	public void OrderCalc_Unregistered_EWaste_RI() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Road Island", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_FL",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to florida and with payment Amex")
	public void OrderCalc_Unregistered_EWaste_FL() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Florida", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_NJ",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to NJ and with payment KCC")
	public void OrderCalc_Unregistered_EWaste_NJ() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "New Jersey", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_CA",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Unregistered_Mattress_CA() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_Mattress_CT",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Unregistered_Mattress_CT() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Connecticut", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_Mattress_RI",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Unregistered_Mattress_RI() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("RI_PAWTUCKET") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Rhode Island", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_Mattress_FL",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Unregistered_Mattress_FL() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("FL_ORLANDO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Florida", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_Mattress_NJ",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Unregistered_Mattress_NJ() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("NJ_TRENTON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "New Jersey", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_CA",
			description = "Kohls application user wants to verify whether sales tax and fee details are getting displayed in response while doing OrderCalc with normal Item (e-waste recycling fee which is shipped to California)")
	public void OrderCalc_Unregistered_EWaste_Mattress_CA() {
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "," + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[1].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[1].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[1].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_EWaste_PUF_CA",
			description = "Verify whether sales tax and fee details are getting displayed in response while doing OrderCalc with normal Item(e-waste recycling fee which is shipped to california) + bopus Item(public recycling fee)")
	public void OrderCalc_Unregistered_EWaste_PUF_CA() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "," + JsonString.getBopusCartJson("VALID", testData.get("PUF_SKUCODE"), "1", testData.get("PUF_STORE_NUMBER")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".*California.*", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*eWaste Recycling Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".+", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*Public User Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[1].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_Mattress_PUF_CA",
			description = "Verify whether sales tax and fee details are getting displayed in response while doing OrderCalc with normal Item(matress recycling fee) + bopus Item(public recycling fee)")
	public void OrderCalc_Unregistered_Mattress_PUF_CA() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "," + JsonString.getBopusCartJson("VALID", testData.get("PUF_SKUCODE"), "1", testData.get("PUF_STORE_NUMBER")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".*California.*", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*Mattress Recycling Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".+", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*Public User Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[1].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Unregistered_PUF_Bopus",
			description = "Verify whether sales tax and fee details along with the store details (Storenum & State Code) are getting displayed in response while doing OrderCalc with Bopus Item")
	public void OrderCalc_Unregistered_PUF_Bopus() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("PUF_SKUCODE"), "1", testData.get("PUF_STORE_NUMBER")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
//		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].location", ".+", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].name", ".*Public User Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_CA",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to california and with payment type VISA")
	public void OrderCalc_Registered_EWaste_CA() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_CT",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to connecticut and with payment type Master and promoCode")
	public void OrderCalc_Registered_EWaste_CT() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Connecticut", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_RI",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to road island and with payment type Discover and kohls Cash")
	public void OrderCalc_Registered_EWaste_RI() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Road Island", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_FL",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to florida and with payment Amex")
	public void OrderCalc_Registered_EWaste_FL() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Florida", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_NJ",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to NJ and with payment KCC")
	public void OrderCalc_Registered_EWaste_NJ() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "New Jersey", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].cost", "$5.00", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_CA",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Registered_Mattress_CA() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_Mattress_CT",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Registered_Mattress_CT() {
		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Connecticut", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_Mattress_RI",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Registered_Mattress_RI() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("RI_PAWTUCKET") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Rhode Island", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_Mattress_FL",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Registered_Mattress_FL() {
		
		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("FL_ORLANDO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "Florida", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@DiscontinuedTest(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_Mattress_NJ",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item")
	public void OrderCalc_Registered_Mattress_NJ() {
		
		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("NJ_TRENTON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "New Jersey", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_CA",
			description = "Kohls application user wants to verify whether sales tax and fee details are getting displayed in response while doing OrderCalc with normal Item (e-waste recycling fee which is shipped to California)")
	public void OrderCalc_Registered_EWaste_Mattress_CA() {
		
		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "," + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[1].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[1].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[1].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_EWaste_PUF_CA",
			description = "Verify whether sales tax and fee details are getting displayed in response while doing OrderCalc with normal Item(e-waste recycling fee which is shipped to california) + bopus Item(public recycling fee)")
	public void OrderCalc_Registered_EWaste_PUF_CA() {

		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("EWASTE_SKUCODE"), "1") + "," + JsonString.getBopusCartJson("VALID", testData.get("PUF_SKUCODE"), "1", testData.get("PUF_STORE_NUMBER")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".*California.*", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*eWaste Recycling Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".+", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*Public User Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[1].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_Mattress_PUF_CA",
			description = "Verify whether sales tax and fee details are getting displayed in response while doing OrderCalc with normal Item(matress recycling fee) + bopus Item(public recycling fee)")
	public void OrderCalc_Registered_Mattress_PUF_CA() {
		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("MATTRESS_SKUCODE"), "1") + "," + JsonString.getBopusCartJson("VALID", testData.get("PUF_SKUCODE"), "1", testData.get("PUF_STORE_NUMBER")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter,  true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".*California.*", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*Mattress Recycling Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].location", ".+", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[*].name", ".*Public User Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[1].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi,  true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 4, testName = "OrderCalc_Registered_PUF_Bopus",
			description = "Verify whether sales tax and fee details along with the store details (Storenum & State Code) are getting displayed in response while doing OrderCalc with Bopus Item")
	public void OrderCalc_Registered_PUF_Bopus() {
		mapheader.put("access_token", testData.get("Access_Tkn_Reg_Adapter"));
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("PUF_SKUCODE"), "1", testData.get("PUF_STORE_NUMBER")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter,  true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
//		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].location", ".+", "location should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].name", ".*Public User Fee.*", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			mapheader.put("access_token", testData.get("Access_Tkn_Reg_oapi"));
			
			// Post the request
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "stc", "regression1" }, enabled = true, priority = 2, testName = "OrderCalc_Registered_V2",
			description = "Kohls application user to verify whether the sales tax and fee details are getting displayed in response while doing orderCalc with normal item which is shipped to california and with payment type VISA")
	public void OrderCalc_Registered_V2() {

		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Pass@1234";
		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "stc_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("stc_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("EWASTE_SKUCODE"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "stc_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("stc_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("EWASTE_SKUCODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
		validator.nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		validator.nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("stc_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
}