package test.java.adapters.order;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDERS_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDERS_OAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_OAPI;
import static main.java.common.GlobalVariables.strGroup;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "Retrieve Order" })
public class RetrieveOrder {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingInvalidAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Checking the Order Details By using Invalid Access Token")
	public void UsingInvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "ASFDKJ14623H");
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order Using ExpiredAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Checking the Order Details By UsingExpiredAccessToken")
	public void UsingExpiredAccessToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingInvalidOrderId", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Checking the Order Details By UsingInvalidOrderId")
	public void UsingInvalidOrderId() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("47374854685");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9252", "This Order Number does not exist. Please double-check the number you entered and try again. If you continue to have problems, please call Customer Service toll free at 1-866-887-8884.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("45356745465");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, 400);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingInvalidAccessTokenForUser", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Checking the Order Details By UsingInvalidAccessTokenForUser")
	public void UsingInvalidAccessTokenForUser() {

		mapheader.put("access_token", "ASFDKJ14623H");

		// Post the request
		String strResponse = RestCall.getRequest(RETRIEVE_ORDERS_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "ASFDKJ14623H");
			String strURLOAPI = RETRIEVE_ORDERS_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingExpiredAccessTokenForUser", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Checking the Order Details By UsingExpiredAccessTokenForUser")
	public void UsingExpiredAccessTokenForUser() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");

		// Post the request
		String strResponse = RestCall.getRequest(RETRIEVE_ORDERS_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");
		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
			String strURLOAPI = RETRIEVE_ORDERS_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}
	@Test(groups = { "regression", "cancelorder"}, enabled = true, priority = 6, testName = "retrieveOrder_validOrderNumber_postalCode",
			dependsOnMethods = "test.java.adapters.order.CancelOrder.CancelOrder_RegisteredUser",
			description = "Kohls applicaiton user wants to verify whether the cancelled  status are getting populated in order details page ")
	public void retrieveOrderForCancelledOrderwithPostalCode() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_BOPUS_CANCEL")
		+"?postalCode=60290";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
		
	}
	@Test(groups = { "regression", "cancelorder"}, enabled = true, priority = 6, testName = "retrieveOrder_validOrderNumber_Accestoken",
			dependsOnMethods = "test.java.adapters.order.CancelOrder.CancelOrder_RegisteredUser",
			description = "Kohls applicaiton user wants to verify whether the cancelled  status are getting populated in order details page ")
	public void retrieveOrderForCancelledOrderwithAccestoken() {

		mapheader.put("access_token", testData.get("Bopus_access_token_cancel"));
		
		String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_BOPUS_CANCEL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true,mapheader);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
		
	}
}
