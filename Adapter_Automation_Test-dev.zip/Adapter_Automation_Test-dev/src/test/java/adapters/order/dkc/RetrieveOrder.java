package test.java.adapters.order.dkc;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;

public class RetrieveOrder
{
ResponseValidator validator;
	
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_NonTokenizedKohlscash() {

		// Create Request
		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO")
				+ "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_KohlscashEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("KOHLS_CASH_EVENT")
				+ "\",\"pin\": \"" + testData.get("KOHLS_CASH_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_RegisteredUserV2_KohlscashEvent() {

		// creating new profile
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Ocb@1234";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "DKC_access_token_adapter");

				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("DKC_access_token_adapter"));
			
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
						+ "]}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

				// Create Request

				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"TDD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("VISA")
						+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +testData.get("KOHLS_CASH_EVENT") + "\",\"pin\": \"" + testData.get("KOHLS_CASH_EVENT_PIN") +  "\"}]}}}}";

				
				// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.email", "EMAIL_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\""+testData.get("EMAIL_DKC")+"\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse2 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse2);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_Guestuser_Bogo() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_CODE_BOGO_SALE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT")
				+ "\",\"pin\": \"" + testData.get("BRIDAL_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_Guestuser_OfferwithInStore() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "1", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT") + "\",\"pin\": \"" + testData.get("BRIDAL_EVENT_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_RegisteredUserV2_Bogo() {

		// creating new profile
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Ocb@1234";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "DKC_access_token_adapter");

				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("DKC_access_token_adapter"));
			
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CODE_BOGO_SALE"), "2", "674")
						+ "]}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

				// Create Request

				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CODE_BOGO_SALE"), "2", "674", "TDD") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"TDD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("VISA")
						+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("KOHLS_CASH_EVENT") + "\",\"pin\": \"" + testData.get("KOHLS_CASH_EVENT_PIN") + "\"}]"
						+ "}}}}";

				// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.email", "EMAIL_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\""+testData.get("EMAIL_DKC")+"\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse2 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse2);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_RegisteredUserV2_OfferwithInStore() {

		// creating new profile
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Ocb@1234";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "DKC_access_token_adapter");

				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("DKC_access_token_adapter"));
			
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OFFERS"), "2", "674")
						+ "]}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

				// Create Request

				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OFFERS"), "2", "674", "TDD") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"TDD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("VISA")
						+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("KOHLS_CASH_EVENT") + "\",\"pin\": \"" + testData.get("KOHLS_CASH_EVENT_PIN") + "\"}]"
						+ "}}}}";

				// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.email", "EMAIL_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\""+testData.get("EMAIL_DKC")+"\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse2 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse2);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_BirthdayEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +testData.get("KOHLS_CASH_EVENT") + "\",\"pin\": \"" + testData.get("KOHLS_CASH_EVENT_PIN") +  "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_BridalEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT")
				+ "\",\"pin\": \"" + testData.get("BRIDAL_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_DiscoverEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("DISCOVER_EVENT")
				+ "\",\"pin\": \"" + testData.get("DISCOVER_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_LoyaltyEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("LOYALTY_EVENT")
				+ "\",\"pin\": \"" + testData.get("LOYALTY_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_FourKohlscashEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_OFFERS"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("LOYALTY_EVENT")
				+ "\",\"pin\": \"" + testData.get("LOYALTY_EVENT_PIN")
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT")
				+ "\",\"pin\": \"" + testData.get("BRIDAL_EVENT_PIN") 
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("DISCOVER_EVENT")
				+ "\",\"pin\": \"" + testData.get("DISCOVER_EVENT_PIN")
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("BIRTHDAY_EVENT")
				+ "\",\"pin\": \"" + testData.get("BIRTHDAY_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_TwoKohlscashEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("LOYALTY_EVENT")
				+ "\",\"pin\": \"" + testData.get("LOYALTY_EVENT_PIN")
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT")
				+ "\",\"pin\": \"" + testData.get("BRIDAL_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER9000 and message invalid kohlscash is thrown when kohlscash passed is invalid")
	public void retrieveOrder_OneKohlscashEventAndInvalidKOhlscash() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_BOPUS"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + "12548565254"
				+ "\",\"pin\": \"" + testData.get("LOYALTY_EVENT_PIN")
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("LOYALTY_EVENT")
				+ "\",\"pin\": \"" + testData.get("LOYALTY_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9000", "ERR_INVALID_KOHLS_CASH");
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_ThreeKohlscashEvent() {

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("LOYALTY_EVENT")
				+ "\",\"pin\": \"" + testData.get("LOYALTY_EVENT_PIN")
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT")
				+ "\",\"pin\": \"" + testData.get("BRIDAL_EVENT_PIN")
				+ "\"},{\"kohlsCashNum\": \"" + testData.get("DISCOVER_EVENT")
				+ "\",\"pin\": \"" + testData.get("DISCOVER_EVENT_PIN") + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_DKC") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_DKC") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");

				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC")
				+"?postalCode=60290";
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the errorcode ORDER9000 and message invalid kohlscash is thrown when kohlscash passed is invalid")
	public void retrieveOrder_InvalidKohlscash() {

		
				
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +"753951465689" + "\",\"pin\": \"" + "4536" + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9000", "ERR_INVALID_KOHLS_CASH");
		
		
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the errorcode ORDER1000 and message missing kohlscash  is thrown when kohlscash passed is invalid")
	public void retrieveOrder_WithoutKohlscash() {

		
				
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +"" + "\",\"pin\": \"" + "4536" + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "missing required parameter kohlscashnum.");
		
		
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the errorcode ORDER9000 and message check redeem dates is thrown when kohlscash passed is invalid")
	public void retrieveOrder_ExpiredKohlscash() {

		
				
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +testData.get("EXPIRED_KC")+ "\",\"pin\": \"" + "4462" + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9000", "we're sorry! you cannot use your kohls cash to complete this order. please check the redeem dates.");
		
		
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the errorcode ORDER9000 and message check redeem dates is thrown when kohlscash passed is invalid")
	public void retrieveOrder_FutureKohlscash() {

		
				
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("FUTURE_DATE_KC") + "\",\"pin\": \"" + "9551" + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9000", "we're sorry! you cannot use your kohls cash to complete this order. please check the redeem dates.");
		
		
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the errorcode ORDER9011 and message invalid kohlscashpin is thrown when kohlscash passed is invalid")
	public void retrieveOrder_InvalidKohlsPin() {

		
				
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT") + "\",\"pin\": \"" + "4536" + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9011", "we're sorry, but the kohl's cash & rewards/pin number does not match our records. please check the number and try again.");
		
		
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the errorcode ORDER1000 and message missing kohlscashpin is thrown when kohlscash passed is invalid")
	public void retrieveOrder_WithoutKohlsPin() {

		
				
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("BRIDAL_EVENT") + "\",\"pin\": \"" + "" + "\"}]}}}}";



		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "missing required parameter pin.");
		
		
	}
	@Test(groups = { "return_dkc" }, enabled = true, priority = 4, testName = "retrieveOrder_Kohlscash",
			description = "Kohls applicaiton user wants to verify whether the kohlscash has been returned successfully when order has been cancelled")
	public void retrieveOrder_RegisteredUserKohlscashEvent() {

		// Create a new profile through OAPI
		String strBopusEmail = Utilities.getNewEmailID();
		String strBopusPaswd = "bopusphase2";
		Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

		// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
		Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "access_token_dkc");

		// Update cart through Adapter
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_dkc"));

		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("KOHLS_CASH_EVENT")
				+ "\",\"pin\": \"" + testData.get("KOHLS_CASH_EVENT_PIN") + "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_DKC");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "VALUEAPPLIED_DKC");
		
		
		
		// Create Request
				String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_DKC")+ "\",\"action\": \"cancel_order\"}}";
				
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true,mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
			//	validator.nodeEquals("$.payload.message", "The order "+testData.get("ORDER_NUMBER_DKC")+" has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");
				
				
				String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_DKC");
				// Post the request
				String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, true,mapheader);
				// Post the request
				

				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Cancelled", "Order status should be 'Submitted'");
				validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
				validator.nodeEquals("$.payload.order.returnKohlsCashCouponsEarned.totalAmountEarned",testData.get("VALUEAPPLIED_DKC") , "Order should be submitted in the response");	
	}
	
}
