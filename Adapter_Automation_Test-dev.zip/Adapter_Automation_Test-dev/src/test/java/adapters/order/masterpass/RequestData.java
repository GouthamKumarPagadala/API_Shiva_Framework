package test.java.adapters.order.masterpass;


import static main.java.common.GlobalVariables.*;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;


@Features("MasterPass")
@Stories({ "GetRequestData" })

public class RequestData {

	ResponseValidator validator;
	@Test(groups = { "regression","masterpass","MasterPassCheckout"}, enabled = true, priority = 2, testName = "Get Request Data with Valid data",
			description = "Verrify whether the user is able to get requestData for MasterPass with valid data")
	public void getRequestData() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"http://mydomain.com\",\"callbackURL\":\"http://mydomain.com/callback\",\"cartTotal\":\"4304\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.requestToken", "[0-9a-z]+", "requestToken should not be empty");
		validator.nodeMatches("$.payload.checkoutID", "[0-9a-z]+", "checkoutID should not be empty");
		validator.nodeMatches("$.payload.allowedCardTypes", ".*", "allowedCardTypes should not be empty");
		validator.nodeEquals("$.payload.merchantInitStatus", "SUCCESS", "merchantInitStatus should be SUCCESS");
	}
	
	@Test(groups = { "regression","masterpass","MasterPassCheckout"}, enabled = true, priority = 2, testName = "Get Request Data with InValid data - cartTotal",
			description = "Verrify whether the user is able to get requestData for MasterPass with invalid cartTotal")
	public void getRequestDataInvalidCartTotal() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"http://mydomain.com\","
				+ "\"callbackURL\":\"http://mydomain.com/callback\","
				+ "\"cartTotal\":\"0\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PYMT1002", "Error code should be PYMT1002");
		validator.nodeEquals("$.errors[0].message", "Invalid value passed for cartTotal.", "Error message should be Invalid value passed for cartTotal.");
	}
	
	@Test(groups = { "regression","masterpass","MasterPassCheckout",}, enabled = true, priority = 2, testName = "Get Request Data with InValid data callbackURL",
			description = "Verrify whether the user is able to get requestData for MasterPass with invalid callback url")
	public void getRequestDataInvalidCallbackURL() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"http://mydomain.com\","
				+ "\"callbackURL\":\"http://mydomain.comcallback\","
				+ "\"cartTotal\":\"100\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PYMT1002", "Error code should be PYMT1002");
		validator.nodeEquals("$.errors[0].message", "Invalid value passed for callbackURL.", "Error message should be Invalid value passed for callbackURL.");
	}
	
	@Test(groups = { "regression","masterpass","MasterPassCheckout"}, enabled = true, priority = 2, testName = "Get Request Data with InValid data origin URL",
			description = "Verrify whether the user is able to get requestData for MasterPass with invalid origin url")
	public void getRequestDataInvalidOriginURL() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"http:/mydomain.com\","
				+ "\"callbackURL\":\"http://mydomain.com/callback\","
				+ "\"cartTotal\":\"100\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PYMT1002", "Error code should be PYMT1002");
		validator.nodeEquals("$.errors[0].message", "Invalid value passed for originURL.", "Error message should be Invalid value passed for originURL.");
	}
	
	@Test(groups = { "regression","masterpass","MasterPassCheckout"}, enabled = true, priority = 2, testName = "Get Request Data with Empty data - cartTotal",
			description = "Verrify whether the user is able to get requestData for MasterPass with Empty cartTotal")
	public void getRequestDataEmptyCartTotal() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"http://mydomain.com\","
				+ "\"callbackURL\":\"http://mydomain.com/callback\","
				+ "\"cartTotal\":\"\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PYMT1000", "Error code should be PYMT1000");
		validator.nodeEquals("$.errors[0].message", "Missing Required Parameter cartTotal.", "Error message should be Missing Required Parameter cartTotal.");
	}
	
	@Test(groups = { "regression","masterpass","MasterPassCheckout"}, enabled = true, priority = 2, testName = "Get Request Data with Empty data callbackURL",
			description = "Verrify whether the user is able to get requestData for MasterPass with Empty callback url")
	public void getRequestDataEmptyCallbackURL() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"http://mydomain.com\","
				+ "\"callbackURL\":\"\","
				+ "\"cartTotal\":\"100\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PYMT1000", "Error code should be PYMT1000");
		validator.nodeEquals("$.errors[0].message", "Missing Required Parameter callbackURL.", "Error message should be Missing Required Parameter callbackURL.");
	}
	
	@Test(groups = { "regression","masterpass","MasterPassCheckout"}, enabled = true, priority = 2, testName = "Get Request Data with Empty data origin URL",
			description = "Verrify whether the user is able to get requestData for MasterPass with Empty origin url")
	public void getRequestDataEmptyOriginURL() {
		
		String strPayload = "{\"payload\":{\"originURL\":\"\","
				+ "\"callbackURL\":\"http://mydomain.com/callback\","
				+ "\"cartTotal\":\"100\"}}";
		
		String strResponse = RestCall.postRequest(REQUEST_DATA, strPayload, Server.Adapter, false);
		
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PYMT1000", "Error code should be PYMT1000");
		validator.nodeEquals("$.errors[0].message", "Missing Required Parameter originURL.", "Error message should be Missing Required Parameter originURL.");
	}
}
