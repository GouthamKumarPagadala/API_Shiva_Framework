package test.java.adapters.order.masterpass;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;


@Features("MasterPass")
@Stories({ "Order Calc v2" })

public class OrderCalcV2 {
	
	ResponseValidator validator;
		
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")	
	public void VisaCard_BrandID_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void MasterCard_KC_KGC_BrandID_NativeApp() {

		String[] arrKC = TestData.createKohlsCash(20);
		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
				+ "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"VISA\","
				    +"\"expDate\":\"03/2018\"}"
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				    + ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
					+ "\"}]}}}}";
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void Discover_KC_BrandID_NativeApp() {

		String[] arrKC = TestData.createKohlsCash(20);
		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1]
						+ "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=tablet";
			
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"VISA\","
				    +"\"expDate\":\"03/2018\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
					+ "\"}]}}}}";
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void AMEX_PC_BrandID_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"AMEX\","
				    +"\"expDate\":\"03/2018\"}"
				    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") 
					 + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass","OrderCalcRegistryItem" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void VisaCard_Registry_Item_BrandID_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully  ")
	public void VisaCard_Bopus_Item_BrandID_NativeApp() {



		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "masterpass","OrderCalcRegistryItem" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully  ")
	public void VisaCard_Normal_Item_Registry_Item_Bopus_Item_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void VisaCard_BrandID_InStore_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod","masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void MasterCard_KC_Promo_Code_BrandID_NativeApp() {
		
		String[] arrKC = TestData.createKohlsCash(20);

		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
				+ "\"}]}}}}";		


		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"mc\","
				    +"\"expDate\":\"03/2018\"}"
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] + "\"}]}}}}";		

			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void DinnersClub_BrandID_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass","OrderCalcRegistryItem" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")
	public void VisaCard_Registry_Item_Bopus_Item_NativeApp() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = { "masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc response successfully")
	public void VisaCard_BrandID_MobilePhone() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=mobilephone"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=mobilephone";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId Tablet", 
			description = "Verify whether Error PYMT1000 is getting displayed in response when are passing request without checkout url")
	public void Without_checkoutResourceURL() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=mobilephone"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1000", "Missing Required Parameter checkoutResourceURL.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=mobilephone";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId Tablet", 
			description = "Verify whether Error PYMT1000 is getting displayed in response when are passing request without oauthToken")
	public void Without_oauthToken() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=tablet"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1000", "Missing Required Parameter oauthToken.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=tablet";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId desktop", 
			description = "Verify whether Error PYMT1000 is getting displayed in response when are passing request Without oauthVerifier")
	public void Without_oauthVerifier() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=desktop"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"sdf346457354634f\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1000", "Missing Required Parameter oauthVerifier.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=desktop";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Null BrandId ", 
			description = "Verify whether Error PYMT1000 is getting displayed in response when are passing request with Null BrandID")
	public void Without_brandID_value() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID="; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"sdf346457354634f\","
				+"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1000", "Missing Required Parameter brandID.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with invalid BrandId ", 
			description = "Verify whether Error PYMT1002 is getting displayed in response when are passing request with invalid BrandId")
	public void invalid_brandID_value() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=123"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"sdf346457354634f\","
				+"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1002", "Invalid value passed for brandID.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=123";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId desktop", 
			description = "Verify whether Error PYMT1002 is getting displayed in response when are passing request with Malformed checkoutResourceURL")
	public void Malformed_checkoutResourceURL() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=desktop"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"sdf346457354634f\","
				+"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercar2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1002", "Invalid value passed for checkoutResourceURL.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=desktop";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId mobilephone", 
			description = "Verify whether Error PYMT1003 is getting displayed in response when are passing request with invalid token")
	public void invalid_token_value() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=mobilephone"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"abc\","
				+"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1003", "invalid or expired token:oauthtoken.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=123";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@DiscontinuedTest(groups = { "regression", "MasterPassCheckout","masterpass" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId nativeapps", 
			description = "Verify whether Error PYMT1003 is getting displayed in response when are passing request with Expired token")
	public void Expired_token_value() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"abc\","
				+"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PYMT1003", "Invalid or Expired token:oauthtoken.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapps";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using amex card for orderCalc API")
	public void MasterPass_AmexCard() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
			    +"\"type\":\"AMEX\","
			    +"\"expDate\":\"03/2018\"}"
			    + "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
	}
		
		@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Visa Card", 
				description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Visa card for orderCalc API")
	public void MasterPass_VisaCard() {

			String strURL = ORDERCALC_ADAPTER_V2;
			
			// Create Request
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
				    +"\"type\":\"VISA\","
				    +"\"expDate\":\"03/2018\"}"
				    + "]}}}}";
			
					
					

			// Post Request
			String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.validateMasterPassResponse();
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI=ORDERCALC_OAPI_V2; 
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
			}
	}
		
		@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card", 
				description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card for orderCalc API")
	public void MasterPass_MasterCard() {

			String strURL = ORDERCALC_ADAPTER_V2;
			
			// Create Request
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"MC\","
				    +"\"expDate\":\"03/2018\"}"
				    + "]}}}}";
			
					
					

			// Post Request
			String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.validateMasterPassResponse();
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI=ORDERCALC_OAPI_V2; 
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
			}
	}
		
		@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Discover Card", 
				description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Discover card for orderCalc API")
	public void MasterPass_DiscCard() {

			String strURL = ORDERCALC_ADAPTER_V2;
			
			// Create Request
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"zJrKhJ+v4Ze9B9WrNm6NOMAq1fXuULez5Wd5qUJnlYA=0450\","
				    +"\"type\":\"DISC\","
				    +"\"expDate\":\"03/2018\"}"
				    + "]}}}}";

			// Post Request
			String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.validateMasterPassResponse();
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI=ORDERCALC_OAPI_V2; 
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
			}
	}
		
		@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card + PromoCode", 
				description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using amex card + PromoCode for orderCalc API")
	public void MasterPass_AmexCard_Promo() {

			String strURL = ORDERCALC_ADAPTER_V2;
			
			// Create Request
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
				    +"\"type\":\"AMEX\","
				    +"\"expDate\":\"03/2018\"}"
				    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE")+"\"}]}}}}";
			
					
					

			// Post Request
			String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.validatepromoCodeOrderResponse(testData.get("PROMOCODE"), false);
			validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.validateMasterPassResponse();
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI=ORDERCALC_OAPI_V2; 
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
			}
		}
			
			@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Visa Card + PromoCode", 
					description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Visa card + PromoCode for orderCalc API")
	public void MasterPass_VisaCard_Promo() {

				String strURL = ORDERCALC_ADAPTER_V2;
				
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
					    +"\"paymentMethod\":\"MASTERPASS\","
					    +"\"transactionID\":\"442305669\"},"
					    +"\"creditCards\" : [{"
					    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
					    +"\"type\":\"VISA\","
					    +"\"expDate\":\"03/2018\"}"
					    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE")+"\"}]}}}}";
				
						
						

				// Post Request
				String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.validatepromoCodeOrderResponse(testData.get("PROMOCODE"), false);
				validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.validateMasterPassResponse();
				// Compare Open API
				if (CompareOAPI) {
					String strURLOAPI=ORDERCALC_OAPI_V2; 
					// Post the request
					String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
				}
		}
			
			@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card + PromoCode", 
					description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card + PromoCode for orderCalc API")
	public void MasterPass_MasterCard_Promo() {

				String strURL = ORDERCALC_ADAPTER_V2;
				
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
					    +"\"paymentMethod\":\"MASTERPASS\","
					    +"\"transactionID\":\"442305669\"},"
					    +"\"creditCards\" : [{"
					    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
					    +"\"type\":\"MC\","
					    +"\"expDate\":\"03/2018\"}"
					    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE")+"\"}]}}}}";
				
						
						

				// Post Request
				String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.validatepromoCodeOrderResponse(testData.get("PROMOCODE"), false);
				validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.validateMasterPassResponse();
				// Compare Open API
				if (CompareOAPI) {
					String strURLOAPI=ORDERCALC_OAPI_V2; 
					// Post the request
					String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
				}
		}
			
			@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Discover Card + PromoCode", 
					description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Discover card + PromoCode for orderCalc API")
	public void MasterPass_DiscCard_Promo() {

				String strURL = ORDERCALC_ADAPTER_V2;
				
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
					    +"\"paymentMethod\":\"MASTERPASS\","
					    +"\"transactionID\":\"442305669\"},"
					    +"\"creditCards\" : [{"
					    +"\"cardNum\":\"zJrKhJ+v4Ze9B9WrNm6NOMAq1fXuULez5Wd5qUJnlYA=0450\","
					    +"\"type\":\"DISC\","
					    +"\"expDate\":\"03/2018\"}"
					    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE")+"\"}]}}}}";
				
						
						

				// Post Request
				String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.validatepromoCodeOrderResponse(testData.get("PROMOCODE"), false);
				validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.validateMasterPassResponse();
				// Compare Open API
				if (CompareOAPI) {
					String strURLOAPI=ORDERCALC_OAPI_V2; 
					// Post the request
					String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
				}
		}

			@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card + KohlsCash", 
					description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using amex card + KohlsCash for orderCalc API")
	public void MasterPass_AmexCard_KC() {

				String strURL = ORDERCALC_ADAPTER_V2;
				String[] KC = TestData.createKohlsCash(10);
				
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
					    +"\"paymentMethod\":\"MASTERPASS\","
					    +"\"transactionID\":\"442305669\"},"
					    +"\"creditCards\" : [{"
					    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
					    +"\"type\":\"AMEX\","
					    +"\"expDate\":\"03/2018\"}"
					    + "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + KC[0] + "\",\"pin\": \"" + KC[1] + "\"}]}}}}";
				
						
						

				// Post Request
				String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.validateKohlsCashOrderResponse(KC[0], false);
				validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.validateMasterPassResponse();
				// Compare Open API
				if (CompareOAPI) {
					String strURLOAPI=ORDERCALC_OAPI_V2; 
					// Post the request
					String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
				}
			}
				
				@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Visa Card + KohlsCash", 
						description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Visa card + KohlsCash for orderCalc API")
	public void MasterPass_VisaCard_KC() {

					String strURL = ORDERCALC_ADAPTER_V2;
					String[] KC = TestData.createKohlsCash(10);
					
					// Create Request
					String strPayload = "{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\","
							+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"true\","
							+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
						    +"\"paymentMethod\":\"MASTERPASS\","
						    +"\"transactionID\":\"442305669\"},"
						    +"\"creditCards\" : [{"
						    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
						    +"\"type\":\"VISA\","
						    +"\"expDate\":\"03/2018\"}"
						    + "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + KC[0] + "\",\"pin\": \"" + KC[1] + "\"}]}}}}";
					
							
							

					// Post Request
					String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

					// Validate Response
					validator = new ResponseValidator(strResponse);
					validator.validateNoErrors();
					// validator.validateCartResponse();
					validator.validatebillAddress();
					validator.validateshipAddress();
					validator.validatePaymentInfo();
					validator.validateTotal();
					validator.validateKohlsCashOrderResponse(KC[0], false);
					validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
					validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
					validator.validateMasterPassResponse();
					// Compare Open API
					if (CompareOAPI) {
						String strURLOAPI=ORDERCALC_OAPI_V2; 
						// Post the request
						String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

						// Compare the result
						Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
					}
			}
				
				@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card + KohlsCash", 
						description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card + KohlsCash for orderCalc API")
	public void MasterPass_MasterCard_KC() {

					String strURL = ORDERCALC_ADAPTER_V2;
					String[] KC = TestData.createKohlsCash(10);
					
					// Create Request
					String strPayload = "{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\","
							+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"true\","
							+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
						    +"\"paymentMethod\":\"MASTERPASS\","
						    +"\"transactionID\":\"442305669\"},"
						    +"\"creditCards\" : [{"
						    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
						    +"\"type\":\"MC\","
						    +"\"expDate\":\"03/2018\"}"
						    + "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + KC[0] + "\",\"pin\": \"" + KC[1] + "\"}]}}}}";
					
							
							

					// Post Request
					String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

					// Validate Response
					validator = new ResponseValidator(strResponse);
					validator.validateNoErrors();
					// validator.validateCartResponse();
					validator.validatebillAddress();
					validator.validateshipAddress();
					validator.validatePaymentInfo();
					validator.validateTotal();
					validator.validateKohlsCashOrderResponse(KC[0], false);
					validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
					validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
					validator.validateMasterPassResponse();
					// Compare Open API
					if (CompareOAPI) {
						String strURLOAPI=ORDERCALC_OAPI_V2; 
						// Post the request
						String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

						// Compare the result
						Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
					}
			}
				
				@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Discover Card + KohlsCash", 
						description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Discover card + KohlsCash for orderCalc API")
	public void MasterPass_DiscCard_KC() {

					String strURL = ORDERCALC_ADAPTER_V2;
					String[] KC = TestData.createKohlsCash(10);
					
					// Create Request
					String strPayload = "{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\","
							+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"true\","
							+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
						    +"\"paymentMethod\":\"MASTERPASS\","
						    +"\"transactionID\":\"442305669\"},"
						    +"\"creditCards\" : [{"
						    +"\"cardNum\":\"zJrKhJ+v4Ze9B9WrNm6NOMAq1fXuULez5Wd5qUJnlYA=0450\","
						    +"\"type\":\"DISC\","
						    +"\"expDate\":\"03/2018\"}"
						    + "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + KC[0] + "\",\"pin\": \"" + KC[1] + "\"}]}}}}";
					
							
							

					// Post Request
					String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

					// Validate Response
					validator = new ResponseValidator(strResponse);
					validator.validateNoErrors();
					// validator.validateCartResponse();
					validator.validatebillAddress();
					validator.validateshipAddress();
					validator.validatePaymentInfo();
					validator.validateTotal();
					validator.validateKohlsCashOrderResponse(KC[0], false);
					validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
					validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
					validator.validateMasterPassResponse();
					// Compare Open API
					if (CompareOAPI) {
						String strURLOAPI=ORDERCALC_OAPI_V2; 
						// Post the request
						String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

						// Compare the result
						Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
					}
			}

	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card + GiftCard", 
						description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using amex card + GiftCard for orderCalc API")
	public void MasterPass_AmexCard_GC() {

					String strURL = ORDERCALC_ADAPTER_V2;
					
					// Create Request
					String strPayload = "{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\","
							+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"true\","
							+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
						    +"\"paymentMethod\":\"MASTERPASS\","
						    +"\"transactionID\":\"442305669\"},"
						    +"\"creditCards\" : [{"
						    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
						    +"\"type\":\"AMEX\","
						    +"\"expDate\":\"03/2018\"}"
						    + "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
					
							
							

					// Post Request
					String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

					// Validate Response
					validator = new ResponseValidator(strResponse);
					validator.validateNoErrors();
					// validator.validateCartResponse();
					validator.validatebillAddress();
					validator.validateshipAddress();
					validator.validatePaymentInfo();
					validator.validateTotal();
					validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
					validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
					validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
					validator.validateMasterPassResponse();
					// Compare Open API
					if (CompareOAPI) {
						String strURLOAPI=ORDERCALC_OAPI_V2; 
						// Post the request
						String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

						// Compare the result
						Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
					}
				}
					
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Visa Card + GiftCard", 
							description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Visa card + GiftCard for orderCalc API")
	public void MasterPass_VisaCard_GC() {

						String strURL = ORDERCALC_ADAPTER_V2;
						
						// Create Request
						String strPayload = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\","
								+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
							    +"\"paymentMethod\":\"MASTERPASS\","
							    +"\"transactionID\":\"442305669\"},"
							    +"\"creditCards\" : [{"
							    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
							    +"\"type\":\"VISA\","
							    +"\"expDate\":\"03/2018\"}"
							    + "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
						
								
								

						// Post Request
						String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

						// Validate Response
						validator = new ResponseValidator(strResponse);
						validator.validateNoErrors();
						// validator.validateCartResponse();
						validator.validatebillAddress();
						validator.validateshipAddress();
						validator.validatePaymentInfo();
						validator.validateTotal();
						validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
						validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
						validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						validator.validateMasterPassResponse();
						// Compare Open API
						if (CompareOAPI) {
							String strURLOAPI=ORDERCALC_OAPI_V2; 
							// Post the request
							String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

							// Compare the result
							Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
						}
				}
					
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card + GiftCard", 
							description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card + GiftCard for orderCalc API")
	public void MasterPass_MasterCard_GC() {

						String strURL = ORDERCALC_ADAPTER_V2;
						
						// Create Request
						String strPayload = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\","
								+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
							    +"\"paymentMethod\":\"MASTERPASS\","
							    +"\"transactionID\":\"442305669\"},"
							    +"\"creditCards\" : [{"
							    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
							    +"\"type\":\"MC\","
							    +"\"expDate\":\"03/2018\"}"
							    + "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
						
								
								

						// Post Request
						String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

						// Validate Response
						validator = new ResponseValidator(strResponse);
						validator.validateNoErrors();
						// validator.validateCartResponse();
						validator.validatebillAddress();
						validator.validateshipAddress();
						validator.validatePaymentInfo();
						validator.validateTotal();
						validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
						validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
						validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						validator.validateMasterPassResponse();
						// Compare Open API
						if (CompareOAPI) {
							String strURLOAPI=ORDERCALC_OAPI_V2; 
							// Post the request
							String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

							// Compare the result
							Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
						}
				}
					
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Discover Card + GiftCard", 
							description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Discover card + GiftCard for orderCalc API")
	public void MasterPass_DiscCard_GC() {

						String strURL = ORDERCALC_ADAPTER_V2;
						
						// Create Request
						String strPayload = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\","
								+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
							    +"\"paymentMethod\":\"MASTERPASS\","
							    +"\"transactionID\":\"442305669\"},"
							    +"\"creditCards\" : [{"
							    +"\"cardNum\":\"zJrKhJ+v4Ze9B9WrNm6NOMAq1fXuULez5Wd5qUJnlYA=0450\","
							    +"\"type\":\"DISC\","
							    +"\"expDate\":\"03/2018\"}"
							    + "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

						// Post Request
						String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

						// Validate Response
						validator = new ResponseValidator(strResponse);
						validator.validateNoErrors();
						// validator.validateCartResponse();
						validator.validatebillAddress();
						validator.validateshipAddress();
						validator.validatePaymentInfo();
						validator.validateTotal();
						validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
						validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
						validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						validator.validateMasterPassResponse();
						// Compare Open API
						if (CompareOAPI) {
							String strURLOAPI=ORDERCALC_OAPI_V2; 
							// Post the request
							String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

							// Compare the result
							Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
						}
				}
	
	@Test(groups = {"retest","masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card and Bopus Item", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card and BopusItem for orderCalc API")
	public void MasterPass_Bopus() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_MASTERPASS"), "2", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"MC\","
			    +"\"expDate\":\"03/2018\"}"
			    + "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateBopusItem(testData.get("SKU_MASTERPASS"),testData.get("BOPUS_STORE"));
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
}
	
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card and InstoreMode", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card for orderCalc API with InstoreMode")
	public void MasterPass_Instore() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"MC\","
			    +"\"expDate\":\"03/2018\"}"
			    + "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateOrderInstoreResponse(false, true, true);
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
}
	
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Master Card and byPass paymentDetails", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Master card for orderCalc APIand byPass paymentDetails")
	public void MasterPass_ByPass() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"Apple\",\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"MC\","
			    +"\"expDate\":\"03/2018\"}"
			    + "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
}
	
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Visa Card and invalid paymnetMethod", 
			description = "Verify user gets proper error message when passing invalid paymnetMethod")
	public void MasterPass_InvalidPaymentMethod() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPSS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
			    + "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.error.code", "ORDER1002", "User should get error code \"ORDER1002\"");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.error.message", "Invalid value passed for paymentMethod.", "User should get error message \"Invalid value passed for paymentMethod.\"");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
}
	
	@Test(groups = {"masterpass","regression"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Visa Card and invalid cardNumber", 
			description = "Verify user gets proper error message when passing invalid card Number")
	public void MasterPass_InvalidCardNum() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"4445222299990007\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
			    + "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].error.code", "ORDER9982", "User should get error code \"ORDER9982\"");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].error.message", "The credit card number is not valid for the specified credit card type.", "User should get error message \"The credit card number is not valid for the specified credit card type.\"");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
}
}
