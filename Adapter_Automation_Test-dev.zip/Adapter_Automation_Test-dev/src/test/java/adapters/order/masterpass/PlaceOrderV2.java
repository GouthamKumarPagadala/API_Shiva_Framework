package test.java.adapters.order.masterpass;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("MasterPass")
@Stories({ "Place Order v2" })

public class PlaceOrderV2 
{
	ResponseValidator validator;
			
	@Test(groups = {"masterpass","MasterPassCheckout","regression","GroupPricing"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId with sku whose sale price value is sale", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully and validate whether saleprice is present since salepricelabel is sale")
	public void PlaceOrderV2_masterpass_with_Sku_whose_SalepriceValue_is_sale() {

		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_SALEPRICESALE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"masterpass\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";

				
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		
		//validate salesprice
		 validator.nodeMatches("$.payload.order.cartItems[0].price.salePrice", ".+", "sale price should be  in the response");
	     validator.nodeEquals("$.payload.order.cartItems[0].price.salePriceLabel","sale","saleprice label should be sale in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	

	@Test(groups = {"masterpass","MasterPassCheckout","regression","GroupPricing"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId and sku with sale price value as null", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully and validate whether sale price is null as salePriceLabel is null")
	
    public void PlaceOrderV2_masterpass_with_Sku_whose_Saleprice_is_Null () {

		String[] arrKC = TestData.createKohlsCash(50);
		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_SALEPRICENULL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
				+ "\"}]}}}}";

				
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		
		//validate salesprice
		 validator.nodeEquals("$.payload.order.cartItems[0].price.salePrice", "null", "sale price should be null in the response");
	     validator.nodeEquals("$.payload.order.cartItems[0].price.salePriceLabel","null","saleprice label should be null in the response");

		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully")
	public void VisaCard_InStoreEnabledTrue() {

			String[] arrKC = TestData.createKohlsCash(20);
			String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
			// Create Request
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"inStoreEnabled\":true,"
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
				    +"\"type\":\"VISA\","
				    +"\"expDate\":\"03/2018\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
					+ "\"}]}}}}";

					
			
					
					

			// Post Request
			String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
			validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
			}
		}

	
	@DiscontinuedTest(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully")
	public void VisaCard_paymentMethod_VC() {

		String[] arrKC = TestData.createKohlsCash(20);
		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"VC\","  
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
				+ "\"}]}}}}}";

				
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@DiscontinuedTest(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully")
	public void VisaCard_paymentMethod_ApplePay() {

		String[] arrKC = TestData.createKohlsCash(20);
		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"APPLEPAY\","
			    +"\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] 
				+ "\"}]}}}}}";

				
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using amex card and promocode to placeorder response successfully")
	public void AmexCard_Promocode() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
			    +"\"type\":\"AMEX\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") 
				 + "\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using discover card and gift card to placeorder response successfully")
	public void Discover_KC_masterPASS() {
		
		String[] arrKC = TestData.createKohlsCash(40);

		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"1E73yH1uEH6hsVzDucOaIMAq1fXuULez5Wd5qUJnlYA=0004\","
			    +"\"type\":\"DISC\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] + "\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	
	@DiscontinuedTest(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using diners club  card to placeorder response successfully")
	public void DinnerClub() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"AMEX\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression", "NuData"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully")	
	public void MasterCard_Kohlscash_Promocode() {

		String[] arrKC = TestData.createKohlsCash(50);
		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] + "\"}]}}}}";		

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			String[] arrKC1 = TestData.createKohlsCash(40);
			// Create Request
			String strPayloadoapi = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"mc\","
				    +"\"expDate\":\"03/2018\"}"
				    + "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC1[0] + "\",\"pin\": \"" + arrKC1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using visa card and kohlscash to placeorder response successfully")
	public void MasterCard_KohlsGiftCard_MASTERPASS() {

		String[] arrKC = TestData.createKohlsCash(40);
		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+"}}}}";		

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			String[] arrKC1 = TestData.createKohlsCash(40);
			// Create Request
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				    +"\"paymentMethod\":\"MASTERPASS\","
				    +"\"transactionID\":\"442305669\"},"
				    +"\"creditCards\" : [{"
				    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
				    +"\"type\":\"mc\","
				    +"\"expDate\":\"03/2018\"}"
				    + "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+"}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using bopus item to placeorder response successfully")
	public void VISA_Bopus() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; ;
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","PlaceOrderRegistryItem","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using master card to placeorder response successfully")
	public void MasterpassCheckoutWithRegistryAndNormal() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"masterpass","MasterPassCheckout","regression","PlaceOrderRegistryItem"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using master card to placeorder response successfully")
	public void MasterpassCheckoutWithRegistry_Bopus() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"masterpass","MasterPassCheckout","regression","PlaceOrderRegistryItem"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using master card to placeorder response successfully")
	public void MasterpassCheckoutWithRegistry() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether Error ORDER1000 is getting displayed in response when are passing request without payment method")
	public void missing_Payment_Method() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000","Missing Required Parameter paymentMethod.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether Error ORDER1002 is getting displayed in response when are passing request without payment method")
	public void without_Payment_Method() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002","Invalid value passed for paymentMethod.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether Error ORDER1002 is getting displayed in response when are passing request invalid payment method")
	public void with_invalid_Payment_Method() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MC\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002","Invalid value passed for paymentMethod.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether Error ORDER1000 is getting displayed in response when are passing request without transaction id")
	public void missing_Transaction_ID() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000","Missing Required Parameter transactionID.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether Error ORDER1002 is getting displayed in response when are passing request without transaction id")
	public void without_Transaction_ID() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002","Invalid value passed for transactionID.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = {"masterpass","MasterPassCheckout","regression"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether Error ORDER1000 is getting displayed in response when are passing request invalid transaction id")
	public void with_invalid_Transaction_ID() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"453488sds\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"aDkD14gCSjQbUYI51WvvRbqeOyZkmTBz1iGH0nUDRm0=4444\","
			    +"\"type\":\"mc\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002","Invalid value passed for transactionID.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}

	
	
}
