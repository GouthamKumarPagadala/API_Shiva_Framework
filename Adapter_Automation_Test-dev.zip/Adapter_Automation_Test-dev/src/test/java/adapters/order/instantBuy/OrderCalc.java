package test.java.adapters.order.instantBuy;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_INSTANTBUY_V2;
import static main.java.common.GlobalVariables.ORDERCALCV2_OAPI_INSTANTBUY_V2;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.apache.commons.lang3.ArrayUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Instant Buy")
@Stories({ "Order Calc" })
public class OrderCalc {
	ResponseValidator validator;

	String strEmail = Utilities.getNewEmailID();
	String strPaswd = "Pass@123";


	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI

		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfileV2(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");


		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfileV2(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
	}

	@BeforeMethod(alwaysRun = true)
	public void testSetup1(){

		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));

	}


	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Instant buy feature - Master card")
	public void InstantBuyOrderCalcWithMasterCard_AsARegisteredUser() {


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"3\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Instant buy feature- Amex card ")
	public void InstantBuyOrderCalcWithAmexCard_AsARegisteredUser() {


		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"3\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","instantbuy","regression","smokeTest" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Instant buy feature- Discover card ")
	public void InstantBuyOrderCalcWithDiscoverCard_AsARegisteredUser() {
		TestData.getRunTimeData("SKU_CODE", false);

		Utilities.AddItemtoCart(testData.get("RUNTIME_SKU_CODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") 
				+ "\",\"skuCode\":\"" + testData.get("RUNTIME_SKU_CODE") + "\", \"qty\":\"3\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Instant buy feature- KCC card ")
	public void InstantBuyOrderCalcWithKCC_Card_AsARegisteredUser() {


		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"3\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Amex card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")

	public void InstantBuyOrderCalcWithAmexCard_Promocode_AsARegisteredUser() {


		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);



		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Master card \n Feature -validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void InstantBuyOrderCalcWithMasterCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("PROMOCODE")};

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateCustomerInfo();

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Discover card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void InstantBuyOrderCalcWithDiscoverCard_Promocode_AsARegisteredUser() {

		String[] promoCodes = {testData.get("PROMOCODE")};
		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateCustomerInfo();

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Visa card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void InstantBuyOrderCalcWithVisaCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes ={testData.get("PROMOCODE")};
		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateCustomerInfo();

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with KCC card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void InstantBuyOrderCalcWithKCCCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card and GiftCard",
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Visa Card and Giftcard <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")

	public void InstantBuyOrderCalcWithApplePay_Visa_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Visa Card and PromoCode",
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Visa Card and Promocode <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithApplePay_Visa_Promo() {

		String[] promoCodes={testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);				

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();


		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Visa Card and KohlsCash",
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Visa Card and Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithApplePay_Visa_KC() {

		String arr[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and PromoCode",
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Amex Card and promocode <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithApplePay_Amex_Promo() {

		String[] promoCodes={testData.get("PROMOCODE")};

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();


		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"InstantBuy","instantbuy","regression"}, enabled = true, priority = 4, testName = "Order Calc Registered User Instore Mode- Master Card with Kohl's Cash", 
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with Instore freeshipping in the request \n Feature - Master Card and Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithInstoreFreeShip_Master_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);


		String[] KohlsCash = ArrayUtils.addAll(arr);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"InstantBuy","instantbuy","regression"}, enabled = true, priority = 4, testName = "V2 Ordercalculation for Registered User Instore Mode- Master card and Kohls Cash",
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with Instore freeshipping in the request \n Feature - KCC Card and Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithInStoreFreeShip_KCC_KC() {

		String arr[]=TestData.createKohlsCash(10);



		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"InstantBuy","instantbuy","regression"}, enabled = true, priority = 4, testName = "V2 Ordercalculation for Registered User Instore Mode- Master card and Kohls Cash + GiftCard", 
			description = "\n TC Description -Verify whether user able to do OrderCalc V2 with Instore freeshipping in the request \n Feature - KCC Card,Gift card Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithInStoreFreeShip_KCC_KC_GC() {			


		String arr[]=TestData.createKohlsCash(1);



		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Master card<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithBopusItemUsingMasterCard() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "]"
						+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");


		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",

			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Amex card,Promocode and kohlscash<br /> Bopus DIE phase2 changes<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithBopusItemUsingAmexCard() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression"}, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",

			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Giftcard,promo,Kohlscash<br /> Bopus DIE phase2 changes<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithBopusItemUsingGiftcardAndPromocode() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
						+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","instantbuy","regression" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",

			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Amex Card and GC,KC<br /> Bopus DIE phase2 changes<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyOrderCalcWithBopusItemUsingVisacardAndPromocode() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
						+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALCV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


}