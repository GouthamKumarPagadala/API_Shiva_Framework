package test.java.adapters.order.instantBuy;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI_INSTANTBUY_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER_INSTANTBUY_V2;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.apache.commons.lang3.ArrayUtils;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Instant Buy")
@Stories({ "Place order" })
public class PlaceOrder {
	String strEmail = Utilities.getNewEmailID();
	String strPaswd = "Pass@123";
	ResponseValidator validator;
	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI

		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfileV2(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");


		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfileV2(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
	}
	@BeforeMethod(alwaysRun = true)
	public void testSetup1(){

		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));

	}


	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "Kohl's application user wants to do placeOrder-v2 with Instant buy feature - Master card")
	public void InstantBuyPlaceOrderWithMasterCard_AsARegisteredUser() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","regression","smokeTest" }, enabled = true, priority = 2, 
			testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "Kohl's application user wants to do placeOrder-v2 with Instant buy feature- Amex card ")
	public void InstantBuyPlaceOrderWithAmexCard_AsARegisteredUser() {

		
		TestData.getRunTimeData("SKU_CODE", false);
		Utilities.AddItemtoCart(testData.get("RUNTIME_SKU_CODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("RUNTIME_SKU_CODE"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
	}
	}
	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "Kohl's application user wants to do placeOrder-v2 with Instant buy feature- Discover card ")
	public void InstantBuyPlaceOrderWithDiscoverCard_AsARegisteredUser() {


		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "Kohl's application user wants to do placeOrder-v2 with Instant buy feature- KCC card ")
	public void InstantBuyPlaceOrderWithKCC_Card_AsARegisteredUser() {


		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.validateCustomerInfo();
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do placeOrder-v2 with Amex card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors")

	public void InstantBuyPlaceOrderWithAmexCard_Promocode_AsARegisteredUser() {


		String[] PromoCodes = {testData.get("PROMOCODE")};

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponse);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do placeOrder-v2 with Master card \n Feature -validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithMasterCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "4", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateCustomerInfo();
		
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do placeOrder-v2 with Discover card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithDiscoverCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "3", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do placeOrder-v2 with Visa card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithVisaCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 2, testName = "Placeorder V2_verify whether that Placeorder V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do placeOrder-v2 with KCC card \n Feature - validate if orderType=instant in the request,user should be able to place order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithKCCCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "InstantBuy","regression"}, enabled = true, priority = 7, testName = "PlaceOrder V2 with PaymentDetails=ApplePay with Visa Card and GiftCard",
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Visa Card and Giftcard <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")

	public void InstantBuyPlaceOrderWithApplePay_Visa_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "1", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and PromoCode",
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Visa Card and Promocode <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithApplePay_Visa_Promo() {


		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "3", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);


		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and KohlsCash",
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Visa Card and Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithApplePay_Visa_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "4", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and PromoCode",
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with paymentDetails=APPLEPAY while passing the request \n Feature - Amex Card and promocode <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithApplePay_Amex_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "3", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);


		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"InstantBuy","regression"}, enabled = true, priority = 4, testName = "Order Calc Registered User Instore Mode- Master Card with Kohl's Cash", 
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with Instore freeshipping in the request \n Feature - Master Card and Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithInstoreFreeShip_Master_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "3", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "4", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"InstantBuy","regression"}, enabled = true, priority = 4, testName = "V2 PlaceOrder for Registered User Instore Mode- Master card and Kohls Cash",
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with Instore freeshipping in the request \n Feature - KCC Card and Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithInStoreFreeShip_KCC_KC() {
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"InstantBuy","regression"}, enabled = true, priority = 4, testName = "V2 PlaceOrder for Registered User Instore Mode- Master card and Kohls Cash + GiftCard", 
			description = "\n TC Description -Verify whether user able to do PlaceOrder V2 with Instore freeshipping in the request \n Feature - KCC Card,Gift card Kohlscash <br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithInStoreFreeShip_KCC_KC_GC() {			

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			description =  "\n TC Description - Verify whether user is able to do Place order with Bopus item \n Feature - PlaceOrder with Bopus Item and Non bopus Item using Master card<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithBopusItemUsingMasterCard() {

		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));
	
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayloadPlaceOrder, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseOAPI, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",

			description =  "\n TC Description - Verify whether user is able to do Place order with Bopus item \n Feature - PlaceOrder with Bopus Item and Non bopus Item using Amex card,Promocode and kohlscash<br /> Bopus DIE phase2 changes<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithBopusItemUsingAmexCard() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression"}, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",

			description =  "\n TC Description - Verify whether user is able to do Place order with Bopus item \n Feature - PlaceOrder with Bopus Item and Non bopus Item using Giftcard,promo,Kohlscash<br /> Bopus DIE phase2 changes<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithBopusItemUsingGiftcardAndPromocode() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
						+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstantBuy","regression" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",

			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item \n Feature - PlaceOrder with Bopus Item and Non bopus Item using Amex Card and GC,KC<br /> Bopus DIE phase2 changes<br/> validate if orderType=instant in the request,user should be able to Calc order successfully without ORDER-3018,ORDER-3017 errors")
	public void InstantBuyPlaceOrderWithBopusItemUsingVisacardAndPromocode() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

				"{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartID\":\"" + testData.get("OAPICART_ID")
						+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
						+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
						+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
						+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER_INSTANTBUY_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI_INSTANTBUY_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}



}
