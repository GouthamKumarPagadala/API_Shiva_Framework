package test.java.adapters.order;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.*;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({"Remedy_placeorder1"})
public class Remedy_Placeorder {

	String strEmail = "";
	String strPaswd = "Pass@123";


	@BeforeMethod(alwaysRun=true)
	public void addCart() throws InterruptedException{
		strEmail = Utilities.getNewEmailID();
		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi_fmnp");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter_fmnp");

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";


		// Post the request for updateCart(ADD) using mapheader to OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
		String strResponseOAPIAddCart1 = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].qty", "QTY");
		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartID", "OAPICART_ID");


	}
	ResponseValidator validator;
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Amexcard by remedy challenge",
			description = "User should be able to place order by remedy challenge with Amex card")
	public void Remedychallenge_Placeorder_With_Amexcard(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp")); 
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
		+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID")  
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, "
		+ "\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("AMEX")
		+ "]}}}}";

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
        //Remedy challenge
		/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
		validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}

	}

	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Visacard by remedy challenge",
			description = "User should be able to place order by remedy challenge with VISA card")
	public void  Remedychallenge_Placeorder_With_Visacard(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
				+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID")  
				+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}

	}

	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Discover_card by remedy challenge",
			description = "User should be able to place order by remedy challenge with DISCOVER card")
	public void Remedychallenge_Placeorder_With_Discover_card(){

		String strPayload1 = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
				+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID")  
				+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}

	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Master_card by remedy challenge",
			description = "User should be able to place order by remedy challenge with MASTER card")
	public void  Remedychallenge_Placeorder_With_Master_card(){
		
		String strPayload1 = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
				+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID")  
				+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}

	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Amexcard_and_promocode by remedy challenge",
			description = "User should be able to place order by remedy challenge with Amex card and promocode")
	public void  Remedychallenge_Placeorder_With_AMEX_and_promocode(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	


		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
		+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("AMEX")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Visacard_and_promocode by remedy challenge",
			description = "User should be able to place order by remedy challenge with VISA card and promocode")
	public void  Remedychallenge_Placeorder_With_Visacard_and_promocode(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	


		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
		+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Discovercard_and_promocode by remedy challenge",
			description = "User should be able to place order by remedy challenge with DISCOVER card and promocode")
	public void  Remedychallenge_Placeorder_With_Discovercard_and_promocode(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	


		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
		+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("DISCOVER")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Master_card_and_promocode by remedy challenge",
			description = "User should be able to place order by remedy challenge with MASTER card and promocode")
	public void  Remedychallenge_Placeorder_With_Master_card_and_promocode(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	


		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
		+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("MASTER")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
		
	
	
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Amex_Card_and_Kohlscash by remedy challenge",
			description = "User should be able to place order by remedy challenge with Amex card and Kohlscash")
	public void  Remedychallenge_Placeorder_With_Amex_Card_and_Kohlscash(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
	    +",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("AMEX")
		+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Visa_Card_and_Kohlscash by remedy challenge",
			description = "User should be able to place order by remedy challenge with VISA card and Kohlscash")
	public void  Remedychallenge_Placeorder_With_Visa_Card_and_Kohlscash(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);


		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
	    +",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Discover_Card_and_Kohlscash by remedy challenge",
			description = "User should be able to place order by remedy challenge with DISCOVER card and Kohlscash")
	public void  Remedychallenge_Placeorder_With_Discover_Card_and_Kohlscash(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
	    +",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("DISCOVER")
		+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Master_Card_and_Kohlscash by remedy challenge",
			description = "User should be able to place order by remedy challenge with MASTER card and Kohlscash")
	public void  Remedychallenge_Placeorder_With_Master_Card_and_Kohlscash(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
			    +",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
				+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Amex_Card_and_Giftcard by remedy challenge",
			description = "User should be able to place order by remedy challenge with Amex card and Giftcard")
	public void  Remedychallenge_Placeorder_With_Amex_Card_and_Giftcard(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		
		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
	    +",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("AMEX")
		+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Discover_Card_and_Giftcard by remedy challenge",
			description = "User should be able to place order by remedy challenge with DISCOVER card and Giftcard")
	public void  Remedychallenge_Placeorder_With_Discover_Card_and_Giftcard(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		
		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
	    +",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("DISCOVER")
		+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder without_Remedychallenge",
			description = "User should be able to place order without Remedy challenge")
	public void  Placeorder_without_Remedychallenge(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = {"Remedy_placeorder1"}, enabled = true, priority = 2, testName = "PlaceOrder with  Incorrectcardnumber by remedy challenge",
			description = "User should get proper error message when try to place order with Incorrect card number with remedy challenge")
	public void  Remedy_Challenge_Place_Order_With_Incorrectcardnumber(){
		String payload1="{\"payload\" :{\"profile\":{\"paymentType\": "+ JsonString.getPaymentTypeJson("UPDATE") + ",\"action\":\"add\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String response=RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, payload1, Server.Adapter,true,mapheader);
		Utilities.setTestData(response, "$.payload.id", "CARD_ID");	

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		String strPayload = "{\"payload\":{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA")  + "\" ,\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"}"
		+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID") 
		+"\",\"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + 1234 + "\"}, \"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
		+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "]}}}}";
	
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		  //Remedy challenge
				/*validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.remedyType",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[0].isDefaultRemedyCard",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardNum",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].type",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].cardID",".+","");
				validator.nodeMatches("$.payload.order.Card Number Challenge.remedyChallenge.paymentTypes[1].isDefaultRemedyCard",".+","");  */
		
		// GetCart from Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_fmnp"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		if (CompareOAPI) {
			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_fmnp"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	
	}
	
	}

