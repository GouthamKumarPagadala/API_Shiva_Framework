package test.java.adapters.order;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("Order")
@Stories({ "Order Calc- Registered user" })
public class OrderCalcV2Registry_items {
	
	

		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Pass@123";


		@BeforeClass(alwaysRun = true)
		
		public void testSetup(){
		// Create a new profile through OAPI
		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);
	}
		@BeforeMethod(alwaysRun = true)
		public void signInSetup() {

			// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter_ipad");
			//Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi_ipad");

			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter_ipad"));
			//mapheader.put("access_token", testData.get("access_token_oapi_ipad"));

		}
		
		ResponseValidator validator;
		
		@Test(groups = { "OrderCalcRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
				description = "Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request with Visa Card.",
				dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

		

		public void ApplePay_VisaGuestUser() {

			//Adding Items to Cart
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : ["+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";
		

		
		
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
}
		@Test(groups = { "OrderCalcRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
				description = "Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request with Visa Card.",
				dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")
		public void ApplePay_VisaRegisteredUser() {

			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : ["+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";
		

		
		
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
}
		

		
	
		@Test(groups = { "OrderCalcRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
				description = "Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request with Visa Card.",
				dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

		
		public void ApplePay_Visa_GC() {

			//Adding Items to Cart
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : ["+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		

		
		
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		}
		
		@Test(groups = { "OrderCalcRegistryItem"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
				description = "Verify whether user able to do OrderCalc with RegistryItem paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.",
				dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred")

		
		public void ApplePayVisaRegistryBopusPromoGuestUser() {

			//Adding Items to Cart
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : ["+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}},{"
					+ JsonString.getBopusCartJson("VALID_V3", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
					+ "],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		

		
		
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateshipAddressRegistrySku();
}
		@Test(groups = {"OrderCalcRegistryItem"}, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
				dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
		public void MFPSignal_normal_normal_Registry_MultiShip() {

			String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [{\"shipIndex\":\"1\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
					+ ",{\"shipIndex\":\"2\",\"giftItem\" : true,\"shippingMethod\" : \"TDD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") + ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("CT_AVON_MULTISHIP")+"],"
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";
			String strResponsePLACEORDERAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadPLACEORDER, Server.Adapter, false);
			validator = new ResponseValidator(strResponsePLACEORDERAdapter);
			validator.validateNoErrors();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			
			validator.validateShipIndexOrder(strPayloadPLACEORDER);
		}
		

		@Test(groups = { "ipad_ordercalc11", "IPK","OrderCalcRegistryItem" }, enabled = true, priority = 2, testName = "Registry Item + Master Card",
				description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
		public void OrderCalcV2_Registry_MasterRegisteredUser() {

				
			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs                         
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			
			// Update ShipAddress
					String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
							+ JsonString.getBillAddressJson("UPDATE")
							+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

					// Post the request
					String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

					Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");
					
			String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")
					+ "\"shipToId\":\"" + testData.get("shipping_id_adapter")
					+ "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";

			mapheader.clear();  
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
			Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");

			// Update cart through Adapter
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			String strPayloadOrderCalc = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
					+ "\",\"cartItems\": [{\"giftItem\":\"true\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1")
					+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":0}}"
					+ "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseOrderCalcAdapter);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddressRegistrySku();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

			
		}
		
		@Test(groups = { "ipad_ordercalc11", "IPK" ,"OrderCalcRegistryItem"}, enabled = true, priority = 2, testName = "Registry Item + Master Card",
				description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
		public void OrderCalcV2_Registry_MasterGuestUser() {

				
			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs                         
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			
			// Update ShipAddress
					String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
							+ JsonString.getBillAddressJson("UPDATE")
							+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

					// Post the request
					String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

					Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");
					
			
			
			String strPayloadOrderCalc = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : ["+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") 
					+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") 
					+ "\",\"wantedQty\":1}}],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, false, null);
			validator = new ResponseValidator(strResponseOrderCalcAdapter);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddressRegistrySku();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

			
		}
		
		@Test(groups = { "ipad_ordercalc111", "IPK" ,"OrderCalcRegistryItem"}, enabled = true, priority = 2, testName = "Registry Item + Master Card",
				description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
		public void OrderCalcV2_RegistryAndBopus_MasterRegisteredUser() {
			mapheader.clear();   // clear any headers set by previous TCs                         
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			
			// Update ShipAddress
					String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
							+ JsonString.getBillAddressJson("UPDATE")
							+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

					// Post the request
					String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

					Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");
					
			String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")
					+ "\"shipToId\":\"" + testData.get("shipping_id_adapter")
					+ "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";

			mapheader.clear();  
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
			Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+testData.get("SKU_NORMAL")+"')].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "OAPICART_ID");
			
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
					+ "]}}}";
			mapheader.clear();  
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseAdapterAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
			Utilities.setTestData(strResponseAdapterAddCart1, "$.payload.cart.cartItems[?(@.skuCode=='"+testData.get("SKU_BOPUS")+"')].cartItemID", "OAPI_CART_ITEM_ID1");
			Utilities.setTestData(strResponseAdapterAddCart1, "$.payload.cart.cartID", "OAPICART_ID1");
			String cartItem1=testData.get("OAPI_CART_ITEM_ID").replace("[\"", "");
			cartItem1=cartItem1.replace("\"]", "");
			String cartItem2=testData.get("OAPI_CART_ITEM_ID1").replace("[\"", "");
			cartItem2=cartItem2.replace("\"]", "");
			// Update cart through Adapter
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			String strPayloadOrderCalc = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
					+ "\",\"cartItems\": [{\"giftItem\":\"true\",\"cartItemID\":\"" + cartItem1 + JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1")
					+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":0}},{\"cartItemID\":\""+ cartItem2
					+ JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
					+ "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"shipAddress\":"+ JsonString.getBillAddressJson("RI_PAWTUCKET") +","
					+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseOrderCalcAdapter);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");

			
	}
		
		@Test(groups = { "ipad_ordercalc1111", "IPK" ,"OrderCalcRegistryItem"}, enabled = true, priority = 2, testName = "Registry Item + Master Card",
				description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
		public void OrderCalcV2_RegistryAndBopus_MasterGuestUser() {

				
			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs                         
			mapheader.put("access_token", testData.get("access_token_adapter_ipad"));
			
			// Update ShipAddress
					String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
							+ JsonString.getBillAddressJson("UPDATE")
							+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

					// Post the request
					String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

					Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");
					
					String strPayloadOrderCalc = "{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\","
							+ "\"cartItems\" : ["+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") 
							+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") 
							+ "\",\"wantedQty\":1}},{"
							+ JsonString.getBopusCartJson("VALID_V3", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
							+ "],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"true\","
							+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
							+ JsonString.getPaymentTypeJson("MASTER")
							+ "]}}}}";
					String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, false, null);
					validator = new ResponseValidator(strResponseOrderCalcAdapter);
					validator.validateNoErrors();
					// validator.validateCartResponse();
					validator.validatebillAddress();
					validator.validateshipAddressRegistrySku();
					validator.validateCustomerInfo();
					validator.validatePaymentInfo();
					validator.validateTotal();
					validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
					validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");
	}
		
		@Test(groups = { "InstoreFreeShipping12", "OrderCalcRegistryItem" }, enabled = true, priority = 4,
				testName = "Order Calc registered User with Normal And RegistryandUSSTD",
				description = "Do Ordercalculation for an order as Guest user Normal And withRegistryandUSSTD")
		public void OrderCalcV2_NormalAndRegistry_KCCGuestUser() {

			// Update ShipAddress
			String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
					+ JsonString.getBillAddressJson("UPDATE")
					+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

			// Post the request
			String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

			Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");
			// Create Request
			String strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + ","
					+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+  " \"shipAddress\":"+ JsonString.getBillAddressJson("RI_PAWTUCKET") +","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KOHLS_CARD")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post Request
			String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, null);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
			validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
			validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
			validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");
		}
		@Test(groups = { "IPK" ,"OrderCalcRegistryItem"}, enabled = true, priority = 2, testName = "Registry Item + Master Card",
				description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
		public void OrderCalcV2_Registry_GuestUserVisaCheckOut() {
			String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "," + JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";
		// Post Request
				String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validatePaymentInfo();
				validator.validateshipAddress();
				validator.validatebillAddress();
				validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.order.cartItems[0].registry.registryName", "Tests", "registry Name should be present in the response");
				validator.nodeEquals("$.payload.order.cartItems[0].registry.registryType", "wishlist", "registry type should be present in the response");
				validator.nodeEquals("$.payload.order.cartItems[0].registry.registryID", "2522230", "registry id should be present in the response");
				validator.nodeEquals("$.payload.order.cartItems[0].registry.shipToId", testData.get("shipping_id_adapter"), "ship to id should be present in the response");

		}
}

