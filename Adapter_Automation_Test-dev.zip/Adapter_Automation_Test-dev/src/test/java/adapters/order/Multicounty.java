package test.java.adapters.order;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Multicounty")
@Stories({ "Multicounty" })

	public class Multicounty {
	ResponseValidator	validator;
	String				strOCBEmail;
	String				strOCBPaswd;
	String				strResponse;

	@BeforeMethod(alwaysRun=true)
	public void setup() {

		
		strOCBEmail = Utilities.getNewEmailID();
	    strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));
		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
        System.out.println(testData.get("access_token_adapter"));
		// Update ShipAddress
		
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");
		

	}
	
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2PlaceOrdersingleshipAddress",
			description = "Do PLACE  order as REGISTERED user with REGISTRY item")
	public void V2PlaceOrdersingleshipAddress() {
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		 strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
		
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
			strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
				JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + ","
				+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
				JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2PlaceOrderToshipAddress1",
			description = "Do PLACE  order as REGISTERED user with REGISTRY item and normal item")
	public void V2PlaceOrderToshipAddress1() {
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"shipIndex\":\"2\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
				JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + ","
				+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"shipIndex\":\"1\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
				JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2PlaceOrderToshipAddress2",
			description = "Do PLACE  order as REGISTERED user with REGISTRY item and normal item")
	public void V2PlaceOrderToshipAddress2() {
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
	Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
	String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"shipIndex\":\"1\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
						JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + ","
						+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"shipIndex\":\"2\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
						JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "]}}}}";
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2PlaceOrderToshipID1",
			description = "Do PLACE  order as REGISTERED user with REGISTRY item and normal item")
	public void V2PlaceOrderToshipID1() {
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
	Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
	Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
	String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
				JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "2") + ","
				+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
				JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2PlaceOrderToshipID2",
			description = "Do PLACE  order as REGISTERED user with REGISTRY item and normal item")
	public void V2PlaceOrderToshipID2() {
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
				JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "2") + ","
				+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
				JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
									}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestplaceOrdersingleshipAddress",
			description = "Do PLACE  order as Guest user with REGISTRY item")
	public void GuestplaceOrdersingleshipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2")+","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":\"1\"},\"shippingMethod\":\"TDD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
			
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestPlaceOrderToShipAddress1",
			description = "Do PLACE  order as Guest user with REGISTRY item and normal item to ship address1")
	public void GuestPlaceOrderToShipAddress1() {
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
				

				// Post the request
				String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

				Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");

				// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shipIndex\":\"2\",\"shippingMethod\": \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")+","
				+ "{\"shipIndex\":\"1\",\"shippingMethod\":\"USSTD"+JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":\"1\"}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestPlaceOrderToShipAddress2",
			description = "Do PLACE  order as Guest user with REGISTRY item and normal item to ship address2")
	public void GuestPlaceOrderToShipAddress2() {
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"ShipIndex\":\"2\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
				

				// Post the request
				String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

				Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
		
				
				
				// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shipIndex\":\"1\",\"shippingMethod\": \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")+","
				+ "{\"shipIndex\":\"2\",\"shippingMethod\":\"USSTD"+JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":\"1\"}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
						
			}
		@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestPlaceOrderToShipID1",
			description = "Do PLACE  order as Guest user with REGISTRY item and normal item to ship address1")
	public void GuestPlaceOrderToShipID1() {
		// Update ShipAddress
			String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
				

				// Post the request
				String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

				Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2")+","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":\"1\"},\"shippingMethod\":\"TDD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestPlaceOrderToShipID2",
			description = "Do PLACE  order as Guest user with REGISTRY item and normal item to ship ID2")
	public void GuestPlaceOrderToShipID2() {
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
				

				// Post the request
				String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

				Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2")+","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":\"1\"},\"shippingMethod\":\"TDD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
	
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2OrderCalcsingleshipAddress",
			description = "Do Ordercalculation for an order as registered user with REGISTRY item")
	public void V2OrderCalcsingleshipAddress() {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		 strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
		
				
		// Post the request for updateCart(ADD) using mapheader to OAPI
			strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
				JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "2") + ","
				+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
				JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		// Post Request
			String	strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2OrderCalcToshipAddress1",
			description = "Do Ordercalculation for an order as registered user with REGISTRY item and a Normal item")
	public void V2OrderCalcToshipAddress1() {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"shipIndex\":\"2\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
						JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + ","
						+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"shipIndex\":\"1\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
						JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "]}}}}";
		// Post Request
			String	strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2OrderCalcToshipAddress2",
			description = "Do Ordercalculation for an order as registered user with REGISTRY item and a Normal item")
	public void V2OrderCalcToshipAddress2() {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"shipIndex\":\"1\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
						JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + ","
						+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"shipIndex\":\"2\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
						JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "]}}}}";
		// Post Request
			String	strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2OrderCalcToshipID1",
			description = "Do Ordercalculation for an order as registered user with REGISTRY item and a Normal item")
	public void V2OrderCalcToshipID1() {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
				JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "2") + ","
				+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
				JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		// Post Request
			String	strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				

			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "V2OrderCalcToshipID2",
			description = "Do Ordercalculation for an order as registered user with REGISTRY item and a Normal item")
	public void V2OrderCalcToshipID2() {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "2")
				+ "]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
	
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+ "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";
			
		// Post the request for updateCart(ADD) using mapheader to OAPI
				 strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				String ADAPTER_CART_ITEM_ID = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==false)].cartItemID");
				ADAPTER_CART_ITEM_ID = ADAPTER_CART_ITEM_ID.substring(2, ADAPTER_CART_ITEM_ID.length()-2);
				//Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
				String ADAPTER_CART_ITEM_ID1 = Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.giftItem==true)].cartItemID");
				ADAPTER_CART_ITEM_ID1 = ADAPTER_CART_ITEM_ID1.substring(2, ADAPTER_CART_ITEM_ID1.length()-2);
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +ADAPTER_CART_ITEM_ID +
						JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "2") + ","
						+ "{\"shippingMethod\":\"USSTD\",\"giftItem\":\"true\",\"cartItemID\":\"" + ADAPTER_CART_ITEM_ID1 +
						JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":1}}],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "]}}}}";
		// Post Request
			String	strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
	}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestOrderCalcsingleshipAddress",
			description = "Do Ordercalculation for an order as guest user with REGISTRY item")
	public void GuestOrderCalcsingleshipAddress() {

		
		// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2")+","
						+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":\"1\"},\"shippingMethod\":\"TDD\"}],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("MASTER")
						+ "]}}}}";
				

				// Post Request
				String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

				
				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
			
			}	
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestOrderCalcshipToId1",
			description = "Do Ordercalculation for an order as guest user with REGISTRY item and a normal item")
	public void GuestOrderCalcshipToId1() {

	
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
// Create Request
String strPayload = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2")+","
		+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":\"1\"},\"shippingMethod\":\"TDD\"}],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("MASTER")
		+ "]}}}}";


				// Post Request
				String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestOrderCalcshipToId1",
			description = "Do Ordercalculation for an order as guest user with REGISTRY item and a normal item")
	public void GuestOrderCalcshipToId2() {

		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");
// Create Request
String strPayload = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2")+","
		+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":\"1\"},\"shippingMethod\":\"TDD\"}],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("MASTER")
		+ "]}}}}";


				// Post Request
				String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestOrderCalcshipToAddress1",
			description = "Do Ordercalculation for an order as guest user with REGISTRY item and a normal item")
	public void GuestOrderCalcshipToAddress1() {

	
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");

		// Create Request
String strPayload = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [{\"shipIndex\":\"2\",\"shippingMethod\": \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")+","
		+ "{\"shipIndex\":\"1\",\"shippingMethod\":\"USSTD"+JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":\"1\"}}],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("MASTER")
		+ "]}}}}";

				// Post Request
				String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
			}
	@Test(groups = { "Multicounty" }, enabled = true, priority = 4,
			testName = "GuestOrderCalcshipToAddress2",
			description = "Do Ordercalculation for an order as guest user with REGISTRY item and a normal item")
	public void GuestOrderCalcshipToAddress2() {

	
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countrycode\":\"US\",\"postalCode\":\"60606\",\"county\":\"COOK\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter1");

		// Create Request
String strPayload = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [{\"shipIndex\":\"1\",\"shippingMethod\": \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")+","
		+ "{\"shipIndex\":\"2\",\"shippingMethod\":\"USSTD"+JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter1") + "\",\"wantedQty\":\"1\"}}],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+"\"shipAddresses\":[{\"firstName\":\"John\",\"lastName\":\"Naik\",\"addr1\":\"201 West Madison\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60606\",\"shipIndex\":\"2\",\"phoneNumber\":\"1234567890\",\"state\":\"IL\",\"isPartialShipAddress\":\"true\"},{\"firstName\":\"JOHN\",\"lastName\":\"GEORGE\",\"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 180\",\"city\":\"Chicago\",\"countryCode\":\"US\",\"postalCode\":\"60290\",\"phoneNumber\":\"1234567891\",\"state\":\"IL\",\"shipIndex\":\"1\",\"isPartialShipAddress\":\"true\"}],"
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("MASTER")
		+ "]}}}}";


				// Post Request
				String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				//validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
				
				
			}
			}
				
			


