package test.java.adapters.order;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.apache.commons.lang3.ArrayUtils;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "Order Calc- Registered user" })
public class OrderCalcV2_Refactor {

	String strEmail = Utilities.getNewEmailID();
	String strPaswd = "Pass@123";


	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI

		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");


		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
	}
	@BeforeMethod(alwaysRun = true)
	public void testSetup1(){

		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));

	}

	ResponseValidator validator;
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Amex card ")
	public void AmexCard_RegisteredUser_V2() {
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Master card ")
	public void MasterCard_RegisteredUser_V2() {


		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Discover card ")
	public void DiscoverCard_RegisteredUser_V2() {


		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with VISA card ")
	public void VisaCard_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with KCC card ")
	public void KCCCard_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Amex card and Gift Card ")
	public void AmexCard_GiftCard_RegisteredUser_V2() {


		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Master card and Gift Card ")
	public void MasterCard_GiftCard_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Discover card and Gift Card")
	public void DiscoverCard_GiftCard_RegisteredUser_V2() {


		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with VISA card and GiftCard")
	public void VisaCard_GiftCard_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with KCC card and GiftCard")
	public void KCCCard_GiftCrad_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "Refactor","regression","smokeTest","startDatePromo","TenderSpecific-NAP2","TenderSpecific-NAP49" }, 
			enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Amex card \n Feature - validate StartDate for promocode,<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")

	public void OrdercalcWithAmexCard_Promocode_AsARegisteredUser() {
		TestData.getRunTimeData("SKU_CODE", false);

		//Inputs 
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};

		Utilities.AddItemtoCart(testData.get("RUNTIME_SKU_CODE"), "2", Server.Adapter);

		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);


		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") 
				+ "\",\"skuCode\":\"" + testData.get("RUNTIME_SKU_CODE") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateOrderResponse(false,true,testData.get("RUNTIME_SKU_CODE"),"USSTD");
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression","startDatePromo","TenderSpecific-NAP2","TenderSpecific-NAP49" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Master card \n Feature - validate StartDate for promocode,<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void OrdercalcWithMasterCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("UNQUALIFIED_PROMOCODE")};

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression","startDatePromo","TenderSpecific-NAP2","TenderSpecific-NAP49" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Discover card \n Feature - validate StartDate for promocode,<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void OrdercalcWithDiscoverCard_Promocode_AsARegisteredUser() {

		String[] promoCodes = {testData.get("UNQUALIFIED_PROMOCODE")};
		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression","startDatePromo","TenderSpecific-NAP2","TenderSpecific-NAP49" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with Visa card \n Feature - validate StartDate for promocode,<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void OrdercalcWithVisaCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes ={testData.get("UNQUALIFIED_PROMOCODE")};
		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression","startDatePromo","TenderSpecific-NAP2","TenderSpecific-NAP49" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "\n TC Description -Kohl's application user wants to do orderCalc-v2 with KCC card \n Feature - validate StartDate for promocode,<br /> Validate isKCCDiscount flag is false as KCC Tender specific promo is not used")
	public void OrdercalcWithKCCCard_Promocode_AsARegisteredUser() {

		String[] PromoCodes = {testData.get("UNQUALIFIED_PROMOCODE")};
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "3", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"3\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as promocode is not KCC tender specific");
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Amex card and Promocode ")

	public void AmexCard_Kohlscash_RegisteredUser_V2() {


		String arr[]=TestData.createKohlsCash(10);

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Master card and Kohlscash ")
	public void MasterCard_Kohlscash_RegisteredUser_V2() {

		String arr[]=TestData.createKohlsCash(10);

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with Discover card and Kohlscash")
	public void DiscoverCard_Kohlscash_RegisteredUser_V2() {


		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		String arr[]=TestData.createKohlsCash(10);

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with VISA card and Kohlscash")
	public void VisaCard_Kohlscash_RegisteredUser_V2() {

		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		String arr[]=TestData.createKohlsCash(10);

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully.",
			description = "Kohl's application user wants to do orderCalc-v2 with KCC card and Kohlscash")
	public void KCCCard_Kohlscash_RegisteredUser_V2() {

		//	Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		mapheader.clear();   // clear any headers set by previous TCs
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}


	//Apple Pay TestCases


	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request with Visa Card.")


	public void ApplePay_Visa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));			

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card and GiftCard",
			description = "Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard.")
	public void ApplePay_Visa_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Visa Card and PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.")
	public void ApplePay_Visa_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);				

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Visa Card and KohlsCash",
			description = "Verify whether user able to do OrderCalc V2 with paymentDetails=APPLEPAY while passing the request with Visa Card and KohlsCash.")
	public void ApplePay_Visa_KC() {

		String arr[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Visa Card and GiftCard + KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + KohlsCash.")
	public void ApplePay_Visa_GC_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr, arr1);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Visa Card and PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.")
	public void ApplePay_Visa_Promo_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card and KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Visa Card and KohlsCash.")
	public void ApplePay_Visa_KC_Promo() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card and GiftCard + PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + PromoCode.")
	public void ApplePay_Visa_GC_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc V2 with PaymentDetails=ApplePay with Visa Card and GiftCard + PromoCode + KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + PromoCode + KohlsCash.")
	public void ApplePay_Visa_GC_Promo_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card.")
	public void ApplePay_Mc() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));	

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and GiftCard",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard.")
	public void ApplePay_Mc_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));	

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and PromoCode.")
	public void ApplePay_Mc_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);				

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and KohlsCash.")
	public void ApplePay_Mc_KC() {

		String arr[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and GiftCard + KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + KohlsCash.")
	public void ApplePay_Mc_GC_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr, arr1);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and PromoCode.")
	public void ApplePay_Mc_Promo_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and KohlsCash.")
	public void ApplePay_Mc_KC_Promo() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and GiftCard + PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + PromoCode.")
	public void ApplePay_Mc_GC_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Master Card and GiftCard + PromoCode + KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + PromoCode + KohlsCash.")
	public void ApplePay_Mc_GC_Promo_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card.")
	public void ApplePay_Amex() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and GiftCard",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard.")
	public void ApplePay_Amex_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));	

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and PromoCode.")
	public void ApplePay_Amex_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);				

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and KohlsCash.")
	public void ApplePay_Amex_KC() {

		String arr[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and GiftCard + KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + KohlsCash.")
	public void ApplePay_Amex_GC_KC() {


		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr, arr1);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and PromoCode.")
	public void ApplePay_Amex_Promo_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and KohlsCash.")
	public void ApplePay_Amex_KC_Promo() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode.")
	public void ApplePay_Amex_GC_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1", "apple_pay","startDatePromo"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode + KohlsCash",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode + KohlsCash.")
	public void ApplePay_Amex_GC_Promo_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		validator.validateOrderKohlsCash(arr[0], false);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	//Instore Testcases


	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc V2 With InstoreMode - VISA card", description = "Perform Ordercalculation for an order as guest user using VISA card with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1","startDatePromo"}, enabled = true, priority = 4, testName = "Order Calc With InstoreMode - VISA card + PromoCode + GiftCard", description = "Perform V2 Ordercalculation for an order as Registered User using VISA card + PromoCode + GiftCard with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa_Promo_GC() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoInstore(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1","startDatePromo"}, enabled = true, priority = 4, testName = "Order Calc With InstoreMode - VISA card and PromoCode", description = "Perform V2 Ordercalculation for an order as Registered User using VISA card and PromoCode with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoInstore(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc With InstoreMode - VISA card and KohlsCash", description = "Perform V2 Ordercalculation for an order as Registered User using VISA card and PromoCode + KohlsCash with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa_KohlsCash() {


		String arr[]=TestData.createKohlsCash(10);


		String[] KohlsCash = ArrayUtils.addAll(arr);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc With InstoreMode - Amex and Gift card", description = "Perform V2 Ordercalculation for an order as Registered User with modes=INGEOFENCE and the combination of Amex card and gift card")
	public void InstoreFreeShip_Amex_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,false, false);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"ODD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1","startDatePromo"}, enabled = true, priority = 4, testName = "Order Calc Registered User Instore Mode- Master Card with Promo code", description = "Perform V2 Ordercalculation for an order as Registered User with the combination of Master card and Promo code with mode=INGEOFENCE")
	public void InstoreFreeShip_Master_Promo() {

		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoInstore(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc Registered User Instore Mode- Master Card with Kohl's Cash", description = "Perform V2 Ordercalculation for an order as Registered User with the combination of Master card and KohlsCash with mode=INGEOFENCE")
	public void InstoreFreeShip_Master_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);


		String[] KohlsCash = ArrayUtils.addAll(arr);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "V2 Ordercalculation for Registered User Instore Mode- Master card and Kohls Cash", description = "Perform V2 Ordercalculation for an order as Registered User using Master card with Kohls cash with modes=INGEOFENCE")
	public void InStoreFreeShip_KCC_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "V2 Ordercalculation for Registered User Instore Mode- Master card and Kohls Cash + GiftCard", description = "Perform V2 Ordercalculation for an order as Registered User using Master card with Kohls cash + GiftCard with modes=INGEOFENCE")
	public void InStoreFreeShip_KCC_KC_GC() {			


		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1"}, enabled = true, priority = 7, testName = "OrderCalc with PaymentDetails=ApplePay and Instore mode with Visa Card",
			description = "Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY  and Modes-INGEOFENCE while passing the request with Visa Card.")
	public void Instore_ApplePay_Visa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderInstoreResponse(false,true, true);

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VisaCheckout with Modes=INGEOFENCE and Card=MC ",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to ordercalc reponse successfully with modes=INGEOFENCE")
	public void Instore_visaCheckoutPaymentDetailsMaster() {


		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "}}}}}";

		//			 	Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		//			 	Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(false, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("MC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderInstoreResponse(false,true, true);

		// Compare Open API
		//			if (CompareOAPI) {
		//				
		//				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		//				Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");
		//				
		//				mapheader.clear();
		//				mapheader.put("access_token", testData.get("access_token_oapi"));
		//				// Create the Json Request
		//				String strPayloadOAPI = "{\"payload\": {\"order\":"
		//				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		//				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
		//				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
		//				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
		//				+ "\"shippingMethod\":\"USSTD\","
		//				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		//				+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
		//				+ JsonString.getPaymentTypeJson("MASTER")
		//				+ "]}}}}";
		//
		//				// Post the request
		//				String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayloadOAPI, Server.OpenApi, false);
		//
		//				// Compare the result
		//				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		//				}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc Registered User with Instore Mode - Discover card", description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Discover card")
	public void InstoreFreeShip_Disc_TDD() {


		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"TDD");
		validator.validateOrderInstoreResponse(false,false, false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc Registered User with Instore Mode - Discover card and KohlsCash", description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Discover card and KohlsCash")
	public void InstoreFreeShip_Disc_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, null, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderKohlsCash(arr[0], false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc Registered User with Instore Mode - Discover card and PromoCode", description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Discover card and PromoCode")
	public void InstoreFreeShip_Disc_Promo() {


		String[] promoCodes={testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc Registered User with Instore mode - Master card", 
			description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Master card with AHSTD")
	public void InstoreFreeShip_Master_AHSTD() {


		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);


		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"AHSTD");
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1","startDatePromo"}, enabled = true, priority = 4, testName = "Order Calc Registered User with Instore mode - Master card", description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Master card")
	public void InstoreFreeShip_Master_KC_Promo() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		String[] KohlsCash = ArrayUtils.addAll(arr,arr1);
		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(KohlsCash, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderInstoreResponse(false,true, true);
		validator.validateOrderKohlsCash(arr[0], false);
		validator.validateOrderPromoInstore(testData.get("UNQUALIFIED_PROMOCODE"), false);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc Registered User with InstoreMode - Kohls card", description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Master card")
	public void InstoreFreeShip_KCC() {



		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);



		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1","startDatePromo"}, enabled = true, priority = 4, testName = "Order Calc Registered User with Instore mode - Kohls card + Promo", description = "Perform V2 Ordercalculation for an order as Registered User with modes= INGEOFENCE using Kohls card and PromoCode")
	public void InstoreFreeShip_KCC_Promo() {


		String[] promoCodes={testData.get("UNQUALIFIED_PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, promoCodes, Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("UNQUALIFIED_PROMOCODE") + "\"}]	}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9133","We're sorry, the Promo Code " + testData.get("UNQUALIFIED_PROMOCODE") +" cannot be applied to provided cart items.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoInstore(testData.get("UNQUALIFIED_PROMOCODE"), false);
		validator.validateOrderInstoreResponse(false,true, true);
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc V2 With InstoreMode - VISA card with ODD", description = "Perform V2 Ordercalculation for an order as Registered user using VISA card with modes=INGEOFENCE & Shipping Method As ODD")
	public void InstoreFreeShip_Visa_ODD() { 

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,false, false);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"ODD");
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Order Calc V2 With InstoreMode - VISA card with ODD", description = "Perform V2 Ordercalculation for an order as Registered user using VISA card with modes=INGEOFENCE & Shipping Method As ODD")
	public void InstoreFreeShip_Visa_TDD() { 

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(false,false, false);
		validator.validateOrderResponse(false, true,testData.get("SKU_NORMAL"),"TDD");
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	//STC Test Cases
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "OrderCalc V2 with STC_EWaste_CA",
			description = "Verify whether the User is getting saleTax and FeeDetails for EWaste products shipped to California in Response for OrderCalc V2")
	public void STC_EWaste_CA_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "2", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"2\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("California","ewaste");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "OrderCalc V2 with STC_EWaste_CT",
			description = "Verify whether the User is getting saleTax and FeeDetails for EWaste products shipped to Connecticut in Response for OrderCalc V2")
	public void STC_EWaste_CT_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("Connecticut","ewaste");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "OrderCalc V2 with STC_Mattress_CT",
			description = "Verify whether the User is getting saleTax and FeeDetails for Mattress products shipped to Connecticut in Response for OrderCalc V2")
	public void STC_Mattress_CT_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("MATTRESS_SKUCODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("MATTRESS_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("MATTRESS_SKUCODE"),"USSTD");
		validator.validateSTCResponse("Connecticut","Mattress");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "OrderCalc V2 with STC_Mattress_CA",
			description = "Verify whether the User is getting saleTax and FeeDetails for Mattress products shipped to California in Response for OrderCalc V2")
	public void STC_Mattress_CA_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("California","Mattress");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	

	// Master Pass	

	@DiscontinuedTest(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry to ordercalc reponse successfully   verify whether kohls cash value is getting deducted from the total cost of the order")	
	public void MasterPass_VisaCard() {


		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=nativeapp"; 
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
				+"\"oauthToken\":\"sdf346457354634f\","
				+"\"oauthVerifier\":\"sdf34545645tfedf334\","
				+"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false,true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderMasterPassResponse();
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

}
