package test.java.adapters.order.cvv2;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;

import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.Utilities.CompareType;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("cvv2")
@Stories({ "PlaceOrder Registered User V2" })
public class PlaceOrderV2 
{
ResponseValidator validator;
	
	String				strCVV2Email;
	String				strCVV2Paswd;
	String				strResponse;
	
	
	@BeforeClass(alwaysRun = true)
	public void testSetup() {

		strCVV2Email = Utilities.getNewEmailID();
		strCVV2Paswd = "Cvv@1234";
		Utilities.createProfile(strCVV2Email, strCVV2Paswd, Server.Adapter);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.Adapter, "CVV2_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("CVV2_access_token_adapter"));

	}
	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with KCC_SecurityPin", description = "Do Placeorder for an order as V2Registered user and validate with KCC_SecurityPin")
	public void KCC_WithSecurityPin() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter_cvv2");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
	//	
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+ JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2")
								+ "]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi_cvv2");
						// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with Kohls Card and kohlsCash", description = "Do Placeorder for an order as V2Registered user and validate with Kohls Card and kohlsCash")
	public void KCC_KohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") 
				+ "\"}]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		//
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2")
								+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") 
								+ "\"}]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with Kohls Card and GiftCard", description = "Do Placeorder for an order as V2Registered user and validate with Kohls Card and GiftCard")
	public void KCCAndGiftCard() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		//
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
								+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with Kohls Card and Promocode", description = "Do Placeorder for an order as V2Registered user and validate with Kohls Card and Promocode")
	public void KCC_KohlsCardAndPromocode() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") 
				 + "\"}]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		//
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		
		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");
			

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"1") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
								+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") 
								 + "\"}]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User without KCC_SecurityPin", description = "Do Placeorder for an order as V2Registered user and validate without KCC_SecurityPin")
	public void KCC_WithoutSecurityPin() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATE")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
	//	
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+ JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATE")
								+ "]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User With Bopus Item alone along with StoreNum", description = "Do Placeorder for an order as V2Registered user and validate With Bopus Item alone along with StoreNum")
	public void KCC_BOPUS() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_BOPUS", testData.get("SKU_BOPUS"),"2",testData.get("BOPUS_STORE"),"USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
	//	
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE"))
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_BOPUS", testData.get("SKU_BOPUS"),"2",testData.get("BOPUS_STORE"),"USSTD") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
								+ "]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User using with KCC and Registry", description = "Do PlaceOrder for an order as V2Registered user and validate with KCC and Registry")
	public void KCC_Registry() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		
		// Update ShipAddress
				String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
						+ JsonString.getBillAddressJson("UPDATE")
						+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

				Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");
		// Update cart through adapter
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+"\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\",\"giftItem\":\"true\"}]"
						+ "}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
				Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
						+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+ "\",\"shippingMethod\":\"USSTD\",\"giftItem\":\"true" 
						+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") +"],"		
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
						+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));
			
			String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1")+"\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"action\":\"add\",\"giftItem\":\"true\"}]"
					+ "}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+ "\",\"shippingMethod\":\"USSTD\",\"giftItem\":\"true" 
					+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") +"],"		
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
					+ "]}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);

						}
		}
	@DiscontinuedTest(groups = { "cvv2","regression1","functional" }, enabled = false, priority = 4, testName = "Place Order V2Registered User with Kohls Card And Productwithoffer", description = "Do Placeorder for an order as V2Registered user and validate with Kohls Card And Productwithoffer")
	public void KCC_ProductOffer() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
	//	
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
				+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","USSTD") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2")
								+ "]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order  V2Registered User With Bopus Item And Normal Item With KCC", description = "Do placeorder for an order as V2Registered user with Bopus Item And Normal Item With KCC")
	public void KCC_BopusItemAndNonBopusItem() {
		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ ","
				+JsonString.getCartJson("VALID_CVV2", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[1].cartItemID", "ADAPTER_CART_ITEM_ID1");
		

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) 
				+ ",{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID1") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_NORMAL"),"1")+"],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		// Post Request
				String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
			//	
				validator.validateTotal();
				validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

				// Compare Open API
				if (CompareOAPI) {
					Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("CVV2_token_oapi"));

					String strPayloadAddCart1 ="{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
							+ ","
							+JsonString.getCartJson("VALID_CVV2", testData.get("SKU_NORMAL"), "1")
							+ "]}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
					Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
					Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
					Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[1].cartItemID", "ADAPTER_CART_ITEM_ID1");

					// Create Request
					String strPayloadOAPI ="{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
							+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) 
							+ ",{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID1") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_NORMAL"),"1")+"],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"true\","
							+ " \"paymentTypes\" :{\"creditCards\" : ["
							+ JsonString.getPaymentTypeJson("KCC_CVV2")
							+ "]}}}}";
					
								
								
								// Post the request
				String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
					// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
				
				}
	}

	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "PLace Order V2Registered User using Normal and Registry Items", description = "Do Placeorder for an order as V2Registered user and validate withNormal and Registry Items")
	public void KCC_NormalAndRegistryItem() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		
		// Update ShipAddress
				String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
						+ JsonString.getBillAddressJson("UPDATE")
						+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

				Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1") + ","
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_NORMAL"), "1")
				+"]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[1].cartItemID", "ADAPTER_CART_ITEM_ID1");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"1","674","USSTD") 
				+ ",{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID1")+JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"}],"		
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
	//	
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));
			String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1") + ","
					+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_NORMAL"), "1")
					+"]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
			Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[1].cartItemID", "ADAPTER_CART_ITEM_ID1");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"1","674","USSTD") 
					+ ",{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID1")+JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"USSTD\"}],"		
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "]}}}}";
						
						// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
	//	Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
	//	Utilities.compareAdapterOAPIResponse(strResponse, strResponseOAPI, CompareType.ORDER);
			
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with Kohls Card and kohlsCashAndPromocode", description = "Do Placeorder for an order as V2Registered user and validate with Kohls Card and kohlsCashAndPromocode")
	public void KCC_KohlsCashAndPromocode() {

		//TestData.getRunTimeData("KOHLS_CASH_NO", true);
		String[] arrKC = TestData.createKohlsCash(20);
		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2_TDD", testData.get("SKU_CVV2"),"1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +arrKC[0] + "\",\"pin\": \"" + arrKC[1] + "\"}]}}}}";

		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		//
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						String[] arrKC1 = TestData.createKohlsCash(20);
						
						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2_TDD", testData.get("SKU_CVV2"),"1") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"TDD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2")
								+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
								+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +arrKC1[0] + "\",\"pin\": \"" + arrKC1[1] +  "\"}]}}}}";

						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartID,payload.order.cartItems.cartItemID,payload.order.paymentTypes.kohlsCash.kohlsCashNum,payload.order.paymentTypes.kohlsCash.balance,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with Kohls Card and kohlsCashAndPromocodeAndGiftCard", description = "Do Placeorder for an order as V2Registered user and validate with Kohls Card and kohlsCashAndPromocodeAndGiftCard")
	public void KCC_KohlsCashAndPromocodeAndGiftCard() {

		//TestData.getRunTimeData("KOHLS_CASH_NO", true);
		String[] arrKC = TestData.createKohlsCash(20);
		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +arrKC[0] + "\",\"pin\": \"" + arrKC[1] +  "\"}]}}}}";

		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		//
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
						
						String[] arrKC1 = TestData.createKohlsCash(20);
						
						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"1") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2")
								+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
								+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
								+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" +arrKC1[0] + "\",\"pin\": \"" + arrKC1[1] + "\"}]}}}}";

						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with TempKohlsCard", description = "Do Placeorder for an order as V2Registered user and validate with TempKohlsCard")
	public void TempKohlsCard() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_TEMP")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
	//	
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

						String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "2")
								+ "]}}}";

						// Post the request for updateCart(ADD) using mapheader to OAPI
						String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
						Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

						// Create Request
						String strPayloadOAPI = "{\"payload\": {\"order\":"
								+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
								+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
								+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")+ JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"2") + "],"
								+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
								+ "\"shippingMethod\":\"USSTD\","
								+ " \"isBillAddressEqualtoShipAddress\":\"true\","
								+ " \"paymentTypes\" :{\"creditCards\" : ["
								+ JsonString.getPaymentTypeJson("KCC_CVV2_TEMP")
								+ "]}}}}";
						
						
						// Post the request
						String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with InstoreFreeShipping_USSTD", description = "Do Placeorder for an order as V2Registered user and validate with InstoreFreeShipping_USSTD")
	public void KCC_V2_WithInstoreFreeShipping_USSTD() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

			String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with InstoreFreeShipping_TDD", description = "Do Placeorder for an order as V2Registered user and validate with InstoreFreeShipping_TDD")
	public void KCC_V2_WithInstoreFreeShipping_TDD() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		//
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

			String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with InstoreFreeShipping_ODD", description = "Do Placeorder for an order as V2Registered user and validate with InstoreFreeShipping_ODD")
	public void KCC_V2_WithInstoreFreeShipping_ODD() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

			String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_CVV2"), "2","674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_CVV2"),"2","674","ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
}
	}
	@Test(groups = { "cvv2","regression1","functional" }, enabled = true, priority = 4, testName = "Place Order V2Registered User with InstoreFreeShipping_AHSTD", description = "Do Placeorder for an order as V2Registered user and validate with InstoreFreeShipping_AHSTD")
	public void KCC_V2_WithInstoreFreeShipping_AHSTD() {

		
		Utilities.removeCart(Server.Adapter, testData.get("CVV2_access_token_adapter"));
		// Update cart through adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "1","674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"),"1","674","AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strCVV2Email, strCVV2Paswd, Server.OpenApi, "CVV2_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));

			String strPayloadAddCart1 =  "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "1","674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"),"1","674","AHSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression1","functional", "cvv2" }, enabled = true, priority = 2, testName = "Place an Order successfully as a registered user",
			description = "Verify whether registered user (V2) is able to do expedited checkout using Kohls Charge card")
	public void KCC_V2_ExpeditedCheckout() {

		// Create a new profile through Adapter
		String strCVV2Email1 = Utilities.getNewEmailID();
		String strCVV2Paswd = "Cvv2@1234";
		Utilities.createProfile(strCVV2Email1, strCVV2Paswd, Server.Adapter);

		// Login using the above profile through Adapter and set the access token in variable 'CVV2_access_token_adapter'
		Utilities.signInProfile(strCVV2Email1, strCVV2Paswd, Server.Adapter, "CVV2_access_token_adapter1");

		// getProfile with Post the request to check isExpeditedCheckout is false
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("CVV2_access_token_adapter1"));
		String strURLGetProfile = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strURLGetProfile);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.isEligibleForExpeditedCheckout", "false", "Verifying without placing an order the isExpeditedCheckout should be false");
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to Adapter
		String strResponseAdapterAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "ADAPTER_CART_ID");

		// Create Request
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTER_CART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"),"1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");

		// getProfile with Post the request to check isExpeditedCheckout is true
		String strURLGetProfile1 = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strURLGetProfile1);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.isEligibleForExpeditedCheckout", "true", "Verifying after placing an order the isExpeditedCheckout should be true");
		validator.nodeEquals("$.payload.profile.paymentTypes[0].isEligibleForExpeditedCheckout", "true", "Verifying after placing an order the isExpeditedCheckout should be true in paymentType");
	}
}