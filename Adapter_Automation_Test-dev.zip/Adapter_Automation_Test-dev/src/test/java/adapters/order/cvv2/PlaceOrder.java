package test.java.adapters.order.cvv2;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("cvv2")
@Stories({ "Place Order" })
public class PlaceOrder {

	ResponseValidator validator;


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "Placr Order With Kohls Card", description = "Do PlaceOrder for an order using Kohls card")
	public void KCC_WithSecurityPin() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "CVV2_ORDER_NUMBER");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
			
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "CVV2_ORDER_NUMBER_OAPI");
			
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "Placr Order With Kohls Card", description = "Do PlaceOrder for an order using Kohls card")
	public void KCC_WithoutSecurityPin() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATE")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true,
			priority = 4, testName = "place order using Kohls Card and kohlsCash",
			description = "Do placeOrder for an order using Kohls Card and kohlsCash")
	public void KCC_KohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
//		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
	//	validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
	//	validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "value should be applied from giftCard in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "place order Unregistered User UsingKohlsCardGiftCardKOHLSCashPromocode", description = "Do place order for an order as guest user UsingKohlsCardGiftCardKOHLSCashPromocode")
	public void KCC_GiftCardKOHLSCashPromocode() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CVV2"), "40") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value", ".+", "value should be applied from PromoCode in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "value should be applied from giftCard in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "place order with kohlsCard",
			description = "Verify whether proper response is getting displayed when Bopus Item alone along with StoreNum , BillAddress and PaymentType Kohls card is provided in the Request.")
	public void KCC_BOPUS() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateTotal();
		// validator.validatePaymentInfo();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.ItemTypeIsBopus("ItemType should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		validator.storeAddresses("storeAddresses should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4,
			testName = "place order Guest User With KCC And Registry",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Do place order for an order as guest user with KCC and Registry")
	public void KCC_Registry() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2", "674", "ODD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateTotal();
		// validator.validatePaymentInfo();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.registryName", ".+", "registry name should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.registryID", ".+", "registry id should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.registryType", ".+", "registry type should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.shipToId", ".+", "registry name should be present in the response");
		
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload..shipToId", ".+", "shipToId should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4,
			testName = "place order using Kohls Card without Security Pin",
			description = "Do place order for an order using Kohls card without Security Pin")
	public void TempKohlsCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2_TEMP")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateTotal();
		// validator.validatePaymentInfo();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "Bopus Item And Normal Item With KCC",
			description = "Verify whether proper response is getting displayed when Bopus Item and a non-Bopus item is provided in the cart along with StoreNum.")
	public void KCC_BopusItemAndNonBopusItem() {

		// Create Request
		String strPayload =

		"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [{\"skuCode\":\"" + testData.get("SKU_BOPUS") + "\",\"bopusItem\":\"true\",\"storeNum\":\"9961\",\"qty\":2},{\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\",\"qty\":1,\"storeNum\":\"759\",\"shippingMethod\":\"USSTD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateTotal();
		// validator.validatePaymentInfo();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", "9961", "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4, testName = "Place Order Normal and Registry Items", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Do Placeorder for an order as guest user")
	public void KCC_NormalAndRegistryItem() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "," + JsonString.getCartJson("REGISTRY", testData.get("SKU_GIFT_WRAP"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\" : \"USSTD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.registryName", ".+", "registry name should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.registryID", ".+", "registry id should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.registryType", ".+", "registry type should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems..registry.shipToId", ".+", "registry name should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With USSTD Shipping method",
			description = "Do PlaceOrder for an order using Kohls card with USSTD Shipping method")
	public void KCC_WithInstoreFreeShipping_USSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2","674","USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With ODD Shipping method",
			description = "Do PlaceOrder for an order using Kohls card with ODD Shipping method")
	public void KCC_WithInstoreFreeShipping_ODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2","674","ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With TDD Shipping method",
			description = "Do PlaceOrder for an order using Kohls card with TDD Shipping method")
	public void KCC_WithInstoreFreeShipping_TDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_CVV2"), "2","674","TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With AHSTD Shipping method",
			description = "Do PlaceOrder for an order using Kohls card with AHSTD Shipping method")
	public void KCC_WithInstoreFreeShipping_AHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2","674","AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional", "errorhandling" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With MissingParameter",
			description = "Do Placeorder for an order using Kohls card with MissingParameter")
	public void KCC_WithMissingParameter() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", "", "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter skucode.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional", "errorhandling" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With InvalidSkucode",
			description = "Do Placeorder for an order using Kohls card with InvalidSkucode")
	public void KCC_WithInvalidSkucode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", "trf5565r", "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3000", "sku (trf5565r) not found.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional", "errorhandling" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With InvalidParameter",
			description = "Do Placeorder for an order using Kohls card with InvalidParameter")
	public void KCC_WithInvalidParameter() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "invalid value passed for email.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "cvv2", "regression1","functional", "errorhandling" }, enabled = true, priority = 4,
			testName = "Place Order Using Kohls Card With SkucodeOutOfStock",
			description = "Do Placeorder for an order using Kohls card with SkucodeOutOfStock")
	public void KCC_WithSkucodeOutOfStock() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"jb123@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_OUT_OF_STOCK"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";
		
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER4000", "sku ("+testData.get("SKU_CODE_OUT_OF_STOCK")+") out of inventory.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

}