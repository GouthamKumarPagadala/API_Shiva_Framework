package test.java.adapters.order.cvv2;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDERS_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDERS_OAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("cvv2")
@Stories({ "Retrieve Order" })
public class RetrieveOrder {

	ResponseValidator validator;


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 6, testName = "Retrieve Order Using OrderID",
			dependsOnMethods = "test.java.adapters.order.cvv2.PlaceOrderV2.KCC_WithSecurityPin",
			description = "Checking the Order Details Using OrderID")
	public void UsingOrderID() {
		
		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter_cvv2");
		mapheader.put("access_token", testData.get("CVV2_access_token_adapter"));
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeMatches("$.payload.order.orderStatus", "Submitted||In Fulfillment", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
		validator.nodeMatches("$.payload.order.email", ".+", "email should be present in the response");
		validator.nodeMatches("$.payload.order.shipments[0].orderItems[0].skuCode", ".+", "skuCode details in orderItems should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi_cvv2");
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("CVV2_token_oapi"));
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true,mapheader);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}
	@DiscontinuedTest(groups = { "cvv2", "regression1","functional" }, enabled = false, priority = 6, testName = "Retrieve Order Using OrderID for ApplePay",
			dependsOnMethods = "test.java.adapters.order.cvv2.PlaceOrder.KCC_WithSecurityPin",
			description = "Verify whether payment detail=Applepay is displayed in the response.")
	public void UsingOrderIDForApplePay() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_oapi_cvv2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeMatches("$.payload.order.orderStatus", "Submitted||In Fulfillment", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
		validator.nodeMatches("$.payload.order.email", ".+", "email should be present in the response");
		validator.nodeMatches("$.payload.order.shipments[0].orderItems[0].skuCode", ".+", "skuCode details in orderItems should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi_cvv2");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID and Postalcode",
			dependsOnMethods="test.java.adapters.order.cvv2.PlaceOrder.KCC_WithSecurityPin",
			description = "To Verify whether the user is able to retrieve order using a valid OrderId and Postal code")
	public void UsingvalidPostalCodeParameter() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("CVV2_ORDER_NUMBER")+"?postalCode=" + "60290";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeMatches("$.payload.order.orderStatus", "Submitted||In Fulfillment", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI  + "/"+testData.get("CVV2_ORDER_NUMBER_OAPI")+"?postalCode=" + "60290";

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 6, testName = "Retrieve Order UsingInvalidAccessToken",
			description = "Checking the Order Details By using Invalid Access Token")
	public void UsingInvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_oapi_cvv2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi_cvv2");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "cvv2", "regression1","functional" }, enabled = true, priority = 6, testName = "Retrieve Order UsingInvalidOrderId",
			description = "Checking the Order Details By UsingInvalidOrderId")
	public void UsingInvalidOrderId() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/473sdhgf74854685?postalCode=53224";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9252", "This Order Number does not exist. Please double-check the number you entered and try again. If you continue to have problems, please call Customer Service toll free at 1-866-887-8884.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("45356745465")+"?postalCode="+testData.get("POSTAl_CODE");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}

}