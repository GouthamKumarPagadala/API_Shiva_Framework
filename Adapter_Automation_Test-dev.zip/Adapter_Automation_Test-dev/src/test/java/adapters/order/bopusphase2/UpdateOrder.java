package test.java.adapters.order.bopusphase2;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("BOPUS-Phase")
@Stories({ "Update Order" })
public class UpdateOrder {
	
	ResponseValidator validator;
	
	
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons_Only with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the alternatePickUp details are added when valid details passed with orderNumber, action as ADD_ALT_PICKUP and alternatePickUpPersons in the request")
	public void updateOrder_alternatePickUpPersonsOnlyWithOrderNumber() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1") + "\","
						+ "\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons_new Email",
			description = "Kohls applicaiton user wants to verify whether the alternatePickUp details are updated when valid details passed with orderNumber, new email, postalCode, action as UPDATE_ALT_PICKUP and alternatePickUpPersons in the request")
	public void updateOrder_alternatePickUpPersonsNewEmail() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"action\":\"UPDATE_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("NEW_EMAIL_ID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons new FName and LName",
			description = "Kohls applicaiton user wants to verify whether the alternatePickUp details are updated when valid details passed with orderNumber, email, postalCode, action as UPDATE_ALT_PICKUP and alternatePickUpPersons details with new firstName and lastName in the request")
	public void updateOrder_alternatePickUpPersonsNewFName_LName() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"action\":\"UPDATE_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("NEW_FNAME_LNAME") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_Without alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the alternatePickUp details are deleted when valid details passed with orderNumber, email, postalCode and action as DEL_ALT_PICKUP details in the request")
	public void updateOrder_WithoutAlternatePickUpPersons() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"DEL_ALT_PICKUP\""
						+ "}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the alternatePickUp details are deleted when valid details passed with orderNumber, email, postalCode and action as DEL_ALT_PICKUP details in the request")
	public void updateOrder_AlternatePickUpPersons() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"DEL_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons without FirstName and LastName and with aciton add",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3022 and message FirstName, LastName are required for alternatePickUpPersons when firstName or lastName field value is not provided in alternatePickUpPerson, orderNumber, email, postalCode and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersonsWithoutFNameLNameAcitonAdd() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("EMPTY_FNAME_LNAME") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER3022", "FirstName, LastName are required for alternatePickUpPersons.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons without firstname and lastname and with aciton Update",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3022 and message FirstName, LastName are required for alternatePickUpPersons when firstName or lastName field value is not provided in alternatePickUpPerson, orderNumber, email, postalCode and action as UPDATE_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersonsWithoutFNameLNameAcitonUpdate() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
						 +JsonString.getAlternatePickUpJson("VALID") + "],"
						+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
						+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"UPDATE_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("EMPTY_FNAME_LNAME") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER3022", "FirstName, LastName are required for alternatePickUpPersons.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
		@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons empty value of orderNumber",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3028 and messageMissing Order Number when alternatePickUpPerson, empty value for orderNumber, email, postalCode and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersonsEmptyValueOrderNumber() {

		// Create Request
		/*String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";*/
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1000", "missing required parameter order number.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons invalid emailID",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3024 and message Invalid email format for alternate pickup person when alternatePickUpPerson with invalid emailid, valid firstName and lastName, orderNumber, email, postalCode and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersonsInvalidEmailID() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("INVALID_EMAIL") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER3024", "Invalid email format for alternate pickup person.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
		@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons_orderNumber_and_different_user_access_token",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3026 and message Order number does not match with the profile when alternatePickUpPerson, with different user orderNumber, email, postalCode and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersons_orderNumber_and_different_user_access_token() {

			// Create a new profile through OAPI
			String strBopusEmail = Utilities.getNewEmailID();
			String strBopusPaswd = "Bopus@123";
			Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

			// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
			Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token1");

			// Update cart through Adapter
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("Bopus_access_token1"));

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo();
	validator.validateTotal();
	validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
	Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
//	Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
	
	mapheader.clear();   // clear any headers set by previous TCs
	mapheader.put("access_token", testData.get("Bopus_access_token1"));
	
	
	// Create Request
			String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1") + "\","
					+ "\"action\":\"ADD_ALT_PICKUP\""
					+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true,mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER3026", "Order number does not match with the profile.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
		@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3027 and message Order number does not match with zip code and email when alternatePickUpPerson, with orderNumber, different email, postalCode and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersons_orderNumber_with_different_zip_code() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + "60291" + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response

validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER3027", "Order number does not match with zip code and email.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
		@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3023 and message Order does not contain BOPUS item when alternatePickUpPerson details, non-bopus item orderNumber and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersons_with_nonbopus_orderNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("BOPUSITEMFALSE", testData.get("SKU_NORMAL"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response

validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER3023", "Order does not contain BOPUS item.");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
	@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",dependsOnMethods="test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3025 and message Alternate PickUp Details cannot be added/updated when alternatePickUpPerson details, which has been picked-up order of orderNumber and action as ADD_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersons_with_already_picked_up_orderNumber() {

	/*	// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		
	
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		*/
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS_VALID") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response

validator = new ResponseValidator(strResponseUpdateOrder);
				
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}
		@Test(groups = {"bopusphase2","Bopus","regression"}, enabled = true, priority = 4, testName = "test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",dependsOnMethods="test.java.adapters.smoke.SmokeTest.updateOrder_alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3025 and message Alternate PickUp Details cannot be added/updated when alternatePickUpPerson details with new firstName, which has been picked-up order of orderNumber and action as UPDATE_ALT_PICKUP is provided in the request")
	public void updateOrder_alternatePickUpPersons_with_new_first_name_already_pickedup_orderNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_BOPUS_VALID") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +"{\"firstName\":\"Samarth\",\"lastName\": \""+testData.get("CUSTOMER_LASTNAME")+"\",\"email\": \"razzirazzu@gmail.com\"}"+ "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response

validator = new ResponseValidator(strResponseUpdateOrder);
				
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}

}