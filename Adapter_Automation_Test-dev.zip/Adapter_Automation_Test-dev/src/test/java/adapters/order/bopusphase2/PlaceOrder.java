package test.java.adapters.order.bopusphase2;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BOPUS-Phase")
@Stories({ "Place Order" })

public class PlaceOrder {
	ResponseValidator validator;

	
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_Master",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Master() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_Discover",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Discover() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_textNotificationNumber",
			description = "Kohls application user wants to verify whether textNotificationNumber information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_textNotificationNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		validator.nodeEquals("$.payload.order.textNotificationNumber",testData.get("BOPUS_PHONE_NUMBER"),"textNotificationNumber should be present");
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_non_bopusItem",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3015 and message The SKU <SKU Value> is not eligible for BOPUS when alternatePickUpPerson, textNotificationNumber and non-bopus item is provided in the request")
	public void placeOrder_valid_non_bopusItem() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_NORMAL"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3015", "The SKU " + testData.get("SKU_NORMAL") + " is not eligible for BOPUS");
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_withDifferentStoreNUm",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3019 and message Item(s) in your shopping bag are not available for pick up at the selected store when alternatePickUpPerson, textNotificationNumber and bopus item which is not available in given storeNumbers in the request")
	public void placeOrder_valid_bopusItem_withDifferentStoreNUm() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", "696") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3019", "Item(s) in your shopping bag are not available for pick up at the selected store.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_inValid_phoneNumber",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3021 and message Invalid Phone number for BOPUS Text Notification when alternatePickUpPerson, alphanumber value of textNotificationNumber and bopus item is provided in the request")
	public void placeOrder_inValid_phoneNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + "54s54g5d4hg5df4hg5d4h" +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3021", "Invalid Phone number for BOPUS Text Notification.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_emptyValue_fName_lName_pickUpPerson",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER3022 and message FirstName, LastName are required for alternatePickUpPersons when firstName and lastName of alternatePickUpPerson is provided empty, textNotificationNumber and bopus item is provided in the request")
	public void placeOrder_emptyValue_fName_lName_pickUpPerson() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("EMPTY_FNAME_LNAME") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3022", "FirstName, LastName are required for alternatePickUpPersons.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_without_fName_pickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the error code ORDER1000 and message Missing Required Parameter firstName when firstName field is not provided in alternatePickUpPerson, textNotificationNumber and bopus item is provided in the request")
	public void placeOrder_without_fName_pickUpPersons() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("MISSING_FNAME") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3022", "FirstName, LastName are required for alternatePickUpPersons.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Visa",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Visa() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
					 +JsonString.getAlternatePickUpJson("VALID") + "],"
					+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Master",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Master() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
					 +JsonString.getAlternatePickUpJson("VALID") + "],"
					+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOapi, Server.OpenApi, false);

			
			// Post the request

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Discover",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Discover() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
					 +JsonString.getAlternatePickUpJson("VALID") + "],"
					+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "bopusphase2","Bopus","regression" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Visa",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Vxo_Amex() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("AMEX_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
					 +JsonString.getAlternatePickUpJson("VALID") + "],"
					+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
}