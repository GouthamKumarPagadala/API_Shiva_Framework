package test.java.adapters.order.bopusphase2;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BOPUS-Phase")
@Stories({ "Place OrderV2" })
public class PlaceOrderV2 {
	
	ResponseValidator validator;
	
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrderV2_valid_bopusItem_promoCode",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and promocode \n Feature - PlaceOrder with BopusItem and promocode,<br /> Bopus DIE phase2 changes")
			
	public void placeOrderV2_valid_bopusItem_promoCode() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "2", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		 validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrderV2_valid_bopusItem_kohlsCash",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and Kohlscash \n Feature - PlaceOrder with BopusItem and kohlscash,<br /> Bopus DIE phase2 changes")
	public void placeOrderV2_valid_bopusItem_kohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrderV2_valid_bopusItem_kohlsGiftCard",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and Giftcard \n Feature - PlaceOrder with BopusItem and Gift card,<br /> Bopus DIE phase2 changes")
	public void placeOrderV2_valid_bopusItem_kohlsGiftCard() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
		if(CompareOAPI){
		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrder_valid_bopusItem_VISA",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and Amex card \n Feature - PlaceOrder with BopusItem and Amex card,<br /> Bopus DIE phase2 changes")
	public void placeOrder_valid_bopusItem_VISA() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrder_valid_bopusItem_Master",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and Master card \n Feature - PlaceOrder with BopusItem and master card,<br /> Bopus DIE phase2 changes")
	public void placeOrder_valid_bopusItem_Master() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrder_valid_bopusItem_AMex",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and Amex card \n Feature - PlaceOrder with BopusItem and Amex card,<br /> Bopus DIE phase2 changes")
	public void placeOrder_valid_bopusItem_Amex() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrder_valid_bopusItem_Discover",
			description =  "\n TC Description - Verify whether user is able to do place order with Bopus item and Discover card \n Feature - PlaceOrder with BopusItem and Disc card,<br /> Bopus DIE phase2 changes")
	public void placeOrder_valid_bopusItem_Discover() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailable flag should be true in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = {"bopusphase2","Bopus","regression","PlaceOrderBopus-NAP149","DIE_Changes"}, enabled = true, priority = 2, testName = "placeOrder_valid_non-bopusItem_alternatePickUp Details",
			description =  "\n TC Description - Verify whether user is able to get proper error message when placing order with Non-Bopus item \n Feature - PlaceOrder with Non bopus Item and validating proper error message is getting displayed,<br /> Bopus DIE phase2 changes")
	public void placeOrder_validNonBopusItemAlternatePickUpDetails() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_CVV2", testData.get("SKU_NORMAL"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_NORMAL"), "1")
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateExpectedErrors("ORDER3023", "Order does not contain BOPUS item.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "errorCode,error,errors.entity", true);

	}

}