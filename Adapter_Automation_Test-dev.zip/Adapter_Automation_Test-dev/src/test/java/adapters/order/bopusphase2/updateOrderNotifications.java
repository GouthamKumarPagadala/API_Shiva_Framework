package test.java.adapters.order.bopusphase2;

import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("BOPUS-Phase")
@Stories({ "Update Order Notifications" })
public class updateOrderNotifications {

	ResponseValidator validator;
	
	@Test(groups = {"NotificationUpdate-NAP183","regression"}, enabled = true, priority = 4, testName = "NotificationsTrueWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the order_notification_success  when user opts to get notification passed with orderNumber, action as ORDER_NOTIFICATION_OPT_IN in the request")
	public void updateOrder_NotificationsTrueWithOrderNumber() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));
				
				// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "]}}}}";
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");

		
		
		// Create RequesT
		String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1") + "\","
						+ "\"action\":\"ORDER_NOTIFICATION_OPT_IN\""
						+ ",\"orderNotifications\":{\"optIn\":true}}}";
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
        //Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.message", "The order `"+testData.get("ORDER_NUMBER_BOPUS1")+ "` has been updated successfully", "Verifying the message as 'order_notification_success' is getting displayed in response");
				

	}
	
	@Test(groups = {"NotificationUpdate-NAP183","regression"}, enabled = true, priority = 4, testName = "NotificationsFalseWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether proper error is getting displayed  when userr deopt for notification passed with orderNumber, action as ORDER_NOTIFICATION_OPT_IN in the request")
	public void updateOrder_NotificationsFalseWithOrderNumber() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");

		
		
		// Create RequesT
		String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1") + "\","
						+ "\"action\":\"ORDER_NOTIFICATION_OPT_IN\""
						+ ",\"orderNotifications\":{\"optIn\":false}}}";
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
        //Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1002","Invalid value passed for optIn.");
				
				

	}
	
	@Test(groups = {"NotificationUpdate-NAP183","regression"}, enabled = true, priority = 4, testName = "NotificationsWithInvalidOrderNumber",
			description = " verify whether Proper error message is displayed when Invalid ordernumber is used to opt for notification, action as ORDER_NOTIFICATION_OPT_IN in the request")
	public void updateOrder_NotificationsWithInvalidOrderNumber() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");

		
		
		// Create RequesT
		String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"abcde\","
						+ "\"action\":\"ORDER_NOTIFICATION_OPT_IN\""
						+ ",\"orderNotifications\":{\"optIn\":\"false\"}}}";
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
        //Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1002","Invalid value passed for Order Number.");

	}
	
	@Test(groups = {"NotificationUpdate-NAP183","regression"}, enabled = true, priority = 4, testName = "NotificationsWithoutOrderNumber",
			description = "verify whether Proper error message is displayed when ordernumber is not used to opt for notification, action as ORDER_NOTIFICATION_OPT_IN in the request")
	public void updateOrder_NotificationsWithoutOrderNumber() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		
		// Create RequesT
		String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"\","
						+ "\"action\":\"ORDER_NOTIFICATION_OPT_IN\""
						+ ",\"orderNotifications\":{\"optIn\":\"false\"}}}";
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
        //Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1000","Missing Required Parameter Order Number.");

	}
	
	@Test(groups = {"NotificationUpdate-NAP183","regression"}, enabled = true, priority = 4, testName = "NotificationsWithInvalid action",
			description = "Verify proper error is getting displayed when invalid value is passed for action")
	public void updateOrder_NotificationsWithInvalidAction() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");

		
		
		// Create RequesT
		String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1") + "\","
						+ "\"action\":\"ORDER_NOTIFICATION_OPT_INn\""
						+ ",\"orderNotifications\":{\"optIn\":\"true\"}}}";
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
        //Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1002","Invalid value passed for Action.");
				
					}
	
	@Test(groups = {"NotificationUpdate-NAP183","regression"}, enabled = true, priority = 4, testName = "Notifications With Invalid Attribute",
			description = "Verify whether proper error message is getting displayed when invalid attribute is passed")
	public void updateOrder_NotificationsWithInvalidAttribute() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopus@123";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");

		
		
		// Create RequesT
		String strPayloadUpdateOrder = "{\"payload\":{\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1") + "\","
						+ "\"action\":\"ORDER_NOTIFICATION_OPT_IN\""
						+ ",\"orderNotification\":{\"optIn\":\"true\"}}}";
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, true, mapheader);
				
        //Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ERR2700","Invalid JSON: Unrecognized field orderNotification");
				
					}
}
