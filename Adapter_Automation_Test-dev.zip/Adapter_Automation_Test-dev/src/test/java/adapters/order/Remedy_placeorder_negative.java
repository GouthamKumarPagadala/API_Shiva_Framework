package test.java.adapters.order;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;
import net.minidev.json.JSONArray;

import org.testng.annotations.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;
    @Features("Order")
	@Stories({ "Remedy_placeorder"})

public class Remedy_placeorder_negative {
	
    	
		ResponseValidator validator;
		
		@Test(groups = {"Remedy_placeorder","Remedy"}, enabled = true, priority = 1, testName = "Place_order with remedy",
		description = "User should get proper error code and error message with remedy place order")
		public void Place_order_with_Remedyaccount() {

	    	String strEmail =testData.get("REMEDY_PLACEORDER");
	    	String strPaswd =testData.get("PASSWORD_REMEDY");

	    	

			// SiginIn to Adapter using the above created OCB profile
			Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
			
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			//Clear cart            
            Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
                       

            String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
    				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
    				+ "]}}}";


    		// Post the request for updateCart(ADD) using mapheader to OAPI
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    	
    		String AddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    		String strResponseOAPIAddCart1 = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].qty", "QTY");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartID", "OAPICART_ID");

    		mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
    		// Create place order Request
			String strPayload = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
					+ ",\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";


			String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true,mapheader);
			
			validator = new ResponseValidator(strResponse);
			validator.validateExpectedErrorsforremedy(strResponse, "ORDER8000", "Remedy Challenge required");
			validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","creditCardNumber","remedyType should be creditCardNumber in the response");
			Object	document;
			document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
		  	JSONArray paymentTypes = JsonPath.read(document, "$.errors[0]...paymentTypes");
		  	 int count = paymentTypes.size();
		  	 for (int i = 0; i < count-1; i++){ 
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardID",".+","cardID should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].type",".+","card Type should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardNum","[x]+[0-9]{4}","cardNum should be present in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].isDefaultRemedyCard","true|false","isDefaultRemedyCard should be present in the response");
		  	 }
			
			
		}
		
		@Test(groups = {"Remedy_placeorder","Remedy"}, enabled = true, priority = 1, testName = "Place_order with remedy",
				description = "User should get proper error code and error message with remedy place order having invalid card number")
				
		
		public void Place_order_with_Remedyaccount_InvalidCardNumber()
		{
			String strEmail =testData.get("REMEDY_PLACEORDER");
	    	String strPaswd =testData.get("PASSWORD_REMEDY");

	    	

			// SiginIn to Adapter using the above created OCB profile
			Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
			
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			//Clear cart            
            Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
                       

            String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
    				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
    				+ "]}}}";


    		// Post the request for updateCart(ADD) using mapheader to OAPI
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    	
    		String AddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    		String strResponseOAPIAddCart1 = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].qty", "QTY");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartID", "OAPICART_ID");

    		mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
    		// Create place order Request
			String strPayload = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
                    + ",\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";


			String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true,mapheader);
			
			validator = new ResponseValidator(strResponse);
			validator.validateExpectedErrorsforremedy(strResponse, "ORDER8000", "Remedy Challenge required");
			validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","creditCardNumber","remedyType should be creditCardNumber in the response");
			Object	document;
			document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
		  	JSONArray paymentTypes = JsonPath.read(document, "$.errors[0]...paymentTypes");
		  	 int count = paymentTypes.size();
		  	 for (int i = 0; i < count-1; i++){ 
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardID",".+","cardID should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].type",".+","card Type should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardNum","[x]+[0-9]{4}","cardNum should be present in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].isDefaultRemedyCard","true|false","isDefaultRemedyCard should be present in the response");
		  	 }
		  	mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
		  	
		  	
		  	String strPayload1 = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
					+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("INVALID_CARD_ID")  
		            +"\",\"cardNum\":\"" +testData.get("INVALID_CARD_NUM")+"\"}, "
					+ "\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
		  	String strResponse1 = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload1, Server.Adapter, true,mapheader);
		  	validator = new ResponseValidator(strResponse1);
		  	validator.validateExpectedErrorsforremedy(strResponse1, "ORDER8001", "The card number entered did not match out records. Please try again.");
		  	validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","creditCardNumber","remedyType should be creditCardNumber in the response");
			Object	document1;
			document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
		  	JSONArray paymentTypes1 = JsonPath.read(document, "$.errors[0]...paymentTypes");
		  	 int count1 = paymentTypes.size();
		  	 for (int i = 0; i < count-1; i++){ 
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardID",".+","cardID should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].type",".+","card Type should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardNum","[x]+[0-9]{4}","cardNum should be present in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].isDefaultRemedyCard","true|false","isDefaultRemedyCard should be present in the response");
		  	 }
		}
		
		@Test(groups = {"Remedy_placeorder","Remedy"}, enabled = true, priority = 1, testName = "Place_order with remedy",
				description = "User should get proper error code and error message with remedy place order having invalid card number")
				
		
		public void Place_order_with_Remedyaccount_WithoutCardNumber()
		{
			String strEmail =testData.get("REMEDY_PLACEORDER");
	    	String strPaswd =testData.get("PASSWORD_REMEDY");

	    	

			// SiginIn to Adapter using the above created OCB profile
			Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
			
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			//Clear cart            
            Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
                       

            String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
    				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
    				+ "]}}}";


    		// Post the request for updateCart(ADD) using mapheader to OAPI
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    	
    		String AddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    		String strResponseOAPIAddCart1 = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].qty", "QTY");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartID", "OAPICART_ID");

    		mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
    		// Create place order Request
			String strPayload = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
					+ ",\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";


			String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true,mapheader);
			
			validator = new ResponseValidator(strResponse);
			validator.validateExpectedErrorsforremedy(strResponse, "ORDER8000", "Remedy Challenge required");
			validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","creditCardNumber","remedyType should be creditCardNumber in the response");
			Object	document;
			document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
		  	JSONArray paymentTypes = JsonPath.read(document, "$.errors[0]...paymentTypes");
		  	 int count = paymentTypes.size();
		  	 for (int i = 0; i < count-1; i++){ 
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardID",".+","cardID should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].type",".+","card Type should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardNum","[x]+[0-9]{4}","cardNum should be present in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].isDefaultRemedyCard","true|false","isDefaultRemedyCard should be present in the response");
		  	 }
		  	mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
		  	
		  	
		  	String strPayload1 = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
					+",\"remedyChallenge\":{\"remedyType\":\"creditCardNumber\",\"cardID\":\"" + testData.get("CARD_ID")  
		            +"\"}, "
					+ "\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
		  	String strResponse1 = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload1, Server.Adapter, true,mapheader);
		  	validator = new ResponseValidator(strResponse1);
		  	validator.validateExpectedErrorsforremedy(strResponse1, "ORDER1000", "Missing Required Parameter cardNum.");
		  	 }
		
		@Test(groups = {"Remedy_placeorder","Remedy"}, enabled = true, priority = 1, testName = "Place_order with remedy",
				description = "User should get proper error code and error message with remedy place order having invalid card number")
				
		
		public void Place_order_with_Remedyaccount_WithInvalidRemedyType()
		{
			String strEmail =testData.get("REMEDY_PLACEORDER");
	    	String strPaswd =testData.get("PASSWORD_REMEDY");

	    	

			// SiginIn to Adapter using the above created OCB profile
			Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
			
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");

			//Clear cart            
            Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
                       

            String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
    				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
    				+ "]}}}";


    		// Post the request for updateCart(ADD) using mapheader to OAPI
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    	
    		String AddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
    		mapheader.clear();
    		mapheader.put("access_token", testData.get("access_token_adapter"));
    		String strResponseOAPIAddCart1 = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartItems[0].qty", "QTY");
    		Utilities.setTestData(strResponseOAPIAddCart1, "$.payload.cart.cartID", "OAPICART_ID");

    		mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
    		// Create place order Request
			String strPayload = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
					+ ",\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";


			String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true,mapheader);
			
			validator = new ResponseValidator(strResponse);
			validator.validateExpectedErrorsforremedy(strResponse, "ORDER8000", "Remedy Challenge required");
			validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","creditCardNumber","remedyType should be creditCardNumber in the response");
			Object	document;
			document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
		  	JSONArray paymentTypes = JsonPath.read(document, "$.errors[0]...paymentTypes");
		  	 int count = paymentTypes.size();
		  	 for (int i = 0; i < count-1; i++){ 
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardID",".+","cardID should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].type",".+","card Type should be displayed in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].cardNum","[x]+[0-9]{4}","cardNum should be present in the response");
			validator.nodeMatches("$.errors[0].remedyChallenge.paymentTypes[" + i + "].isDefaultRemedyCard","true|false","isDefaultRemedyCard should be present in the response");
		  	 }
		  	

		  	mapheader.put("X-APP-API_SESSIONID", String.valueOf(System.nanoTime()));
		  	
		  	
		  	String strPayload1 = "{\"payload\": "
					+ "{\"nuData\":{\"channel\":\"" + testData.get("ADAPTER_NUDATA_CHANNEL")  + "\" ,\"ndpdData\":\"" + testData.get("REMEDY_PLACEORDER_NDPDDATA")+"\"}" 
					+",\"remedyChallenge\":{\"remedyType\":\"cfhcfifdvj\",\"cardID\":\"" + testData.get("VALID_CARD_ID")  
		            +"\",\"cardNum\":\"" + testData.get("VALID_CARD_NUM") + "\"}, "
					+ "\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\""+testData.get("REMEDY_PLACEORDER")+"\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
		  	String strResponse1 = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload1, Server.Adapter, true,mapheader);
		  	validator = new ResponseValidator(strResponse1);
		  	validator.validateExpectedErrorsforremedy(strResponse1, "ORDER1002", "Invalid value passed for remedyType.");
		  	 }
    
    }
    