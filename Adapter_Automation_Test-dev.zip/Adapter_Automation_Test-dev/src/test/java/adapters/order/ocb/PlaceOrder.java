package test.java.adapters.order.ocb;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.GET_WALLET_ID;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omni Channel Bag")
@Stories({ "Place Order" })
public class PlaceOrder {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc V2",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point")
	public void V2() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Bopus And NonBopus Item",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point")
	public void BopusAndNonBopusItem() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ ","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		String cartItemId1=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId1=cartItemId1.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" +cartItemId0 + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1")
				+ ",{\"cartItemID\":\"" + cartItemId1 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		
		
				
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb","errorhandling" }, enabled = true, priority = 2, testName = "OCB orderCalc Sku Mismatch",
			description = "Verify whether cart3017 Error getting displayed with 200 Response code in response when the provided skucode which does not match with persisted CartItem.")
	public void SkuMismatch() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_OFFERS"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb","errorhandling" }, enabled = true, priority = 2, testName = "OCB orderCalc Qty Mismatch",
			description = "Relogin the same user and Verify whether cart3017 Error getting displayed with 200 Response code in response when the provided QTY which does not match with persisted CartItem.")
	public void QtyMismatch() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc PromoCode KohlsCash",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point")
	public void PromoCodeKohlsCash() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Visa Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed when a payload with storeAddress , BillAddress and PaymentType Visa card is provided in the order Calc Request.")
	public void VisaCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Master Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with BillAddress,ShipAddress,MasterCard,promocode and kohlsCash is provided in the order Calc")
	public void MasterCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Kohls Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with BillAddress,ShipAddress,MasterCard,promocode and kohlsCash is provided in the order Calc")
	public void KohlsCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD3")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");

		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Discover Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with BillAddress,ShipAddress,MasterCard,promocode and kohlsCash is provided in the order Calc")
	public void DiscoverCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Bill same as ship address",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with storeAddress ,billAddress, kohlsCash, Promocode and isBillEqualtoShip=false is provided for the non-Bopus item in the order Calc request.")
	public void IsBillAddressToShipAddress() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"TDD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Bopus Normal And Registry item",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when Bopus Item (Normal) and non-Bopus items(one normal and one registry) are provided in the order along with storeAddress ,single shipAddress, billAddress, kohlsCash, Promocode in the order Calc request.")
	public void BopusNormalAndRegistry() {

		// kohls cash script
		//TestData.getRunTimeData("KOHLS_CASH_NO", true);
		String[] arrKC = TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		// Update ShipAddress
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);

		Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");

		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2") + ","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter")
				+ "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseAdapterAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"' && @.qty==2)].cartItemID");
		cartItemId0=cartItemId0.substring(2,12);
		String cartItemId1=Utilities.getJsonNodeValue(strResponseAdapterAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		cartItemId1=cartItemId1.substring(2,12);
		String cartItemId2=Utilities.getJsonNodeValue(strResponseAdapterAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"' && @.qty==1)].cartItemID");
		cartItemId2=cartItemId2.substring(2,12);

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + cartItemId1 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ ",{\"giftItem\":true,\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + cartItemId2 + JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_CVV2"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}},"
				+ "{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + cartItemId0 + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "2")
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arrKC[0] + "\",\"pin\":\"" + arrKC[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		//validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
	//	validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload..orderStatus", "[\"Submitted\"]", "order Status should be submitted");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "placeOrder last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do Place order  checkout for persisted CartItems with V2 end point Using Visa card Last 4 digit")
	public void VisaCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("VISA_CARD_NUMBER").substring(testData.get("VISA_CARD_NUMBER").length()-4, testData.get("VISA_CARD_NUMBER").length());
				testData.put("VISA_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA_LAST4")
				+ "]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "placeOrder last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do Place order  checkout for persisted CartItems with V2 end point Using Amex card Last 4 digit")
	public void AmexCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE_AMEX")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("AMEX_CARD_NUMBER").substring(testData.get("AMEX_CARD_NUMBER").length()-4, testData.get("AMEX_CARD_NUMBER").length());
				testData.put("AMEX_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX_LAST4")
				+ "]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "placeOrder last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do Place order  checkout for persisted CartItems with V2 end point Using Master card Last 4 digit")
	public void MasterCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE_MASTER")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("MASTER_CARD_NUMBER").substring(testData.get("MASTER_CARD_NUMBER").length()-4, testData.get("MASTER_CARD_NUMBER").length());
				testData.put("MASTER_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER_LAST4")
				+ "]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "placeOrder last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do Place order  checkout for persisted CartItems with V2 end point Using Discover card Last 4 digit")
	public void DiscoverCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE_DISCOVER")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("DISCOVER_CARD_NUMBER").substring(testData.get("DISCOVER_CARD_NUMBER").length()-4, testData.get("DISCOVER_CARD_NUMBER").length());
				testData.put("DISCOVER_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER_LAST4")
				+ "]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	
	
	
	
/*
 * OCB phase II placeOrder Scenarios
 */

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
						description = "Verify whether User is able to do V2 orderCalc with single promocode")
	
	public void PC_SinglePromoCode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
							
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlepromo");
						
						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
						String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
								+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
								+ "]}}}";
						
						//Validation UpdateCart Response
						String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
						validator = new ResponseValidator(strResponseOAPIAddCart);
						validator.validateNoErrors();
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlepromo");
						Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlepromo");
						validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
						validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
						validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlepromo");
						
						
						//Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));
						
				// Updating single PromoCode to the cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				
				//Validating CartItem Details 
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with SUPC PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SUPCPromocode",	
			description = "Verify whether User is able to do V2 orderCalc with SUPC promocode")
	
	public void SUPCpromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_supcpromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_supcpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_supcpromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC3") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("SUPC2"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	
	public void PC_MultiplePromoCode() {
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";
		
		//Validation UpdateCart Response
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		validator = new ResponseValidator(strResponseOAPIAddCart);
		validator.validateNoErrors();
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
		// Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							
				// Update cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"},{\"code\":\"" + testData.get("OCB_Promocode4") + "\"},{\"code\":\"" + testData.get("OCB_Promocode") + "\"},{\"code\":\"" + testData.get("OCB_Promocode2") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.ExpiredPromoCode",	
			description = "Verify whether User is able to do V2 orderCalc with single promocode")

	public void ExpiredSinglePromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_ExpPromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode4") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_ExpPromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with SUPC PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.RedeemedSUPC",	
			description = "Verify whether User is able to do V2 orderCalc with SUPC promocode")
	
	public void RedeemedSUPCpromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_supcpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_supcpromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC3") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("SUPC3"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase22", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	public void SingleKohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("kohlscash_single") + "\",\"pin\":\"" + testData.get("kohlscash_single_pin") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	public void ExpiredKohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_expiredkohlscash"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("OCB_EXPIRED_KOHLS_CASH") + "\",\"pin\":\"" + testData.get("OCB_EXPIRED_KC_PIN") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateExpectedErrors("CART9908", "we're sorry! you cannot use your kohl's cash to complete this order. please check the redeem dates.");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_expiredkohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}	
	
	public void Multiple_KohlsCash_Masterpass() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplekohlscash"));

		// Update cart through Adapter
		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=tablet";
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multiplekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multiplekohlscash") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("kohlscash_multiple") + "\",\"pin\":\"" + testData.get("kohlscash_multiple_pin")+"\"}," 
				+"{\"kohlsCashNum\":\"" + testData.get("kohlscash_multiple1") + "\",\"pin\":\"" + testData.get("kohlscash_multiple1_pin")+"\"},"
			    +"{\"kohlsCashNum\":\"" + testData.get("kohlscash_multiple9") + "\",\"pin\":\"" + testData.get("kohlscash_multiple9_pin")+"\"}"
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(strURL, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with single promocode")
	
	public void PC_SinglePromoCode_KohlsCash_KohlsGiftCard_KCC() {

	String arr[]=TestData.createKohlsCash(10);
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}"
						+ "]},\"kohlsCash\":{\"voucher\":["						
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
				
				
				//Validation UpdateCart Response
				
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_promo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_promo");
				
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");		
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.promoCodes.promoCode[0].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));

				// Update cart through Adapter
				
				String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\": \""+ testData.get("OAPICART_ID_promo")
						+ "\", \"cartItems\" : [{\"shippingMethod\":\"USSTD\",\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_promo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ "\"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
						+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode4") + "\"}]"
						+",\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0]+ "\",\"pin\":\"" + arr[1] 
						+ "\"}],"
						+ "\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") 
						+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

				
				String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponsePlaceOrderAdapter);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validateCustomerInfo();
				validator.kohlscashvalidate("$.payload..kohlsCashNum", arr[0]);
				//validator.validatePaymentInfo();
				validator.validateTotal();
				
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
				
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				
				validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("OCB_Promocode4"), "Given Promocode should be present in the response");
				
				
			
				
				// GetCart from Adapter
				String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

				// Compare the Getcart from Adapter and OAPI
				// GetCart response from OAPI
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_OAPI_promo");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
  
	}

	@Test(groups = { "ocbphase22", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	
	public void PC_MultiplePromoCode_MultipleKohlsCash() {


		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_multipromokc", arr[0]);
		testData.put("kohlscash_multipromokc1", arr1[0]);
		// Create a new profile through OAPI/
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multiplepromo_kohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromo_kohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multiplepromo_kohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multiplepromo_kohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multiplepromo_kohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromo_kohlscash"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multiplepromo_kohlscash")+"\","
				+ "\"paymentTypes\":"
				+ "{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
							+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]},"
				+"\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"
				+"]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		//validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		
		
		/*
		 * OCB phase II OrderCalc
		 */
		
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromo_kohlscash"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multiplepromo_kohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multiplepromo_kohlscash") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode4") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode1") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
				+ "\"}],\"kohlsCash\":[{"+"\"kohlsCashNum\":\"" + arr[0]+ "\",\"pin\":\"" + arr[1]+"\"},"
				+"{\"kohlsCashNum\":\"" + arr1[0]+ "\",\"pin\":\"" + arr1[1]+"\"}"
				+ "]}}}}";
			
				
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.kohlscashvalidate("$.payload..kohlsCashNum", arr[0]);
		validator.kohlscashvalidate("$.payload..kohlsCashNum", arr1[0]);
		validator.validateTotal();
		
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromo_kohlscash"));
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromo_kohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload without KC pin is sent with request.")
	
	public void MismatchSinglePromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of promocodes in request with persisted cart.", "proper Error details should be displayed in response");
		// validator.validateCartResponse();
		//validator.validateExpectedErrors(strCode, strMessage);
		

		
	}	

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SingleKohlsCash",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload with wrong KC is sent with request.")
	
	public void MismatchSingleKohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "3") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"142777972199303\",\"pin\":\"9509\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of Kohl's Cash in request with persisted cart.", "proper Error details should be displayed in response");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		
	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload with wrong cartItems is sent with request.")
	
	public void MismatchCartItems() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_BOPUS"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		
		// validator.validateCartResponse();
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Total count of items available in request do not match with total count of items available in persisted bag.", "proper Error details should be displayed in response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		
		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}	
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload with wrong cartID is sent with request.")
	
	public void MismatchCartID() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"453151531\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode4") + "\"}]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateExpectedErrors("ORDER3016", "Cart ID 453151531 provided is either invalid or not found in the database or is already a submitted order");
		validator.nodeEquals("$.payload.order.error.errorDetail","The cart id in the request do not match with persisted cart id.", "proper Error details should be displayed in response");		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			description = "Verify whether User is able to do V2 orderCalc with single KohlsCash")
	
	public void PC_WithoutKohlsCashPin_ApplePay() {

		String arr[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_single", arr[0]);
		testData.put("kohlscash_single_pin", arr[1]);
		


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlekohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlekohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlekohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlekohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));				// Update cart through Adapter
		
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		validator.kohlscashvalidate("$.payload..kohlsCashNum", arr[0]);
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		
		
		
		/*
		 * Bopus phase II OrdercalcV2
		 */
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("kohlscash_single") + "\",\"pin\":\"\"}]}}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode + Extra promoCode",
			description = "Verify whether User Error ORDER3017 is getting displayed in response when we are doing orderCalc with multiple promocode")
	
	public void PC_MultiplePromoCode_WithExtraPromoCode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_extrapromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_extrapromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_extrapromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_extrapromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_extrapromo");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_extrapromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_extrapromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_extrapromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_extrapromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_extrapromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"},"
						+ "{\"code\":\"" + testData.get("OCB_Promocode4") + "\"},"
								+ "{\"code\":\"" + testData.get("OCB_Promocode") + "\"},"
										+ "{\"code\":\"" + testData.get("OCB_Promocode2") + "\"},"
												+ "{\"code\":\""+ testData.get("OCB_Promocode3") + "\"}]}}}}";
		
											
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		
		validator.validateExpectedErrors("ORDER5000", "Too many promoCodes supplied.");
	
		
		
		
		

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with without PromoCode & KohlsCash",
			description = "Verify whether User Error ORDER3017 is getting displayed in response when we are doing orderCalc without promocode")
	
	public void PC_WithoutPromoCode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_withoutpromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_withoutpromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_withoutpromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_withoutpromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_withoutpromo");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_withoutpromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_withoutpromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
			
				
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_withoutpromo"));

		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_withoutpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_withoutpromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		//validator.validatePaymentInfo();
		validator.validateTotal();
			
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of promocodes in request with persisted cart.", "proper Error details should be displayed in response");
		


	}

	//OCB PHASE II Wallet

		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with Multi PromoCode",
				description = "Verify whether User is able to do V2 placeOrder with Multi promocode")
		
		public void OC_MultiplePromoCode_Wallet_PlaceOrder() {
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
													+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
						
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
					+ "\"},{\"code\":\"" + testData.get("OCB_Promocode4") 
					+ "\"},{\"code\":\"" + testData.get("OCB_Promocode1") 
					+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
					+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
					+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", "[0-9.]+", "Value should be applied in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with single PromoCode",
				description = "Verify whether User is able to do V2 placeOrder with single promocode")
		
		public void OC_SinglePromoCode_Wallet_PlaceOrder() {
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
													+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
						
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
					+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
					+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", "[0-9.]+", "Value should be applied in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with single KohlsCash",
				description = "Verify whether User is able to do V2 placeOrder with single KohlsCash")
		
		public void OC_SingleKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}"+"]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
						
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash",
				description = "Verify whether User is able to do V2 placeOrder with Multiple KohlsCash")
		
		public void OC_MultiKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			String arr1[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
										+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
					+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and single promoCode",
				description = "Verify whether User is able to do V2 placeOrder with Multiple KohlsCash and single Promo")
		
		public void OC_MultiKohlsCashSinglePromo_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			String arr1[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
										+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]},"
												+ "\"promoCodes\":{\"promoCode\":["+"{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
					+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}],"
							+ "\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
					+ "\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and single promoCode",
				description = "Verify whether User is able to do V2 placeOrder with Multiple KohlsCash and single Promo")
		
		public void OC_MultiPromoSingleKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]},"
												+ "\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
														+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"}],"
					+ "\"promoCodes\":["
					+ "{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}"
					+ "]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode",
				description = "Verify whether User is able to do V2 placeOrder with Multiple KohlsCash and Multiple Promo")
		
		public void OC_MultiPromoMultiKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			String arr1[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+ "{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
										+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]},"
										+ "\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
							+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}],"
					+ "\"promoCodes\":["
					+ "{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}"
					+ "]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Merge Cart")
		
		public void OC_MergePromo_Wallet_PlaceOrder() {
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
														+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]}}}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							mapheader.put("Accept", "application/json");
										
					// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
							+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
			validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],"
					+ "\"promoCodes\":["
					+ "{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode1") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode2") +"\"}"
					+ "]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Merge cart")
		
		public void OC_MergePromoUpdate_Wallet_PlaceOrder() {
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
														+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]}}}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							mapheader.put("Accept", "application/json");
										
					// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
							+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\"},"
									+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
			validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],"
					+ "\"promoCodes\":["
					+ "{\"code\":\"" + testData.get("OCB_Promocode3") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}"
					+ "]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Merge cart")
		
		public void OC_MergeKohlsCashUpdate_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
					String arr[]=TestData.createKohlsCash(10);
					String arr1[]=TestData.createKohlsCash(10);
					String arr2[]=TestData.createKohlsCash(10);
					String arr3[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
												+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]}}}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							mapheader.put("Accept", "application/json");
										
					// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\"},"
												+ "{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
			validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr3[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr3[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],"
					+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr2[0] + "\",\"pin\":\""+arr2[1]+"\"},"
					+ "{\"kohlsCashNum\":\"" + arr3[0] + "\",\"pin\":\""+arr3[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr2[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr3[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Merge cart")
		
		public void OC_MergeKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
					String arr[]=TestData.createKohlsCash(10);
					String arr1[]=TestData.createKohlsCash(10);
					String arr2[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
												+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]}}}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							mapheader.put("Accept", "application/json");
										
					// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\"}"
												+ "]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
			validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],"
					+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr2[0] + "\",\"pin\":\""+arr2[1]+"\"},"
						+ "{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
							+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr2[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[2].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}

		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Merge cart")
		
		public void OC_MergeCartKohlsAndAddPromo_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
					String arr[]=TestData.createKohlsCash(10);
					String arr1[]=TestData.createKohlsCash(10);
					String arr2[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
												+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]}}}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							mapheader.put("Accept", "application/json");
										
					// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
							"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\"}"
												+ "]},"
												+ "\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
										+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
			validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadplaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],"
					+ "\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode1") +"\"}],"
					+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr2[0] + "\",\"pin\":\""+arr2[1]+"\"},"
						+ "{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
							+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponseplaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadplaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponseplaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr2[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[2].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Merge cart")
		
		public void OC_MergeCartPromoAndAddKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
					String arr[]=TestData.createKohlsCash(10);
					String arr1[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
							+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
														+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]}}}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
							mapheader.put("Accept", "application/json");
										
					// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
							"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\"},"
										+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\"}]},"
										+ "\"promoCodes\":{\"promoCode\":["
										+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}"
										+ "]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
			validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],"
					+ "\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode1") +"\"},{\"code\":\"" + testData.get("OCB_Promocode2") +"\"},"
							+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}],"
					+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
							+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponsePlaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[1].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with multiple KohlsCash and multiple promoCode after merging",
				description = "Verify whether User is able to do V2 placeOrder with Mismatch cart")
		
		public void OC_CartMismatch_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			String arr1[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
										+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponsePlaceOrderAdapter);
			validator.validateExpectedErrors("ORDER3017", "The cart in the request do not match the persisted shopping cart");
			
		}

		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with Multi PromoCode",
				description = "Verify whether User is able to do V2 placeOrder with Multi promocode")
		
		public void OC_RemovePromoCode_Wallet_PlaceOrder() {
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
													+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
						
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

					//Removing PromoCode from cart
					strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
							+ "{\"code\":\""+(testData.get("OCB_Promocode4")).toUpperCase()+"\",\"action\":\"remove\"}]}}}}}";
					
					// Post the request for updateCart(ADD) using mapheader to OAPI
					strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
						
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
					+ "\"},"
					+ "{\"code\":\"" + testData.get("OCB_Promocode1") 
					+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
					+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
					+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponsePlaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].value","[0-9.]+", "Value should be applied in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
			validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");		
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", "[0-9.]+", "Value should be applied in the response");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}
		
		@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB placeOrder with Multi PromoCode",
				description = "Verify whether User is able to do V2 placeOrder with Multi promocode")
		public void OC_RemoveKohlsCash_Wallet_PlaceOrder() {
			
			//Creating KohlsCash 
			String arr[]=TestData.createKohlsCash(10);
			String arr1[]=TestData.createKohlsCash(10);
			
			// Create a new profile through OAPI
					String strOCBEmail = Utilities.getNewEmailID();
					String strOCBPaswd = "Qwerty#1";
					Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
					
					// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
					Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
					
					// Update cart through OAPI
					mapheader.clear();   // clear any headers set by previous TCs
					mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
					String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
							+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
							+ "]}}}";
					
					//Validation UpdateCart Response
					String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
					validator = new ResponseValidator(strResponseOAPIAddCart);
					validator.validateNoErrors();
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
					Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
							

					// SiginIn to Adapter using the above created OCB profile
							Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
					// Update cart through Adapter
							mapheader.clear();
							mapheader.put("Wallet_token", testData.get("walletToken"));
							mapheader.put("X-Wallet-Id", testData.get("walletId"));
							mapheader.put("X-Add-To-Wallet", "true");
							mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
										
							// Update cart through Adapter
					
					String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
										+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
										+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";

					// Post the request for updateCart(ADD) using mapheader to OAPI
					String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

					strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
							+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"remove\"}]}}}}}";
					
					strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
					
					validator = new ResponseValidator(strResponseAddCart1);
					validator.validateNoErrors();
					validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
					validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

			//get wallet and see promocode
			String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

			// Get wallet response
			mapheader.clear();
			mapheader.put("token", testData.get("walletToken"));
			
			String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
			
			validator = new ResponseValidator(strResponsewallet);
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
			validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
			
			// Perform placeOrder with PromoCodes added earlier
			
			String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\":["
					+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
			
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
			String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
			validator = new ResponseValidator(strResponsePlaceOrderAdapter);
			validator.validateNoErrors();
			validator.validateOrderResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validateCustomerInfo();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
			validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9.]+", "Kohls Cash should be applied successfully");
			

			// GetCart from Adapter
			String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

			// Compare the Getcart from Adapter and OAPI
			// GetCart response from OAPI
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
			String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

		}

		
}
