package test.java.adapters.order.ocb;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_OAPI;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omni Channel Bag")
@Stories({ "Order Calculation" })
public class OrderCalc {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc V2",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point")
	public void V2() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Bopus And NonBopus Item",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point")
	public void BopusAndNonBopusItem() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ ","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		String cartItemId=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].cartItemID");
		String strCartItemId=cartItemId.substring(2,12);
		
		String cartItemId1=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		String strCartItemId1=cartItemId1.substring(2,12);
		testData.put("OAPI_CART_ITEM_ID", strCartItemId);
		testData.put("OAPI_CART_ITEM_ID1", strCartItemId1);
//		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
//		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID", "OAPI_CART_ITEM_ID1");
		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1")
				+ ",{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID1") + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "[\"BOPUS\"]", "itemType should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].itemType", "[\"OTHERS\"]", "webID should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb","errorhandling" }, enabled = true, priority = 2, testName = "OCB orderCalc Sku Mismatch",
			description = "Verify whether cart3017 Error getting displayed with 200 Response code in response when the provided skucode which does not match with persisted CartItem.")
	public void SkuMismatch() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_OFFERS"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		
		
		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb","errorhandling" }, enabled = true, priority = 2, testName = "OCB orderCalc Qty Mismatch",
			description = "Relogin the same user and Verify whether cart3017 Error getting displayed with 200 Response code in response when the provided QTY which does not match with persisted CartItem.")
	public void QtyMismatch() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");

		// GetCart from Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc PromoCode KohlsCash",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point")
	public void PromoCodeKohlsCash() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Visa Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed when a payload with storeAddress , BillAddress and PaymentType Visa card is provided in the order Calc Request.")
	public void VisaCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Master Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with BillAddress,ShipAddress,MasterCard,promocode and kohlsCash is provided in the order Calc")
	public void MasterCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Kohls Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with BillAddress,ShipAddress,MasterCard,promocode and kohlsCash is provided in the order Calc")
	public void KohlsCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();

		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");

		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Discover Card",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with BillAddress,ShipAddress,MasterCard,promocode and kohlsCash is provided in the order Calc")
	public void DiscoverCard() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\""
				+ testData.get("PROMOCODE")
				+ "\"}],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Bill same as ship address",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when a payload with storeAddress ,billAddress, kohlsCash, Promocode and isBillEqualtoShip=false is provided for the non-Bopus item in the order Calc request.")
	public void IsBillAddressToShipAddress() {

		// kohls cash script
		String arr[]=TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "5")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\"" + arr[1] + "\"}]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}


	@Test(groups = { "regression","functional", "ocb" }, enabled = true, priority = 2, testName = "OCB orderCalc Bopus Normal And Registry item",
			description = "Relogin the same user and Verify whether proper response is getting displayed for registered user when Bopus Item (Normal) and non-Bopus items(one normal and one registry) are provided in the order along with storeAddress ,single shipAddress, billAddress, kohlsCash, Promocode in the order Calc request.")
	public void BopusNormalAndRegistry() {

		// kohls cash script
		//TestData.getRunTimeData("KOHLS_CASH_NO", true);
		String[] arrKC = TestData.createKohlsCash(10);

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		// Update ShipAddress
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);

		Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_CVV2"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter")
				+ "\",\"wantedQty\":1},\"action\":\"add\"}]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAdapterAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		String cartItemId=Utilities.getJsonNodeValue(strResponseAdapterAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].cartItemID");
		String strCartItemId=cartItemId.substring(2,12);
		
		String cartItemId1=Utilities.getJsonNodeValue(strResponseAdapterAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		String strCartItemId1=cartItemId1.substring(2,12);
		testData.put("CART_ITEM_ID", strCartItemId);
		testData.put("CART_ITEM_ID1", strCartItemId1);
//		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseAdapterAddCart, "$.payload.cart.cartID", "CART_ID");
//		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID", "OAPI_CART_ITEM_ID1");
		// SiginIn to Adapter using the above created OCB profile

		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("CART_ITEM_ID1") + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ ",{\"giftItem\":true,\"cartItemID\":\"" + testData.get("CART_ITEM_ID") + JsonString.getCartJson("REGISTRY_V2", testData.get("SKU_CVV2"), "1")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}"
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arrKC[0] + "\",\"pin\":\"" + arrKC[1] + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].registry.registryName", "Tests", "Registry should be applied in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].registry.registryType", "wishlist", "RegistryType should be applied in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].registry.registryID", "2522230", "Registry ID should be applied in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_CVV2") +"')].registry.shipToId", testData.get("shipping_id_adapter"), "Registry ship to id should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "OCB orderCalc last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point Using Visa card Last 4 digit")
	public void VisaCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("VISA_CARD_NUMBER").substring(testData.get("VISA_CARD_NUMBER").length()-4, testData.get("VISA_CARD_NUMBER").length());
				testData.put("VISA_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA_LAST4")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "OCB orderCalc last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point Using Amex card Last 4 digit")
	public void AmexCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE_AMEX")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("AMEX_CARD_NUMBER").substring(testData.get("AMEX_CARD_NUMBER").length()-4, testData.get("AMEX_CARD_NUMBER").length());
				testData.put("AMEX_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX_LAST4")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "OCB orderCalc last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point Using Master card Last 4 digit")
	public void MasterCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE_MASTER")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("MASTER_CARD_NUMBER").substring(testData.get("MASTER_CARD_NUMBER").length()-4, testData.get("MASTER_CARD_NUMBER").length());
				testData.put("MASTER_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER_LAST4")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	@Test(groups = { "ocb","ocb_payment" }, enabled = true, priority = 2, testName = "OCB orderCalc last4Digit CardNum",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point Using Discover card Last 4 digit")
	public void DiscoverCardUsinglast4DigitCardNum() {

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		// Update payment type using the above OCB Profile
				
				String strPayloadUpdatePayment = "{\"payload\":{\"profile\":{\"paymentType\":"
						+ JsonString.getPaymentTypeJson("UPDATE_DISCOVER")
						+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
				String strResponseUpdatePayment = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayloadUpdatePayment, Server.Adapter, true,mapheader);

				Utilities.setTestData(strResponseUpdatePayment, "$.payload.id", "adapter_payment_id");
				
				String card4Digit=testData.get("DISCOVER_CARD_NUMBER").substring(testData.get("DISCOVER_CARD_NUMBER").length()-4, testData.get("DISCOVER_CARD_NUMBER").length());
				testData.put("DISCOVER_CARD_NUMBER_LAST4", card4Digit);
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_oapi");
				
				
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER_LAST4")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	/*
	 * OCBphase II orderCalc Scenarios
	 */
	
	

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Verify whether User is able to do V2 orderCalc with single promocode")
	
	public void OC_SinglePromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
		+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("AMEX")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") + "\"}]},\"modes\":[\"INGEOFENCE\"]}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with SUPC PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SUPCPromocode",	
			description = "Verify whether User is able to do V2 orderCalc with SUPC promocode")
	
	public void OC_SUPCpromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_supcpromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_supcpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_supcpromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC6") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code", ".*"+testData.get("SUPC6")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_supcpromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	
	public void OC_MultiplePromoCode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode4") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode1") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
				+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
				+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "Value should be applied in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB EmptyPayload with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Verify whether User is able to do V2 empty payload orderCalc with single promocode")
	
	public void EmptyPayload_SinglePromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
//		validator.validatebillAddress();
//		validator.validateshipAddress();
//		validator.validateCustomerInfo();
//		validator.validatePaymentInfo();
//		validator.validateTotal();
			
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB EmptyPayload with Multi PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.MultiplePromoCodes",	
			description = "Verify whether User is able to do V2 empty payload orderCalc with Multi promocode")
	
	public void EmptyPayload_MultiPromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
//		validator.validatebillAddress();
//		validator.validateshipAddress();
//		validator.validateCustomerInfo();
//		validator.validatePaymentInfo();
//		validator.validateTotal();
			
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code", ".*"+testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB EmptyPayload with SUPC PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SUPCPromocode",	
			description = "Verify whether User is able to do V2 empty payload orderCalc with SUPC promocode")
	
	public void EmptyPayload_SUPCpromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_supcpromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
//		validator.validatebillAddress();
//		validator.validateshipAddress();
//		validator.validateCustomerInfo();
//		validator.validatePaymentInfo();
//		validator.validateTotal();
			
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("SUPC6"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_supcpromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB EmptyPayload with Single KohlsCash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SingleKohlsCash",	
			description = "Verify whether User is able to do V2 empty payload orderCalc with single KohlsCash")
	
	public void EmptyPayload_SinglekohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_single"));
//		validator.validatebillAddress();
//		validator.validateshipAddress();
//		validator.validateCustomerInfo();
//		validator.validatePaymentInfo();
//		validator.validateTotal();
			
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SingleKohlsCash",	
			description = "Verify whether User is able to do V2 orderCalc with single KohlsCash")
	
	public void SingleKohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "3") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("kohlscash_single") + "\",\"pin\":\"" + testData.get("kohlscash_single_pin") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_single"));
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocphase2" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode & Kohls Cash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.multiPromoCodeKohlsCash",	
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode & KohlsCash")
	
	public void EmptyPayload_Multi_Promo_KohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromokohlscash"));

		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Value should be applied in the response");
			
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_multipromokc"));
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_multipromokc1"));
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

				
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromokohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocphase2" }, enabled = true, priority = 2, testName = "OCB Perform Empty Payload orderCalc with Single PromoCode & Kohls Cash",	
			description = "Verify whether User is able to do V2 Empty Payload orderCalc with Single promocode & KohlsCash")
	
	public void EmptyPayload_Single_Promo_KohlsCash() {
		String arr[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_promokc", arr[0]);
		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_emptypromokohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_emptypromokohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_emptypromokohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_emptypromokohlscash");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_emptypromokohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_emptypromokohlscash"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_emptypromokohlscash")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]},"
				+"\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}"
				+"]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		

		//Empty Payload OrderCalc
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_emptypromokohlscash"));

		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_promokc"));
			
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

				
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_emptypromokohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB Perform Empty Payload orderCalc with Single PromoCode & Kohls Cash",	
			description = "Verify whether error ERR2700 is getting fisplayed in response ehile doing empty payload with promocde and kohlas in request")
	
	public void EmptyPayload_Negative() {
				// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_emptynegative");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_emptynegative"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_emptypromokohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_emptynegative");
				
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_emptynegative");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_emptynegative"));
				
			

		//Empty Payload OrderCalc
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_emptynegative"));
		
		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":{\"paymentTypes\":{\"promoCodes\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\"}], "
										+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" +testData.get("RUNTIME_KOHLSCASH_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		
		validator.validateExpectedErrors("ERR2700", "unexpected parameter in the payload");
		

	}
		
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode + Extra promoCode",
			description = "Verify whether User Error ORDER3017 is getting displayed in response when we are doing orderCalc with multiple promocode")
	
	public void OC_MultiplePromoCode_WithExtraPromoCode() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_extrapromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_extrapromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_extrapromo");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_extrapromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_extrapromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"},"
						+ "{\"code\":\"" + testData.get("OCB_Promocode4") + "\"},"
								+ "{\"code\":\"" + testData.get("OCB_Promocode") + "\"},"
										+ "{\"code\":\"" + testData.get("OCB_Promocode2") + "\"},"
												+ "{\"code\":\""+ testData.get("OCB_Promocode3") + "\"}]}}}}";
		
											
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		
		validator.validateExpectedErrors("ORDER5000", "Too many promoCodes supplied.");
		

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with without PromoCode & KohlsCash",
			description = "Verify whether User Error ORDER3017 is getting displayed in response when we are doing orderCalc without promocode")
	
	public void WithoutPromoCode_KohlsCash() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_wihtoutpromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_wihtoutpromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_wihtoutpromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_wihtoutpromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_wihtoutpromo");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_wihtoutpromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_wihtoutpromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				
				
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_withoutpromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_withoutpromo");
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		
		

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_wihtoutpromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_withoutpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_withoutpromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
			
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of promocodes in request with persisted cart.", "proper Error details should be displayed in response");
		

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with without PromoCode & KohlsCash",
			description = "Verify whether User Error ORDER3017 is getting displayed in response when Cart doest having any promo and we are doing orderCalc with promocode")
	
	public void CartDoesntHave_Promo_Kohls() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_doesntpromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_doesntpromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_doesntpromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_doesntpromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_doesntpromo");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_doesntpromo"));
									
						// Update cart through Adapter
				
				

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_doesntpromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_doesntpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_doesntpromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of promocodes in request with persisted cart.", "proper Error details should be displayed in response");

	}
	
	
	
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.ExpiredKohlsCash",	
			description = "Kohl's application user wants to  Verify whether kohls cash details persists in the reponse.")
	

	public void ExpiredKohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_expiredkohlscash"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("OCB_EXPIRED_KOHLS_CASH") + "\",\"pin\":\"" + testData.get("OCB_EXPIRED_KC_PIN") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("CART9908", "we're sorry! you cannot use your kohl's cash to complete this order. please check the redeem dates.");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_expiredkohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}	
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload without KC pin is sent with request.")
	
	public void MismatchSinglePromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
//		validator.validateNoErrors();
		// validator.validateCartResponse();
		//validator.validateExpectedErrors(strCode, strMessage);
		
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of promocodes in request with persisted cart.", "proper Error details should be displayed in response");

	}	

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SingleKohlsCash",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload with wrong KC is sent with request.")
	
	public void MismatchSingleKohlsCash() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlekohlscash") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), ""
						+ "3") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"142777972199303\",\"pin\":\"9509\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		//validator.validateExpectedErrors(strCode, strMessage);
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
		
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Mismatch in the number of Kohl's Cash in request with persisted cart.", "proper Error details should be displayed in response");

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload with wrong cartItems is sent with request.")
	
	public void MismatchCartItems() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_BOPUS"), "5") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode1") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart items in the request do not match the items in the persisted shopping bag.");
		validator.nodeEquals("$.payload.order.error.errorDetail","Total count of items available in request do not match with total count of items available in persisted bag.", "proper Error details should be displayed in response");
		// validator.validateCartResponse();
		//validator.validateExpectedErrors(strCode, strMessage);
		

	}	
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.SinglePromocode",	
			description = "Kohl's application user wants to  Verify whether error details are  displayed in the response when payload with wrong cartID is sent with request.")
	
	public void MismatchCartID() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"453151531\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode4") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		//validator.validateExpectedErrors(strCode, strMessage);	
		
		validator.validateExpectedErrors("ORDER3016", "Cart ID 453151531 provided is either invalid or not found in the database or is already a submitted order");
		validator.nodeEquals("$.payload.order.error.errorDetail","The cart id in the request do not match with persisted cart id.", "proper Error details should be displayed in response");

		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocphase2" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			description = "Verify whether User is able to do V2 orderCalc with single KohlsCash")
	
	public void WithoutKohlsCashPin_ApplePay() {

		String arr[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_single", arr[0]);
		testData.put("kohlscash_single_pin", arr[1]);
		
		


		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlekohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlekohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlekohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlekohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));				// Update cart through Adapter
		
			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlekohlscash")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		
		
		
		/*
		 * Bopus phase II OrdercalcV2
		 */
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlekohlscash"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":"
				+ "{\"customerName\":" + JsonString.getCustomerNameJson("VALID")+","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""+testData.get("OAPICART_ID_singlekohlscash")
				+ "\",\"cartItems\":[{\"cartItemID\":\"" +testData.get("OAPICARTITEM_ID_singlekohlscash")+JsonString.getCartJson("VALID_V2",testData.get("SKU_CVV2"),"1")+"],"
				+ "\"billAddress\":"+ JsonString.getBillAddressJson("IL_CHICAGO") +","
				+ "\"shippingMethod\":\"USSTD\","
				+ "\"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\","
				+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" +testData.get("kohlscash_single")
				+"\",\"pin\":\"\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_single"));
		
		validator.nodeMatches("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with single promocode")
	
	public void OC_SinglePromoCode_KohlsCash_KohlsGiftCard_KCC() {

	String arr[]=TestData.createKohlsCash(10);
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
		
		
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"action\": \"add\", \"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode")+"\"}"
						+ "]},\"kohlsCash\":{\"voucher\":["						
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_promo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_promo");
				
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");		
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));

				// Update cart through Adapter
				
				String strPayloadOrderCalc = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_promo")
						+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_promo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
						+ "\"billAddress\" : " 
						+ "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"},"
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("KCC_CVV2_V2")
						+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") + "\"}]"
						+",\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0]+ "\",\"pin\":\"" + arr[1] 
						+ "\"}],"
						+ "\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER") 
						+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

				
				String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseOrderCalcAdapter);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validateCustomerInfo();
			//	validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				
				validator.kohlscashvalidate("$.payload..kohlsCashNum", arr[0]);

				// GetCart from Adapter
				String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

				// Compare the Getcart from Adapter and OAPI
				// GetCart response from OAPI
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_OAPI_promo");
			
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_promo"));
				String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
  
	}


	@Test(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
						description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	
	public void OC_MultiplePromoCode_MultipleKohlsCash() {


		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		testData.put("kohlscash_multipromokc", arr[0]);
		testData.put("kohlscash_multipromokc1", arr1[0]);
		// Create a new profile through OAPI/
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multiplepromokohlscash");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromokohlscash"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multiplepromokohlscash");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multiplepromokohlscash");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				

		// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multiplepromokohlscash");
				
				//Update cart through Adapter
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromokohlscash"));
				
		// Updating single PromoCode to the cart through Adapter
		
		String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multiplepromokohlscash")+"\",\"paymentTypes\":"
				+ "{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
								+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
						+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]},"
				+"\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
						+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"
				+"]}}}}}";

		// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
		String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseAddCart1);
		validator.validateNoErrors();
		//validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum",".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		
		//Validating CartItem Details 
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		
		
		/*
		 * OCB phase II OrderCalc
		 */
		
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplepromokohlscash"));

		// Update cart through Adapter
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multiplepromokohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multiplepromokohlscash") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\":["
		+ JsonString.getPaymentTypeJson("AMEX")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode4") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode1") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
				+ "\"}],"
				+ "\"kohlsCash\":[{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]
			 +"\"},"
			 + "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]
			 +"\"}]}}}}";
			
				
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Value should be applied in the response");
		
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_multipromokc"));
		validator.kohlscashvalidate("$.payload..kohlsCashNum", testData.get("kohlscash_multipromokc1"));

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplepromokohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocphase2" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with single promocode")
	
	public void SinglePromoCode_SingleKohlsCash_PartialShipAddress() {
		String arr[]=TestData.createKohlsCash(10);
		

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Qwerty#1";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
		
	// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
					
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_promo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"action\": \"merge\", \"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\"}"
						+ "]},\"kohlsCash\":{\"voucher\":["						
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_partialpromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_partialpromo");
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");		
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.paymentTypes.kohlsCash.voucher[0].kohlsCashNum", arr[0], "Given KohlsCash should be present in the response");
				mapheader.clear();
				mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_promo"));

				// Update cart through Adapter
				
				String strPayloadOrderCalc = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_partialpromo")
						+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_partialpromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
								+ "\"shipAddress\" :{ \"isPartialShipAddress\": \"true\""
								+ ",\"city\":\"" + testData.get("IL_BILLING_CITY") + "\",\"countryCode\": \"" + testData.get("IL_BILLING_COUNTRYCODE") + 
								"\",\"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") +"\",\"state\":\""+ testData.get("IL_BILLING_STATE") +"\"},"
								+ "\"shippingMethod\":\"USSTD\","
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"false\","
						+ "\"paymentTypes\" :{\"creditCards\":["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode4")+"\"}]"
						+",\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0]+ "\",\"pin\":\"" + arr[1] 
						+ "\"}]}}}}";
						
									
				String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseOrderCalcAdapter);
				validator.validateNoErrors();
				// validator.validateCartResponse();
				validator.validatebillAddress();
				//validator.validateshipAddress();
				validator.validateCustomerInfo();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
				validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				
				validator.kohlscashvalidate("$.payload..kohlsCashNum", arr[0]);
				
				

				// GetCart from Adapter
				String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

				// Compare the Getcart from Adapter and OAPI
				// GetCart response from OAPI
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_partialpromo");
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_partialpromo"));
				String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
  
	}

	
	
	/* Discontinued Channel based TestCases*/
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Single KohlsCash",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.MultipleKohlsCash",	
			description = "Kohl's application user wants to  Verify whether multi kohls cash details persists in the reponse.")
	public void Multiple_KohlsCash_Masterpass() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multiplekohlscash"));

		// Update cart through Adapter
		String strURL=ORDERCALC_ADAPTER_V2+"&brandID=tablet";
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multiplekohlscash")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multiplekohlscash") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+"\"presentationDetails\":{"  
			    +"\"oauthToken\":\"sdf346457354634f\","
			    +"\"oauthVerifier\":\"sdf34545645tfedf334\","
			    +"\"checkoutResourceURL\":\"https%3A%2F%2Fsandbox.api.mastercard.com%2Fmasterpass%2Fv6%2Fcheckout%2F10189977%3Fwallet%3Dphw\"},"
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("kohlscash_multiple") + "\",\"pin\":\"" + testData.get("kohlscash_multiple_pin")+"\"}," 
				+"{\"kohlsCashNum\":\"" + testData.get("kohlscash_multiple1") + "\",\"pin\":\"" + testData.get("kohlscash_multiple1_pin")+"\"},"
			    +"{\"kohlsCashNum\":\"" + testData.get("kohlscash_multiple9") + "\",\"pin\":\"" 
				+ testData.get("kohlscash_multiple9_pin")+"\"}"
				+ "]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(strURL, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "masterpass","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multiplekohlscash"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Channel Based PromoCode and without channel",
			description = "Verify whether User is able to do V2 orderCalc with Channel Based PromoCode and without channel")
	
	
	public void Channel_Based_Promo() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelpromo"));

		// Update cart through Adapter
		
		String strURL = ORDERCALC_ADAPTER_V2 +"&channel=endless_Aisle";
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_channelpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_channelpromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("Endless_Aisle") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(strURL, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("Endless_Aisle"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelpromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Channel Based PromoCode and without channel",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.EndlessAislePromoCode",	
			description = "Verify whether User is able to do V2 orderCalc with Channel Based PromoCode and without channel")
	
	public void Channel_Based_Promo_wihtoutChannel() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelpromo"));

		// Update cart through Adapter
		
				
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_channelpromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_channelpromo") + JsonString.getCartJson("VALID_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("Endless_Aisle") + "\"}]}}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
//		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("Endless_Aisle"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelpromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB EmptyPayload with channel based PromoCode",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.EndlessAislePromoCode",	
			description = "Verify whether User is able to do V2 empty payload orderCalc with channel based promocode")
	
	public void EmptyPayload_ChannelPromoCode() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_channelpromo"));

		// Update cart through Adapter
		
		String strURL = ORDERCALC_ADAPTER_V2 +"&channel=endless_Aisle";
		
		
		String strPayloadOrderCalc = "{\"payload\":{\"order\":{}}}";
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(strURL, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
//		validator.validatebillAddress();
//		validator.validateshipAddress();
//		validator.validateCustomerInfo();
//		validator.validatePaymentInfo();
//		validator.validateTotal();
			
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("Endless_Aisle"), "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_channelpromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@DiscontinuedTest(groups = { "ocbphase2", "regression1" }, enabled = true, priority = 2, testName = "OCB EmptyPayload with channel based PromoCode and wihtout channel details",
			dependsOnMethods = "test.java.adapters.cart.ocbphase2.UpdateCart.EndlessAislePromoCode",	
			description = "Verify whether User is able to do V2 empty payload orderCalc with channel based promocode and wihtout channel details")
	
	public void EmptyPayload__Without_Channel() {

}

//OCB PHASE II Wallet

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	
	public void OC_MultiplePromoCode_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode4") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode1") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
				+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
				+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "Value should be applied in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with single PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with single promocode")
	
	public void OC_SinglePromoCode_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
				+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "Value should be applied in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with single KohlsCash",
			description = "Verify whether User is able to do V2 orderCalc with single KohlsCash")
	
	public void OC_SingleKohlsCash_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}"+"]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash",
			description = "Verify whether User is able to do V2 orderCalc with Multiple KohlsCash")
	
	public void OC_MultiKohlsCash_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
									+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
				+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and single promoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multiple KohlsCash and single Promo")
	
	public void OC_MultiKohlsCashSinglePromo_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
									+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]},"
											+ "\"promoCodes\":{\"promoCode\":["+"{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
				+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}],"
						+ "\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and single promoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multiple KohlsCash and single Promo")
	
	public void OC_MultiPromoSingleKohlsCash_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"}]},"
											+ "\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"}],"
				+ "\"promoCodes\":["
				+ "{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}"
				+ "]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multiple KohlsCash and Multiple Promo")
	
	public void OC_MultiPromoMultiKohlsCash_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+ "{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
									+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]},"
									+ "\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
									+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
						+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}],"
				+ "\"promoCodes\":["
				+ "{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}"
				+ "]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode after merging",
			description = "Verify whether User is able to do V2 orderCalc with Merge Cart")
	
	public void OC_MergePromo_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
											+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":["
				+ "{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode1") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode2") +"\"}"
				+ "]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode after merging",
			description = "Verify whether User is able to do V2 orderCalc with Merge cart")
	
	public void OC_MergePromoUpdate_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
											+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\"},"
								+ "{\"code\":\""+testData.get("OCB_Promocode3")+"\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":["
				+ "{\"code\":\"" + testData.get("OCB_Promocode3") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}"
				+ "]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode3")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode after merging",
			description = "Verify whether User is able to do V2 orderCalc with Merge cart")
	
	public void OC_MergeKohlsCashUpdate_Wallet() {
		
		//Creating KohlsCash 
				String arr[]=TestData.createKohlsCash(10);
				String arr1[]=TestData.createKohlsCash(10);
				String arr2[]=TestData.createKohlsCash(10);
				String arr3[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
											+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\"},"
											+ "{\"kohlsCashNum\":\""+arr3[0]+"\",\"pin\":\""+arr3[1]+"\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr3[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr3[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr2[0] + "\",\"pin\":\""+arr2[1]+"\"},"
				+ "{\"kohlsCashNum\":\"" + arr3[0] + "\",\"pin\":\""+arr3[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr2[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr3[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode after merging",
			description = "Verify whether User is able to do V2 orderCalc with Merge cart")
	
	public void OC_MergeKohlsCash_Wallet() {
		
		//Creating KohlsCash 
				String arr[]=TestData.createKohlsCash(10);
				String arr1[]=TestData.createKohlsCash(10);
				String arr2[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
											+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\"}"
											+ "]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr2[0] + "\",\"pin\":\""+arr2[1]+"\"},"
					+ "{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
						+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr2[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[2].isApplied", "true", "Kohls Cash should be applied successfully");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode after merging",
			description = "Verify whether User is able to do V2 orderCalc with Merge cart")
	
	public void OC_MergeCartKohlsAndAddPromo_Wallet() {
		
		//Creating KohlsCash 
				String arr[]=TestData.createKohlsCash(10);
				String arr1[]=TestData.createKohlsCash(10);
				String arr2[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "],\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
											+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
						"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr2[0]+"\",\"pin\":\""+arr2[1]+"\"}"
											+ "]},"
											+ "\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
									+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr2[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr2[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode1") +"\"}],"
				+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr2[0] + "\",\"pin\":\""+arr2[1]+"\"},"
					+ "{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
						+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr2[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[2].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash and multiple promoCode after merging",
			description = "Verify whether User is able to do V2 orderCalc with Merge cart")
	
	public void OC_MergeCartPromoAndAddKohlsCash_Wallet() {
		
		//Creating KohlsCash 
				String arr[]=TestData.createKohlsCash(10);
				String arr1[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "2")
						+ "],\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
											+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
													+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"}]}}}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
						mapheader.put("Accept", "application/json");
									
				// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+
						"\",\"action\": \"merge\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\"},"
									+ "{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\"}]},"
									+ "\"promoCodes\":{\"promoCode\":["
									+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}"
									+ "]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
		validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ arr1[0]+".*", "Given KohlsCash should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.cart.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") +"\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode1") +"\"},{\"code\":\"" + testData.get("OCB_Promocode2") +"\"},"
						+ "{\"code\":\"" + testData.get("OCB_Promocode4") +"\"}],"
				+ "\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr[0] + "\",\"pin\":\""+arr[1]+"\"},"
						+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[1].isApplied", "true", "Kohls Cash should be applied successfully");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[3].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}
	
	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash",
			description = "Verify whether User is able to do V2 orderCalc with Mismatch Cart")
	
	public void OC_CartMismatch_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
									+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER3017", "The cart in the request do not match the persisted shopping cart");
		
	}

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with Multi PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with Multi promocode")
	
	public void OC_RemovePromoCode_Wallet() {
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
												+ "{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode1")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode2")+"\",\"action\":\"add\"},"
												+ "{\"code\":\""+testData.get("OCB_Promocode4")+"\",\"action\":\"add\"}]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

				//Removing PromoCode from cart
				strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":["
						+ "{\"code\":\""+(testData.get("OCB_Promocode4")).toUpperCase()+"\",\"action\":\"remove\"}]}}}}}";
				
				// Post the request for updateCart(ADD) using mapheader to OAPI
				strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
					
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].promoCode", ".*"+testData.get("OCB_Promocode4")+".*", "Given Promocode should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") 
				+ "\"},"
				+ "{\"code\":\"" + testData.get("OCB_Promocode1") 
				+ "\"},{\"code\":\"" + testData.get("OCB_Promocode2") 
				+ "\"}],\"kohlsGiftCards\":[{\"giftCardNum\":\"" + testData.get("GIFT_CARD_NUMBER1") 
				+ "\",\"pin\":\"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[1].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[2].isApplied",".*" +"true"+".*", "Value should be applied in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode2")+".*", "Given Promocode should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+ testData.get("OCB_Promocode1")+".*", "Given Promocode should be present in the response");		
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "Value should be applied in the response");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

	@Test(groups = { "ocbphase2wallet", "regression1" }, enabled = true, priority = 2, testName = "OCB orderCalc with multiple KohlsCash",
			description = "Verify whether User is able to do V2 orderCalc with Multiple KohlsCash")
	
	public void OC_RemoveKohlsCash_Wallet() {
		
		//Creating KohlsCash 
		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		
		// Create a new profile through OAPI
				String strOCBEmail = Utilities.getNewEmailID();
				String strOCBPaswd = "Qwerty#1";
				Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
				Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_multipromo");
				
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_CVV2"), "1")
						+ "]}}}";
				
				//Validation UpdateCart Response
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				validator = new ResponseValidator(strResponseOAPIAddCart);
				validator.validateNoErrors();
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_multipromo");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_multipromo");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
						

				// SiginIn to Adapter using the above created OCB profile
						Utilities.signInProfileV2(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_multipromo","walletId","walletToken");
				// Update cart through Adapter
						mapheader.clear();
						mapheader.put("Wallet_token", testData.get("walletToken"));
						mapheader.put("X-Wallet-Id", testData.get("walletId"));
						mapheader.put("X-Add-To-Wallet", "true");
						mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
									
						// Update cart through Adapter
				
				String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
									+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"add\"},"
									+"{\"kohlsCashNum\":\""+arr1[0]+"\",\"pin\":\""+arr1[1]+"\",\"action\":\"add\"}"+"]}}}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

				strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")+"\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":["
						+"{\"kohlsCashNum\":\""+arr[0]+"\",\"pin\":\""+arr[1]+"\",\"action\":\"remove\"}]}}}}}";
				
				strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
				
				validator = new ResponseValidator(strResponseAddCart1);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
				validator.nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+arr1[0]+".*", "Given KohlsCash should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("SKU_CVV2"), "Given Sku code should be present in the response");
				validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		//get wallet and see promocode
		String strURL = GET_WALLET_ID + "/" + testData.get("walletId");

		// Get wallet response
		mapheader.clear();
		mapheader.put("token", testData.get("walletToken"));
		
		String strResponsewallet = RestCall.getRequest(strURL, Server.WalletAuth, false, mapheader);
		
		validator = new ResponseValidator(strResponsewallet);
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr[0]+".*", "Given kohlscash should be present in the response");
		validator.nodeMatches("$.currentWalletItems[*].id", ".*"+arr1[0]+".*", "Given kohlscash should be present in the response");
		
		// Perform orderCalc with PromoCodes added earlier
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_multipromo")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_multipromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_CVV2"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":["
				+ "{\"kohlsCashNum\":\"" + arr1[0] + "\",\"pin\":\""+arr1[1]+"\"}]}}}}";
		
		mapheader.clear();
		mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_multipromo"));
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validateOrderResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.kohlscashvalidate("$.payload.order.paymentTypes.kohlsCash[*].kohlsCashNum", arr1[0]);
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Kohls Cash should be applied successfully");
		

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_multipromo"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}

}
