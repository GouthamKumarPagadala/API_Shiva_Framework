package test.java.adapters.order.bopus;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.INVENTORY_SKU_ADAPTER;
import static main.java.common.GlobalVariables.INVENTORY_SKU_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Bopus")
@Stories({ "Order Calc" })
public class OrderCalc {

	ResponseValidator validator;
	String strEmail = Utilities.getNewEmailID();
	String strPaswd = "Pass@123";
	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI
				
				Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");
						
				
				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
	}
	@BeforeMethod(alwaysRun = true)
	public void testSetup1(){
		
		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
		
	}

	@Test(groups = { "Bopus","regression","OrderCalcBopus-NAP148","DIE Changes"}, enabled = true,
			priority = 4,
			testName = "Normal Item Treated as Bopus ItemType=Bopus",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus,<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWhoseItemTypeBopus() {
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1","759", Server.Adapter);
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayload =	"{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartID\":\"" + testData.get("OAPICART_ID")
		+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{"
		+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateBopusOrderResponse(false, false, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		
		
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	
    public void BopusOrderCalcWithItemGiftWrapped() {

			//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1","759", Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));


				String strPayload =	"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			
		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateBopusOrderResponse(false, false, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		// validator.validateExpectedErrors("ORDER3001", "The SKU ("+testData.get("SKU_BOPUS")+") is not eligible for gift wrap.");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"cartItems\" : ["+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"),"1", testData.get("BOPUS_STORE")) +"]}}}";
			 */
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Normal Item Treated as Bopus ItemType=Bopus",
			
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus and promocode,<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithPromoCodeApplied() {
		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1","759", Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));
		// Create Request
		

				String strPayload =	"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
        validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "PromoCode should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			

			// Create the Json Request for create profile
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"cartItems\" : ["+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"),"1", testData.get("BOPUS_STORE")) +"]}}}";
			 */
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Kohlscash,<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithKohlscash() {

		String arr[]=TestData.createKohlsCash(10);

		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

		"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{"
				+ "\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.ItemTypeIsBopus("ItemType should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		validator.storeAddresses("storeAddresses should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			
			description = "Verify whether giftWrap=true is given in the request for a BOPUS item then return the error ORDER3001, 200 response code.")
	public void BopusOrderCalcWithItemNon_GiftWrappable() {

		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\""
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = false, priority = 4, testName = "Order Calc With Kohls Card & Promo Code",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus and Kohlscard,<br /> Bopus DIE phase2 changes")
	public void BopusOrdeCalcWithKohlsCardAndPromoCode() {

		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validatePaymentInfo();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Order Calc With Visa Card",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and visa card,<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithVisaCard() {

		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateTotal();
		validator.validatePaymentInfo();
		validator.validateCustomerInfo();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Visa card should be present in the response");
		validator.ItemTypeIsBopus("ItemType should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		validator.storeAddresses("storeAddresses should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Order Calc With Amex Card",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item with Amex card using GC<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithAmexCardAndGiftcard() {

		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
//		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "AMEX", "Visa card should be present in the response");
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));validator.ItemTypeIsBopus("ItemType should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		validator.storeAddresses("storeAddresses should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Order Calc With Discover Card",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus,<br /> Discover card using Kohlscash,GC,Promo,<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithDiscoverCard() {

		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		//  Create Kohls Cahs for specific amount
		String[] arrKC = TestData.createKohlsCash(10);  // Create KC for $10
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arrKC[0] + "\",\"pin\": \"" + arrKC[1] + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
	//	validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "DISC", "Visa card should be present in the response");
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));validator.ItemTypeIsBopus("ItemType should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		validator.storeAddresses("storeAddresses should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional","regression","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Order Calc With Visa Card",
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item with Master card <br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithMasterCard() {

		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	//	validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		
		validator.validateTotal();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Visa card should be present in the response");
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.ItemTypeIsBopus("ItemType should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		validator.storeAddresses("storeAddresses should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Master card<br /> Bopus DIE phase2 changes")
	public void OrderCalcWithBopusAndNonBopusItemUsingMasterCard() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

		"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Amex card,Promocode and kohlscash<br /> Bopus DIE phase2 changes")
	public void OrderCalcWithBopusAndNonBopusItemUsingAmexCard() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

		"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes"}, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Giftcard,promo,Kohlscash<br /> Bopus DIE phase2 changes")
	public void OrderCalcWithBopusAndNonBopusItemUsingGiftcardAndPromocode() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

		"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "Kohls cash applied for Bopus Item",
			
			description =  "\n TC Description - Verify whether user is able to do order calculation with Bopus item \n Feature - OrderCalc with Bopus Item and Non bopus Item using Amex Card and GC,KC<br /> Bopus DIE phase2 changes")
	public void OrderCalcWithBopusAndNonBopusUsingVisacardAndPromocode() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
				Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));

		// Create Request
		String strPayload =

		"{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateBopusOrderResponse(false, true, testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.earnedAmt", ".+", "kohlsCash earnedAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsCash.nxtQualifyAmt", ".+", "kohlsCash nxtQualifyAmt should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.earnedRewards", ".+", "kohlsRewards earnedRewards should be present in the response");
		validator.nodeMatches("$.payload.order.totals.purchaseEarnings.kohlsRewards.nxtQualifyAmt", ".+", "kohlsRewards nxtQualifyAmt should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.isBopusEligibleNotNull("isBopusEligible should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "Bopus","errorhandling" }, enabled = false, priority = 4, testName = "Error message should be dispalyed for out of stock skuCode",
			description = "Do Ordercalculation for an order with out of stock skucode")
	public void OutOfStockskuCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", "762") + "]}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		validator.validateExpectedErrors("ORDER3019", "Item(s) in your shopping bag are not available for pick up at the selected store.");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"cartItems\" : ["+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"),"1", testData.get("BOPUS_STORE")) +"]}}}";
			 */
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","errorhandling","OrderCalcBopus-NAP148","DIE Changes" }, enabled = true, priority = 4, testName = "WhetherErrorwhenBOPUSItemGiftWrapped",
						description =  "\n TC Description - Verify whether user is able to get proper error message when using Non-Gift wrappable item with Bopus item \n Feature - OrderCalc with Bopus Item and Non Gift wrappable item<br /> Bopus DIE phase2 changes")
	public void BopusOrderCalcWithoutCartId() {
		
		//Adding Items to Cart
		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"), Server.Adapter);
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));

		
		// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\""
						+ ", \"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")+"\",\"bopusItem\":\"false" +  JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\""
						+ "}}}";

			// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter CartID.");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"cartItems\" : ["+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"),"1", testData.get("BOPUS_STORE")) +"]}}}";
			 */
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email", true);
		}
	}
}