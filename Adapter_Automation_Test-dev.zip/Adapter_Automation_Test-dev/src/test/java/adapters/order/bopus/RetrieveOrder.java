package test.java.adapters.order.bopus;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;
import main.java.common.Utilities;

import main.java.common.RestCall;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Bopus")
@Stories({ "Retrieve Order" })
public class RetrieveOrder {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "Bopus","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID",
			dependsOnMethods = "test.java.adapters.order.bopus.PlaceOrder.BopusItemVisa",
			description = "To Verify whether the Error message is getting displayed with missing required parameter - Error code Order 1000.")
	public void MissingOrderID() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter orderNumber.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/";

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true,400);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID",
			description = "To Verify whether the Error message is getting displayed with invalid required parameter - Error code Order 1001.")
	public void InvalidPostalCodeParameter() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/8333005479?postalCde=10011";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1001", "postalCde is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/8333005479?postalCde=10011";

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus","errorhandling" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "To Verify whether the Error message is getting displayed missing access token - Error code Order1003.")
	public void OrderIDWithoutPostalCodeAndAccessToken() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter");			// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1003", "An access_token or postalCode is required to retrieve an order.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Item level status is populated in status field within the orderItem for each item in the BOPUS shipment  in response")
	public void OrderIDWithBopusItemOrder() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Verify whether shipAddress is getting displayed in the response if shipping item (non-Bopus) is provided in the cart")
	public void OrderIDWithNonBopusItem() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}

}
