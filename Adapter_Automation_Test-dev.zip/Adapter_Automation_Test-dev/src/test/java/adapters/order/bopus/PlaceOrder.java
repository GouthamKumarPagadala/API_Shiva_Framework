package test.java.adapters.order.bopus;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Bopus")
@Stories({ "Place Order" })
public class PlaceOrder {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "Bopus", "errorhandling" }, enabled = true, priority = 4, testName = "Bopus ItemType with Visa Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Visa Card")
	public void BopusItemVisa() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Master Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Master Card")
	public void BopusItemMaster() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();validator.validateCustomerInfo();validator.validatebillAddress();validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Discover Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Discover Card")
	public void BopusItemDiscover() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();validator.validateCustomerInfo();validator.validatebillAddress();validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Amex Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Amex Card")
	public void BopusItemAmex() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Kohls Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Visa Card")
	public void BopusItem_VisaCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Visa Card adn KC",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Visa Card and KC")
	public void BopusItemVisa_KC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with KC and Master Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Master Card and KC")
	public void BopusItemMaster_KC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Discover Card and KC",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Discover Card and KC")
	public void BopusItemDiscover_KC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus", "KC" }, enabled = true, priority = 4, testName = "Bopus ItemType with KC and Amex Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Amex Card and KC")
	public void BopusItemAmex_KC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);
		System.out.println("Balance for Amex" + testData.get("BALANCE"));
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with KC and Kohls Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Kohls Card and KC")
	public void BopusItemKohlsCard_KC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KOHLS_CARD")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Surcharge with Visa Card",
		dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with surcharge skucode with Visa Card")
	public void SurchargeSkuVisa() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_SURCHARGE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_CODE_SURCHARGE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Hazardous with Visa Card",
		dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with Hazardous skucode with Visa Card")
	public void HazardousVisa() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_HAZARDOUS"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_CODE_HAZARDOUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "BOGO + Sale with Visa Card",
		dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with BOGO + Sale skucode with Visa Card")
	public void BogoSaleVisa() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_BOGO_SALE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_CODE_BOGO_SALE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "Bopus" }, enabled = true, priority = 4, testName = "Bopus ItemType with Gift Card",
				dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.signInProfile"}, description = "Do Place Order an order with bopus skucode with Gift Card")
	public void BopusItemGiftCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER1") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN1") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
}