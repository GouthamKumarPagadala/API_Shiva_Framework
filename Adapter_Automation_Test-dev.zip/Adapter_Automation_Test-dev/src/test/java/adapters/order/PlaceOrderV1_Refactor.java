package test.java.adapters.order;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "Place Order - Guest user" })
public class PlaceOrderV1_Refactor {

	ResponseValidator validator;

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place order Guest User - Amex card", description = "Perform Place Order for an order as guest user using Amex card")
public void guestUserAmex() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}
@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - VISA card", description = "Perform PlaceOrder for an order as guest user using VISA card")
public void guestUserVisa() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Discover card", description = "Perform PlaceOrder for an order as guest user using Discover card")
public void guestUserDisc() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Master card", description = "Perform PlaceOrder for an order as guest user using Master card")
public void guestUserMaster() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo();
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Master card", description = "Perform Place Order for an order as guest user using Master card")
public void guestUserKCC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Amex and Gift card", description = "Perform PlaceOrder for an order as guest user with the combination of Amex card and gift card")
public void guestUserAmex_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - VISA card and Gift card", description = "Perform PlaceOrder for an order as guest user using VISA card with Gift card")
public void guestUserVisa_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Discover and Gift Card", description = "Perform PlaceOrder for an order as guest user with the combination of Discover and Gift Card")
public void guestUserDisc_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order for guest user - Master card with Gift Card", description = "Perform PlaceOrder for an order as guest user with the combination of Master card and Gift card")
public void guestUserMaster_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo();
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder for guest user - Master card with Gift Card", description = "Perform PlaceOrder for an order as guest user with the combination of Master card and Gift card")
public void guestUserKCC_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Amex and Promo code", description = "Perform PlaceOrder for an order as guest user with the combination of Amex card and Promo code")
public void guestUserAmex_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - VISA Card and Promo code", description = "Do Place Order for an order as guest user using VISA card with Promo code")
public void guestUserVisa_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Discover and Promocode", description = "Perform PlaceOrder for an order as guest user with the combination of Discover card and Promo code")
public void guestUserDisc_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"
		+ ""}, enabled = true, priority = 4, testName = "Place Order Guest User - Master Card with Promo code", description = "Perform PlaceOrder for an order as guest user with the combination of Master card and Promo code")
public void guestUserMaster_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo();
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User - Master Card with Promo code", description = "Perform PlaceOrder for an order as guest user with the combination of Master card and Promo code")
public void guestUserKCC_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Amex and Kohls Cash", description = "Perform PlaceOrder for an order as guest user with the combination of Amex card and Kohls Cash")
public void guestUserAmex_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);

	// Compare Open API
	//Payload for OAPI
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - VISA card with Kohls cash", description = "Perform PlaceOrder for an order as guest user using VISA card with Kohls Cash")
public void guestUserVisa_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	// Compare Open API
	
	//Payload for OAPI
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order Guest User - Discover Card", description = "Perform PlaceOrder for an order as guest user with the combination of Discover card and Kohls Cash")
public void guestUserDisc_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	
	// Compare Open API
	//Payload for OAPI
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order for guest user - Master card and Kohls Cash", description = "Perform PlaceOrder for an order as guest user using Master card with Kohls cash")
public void guestUserMaster_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo();
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	
	// Compare Open API
	//Payload for OAPI
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder for guest user - Master card and Kohls Cash", description = "Perform PlaceOrder for an order as guest user using Master card with Kohls cash")
public void guestUserKCC_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	
	// Compare Open API
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VisaCheckout with Visa Card",

description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully while paymentDetails=VC")
public void visaCheckoutPaymentDetailsVisa() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
	+ testData.get("VISA_ENC_DATA")
	+ "}}}}}";

// Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VXO-Place Order",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
public void visaCheckoutPaymentDetailsMaster() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("MASTER_ENC_DATA")
+ "}}}}}";

// 	Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// 	Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("MC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("MASTER")
+ "]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Amec card",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
public void visaChecoutPaymentDetailsAmex() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("AMEX_ENC_DATA")
+ "}}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("AMEX");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

//Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("AMEX")
+ "]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover card",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Discover card.")
public void visaCheckoutPaymentDetailsDisc() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("DISCOVER_ENC_DATA")
+ "}}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("DISC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

//Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("DISCOVER")
+ "]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Visa Card and Kohl's Cash",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with visa card and KohlsCash")
public void visaCheckoutPaymentDetailsVisa_KC() {

String arr[]=TestData.createKohlsCash(10);
String arr1[]=TestData.createKohlsCash(10);
// Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("VISA_ENC_DATA")
+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

// Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);


// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
	+ JsonString.getPaymentTypeJson("VISA")
	+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Master Card and Kohl's Cash",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Master Card and KohlsCash")
public void visaCheckoutPaymentDetailsMaster_KC() {

String arr[]=TestData.createKohlsCash(10);
String arr1[]=TestData.createKohlsCash(10);
//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("MASTER_ENC_DATA")
+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("MC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);

//Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("MASTER")
+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Amex card with Kohls cash",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
public void visaCheckoutPaymentDetailsAmex_KC() {

String arr[]=TestData.createKohlsCash(10);
String arr1[]=TestData.createKohlsCash(10);
//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("AMEX_ENC_DATA")
+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("AMEX");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);

//Compare Open API
if (CompareOAPI) {
//Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("AMEX")
+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

//Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

//Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover Card and Kohl's Cash",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
public void visaCheckoutPaymentDetailsDisc_KC() {

String arr[]=TestData.createKohlsCash(10);
String arr1[]=TestData.createKohlsCash(10);
//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("DISCOVER_ENC_DATA")
+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("DISC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);

//Compare Open API
if (CompareOAPI) {
//Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("DISCOVER")
+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

//Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

//Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}


@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Visa Card and PromoCode",

description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Visa Card and PromoCode")
public void visaCheckoutPaymentDetailsVisa_Promo() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
	+ testData.get("VISA_ENC_DATA")
	+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

// Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Master Card and PromoCode",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Master Card and PromoCode")
public void visaCheckoutPaymentDetailsMaster_Promo() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("MASTER_ENC_DATA")
+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

// 	Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// 	Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("MC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("MASTER")
+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Amex card and Promocode",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
public void visaCheckoutPaymentDetailsAmex_Promo() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("AMEX_ENC_DATA")
+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("AMEX");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

//Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("AMEX")
+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover Card and PromoCode",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Discover card and PromoCode")
public void visaCheckoutPaymentDetailsDisc_Promo() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("DISCOVER_ENC_DATA")
+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("DISC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

//Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("DISCOVER")
+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Visa Card and GiftCard",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Visa card and GiftCard")
public void visaCheckoutPaymentDetailsVisa_GC() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("VISA_ENC_DATA")
+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
	+ JsonString.getPaymentTypeJson("VISA")
	+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with master Card and GiftCard",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Master Card And GiftCard")
public void visaCheckoutPaymentDetailsMaster_GC() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("MASTER_ENC_DATA")
+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("MC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

//Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("MASTER")
+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA checkout - Place Order with Amex card and Gift card",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
public void visaCheckoutPaymentDetailsAmex_GC() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("AMEX_ENC_DATA")
+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("AMEX");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

//Compare Open API
if (CompareOAPI) {
//Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("AMEX")
+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

//Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

//Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover Card and GiftCard",
description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Discover Card and GiftCard")
public void visaCheckoutPaymentDetailsDisc_GC() {

//Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("DISCOVER_ENC_DATA")
+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

//Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("DISC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

//Compare Open API
if (CompareOAPI) {
//Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
+ JsonString.getPaymentTypeJson("DISCOVER")
+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

//Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

//Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "Place Order With Master Card Bin Range", description = "Do PlaceOrder for an order using Master card bin range")
public void MasterCard_Binrange() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER_BINRANGE")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo();
	validator.validateTotal();
	validator.validatePaymentInfo("MC");
	validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
	
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
		String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card.")
public void ApplePay_Visa() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

// Compare Open API
if (CompareOAPI) {
	
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard.")
public void ApplePay_Visa_GC() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "3") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

// Compare Open API
if (CompareOAPI) {

	 strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "3") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
			+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.")
public void ApplePay_Visa_Promo() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and KohlsCash.")
public void ApplePay_Visa_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard + KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + KohlsCash.")
public void ApplePay_Visa_GC_KC() {
	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.")
public void ApplePay_Visa_Promo_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and KohlsCash.")
public void ApplePay_Visa_KC_Promo() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard + PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + PromoCode.")
public void ApplePay_Visa_GC_Promo() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard + PromoCode + KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + PromoCode + KohlsCash.")
public void ApplePay_Visa_GC_Promo_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
									+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
									+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card.")
public void ApplePay_Mc() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard.")
public void ApplePay_Mc_GC() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and PromoCode.")
public void ApplePay_Mc_Promo() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems[0].cartItemID,payload.order.cartItems[0].shipmentGroupID,payload.order.shippingMethods[0].shipmentGroupID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and KohlsCash.")
public void ApplePay_Mc_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard + KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + KohlsCash.")
public void ApplePay_Mc_GC_KC() {
	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and PromoCode.")
public void ApplePay_Mc_Promo_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and KohlsCash.")
public void ApplePay_Mc_KC_Promo() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard + PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + PromoCode.")
public void ApplePay_Mc_GC_Promo() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard + PromoCode + KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + PromoCode + KohlsCash.")
public void ApplePay_Mc_GC_Promo_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"mc\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
									+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
									+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card.")
public void ApplePay_Amex() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard.")
public void ApplePay_Amex_GC() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and PromoCode.")
public void ApplePay_Amex_Promo() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and KohlsCash.")
public void ApplePay_Amex_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard + KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + KohlsCash.")
public void ApplePay_Amex_GC_KC() {
	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and PromoCode.")
public void ApplePay_Amex_Promo_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and KohlsCash.")
public void ApplePay_Amex_KC_Promo() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderKohlsCash(arr[0], true);
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode.")
public void ApplePay_Amex_GC_Promo() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode + KohlsCash",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode + KohlsCash.")
public void ApplePay_Amex_GC_Promo_KC() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"amex\"}"
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
									+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
validator.validateOrderKohlsCash(arr[0], true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "5") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
							+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
									+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}


@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card", description = "Perform Ordercalculation for an order as guest user using VISA card with modes=INGEOFENCE")
public void InstoreFreeShip_Visa() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
			+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card + PromoCode + GiftCard", description = "Perform Ordercalculation for an order as guest user using VISA card + PromoCode + GiftCard with modes=INGEOFENCE")
public void InstoreFreeShip_Visa_Promo_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
			+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card and PromoCode", description = "Perform Ordercalculation for an order as guest user using VISA card and PromoCode with modes=INGEOFENCE")
public void InstoreFreeShip_Visa_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
			+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card and KohlsCash", description = "Perform Ordercalculation for an order as guest user using VISA card and PromoCode + KohlsCash with modes=INGEOFENCE")
public void InstoreFreeShip_Visa_KohlsCash() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
			+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("VISA_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	
	//OpenAPI Payload
	strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
			+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("VISA")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - Amex and Gift card", description = "Perform Ordercalculation for an order as guest user with modes=INGEOFENCE and the combination of Amex card and gift card")
public void InstoreFreeShip_Amex_GC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_V1_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "TDD") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"TDD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("AMEX")
			+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderInstoreResponse(true,false, false);
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"TDD");
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User Instore Mode- Master Card with Promo code", description = "Perform Ordercalculation for an order as guest user with the combination of Master card and Promo code with mode=INGEOFENCE")
public void InstoreFreeShip_Master_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User Instore Mode- Master Card with Kohl's Cash", description = "Perform Ordercalculation for an order as guest user with the combination of Master card and KohlsCash with mode=INGEOFENCE")
public void InstoreFreeShip_Master_KohlsCash() {

	String arr[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Ordercalculation for guest user Instore Mode- Master card and Kohls Cash", description = "Perform Ordercalculation for an order as guest user using Master card with Kohls cash with modes=INGEOFENCE")
public void InStoreFreeShip_KCC_KC() {

	String arr[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Ordercalculation for guest user Instore Mode- Master card and Kohls Cash + GiftCard", description = "Perform Ordercalculation for an order as guest user using Master card with Kohls cash + GiftCard with modes=INGEOFENCE")
public void InStoreFreeShip_KCC_KC_GC() {

	String arr[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderKohlsCash(arr[0], true);
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = { "Refactor","regression1"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay and Instore mode with Visa Card",
description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY  and Modes-INGEOFENCE while passing the request with Visa Card.")
public void Instore_ApplePay_Visa() {

// Create the Json Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+ "{\"type\":\"visa\"}"
			+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

// Post the request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderApplePayResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_APPLEPAY"), "USSTD");
validator.validatePaymentInfo("VISA");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderInstoreResponse(true,true, true);

// Compare Open API
if (CompareOAPI) {

	strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_APPLEPAY"), "1") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
			+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
			+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

// Get the request
String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
}
}

@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VisaCheckout with Modes=INGEOFENCE and Card=MC ",
description = "Verify whether payment details getting retrieved from VISA checkout registry to ordercalc reponse successfully with modes=INGEOFENCE")
public void Instore_visaCheckoutPaymentDetailsMaster() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
+ "\"email\":\"shankarc44@gmail.com\","
+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
+ "\"shippingMethod\":\"USSTD\","
+ " \"isBillAddressEqualtoShipAddress\":\"true\","
+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
+ testData.get("MASTER_ENC_DATA")
+ "}}}}}";

// 	Post Request
String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

// 	Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validateOrderVXOResponse();
validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
validator.validatePaymentInfo("MC");
validator.validatebillAddress();
validator.validateCustomerInfo();
validator.validateshipAddress();
validator.validateOrderInstoreResponse(true,true, true);

// Compare Open API
if (CompareOAPI) {
	// Create the Json Request
	String strPayloadOAPI = "{\"payload\": {\"order\":"
	+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
	+ JsonString.getPaymentTypeJson("MASTER")
	+ "]}}}}";

	// Post the request
	String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

	// Compare the result
	Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore Mode - Discover card", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Discover card")
public void InstoreFreeShip_Disc() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_V1_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "ODD") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"ODD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"ODD");
	validator.validateOrderInstoreResponse(true,false, false);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore Mode - Discover card and KohlsCash", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Discover card and KohlsCash")
public void InstoreFreeShip_Disc_KohlsCash() {

	String arr[]=TestData.createKohlsCash(10);
	String arr1[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderKohlsCash(arr[0], true);
	
	//PlaceOrder Payload
	strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore Mode - Discover card and PromoCode", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Discover card and PromoCode")
public void InstoreFreeShip_Disc_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("DISCOVER")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore mode - Master card", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Master card")
public void InstoreFreeShip_Master() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_V1_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "AHSTD") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"AHSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"false\","
			+ "\"shipAddress\":" + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"AHSTD");
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore mode - Master card", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Master card")
public void InstoreFreeShip_Master_KC_Promo() {

	String arr[]=TestData.createKohlsCash(10);
	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("MASTER")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderInstoreResponse(true,true, true);
	validator.validateOrderKohlsCash(arr[0], true);
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with InstoreMode - Kohls card", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Master card")
public void InstoreFreeShip_KCC() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "]}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}

@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore mode - Kohls card + Promo", description = "Perform Ordercalculation for an order as guest user with modes= INGEOFENCE using Kohls card and PromoCode")
public void InstoreFreeShip_KCC_Promo() {

	// Create Request
	String strPayload = "{\"payload\": {\"order\":"
			+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
			+ "\"email\":\"shankarc44@gmail.com\","
			+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
			+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
			+ "\"shippingMethod\":\"USSTD\","
			+ " \"isBillAddressEqualtoShipAddress\":\"true\","
			+ " \"paymentTypes\" :{\"creditCards\" : ["
			+ JsonString.getPaymentTypeJson("KCC_CVV2")
			+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]	}}}}";

	// Post Request
	String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

	// Validate Response
	validator = new ResponseValidator(strResponse);
	validator.validateNoErrors();
	// validator.validateCartResponse();
	validator.validatebillAddress();
	validator.validateshipAddress();
	validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
	validator.validateTotal();
	validator.validateCustomerInfo();
	validator.validateOrderResponse(true, false,testData.get("SKU_NORMAL"),"USSTD");
	validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
	validator.validateOrderInstoreResponse(true,true, true);
	// Compare Open API
	if (CompareOAPI) {
		// Post the request
		String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
	}
}
}