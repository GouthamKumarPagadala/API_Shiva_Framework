package test.java.adapters.order;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("Order")
@Stories({ "Place Order - Registered user" })


public class PlaceOrderV2_Refactor {

	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Pass@123";
		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");


		// SiginIn to Adapter using the above created OCB profile
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
	}
	@BeforeMethod(alwaysRun = true)
	public void testSetup1(){

		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));

	}

	ResponseValidator validator;

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place order registered user - Amex card", description = "Perform Place Order for an order as registered user using Amex card")
	public void RegisteredUserAmex() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "Refactor", "regression",
	"NuData" }, enabled = true, priority = 4, testName = "Place Order registered user - VISA card", description = "Perform PlaceOrder for an order as registered user using VISA card")
	public void RegisteredUserVisa() {

		// Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("VISA") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("VISA") + "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.orderNumber,payload.order.cartItems.cartItemID,payload.order.cartID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Discover card", description = "Perform PlaceOrder for an order as registered user using Discover card")
	public void RegisteredUserDisc() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Master card", description = "Perform PlaceOrder for an order as registered user using Master card")
	public void RegisteredUserMaster() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Master card", description = "Perform Place Order for an order as registered user using Master card")
	public void RegisteredUserKCC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Amex and Gift card", description = "Perform PlaceOrder for an order as registered user with the combination of Amex card and gift card")
	public void RegisteredUserAmex_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - VISA card and Gift card", description = "Perform PlaceOrder for an order as registered user using VISA card with Gift card")
	public void RegisteredUserVisa_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Discover and Gift Card", description = "Perform PlaceOrder for an order as registered user with the combination of Discover and Gift Card")
	public void RegisteredUserDisc_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order for registered user - Master card with Gift Card", description = "Perform PlaceOrder for an order as registered user with the combination of Master card and Gift card")
	public void RegisteredUserMaster_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder for registered user - Master card with Gift Card", description = "Perform PlaceOrder for an order as registered user with the combination of Master card and Gift card")
	public void RegisteredUserKCC_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Amex and Promo code", description = "Perform PlaceOrder for an order as registered user with the combination of Amex card and Promo code")
	public void RegisteredUserAmex_Promo() {

		String[] PromoCodes = {testData.get("PROMOCODE")};

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			//Adding PromoCodes to Cart
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);

			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - VISA Card and Promo code", description = "Do Place Order for an order as registered user using VISA card with Promo code")
	public void RegisteredUserVisa_Promo() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			//Adding PromoCodes to Cart
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);

			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Discover and Promocode", description = "Perform PlaceOrder for an order as registered user with the combination of Discover card and Promo code")
	public void RegisteredUserDisc_Promo() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			//Adding PromoCodes to Cart
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"
			+ ""}, enabled = true, priority = 4, testName = "Place Order registered user - Master Card with Promo code", description = "Perform PlaceOrder for an order as registered user with the combination of Master card and Promo code")
	public void RegisteredUserMaster_Promo() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			//Adding PromoCodes to Cart
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);

			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder registered user - Master Card with Promo code", description = "Perform PlaceOrder for an order as registered user with the combination of Master card and Promo code")
	public void RegisteredUserKCC_Promo() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);

			//Adding PromoCodes to Cart
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);

			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Amex and Kohls Cash", description = "Perform PlaceOrder for an order as registered user with the combination of Amex card and Kohls Cash")
	public void RegisteredUserAmex_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding PromoCodes to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API

		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			//Adding PromoCodes to Cart
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - VISA card with Kohls cash", description = "Perform PlaceOrder for an order as registered user using VISA card with Kohls Cash")
	public void RegisteredUserVisa_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding KohlsCash to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);
		// Compare Open API

		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			//Adding KohlsCash to Cart
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			//Payload for OAPI
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order registered user - Discover Card", description = "Perform PlaceOrder for an order as registered user with the combination of Discover card and Kohls Cash")
	public void RegisteredUserDisc_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding KohlsCash to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API

		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			//Adding KohlsCash to Cart
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			//Payload for OAPI
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Place Order for registered user - Master card and Kohls Cash", description = "Perform PlaceOrder for an order as registered user using Master card with Kohls cash")
	public void RegisteredUserMaster_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding KohlsCash to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API

		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			//Adding KohlsCash to Cart
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);

			//Payload for OAPI
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder for registered user - Master card and Kohls Cash", description = "Perform PlaceOrder for an order as registered user using Master card with Kohls cash")
	public void RegisteredUserKCC_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.Adapter);

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding KohlsCash to Cart
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API

		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "1", Server.OpenApi);
			//Adding KohlsCash to Cart
			Utilities.AddPaymentTypetoCart(arr, null, Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VisaCheckout with Visa Card",

			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully while paymentDetails=VC")
	public void visaCheckoutPaymentDetailsVisa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VXO-Place Order",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
	public void visaCheckoutPaymentDetailsMaster() {

		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "}}}}}";

		//			 	Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//			 	Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("MC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Amec card",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
	public void visaChecoutPaymentDetailsAmex() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("AMEX_ENC_DATA")
				+ "}}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("AMEX");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		//Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover card",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Discover card.")
	public void visaCheckoutPaymentDetailsDisc() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "}}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("DISC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		//Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Visa Card and Kohl's Cash",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with visa card and KohlsCash")
	public void visaCheckoutPaymentDetailsVisa_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);


		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Master Card and Kohl's Cash",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Master Card and KohlsCash")
	public void visaCheckoutPaymentDetailsMaster_KC() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("MC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		//Compare Open API
		if (CompareOAPI) {
			String arr1[]=TestData.createKohlsCash(10);
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor", "regression",
	"NuData" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Amex card with Kohls cash", description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
	public void visaCheckoutPaymentDetailsAmex_KC() {

		String arr[] = TestData.createKohlsCash(10);
		// Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("AMEX_ENC_DATA") + "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \""
				+ arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("AMEX");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			String arr1[] = TestData.createKohlsCash(10);
			// Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX") + "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0]
							+ "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover Card and Kohl's Cash",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
	public void visaCheckoutPaymentDetailsDisc_KC() {

		String arr[]=TestData.createKohlsCash(10);
		//String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("DISC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		//Compare Open API
		if (CompareOAPI) {
			String arr1[]=TestData.createKohlsCash(10);
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			//Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			//Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			//Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Visa Card and PromoCode",

			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Visa Card and PromoCode")
	public void visaCheckoutPaymentDetailsVisa_Promo() {

		String[] PromoCodes = {testData.get("PROMOCODE")};
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Master Card and PromoCode",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Master Card and PromoCode")
	public void visaCheckoutPaymentDetailsMaster_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		//			 	Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//			 	Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("MC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Amex card and Promocode",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
	public void visaCheckoutPaymentDetailsAmex_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("AMEX_ENC_DATA")
				+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("AMEX");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		//Compare Open API


		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover Card and PromoCode",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Discover card and PromoCode")
	public void visaCheckoutPaymentDetailsDisc_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "},\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("DISC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		//Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Visa Card and GiftCard",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Visa card and GiftCard")
	public void visaCheckoutPaymentDetailsVisa_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with master Card and GiftCard",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Master Card And GiftCard")
	public void visaCheckoutPaymentDetailsMaster_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("MC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		//Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA checkout - Place Order with Amex card and Gift card",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully")
	public void visaCheckoutPaymentDetailsAmex_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("AMEX_ENC_DATA")
				+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("AMEX");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		//Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			//Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			//Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			//Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VISA Checkout - Place Order with Discover Card and GiftCard",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to Place Order reponse successfully with Discover Card and GiftCard")
	public void visaCheckoutPaymentDetailsDisc_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		//Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		//Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("DISC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		//Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			//Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			//Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			//Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "Place Order With Master Card Bin Range", description = "Do PlaceOrder for an order using Master card bin range")
	public void MasterCard_Binrange() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER_BINRANGE")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validatePaymentInfo("MC");
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
			// Post the request
			String strURLOAPI = PLACEORDERV2_OAPI + "&channel=mobile";
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER_BINRANGE")
					+ "]}}}}";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card.")
	public void ApplePay_Visa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "1", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "1", Server.OpenApi);

			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard.")
	public void ApplePay_Visa_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "3", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "3", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "3", Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "3", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.")
	public void ApplePay_Visa_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and KohlsCash.")
	public void ApplePay_Visa_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "4", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "4", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {

			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "4", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "4", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard + KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + KohlsCash.")
	public void ApplePay_Visa_GC_KC() {
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {

			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and PromoCode.")
	public void ApplePay_Visa_Promo_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {

			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and KohlsCash.")
	public void ApplePay_Visa_KC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard + PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + PromoCode.")
	public void ApplePay_Visa_GC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Visa Card and GiftCard + PromoCode + KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Visa Card and GiftCard + PromoCode + KohlsCash.")
	public void ApplePay_Visa_GC_Promo_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor", "regression", "apple_pay",
	"NuData" }, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card", description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card.")
	public void ApplePay_Mc() {

		// Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "2", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + "{\"type\":\"mc\"}"
				+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {
			// Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "2", Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
					+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
					+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MC_APPLEPAY") + "],\"paymentToken\":\""
					+ testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result

			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}



	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard.")
	public void ApplePay_Mc_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and PromoCode.")
	public void ApplePay_Mc_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and KohlsCash.")
	public void ApplePay_Mc_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.Adapter);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard + KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + KohlsCash.")
	public void ApplePay_Mc_GC_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and PromoCode.")
	public void ApplePay_Mc_Promo_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and KohlsCash.")
	public void ApplePay_Mc_KC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard + PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + PromoCode.")
	public void ApplePay_Mc_GC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Master Card and GiftCard + PromoCode + KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Master Card and GiftCard + PromoCode + KohlsCash.")
	public void ApplePay_Mc_GC_Promo_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"mc\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("MC_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card.")
	public void ApplePay_Amex() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "2", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "2", Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard.")
	public void ApplePay_Amex_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and PromoCode.")
	public void ApplePay_Amex_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and KohlsCash.")
	public void ApplePay_Amex_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard + KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + KohlsCash.")
	public void ApplePay_Amex_GC_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER")+ "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}"
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and PromoCode.")
	public void ApplePay_Amex_Promo_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and KohlsCash.")
	public void ApplePay_Amex_KC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode.")
	public void ApplePay_Amex_GC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1", "apple_pay"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode + KohlsCash",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode + KohlsCash.")
	public void ApplePay_Amex_GC_Promo_KC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"amex\"}"
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX") + "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		validator.validateOrderKohlsCash(arr[0], true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "5", Server.OpenApi);
			String arr1[]=TestData.createKohlsCash(10);
			Utilities.AddPaymentTypetoCart(arr1, PromoCodes, Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "5", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("AMEX_APPLEPAY")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
					+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card", description = "Perform PlaceOrder for an order as guest user using VISA card with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		// Compare Open API
		if (CompareOAPI) {
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
			strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
					+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card + PromoCode + GiftCard", description = "Perform PlaceOrder for an order as guest user using VISA card + PromoCode + GiftCard with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa_Promo_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
					+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
					+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card and PromoCode", description = "Perform PlaceOrder for an order as guest user using VISA card and PromoCode with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
					+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - VISA card and KohlsCash", description = "Perform PlaceOrder for an order as guest user using VISA card and PromoCode + KohlsCash with modes=INGEOFENCE")
	public void InstoreFreeShip_Visa_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
				+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":{\"modes\":[\"INGEOFENCE\"],"
					+ "\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder With InstoreMode - Amex and Gift card", description = "Perform PlaceOrder for an order as guest user with modes=INGEOFENCE and the combination of Amex card and gift card")
	public void InstoreFreeShip_Amex_GC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderInstoreResponse(true,false, false);
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"TDD");
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User Instore Mode- Master Card with Promo code", description = "Perform PlaceOrder for an order as guest user with the combination of Master card and Promo code with mode=INGEOFENCE")
	public void InstoreFreeShip_Master_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User Instore Mode- Master Card with Kohl's Cash", description = "Perform PlaceOrder for an order as guest user with the combination of Master card and KohlsCash with mode=INGEOFENCE")
	public void InstoreFreeShip_Master_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder for guest user Instore Mode- Master card and Kohls Cash", description = "Perform PlaceOrder for an order as guest user using Master card with Kohls cash with modes=INGEOFENCE")
	public void InStoreFreeShip_KCC_KC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder for guest user Instore Mode- Master card and Kohls Cash + GiftCard", description = "Perform PlaceOrder for an order as guest user using Master card with Kohls cash + GiftCard with modes=INGEOFENCE")
	public void InStoreFreeShip_KCC_KC_GC() {

		String arr[]=TestData.createKohlsCash(10);
		String arr1[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]"
				+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), true);
		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.OpenApi);
			Utilities.AddPaymentTypetoCart(arr1, null, Server.OpenApi);
			// Create Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("KCC_CVV2")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr1[0] + "\",\"pin\": \"" + arr1[1] + "\"}]"
					+ ",\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1"}, enabled = true, priority = 7, testName = "PlaceOrder with PaymentDetails=ApplePay and Instore mode with Visa Card",
			description = "Verify whether user able to do PlaceOrder with paymentDetails=APPLEPAY  and Modes-INGEOFENCE while passing the request with Visa Card.")
	public void Instore_ApplePay_Visa() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "1", Server.Adapter);
		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderApplePayResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_APPLEPAY"), "USSTD");
		validator.validatePaymentInfo("VISA");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderInstoreResponse(true,true, true);

		// Compare Open API
		if (CompareOAPI) {
			//Adding Items to Cart
			Utilities.AddItemtoCart(testData.get("SKU_APPLEPAY"), "1", Server.OpenApi);
			// Create the Json Request
			strPayload = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_APPLEPAY"), "1", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+  JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "VisaCheckout with Modes=INGEOFENCE and Card=MC ",
			description = "Verify whether payment details getting retrieved from VISA checkout registry to ordercalc reponse successfully with modes=INGEOFENCE")
	public void Instore_visaCheckoutPaymentDetailsMaster() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "}}}}}";

		//			 	Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		//			 	Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateOrderVXOResponse();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo("MC");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderInstoreResponse(true,true, true);

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "Refactor", "regression",
	"NuData" }, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore Mode - Discover card", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Discover card")
	public void InstoreFreeShip_Disc() {

		// Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\"," + "\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("DISCOVER") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true, testData.get("SKU_NORMAL"), "ODD");
		validator.validateOrderInstoreResponse(true, false, false);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore Mode - Discover card and KohlsCash", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Discover card and KohlsCash")
	public void InstoreFreeShip_Disc_KohlsCash() {

		String arr[]=TestData.createKohlsCash(10);
		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		Utilities.AddPaymentTypetoCart(arr, null, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderKohlsCash(arr[0], true);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore Mode - Discover card and PromoCode", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Discover card and PromoCode")
	public void InstoreFreeShip_Disc_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore mode - Master card", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Master card")
	public void InstoreFreeShip_Master() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"AHSTD");
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore mode - Master card", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Master card")
	public void InstoreFreeShip_Master_KC_Promo() {


		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String arr[]=TestData.createKohlsCash(10);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(arr, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderInstoreResponse(true,true, true);
		validator.validateOrderKohlsCash(arr[0], true);
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with InstoreMode - Kohls card", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Master card")
	public void InstoreFreeShip_KCC() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "PlaceOrder Guest User with Instore mode - Kohls card + Promo", description = "Perform PlaceOrder for an order as guest user with modes= INGEOFENCE using Kohls card and PromoCode")
	public void InstoreFreeShip_KCC_Promo() {

		//Adding Items to Cart
		Utilities.AddItemtoCart(testData.get("SKU_NORMAL"), "2", Server.Adapter);
		String[] PromoCodes = {testData.get("PROMOCODE")};
		Utilities.AddPaymentTypetoCart(null, PromoCodes, Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"modes\":[\"INGEOFENCE\"],\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2_SHIPMETHOD", testData.get("SKU_NORMAL"), "2", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]	}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true, true,testData.get("SKU_NORMAL"),"USSTD");
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderInstoreResponse(true,true, true);
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	//STC Test cases


	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "PlaceorderV2 with STC_EWaste_CA",
			description = "Verify whether the User is getting SaleTax and FeeDetails for EWaste product shipped to California in reponse for PlaceOrder V2 Call.")
	public void STC_EWaste_CA_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "1", Server.Adapter);
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("California","ewaste");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));

			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "PlaceorderV2 with STC_EWaste_CT",
			description = "Verify whether the User is getting SaleTax and FeeDetails for EWaste product shipped to Connecticut in reponse for PlaceOrder V2 Call.")
	public void STC_EWaste_CT_RegisteredUser_V2() {


		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("Connecticut","ewaste");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "PlaceorderV2 with STC_Mattress_CT",
			description = "Verify whether the User is getting SaleTax and FeeDetails for Mattress product shipped to Connecticut in reponse for PlaceOrder V2 Call.")
	public void STC_Mattress_CT_RegisteredUser_V2() {


		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CT_AVON") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("Connecticut","Mattress");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}	
	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 2, testName = "PlaceorderV2 with STC_Mattress_CA",
			description = "Verify whether the User is getting SaleTax and FeeDetails for Mattress product shipped to California in reponse for PlaceOrder V2 Call.")
	public void STC_Mattress_CA_RegisteredUser_V2() {

		Utilities.AddItemtoCart(testData.get("EWASTE_SKUCODE"), "1", Server.Adapter);

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));


		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + "\",\"skuCode\":\"" + testData.get("EWASTE_SKUCODE") + "\", \"qty\":\"1\", \"shippingMethod\":\"USSTD\"}" + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadOrderCalc, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);

		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(true,true,testData.get("EWASTE_SKUCODE"),"USSTD");
		validator.validateSTCResponse("California","Mattress");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			// GetCart response from OAPI
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi"));
			String strURLOAPI = ORDERCALC_OAPI + "&channel=mobile";

			String strResponseOAPIGetCart = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
	}

	//Master Pass

	@Test(groups = {"Refactor","regression1"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using amex card and promocode to placeorder response successfully")
	public void MasterPass_AmexCard_Promocode() {


		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				+"\"paymentMethod\":\"MASTERPASS\","
				+"\"transactionID\":\"442305669\"},"
				+"\"creditCards\" : [{"
				+"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
				+"\"type\":\"AMEX\","
				+"\"expDate\":\"03/2018\"}"
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") 
				+ "\"}]}}}}";


		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		validator.validateOrderResponse(true, false, testData.get("SKU_NORMAL"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validateOrderPromoCode(testData.get("PROMOCODE"), true);
		validator.validateOrderMasterPassResponse();
		//validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}

	//Bopus alternative pickup

	@Test(groups = { "Refactor","regression1" }, enabled = true, priority = 4, testName = "PlaceOrder V2 with BopusAlternate Pickup Notification number",
			description = "Kohls application user wants to verify whether textNotificationNumber information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_textNotificationNumber() {

		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"), Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID") +"\",\"alternatePickUpPersons\":["
				+JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		validator.validateOrderResponse(true, false, testData.get("SKU_BOPUS"), "USSTD");
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validatebillAddress();
		validator.validateBopusItem(testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.validateBopusAlternatePickup(testData.get("CUSTOMER_FIRSTNAME"), testData.get("CUSTOMER_LASTNAME"), "razzirazzu@gmail.com");
		validator.validateBopusAlternatePickupNotificationNumber(testData.get("BOPUS_PHONE_NUMBER"));

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "Refactor", "regression",
	"NuData" }, enabled = true, priority = 4, testName = "PlaceOrder V2 with BopusAlternate pickup Details", description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail_Master() {

		Utilities.AddBopusItemtoCart(testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"), Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"nuData\":{\"channel\":\"iphone\",\"ndpdData\":\"eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bnEtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogXCJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJhdFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJoYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj\"},\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"alternatePickUpPersons\":[" + JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]," + "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("MASTER") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);

		validator.validateNoErrors();
		validator.validateOrderResponse(true, false, testData.get("SKU_BOPUS"), "USSTD");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateBopusItem(testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
		validator.validateBopusAlternatePickup(testData.get("CUSTOMER_FIRSTNAME"), testData.get("CUSTOMER_LASTNAME"),
				"razzirazzu@gmail.com");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
}