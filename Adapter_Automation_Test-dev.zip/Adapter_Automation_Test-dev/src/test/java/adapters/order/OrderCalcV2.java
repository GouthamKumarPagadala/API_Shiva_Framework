package test.java.adapters.order;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "Order Calc- Registered user" })
public class OrderCalcV2 {
	
	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Pass@123";
				Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "access_token_oapi");
				
				String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
						+ JsonString.getCartJson("VALID_ADD", testData.get("SKU_NORMAL"), "1")
						+ "]}}}";

				// Post the request for updateCart(ADD) using mapheader to OAPI
				String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true);
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
				Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
	}

	ResponseValidator validator;
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with single character firstname in the shipping address with trEnabled=true.",
			description = "Kohl's application user wants to do orderCalc-v2 with single character firstname in the shipping address with trEnabled=true")
	public void singleCharacterShipAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		

	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with single character lastname in the shipping address with trEnabled=true.",
			description = "Kohl's application user wants to do orderCalc-v2 with single character lastname in the shipping address with trEnabled=true")
	public void singleCharacterShipAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
			
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with single character firstname as well as single character lastname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with single character firstname as well as single character lastname in the shipping address with trEnabled=true")
	public void singleCharacterShipAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with single character firstname and single character lastname in shipping address as well as single character firstname and single character lastname in the bill address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with single character firstname and single character lastname in shipping address as well as single character firstname and single character lastname in thebill address with trEnabled=true")
	public void singleCharacterShip_BillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as firstname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with single character firstname in the shipping address with trEnabled=true")
	public void spaceShipAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as lastname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with space as lastname in the shipping address with trEnabled=true")
	public void spaceShipAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Last Name.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as both firstname and Lastname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with space as both firstname and lastname in the shipping address with trEnabled=true")
	public void spaceShipAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as firstname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character firstname in the shipping address with trEnabled=true")
	public void specialCharacterShipAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as lastname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character as lastname in the shipping address with trEnabled=true")
	public void specialCharacterShipAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as both firstname and Lastname in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character as both firstname and lastname in the shipping address with trEnabled=true")
	public void specialCharacterShipAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Compare the Getcart from Adapter and OAPI
		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with firstname starting with space in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with firstname  starting with spacein the shipping address with trEnabled=true")
	public void startingWithSpaceShipAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with lastname starting with space in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with lastname starting with space  in the shipping address with trEnabled=true")
	public void startingWithSpaceShipAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with both firstname and Lastname starting with space in the shipping address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with both firstname and lastname starting with space in the shipping address with trEnabled=true")
	public void startingWithSpaceShipAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as firstname in the bill address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with single character firstname in the bill address with trEnabled=true")
	public void spaceBillAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as lastname in the bill address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with space as lastname in the billing  address with trEnabled=true")
	public void spaceBillAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Last Name.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as both firstname and Lastname in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with space as both firstname and lastname in the billing address with trEnabled=true")
	public void spaceBillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as firstname in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character firstname in the billing address with trEnabled=true")
	public void specialCharacterBillAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as lastname in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character as lastname in the billing address with trEnabled=true")
	public void specialCharacterBillAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as both firstname and Lastname in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character as both firstname and lastname in the billing address with trEnabled=true")
	public void specialCharacterBillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with firstname starting with space in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with firstname  starting with spacein the billing address with trEnabled=true")
	public void startingWithSpaceBillAddressFN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with lastname starting with space in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with lastname starting with space  in the billing address with trEnabled=true")
	public void startingWithSpaceBillAddressLN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with both firstname and Lastname starting with space in the billing address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with both firstname and lastname starting with space in the billing address with trEnabled=true")
	public void startingWithSpaceBillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with space as firsttname and space as lastname in shipping address as well as space as firsttname and space as lastname in the bill address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with space as firsttname and space as lastname in shipping address as well as space as firsttname and space as lastname in thebill address with trEnabled=true")
	public void spaceShip_BillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with special character as firsttname and special character as lastname in shipping address as well as special character as firsttname and special character as lastname in the bill address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with special character as firsttname and special character as lastname in shipping address as well as special character as firsttname and special character as lastname in thebill address with trEnabled=true")
	public void specialCharacterShip_BillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "orderCalc V2_verify whether that orderCalc V2 is performed successfully with firsttname  starting with space and lastname starting with space in shipping address as well as firsttname  starting with space and lastname starting with space in the bill address with trEnabled=true",
			description = "Kohl's application user wants to do orderCalc-v2 with firsttname  starting with space and lastname starting with space in shipping address firsttname  starting with space and lastname starting with space in thebill address with trEnabled=true")
	public void startingWithSpaceShip_BillAddressFN_LN_V2() {

		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPI_CART_ITEM_ID") + JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";
		String strResponseOrderCalcAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadOrderCalc, Server.Adapter, true);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		if (CompareOAPI) {
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);
		}
		
	}
}