package test.java.adapters.order;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.RETRIEVE_ORDER_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("Order")
@Stories({ "CancelOrder" })

public class CancelOrder {
	
	ResponseValidator validator;
	
	@Test(groups = { "regression", "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the order has been cancelled successfully when valid details passed with orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.message", "The order .*"+testData.get("ORDER_NUMBER_CANCEL")+".* has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");
				
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Errorcode ORDER1002 and error message invalid email is displayed when invalid email passed with orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser_withInvalidEmail() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc4\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Email.");
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Errorcode ORDER1000 and error message missing email is displayed when without email passed with orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser_withoutEmail() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1000", "missing required parameter email.");
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1002 and error message invalid ordernum is displayed when invalid  orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser_WithInvalidOrderNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  "hgfyfvhgcfc" + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Order Number.");
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1000 and error message missing ordernum is displayed when without orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser_WithOutOrderNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  "" + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1000", "missing required parameter order number.");
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code code ORDER1002 and error message invalid postalcode is displayed when invalid postal code with orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser_WithInvalidPostalCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + "fgfgf" + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Postal code.");
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1000 and error message missing postalcode is displayed when without postal code with orderNumber and action as CANCEL_ORDER in the request")
	public void cancelOrder_GuestUser_WithOutPostalCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + "" + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1000", "missing required parameter postal code.");
	}
	@Test(groups = {"regression", "cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the order has been cancelled successfully when valid details passed with orderNumber and action as CANCEL_ORDER in the request")
	public void CancelOrder_RegisteredUser() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token_cancel");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token_cancel"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS_CANCEL");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS_CANCEL")+ "\",\"action\": \"cancel_order\"}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.message", "The order .*"+testData.get("ORDER_NUMBER_BOPUS_CANCEL")+".* has been successfully cancelled", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
			
	}
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1002 and error message invalid action is displayed when orderNumber and invaild action as CANCELRDER in the request")
	public void CancelOrder_RegisteredUser_withInvalidAction() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\",\"action\": \"canceorder\"}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Action.");
			
	}
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code 401 and error message invalid token is displayed when orderNumber and invaild accestoken in the request")
	public void CancelOrder_RegisteredUser_withInvalidAccesstoken() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token","fghdghght");
		
		// Create Request
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\",\"action\": \"canceorder\"}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("401", "invalid token. please enter valid token.");
			
	}
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code 401 and error message invalid token is displayed when orderNumber and without accesstoken in the request")
	public void CancelOrder_RegisteredUser_withoutAccesstoken() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token","");
		
		// Create Request
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\",\"action\": \"canceorder\"}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("401", "invalid token. please enter valid token.");
			
	}
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1000 and error message missing action is displayed when orderNumber and without action in the request")
	public void CancelOrder_RegisteredUser_withoutAction() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\",\"action\": \"\"}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1000", "missing required parameter action.");
			
	}
	@Test(groups = { "regression", "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			dependsOnMethods = "CancelOrder_RegisteredUser",description = "Kohls applicaiton user wants to verify whether the Error code ORDER3028 and error message order cant canceled is displayed when cancelled order is cancelled again")
	public void CancelOrder_WithAlreadyCancelledOrder() {

		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Bopus_access_token_cancel"));
		
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true,mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER3028", "Order "+testData.get("ORDER_NUMBER_BOPUS_CANCEL")+" cannot be cancelled");
				
	}
	@Test(groups = { "regression", "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the order has been cancelled successfully when valid details passed with orderNumber and action as CANCEL_ORDER in the request")
	public void CancelOrderWithCancellableFlagasTrue() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		

			String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_CANCEL")+"?postalCode=60290";
			// Post the request
			String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse1);
			validator.validateNoErrors();
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.nodeMatches("$.payload.order.orderStatus", "Submitted||In Fulfillment", "Order status should be 'Submitted'");
			validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
			validator.nodeEquals("$.payload.order.isCancellable", "true", "Order Cancellable status should be present in the response");
		   
		     

		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
				validator.nodeMatches("$.payload.message", "The order .*"+testData.get("ORDER_NUMBER_CANCEL")+".* has been successfully cancelled", "Verifying the message as 'The order has been successfully cancelled' is getting displayed in response");
				
	}
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER3028 is displayed and message order cnat cancelled when iscancel flag is false in  retrieve order and trying to cnacel the order")
	public void CancelOrderWithCancellableFlagasFalse() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		

			String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_CANCEL")+"?postalCode=60290";
			// Post the request
			String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse1);
			validator.validateNoErrors();
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.nodeMatches("$.payload.order.orderStatus", "Submitted||In Fulfillment", "Order status should be 'Submitted'");
			validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
			validator.nodeEquals("$.payload.order.isCancellable", "false", "Order Number should be present in the response");
		   
		     

		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" +  testData.get("ORDER_NUMBER_CANCEL") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\""
						+ "}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateNoErrors();
				validator.validateExpectedErrors("ORDER3029", "Order "+testData.get("ORDER_NUMBER_BOPUS_CANCEL")+" cannot be cancelled");
				
	}
	
	@Test(groups = { "cancelorder" }, enabled = true, priority = 4, testName = "cancelOrder_alternatePickUpPersonsWithOrderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1002 and message invalid ordernum is displayed when we passed orderNumber as whitespace and action as CANCEL_ORDER in the request")
	public void CancelOrder_GuestUser_orderNumberAsWhiteSpace() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_CANCEL");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
			//	String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_CANCEL")+ "\",\"action\": \"cancel_order\"}}";
				
				String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"  \","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\"}}";
				// Post Request
				String strResponseCancelOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseCancelOrder);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Order Number.");
	}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1000 and error message missing action is displayed when orderNumber and without action tag in the request")
	public void CancelOrder_RegisteredUser_withoutActionTag() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1000", "missing required parameter action.");
			
	}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1000 and error message missing ordernum is displayed when we send request without Order Number")
	public void CancelOrder_RegisteredUser_withoutOrderNumberTag() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		
		String strPayloadCancelOrder = "{\"payload\": {\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"cancel_order\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Order Number.");
			
	}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ORDER1000 and error message missing email is displayed when we semd request without Email tag")
	public void CancelOrder_RegisteredUser_withoutEmailTag() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		
		String strPayloadCancelOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"action\":\"cancel_order\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Email.");
			
	}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ERR2700 and error message invalid Json is displayed when we send invalid Json field request")
	public void CancelOrder_RegisteredUser_InvalidJsonFieldRequest() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		
		// Create Request
		
		String strPayloadCancelOrder = "{\"payload\": {\"orderNum\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"action\":\"cancel_order\",\"email\":\"shankarc44@gmail.com\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ERR2700", "Invalid JSON: Unrecognized field orderNum");
			
	}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code ERR2000 and message invalid Json is displayed when we send invalid Json request")
	public void CancelOrder_RegisteredUser_InvalidJsonRequest() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		
		// Create Request
				String strPayloadCancelOrder = "{\"payload\": {\"orderNumb\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\"\"action\":\"cancel_order\",\"email\":\"shankarc44@gmail.com\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("ERR2000", "Invalid JSON Provided.");
			
			
	}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code 415  is displayed when we send invalid Content Type header in request")
	public void CancelOrder_RegisteredUser_InvalidContentType() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		mapheader.clear();
		mapheader.put("Content-Type", "application/ja");
		// Create Request
				String strPayloadCancelOrder = "{\"payload\": {\"orderNumb\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\"\"action\":\"cancel_order\",\"email\":\"shankarc44@gmail.com\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader, 200);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("415", "Unsupported Media Type");
							
			
				}
	
	@Test(groups = {"cancelorder"}, enabled = true, priority = 4, testName = "CancelOrder_RegisteredUser with orderNumber",
			description = "Kohls applicaiton user wants to verify whether the Error code 406 is displayed when we send invalid Accept header in request")
	public void CancelOrder_RegisteredUser_InvalidAcceptHeader() {
		
		// Create a new profile through OAPI
				String strBopusEmail = Utilities.getNewEmailID();
				String strBopusPaswd = "Bopusphase@2";
				Utilities.createProfile(strBopusEmail, strBopusPaswd, Server.Adapter);

				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
				Utilities.signInProfile(strBopusEmail, strBopusPaswd, Server.Adapter, "Bopus_access_token");

				// Update cart through Adapter
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("Bopus_access_token"));

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS1");
//		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		mapheader.clear();
		mapheader.put("accept", "application/java");
		// Create Request
				String strPayloadCancelOrder = "{\"payload\": {\"orderNumb\":\"" + testData.get("ORDER_NUMBER_BOPUS1")+ "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\"\"action\":\"cancel_order\",\"email\":\"shankarc44@gmail.com\"}}";
		
		
				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadCancelOrder, Server.Adapter, true, mapheader, 200);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateExpectedErrors("406", "Not Acceptable");
							
			
	}
	
	
	
	


}