package test.java.adapters.order;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "MFP Signal" })
public class MFPSignal {
	ResponseValidator validator;

	@Test(groups = { "regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_shipcount_1() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("1",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = { "regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_shipcount_2() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"giftItem\":\"true\",\"shippingMethod\" : \"ODD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_Registry() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_normal_Registry() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"shippingMethod\" : \"TDD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_OFFERS"), "1")
				+ ",{\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("3",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_Registry_Registry() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522231\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}"
				+ ",{\"giftItem\" : true,\"shippingMethod\" : \"TDD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("3",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_Registry_Registry_MultiShip() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shipIndex\":\"1\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"shipIndex\":\"1\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522231\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}"
				+ ",{\"shipIndex\":\"2\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") + ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("CT_AVON_MULTISHIP")+"],"
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("3",strPayloadPLACEORDER);
		validator.validateShipIndexOrder(strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_normal_Registry_MultiShip() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shipIndex\":\"1\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"shipIndex\":\"2\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\"}"
				+ ",{\"shipIndex\":\"2\",\"giftItem\" : true,\"shippingMethod\" : \"TDD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") + ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("CT_AVON_MULTISHIP")+"],"
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("3",strPayloadPLACEORDER);
		validator.validateShipIndexOrder(strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_normal_Registry_MultiShipSameShipMethod() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shipIndex\":\"1\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"shipIndex\":\"2\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\"}"
				+ ",{\"shipIndex\":\"1\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_NORMAL")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") + ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("CT_AVON_MULTISHIP")+"],"
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("3",strPayloadPLACEORDER);
		validator.validateShipIndexOrder(strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_normal_Registry_MultiShip_AHSTD_USSTD() {

		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shipIndex\":\"2\",\"shippingMethod\" : \"AHSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"shipIndex\":\"1\",\"giftItem\" : true,\"shippingMethod\" : \"USSTD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}"
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") 
				+ ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("AHSTD_AE_APO_MULTISHIP")+"],"
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		validator.validateShipIndexOrder(strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = { "regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_Registered_shipcount_1() {
		String strEmailID = Utilities.getNewEmailID();
		String strPassword = "Qwerty@123";
		Utilities.createProfile(strEmailID, strPassword, Server.Adapter);
		Utilities.signInProfile(strEmailID, strPassword, Server.Adapter, "access_token_adapter");
		String strCartResponse = Utilities.AddToCart(testData.get("SKU_NORMAL"), "1", false, false);
		
		String cartItemID = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[0].cartItemID");
		String cartID = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartID");
		
		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""+cartID+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\""+cartItemID+"\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, true);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("1",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = { "regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_Registered_shipcount_2() {

		String strEmailID = Utilities.getNewEmailID();
		String strPassword = "Qwerty@123";
		Utilities.createProfile(strEmailID, strPassword, Server.Adapter);
		Utilities.signInProfile(strEmailID, strPassword, Server.Adapter, "access_token_adapter");
		String strCartResponse = Utilities.AddToCart(testData.get("SKU_NORMAL"), "1", false, false);
		strCartResponse = Utilities.AddToCart(testData.get("SKU_OFFERS"), "1", false, false);
		
		String cartID = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartID");
		String cartItemID1 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, 12);
		String cartItemID2 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_OFFERS")+")].cartItemID");
		cartItemID2 = cartItemID2.substring(2, 12);
		
		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""+cartID+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\""+cartItemID1+"\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"cartItemID\":\""+cartItemID2+"\",\"shippingMethod\" : \"ODD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_OFFERS"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_Registered_normal_Registry() {

		String strEmailID = Utilities.getNewEmailID();
		String strPassword = "Qwerty@123";
		Utilities.createProfile(strEmailID, strPassword, Server.Adapter);
		Utilities.signInProfile(strEmailID, strPassword, Server.Adapter, "access_token_adapter");
		
		String strCartResponse = Utilities.AddToCart(testData.get("SKU_NORMAL"), "1", false, false);
		strCartResponse = Utilities.AddToCart(testData.get("SKU_OFFERS"), "1", true, true);
		
		String cartID = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartID");
		String cartItemID1 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, 12);
		String cartItemID2 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_OFFERS")+")].cartItemID");
		cartItemID2 = cartItemID2.substring(2, 12);
		
		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""+cartID+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\""+cartItemID1+"\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"cartItemID\":\""+cartItemID2+"\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_Registered_normal_Registry_MultiShip() {

		String strEmailID = Utilities.getNewEmailID();
		String strPassword = "Qwerty@123";
		Utilities.createProfile(strEmailID, strPassword, Server.Adapter);
		Utilities.signInProfile(strEmailID, strPassword, Server.Adapter, "access_token_adapter");
		
		String strCartResponse = Utilities.AddToCart(testData.get("SKU_NORMAL"), "1", false, false);
		strCartResponse = Utilities.AddToCart(testData.get("SKU_OFFERS"), "1", true, true);
		
		String cartID = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartID");
		String cartItemID1 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, 12);
		String cartItemID2 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_OFFERS")+")].cartItemID");
		cartItemID2 = cartItemID2.substring(2, 12);
		
		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""+cartID+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\""+cartItemID1+"\",\"shipIndex\":\"1\",\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"cartItemID\":\""+cartItemID2+"\",\"shipIndex\":\"1\",\"giftItem\" : true,\"shippingMethod\" : \"ODD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") + ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("CT_AVON_MULTISHIP")+"],"
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		validator.validateShipIndexOrder(strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	
	@Test(groups = {"regression","MSM-3071","MFPSignal" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_Registered_normal_Registry_MultiShip_AHSTD_USSTD() {

		String strEmailID = Utilities.getNewEmailID();
		String strPassword = "Qwerty@123";
		Utilities.createProfile(strEmailID, strPassword, Server.Adapter);
		Utilities.signInProfile(strEmailID, strPassword, Server.Adapter, "access_token_adapter");
		
		String strCartResponse = Utilities.AddToCart(testData.get("SKU_NORMAL"), "1", false, false);
		strCartResponse = Utilities.AddToCart(testData.get("SKU_OFFERS"), "1", true, true);


String cartID = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartID");
		String cartItemID1 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_NORMAL")+")].cartItemID");
		cartItemID1 = cartItemID1.substring(2, 12);
		String cartItemID2 = Utilities.getJsonNodeValue(strCartResponse, "$.payload.cart.cartItems[?(@.skuCode=="+testData.get("SKU_OFFERS")+")].cartItemID");
		cartItemID2 = cartItemID2.substring(2, 12);
		
		
		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""+cartID+"\","
				+ "\"cartItems\" : [{\"cartItemID\":\""+cartItemID1+"\",\"shipIndex\":\"2\",\"shippingMethod\" : \"AHSTD"+ JsonString.getCartJson("VALID_V2", testData.get("SKU_NORMAL"), "1")
				+ ",{\"cartItemID\":\""+cartItemID2+"\",\"shipIndex\":\"1\",\"giftItem\" : true,\"shippingMethod\" : \"USSTD\",\"skuCode\" : \""+testData.get("SKU_OFFERS")+"\",\"qty\" : \"1\",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}}"
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddresses\" : [{\"shipIndex\":\"1\"," + JsonString.getBillAddressJson("IL_CHICAGO_MULTISHIP") 
				+ ",{\"shipIndex\":\"2\"," + JsonString.getBillAddressJson("AHSTD_AE_APO_MULTISHIP")+"],"
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		validator.validateNoErrors();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("2",strPayloadPLACEORDER);
		validator.validateShipIndexOrder(strPayloadPLACEORDER);
		
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
}
