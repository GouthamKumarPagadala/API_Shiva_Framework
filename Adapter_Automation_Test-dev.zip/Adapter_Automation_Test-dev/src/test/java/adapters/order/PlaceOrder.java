package test.java.adapters.order;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Order")
@Stories({ "Place Order" })
public class PlaceOrder {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place Order Unregistered User", description = "Do PlaceOrder for an order as guest user")
	public void UnRegisteredUser() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With Master Card", description = "Do PlaceOrder for an order using Master card")
	public void MasterCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "mfp","master_bin" }, enabled = true, priority = 4, testName = "Placr Order With Master Card", description = "Do PlaceOrder for an order using Master card")
	public void MasterCard_Binrange() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER_BINRANGE")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With Discover Card", description = "Do PlaceOrder for an order using Disc card")
	public void DiscoverCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "DISC", "Discover card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With Visa Card", description = "Do PlaceOrder for an order using Visa card")
	public void VisaCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place Order With Kohls Card", description = "Do PlaceOrder for an order using Kohls card")
	public void KohlsCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD2")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With Amex Card", description = "Do PlaceOrder for an order using Amex card")
	public void AmexCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "AMEX", "Amex card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place order With Master Card and Kohls Cash", description = "Do PlaceOrder for an order using Master card")
	public void MasterCardAndKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place order With Discover Card And Kohls Cash", description = "Do PlaceOrder for an order using Disc card")
	public void PlacrOrderWithDiscoverCardAndKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "DISC", "Discover card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place Order With Visa Card", description = "Do PlaceOrder for an order using Visa card")
	public void VisaCardAndKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID_TDD", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place Order With Kohls Card", description = "Do PlaceOrder for an order using Kohls card")
	public void KohlsCardAndKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD3")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");

		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "PlaceOrder - SKUWhichKohlsCashCannotBeApplied", description = "Do PlaceOrder for an order using Kohls card")
	public void SKUWhichKohlsCashCannotBeApplied() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_GIFTCARD"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{"
				+ "\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9455", "Kohl's Cash cannot be applied to the Gift Card(s), gift wrap or Kohl's Cares cause merchandise in your shopping bag.");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With Surcharge Sku", description = "Do PlaceOrder for an order using Kohls card")
	public void SurchargeSku() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_SURCHARGE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With hazardous Sku", description = "Do PlaceOrder for an order using Kohls card")
	public void HazardousSku() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_HAZARDOUS"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With Ship Alone", description = "Do PlaceOrder for an order using Kohls card")
	public void ShipAlone() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With BOGO+Sales", description = "Do PlaceOrder for an order using Kohls card")
	public void BogoPlusSales() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_BOGO_SALE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "placeOrder With Gift Card", description = "Do PlaceOrder for an order using Visa card")
	public void GiftCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "], \"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		
		
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		// validator.validatePaymentInfo();
		validator.validateTotal();
		// validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "value should be applied from giftCard in the response");
		// validator.nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true","value should be applied from giftCard in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Place order MultipleCartItems", description = "Do Placeorder for an order as guest user")
	public void MultipleSku() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "," + JsonString.getCartJson("VALID", testData.get("SKU_GIFT_WRAP"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "place order Sku Not found", description = "Do Place Order with sku not found")
	public void SKUNotFound() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NOT_FOUND"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3000", "sku (" + testData.get("SKU_NOT_FOUND") + ") not found.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "place order Missing Qty", description = "Do Place Order with sku not found")
	public void MissingQty() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter Qty.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "place order Missing SkuCode", description = "Do Place Order with sku not found")
	public void MissingSkuCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", "", "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter skucode.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "place order nonnumeric qty", description = "Do Place Order with sku not found")
	public void NonnumericQty() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "a") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Qty.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "place order sku out of stock", description = "Do Place Order with sku not found")
	public void OutOfStock() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_OUT_OF_STOCK"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER4000", "SKU (" + testData.get("SKU_CODE_OUT_OF_STOCK") + ") out of inventory.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder" }, enabled = true, priority = 4, testName = "Placr Order With valid discount promoCode", description = "Do PlaceOrder for an order using Kohls card")
	public void ValidDiscountPromoCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder" }, enabled = true, priority = 4, testName = "Placr Order With valid shipping promoCode", description = "Do PlaceOrder for an order using Kohls card")
	public void ValidShippingPromoCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With valid special character name", description = "Do PlaceOrder for an order using Kohls card")
	public void ValidSpecialCharacterName() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIALCHAR_NAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Placr Order With repeat isBillAddressEqualsToShip", description = "Do PlaceOrder for an order using Kohls card")
	public void RepeatIsBillEqualToShip() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\",\"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With invalid shippingmethod", description = "Do PlaceOrder for an order using Kohls card")
	public void InvalidShippingMethod() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("INVALID_SHIPPING_METHOD", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSSY\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Shipping Method.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With blank shippingmethod", description = "Do PlaceOrder for an order using Kohls card")
	public void BlankShippingMethod() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("BLANK_SHIPPING_METHOD", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSSY\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Shipping Method.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder" }, enabled = true, priority = 4, testName = "Placr Order With ValidState&ZipButInvalidCity", description = "Do PlaceOrder for an order using Kohls card")
	public void ValidStateAndZipButInvalidCity() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("INVALID_CITY") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9279", "According to our system, the City and ZIP code combination you've entered has an error. Please enter a valid City and ZIP code combination.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder" }, enabled = true, priority = 4, testName = "Placr Order With ValidStateButInvalidZipCity", description = "Do PlaceOrder for an order using Kohls card")
	public void ValidStateButInvalidZipCity() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("INVALID_ZIP_CITY") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9279", "According to our system, the City and ZIP code combination you've entered has an error. Please enter a valid City and ZIP code combination.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With Another city postal code", description = "Do PlaceOrder for an order using Kohls card")
	public void AnotherCityPostalCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_CODE_SHIPALONE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("ANOTHER_CITY_POSTALCODE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9277", "According to our system, the City, State and ZIP code combination you've entered has an error. Please enter a valid City, State and ZIP code combination.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With 21 Character KohslCash number", description = "Do PlaceOrder for an order using Kohls card")
	public void KohlsCash21Digit() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"1234567890123456789010\",\"pin\": \"" + testData.get("KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for kohlsCashNum.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With Invalid KohslCash Pin", description = "Do PlaceOrder for an order using Kohls card")
	public void InvalidKohlsCashPin() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"1asd1\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for PIN.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With Invalid phone number", description = "Do PlaceOrder for an order using Kohls card")
	public void InvalidBillPhoneNumber() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("INVALID_PHONENO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Phone Number.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With 11 digit phone number", description = "Do PlaceOrder for an order using Kohls card")
	public void InvalidBillPhoneNumber11Digit() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("11DIGIT_PHONENO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Phone Number.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling"}, enabled = true, priority = 4, testName = "Placr Order With Invalid Name Format", description = "Do PlaceOrder for an order using Kohls card")
	public void InvalidNameFormat() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("FN_NUMERIC") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "bopusplaceorder","errorhandling" }, enabled = true, priority = 4, testName = "Placr Order With Missing First Name", description = "Do PlaceOrder for an order using Kohls card")
	public void MissingFirstName() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("EMPTY_FN") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter First Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 7, testName = "Get Profile", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.OrderCalc",
			description = "Get Profile")
	public void NoDuplicateShipAddressInProfile() {

		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
		Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		System.out.println("Author Id" + testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		// validator.nodeEquals("$.payload.profile.email", testData.get("ADAPTER_EMAIL_ID"), "Profile email should be present");
		validator.nodeMatches("$.payload.profile.shipAddresses[0].state", ".+", "state should be available in response");
		validator.nodeMatches("$.payload.profile.shipAddresses[0].countryCode", ".+", "countryCode should be available in response");
		validator.nodeMatches("$.payload.profile.shipAddresses[0].city", ".+", "city should be available in response");
		validator.nodeMatches("$.payload.profile.shipAddresses[0].postalCode", ".+", "postalCode should be available in response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true);
			Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Placeorder for an order as guest user with Ship Address using Single Character Firstname")
	public void SingleCharacterFN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Placeorder for an order as guest user with Ship Address using Single Character Firstname and Lastname")
	public void SingleCharacterFN_LN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using Single Character Firstname and Lastname")
	public void SingleCharacterFN_LN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Ship And Bill address", description = "Do Placeorder for an order as guest user with Bill and Ship Address using Single Character Firstname and Lastname")
	public void SingleCharacterFN_LN_BillAndShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Placeorder for an order as guest user with Ship Address using Single Character Lastname")
	public void SingleCharacterLN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using Single Character Firstname")
	public void SingleCharacterFN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress Single Character Lastname", description = "Do Placeorder for an order as guest user with Bill Address using Single Character Lastname")
	public void SingleCharacterLN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress Firstname", description = "Do Placeorder for an order as guest user with Ship Address using space as Firstname")
	public void SpaceasFN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Placeorder for an order as guest user with Ship Address using space as Firstname and Lastname")
	public void SpaceasbothFN_LN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using space Firstname and Lastname")
	public void SpaceasbothFN_LN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		
		// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
				// Compare Open API
				if (CompareOAPI) {
					// Post the request
					String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
				}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress And BillAddress ", description = "Do Placeorder for an order as guest user with Bill and Ship Address using space as Firstname and Lastname")
	public void SpaceasbothFN_LN_BillAndShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Placeorder for an order as guest user with Ship Address using space as Lastname")
	public void SpaceasLN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Last Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress ", description = "Do Placeorder for an order as guest user with Bill Address using space as Firstname")
	public void SpaceasFN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress ", description = "Do Placeorder for an order as guest user with Bill Address using space as Lastname")
	public void SpaceasLN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Last Name.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Placeorder for an order as guest user with Ship Address using Special Character Firstname")
	public void SpecialCharacterFN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Placeorder for an order as guest user with Ship Address using Special Character Firstname and Lastname")
	public void SpecialCharacterFN_LN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using Special Character Firstname and Lastname")
	public void SpecialCharacterFN_LN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Ship And Bill address", description = "Do Placeorder for an order as guest user with Bill and Ship Address using Special Character Firstname and Lastname")
	public void SpecialCharacterFN_LN_BillAndShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Placeorder for an order as guest user with Ship Address using Special Character Lastname")
	public void SpecialCharacterLN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using Special Character Firstname")
	public void SpecialCharacterFN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress Special Character Lastname", description = "Do Placeorder for an order as guest user with Bill Address using Special Character Lastname")
	public void SpecialCharacterLN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Placeorder for an order as guest user with Ship Address using Starting WithSpace Firstname")
	public void StartingWithSpaceFN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Placeorder for an order as guest user with Ship Address using Starting WithSpace Firstname and Lastname")
	public void StartingWithSpaceFN_LN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using Starting WithSpace Firstname and Lastname")
	public void StartingWithSpaceFN_LN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Ship And Bill address", description = "Do Placeorder for an order as guest user with Bill and Ship Address using Starting WithSpace Firstname and Lastname")
	public void StartingWithSpaceFN_LN_BillAndShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Placeorder for an order as guest user with Ship Address using Starting WithSpace Lastname")
	public void StartingWithSpaceLN_ShipAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Placeorder for an order as guest user with Bill Address using Starting WithSpace Firstname")
	public void StartingWithSpaceFN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress Starting WithSpace Lastname", description = "Do Placeorder for an order as guest user with Bill Address using Starting WithSpace Lastname")
	public void StartingWithSpaceLN_BillAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Single Character Firstname with visa chceckout")
	public void SingleCharacterFN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Single Character Lastname with visa chceckout")
	public void SingleCharacterLN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Single Character First and Last name with visa chceckout")
	public void SingleCharacterFN_LN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Special Character Firstname with visa chceckout")
	public void SpecialCharacterFN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Special Character Lastname with visa chceckout")
	public void SpecialCharacterLN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Special Character First and Last name with visa chceckout")
	public void SpecialCharacterFN_LN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Starting With Space Firstname with visa chceckout")
	public void StartingWithSpaceFN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Starting With Space Lastname with visa chceckout")
	public void StartingWithSpaceLN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Starting With Space First and Last name with visa chceckout")
	public void StartingWithSpaceFN_LN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Space as Firstname with visa chceckout")
	public void SpaceasFN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Space as Lastname with visa chceckout")
	public void SpaceasLN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for LAST Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place Order Unregistered User with Shipaddress with VC ", description = "Do Placeorder for an order as guest user with Ship Address using Space as First and Last name with visa chceckout")
	public void SpaceasBothFN_LN_ShipAddress_VC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadoapi = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadoapi, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Place order for an order as guest user with Ship Address using Single Character Firstnameusing Applepay")
	public void SingleCharacterFN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		
		
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Place order for an order as guest user with Ship Address using Single Character Firstname and Lastname using Applepay")
	public void SingleCharacterFN_LN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		
		/*String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";*/

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using Single Character Firstname and Lastname using Applepay")
	public void SingleCharacterFN_LN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Place order for an order as guest user with Ship Address using Single Character Lastname using Applepay")
	public void SingleCharacterLN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using Single Character Firstname using Applepay")
	public void SingleCharacterFN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_FNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress Single Character Lastname", description = "Do Place order for an order as guest user with Bill Address using Single Character Lastname using Applepay")
	public void SingleCharacterLN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SINGLE_CHAR_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress Firstname", description = "Do Place order for an order as guest user with Ship Address using space as Firstname using Applepay")
	public void SpaceasFN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Place order for an order as guest user with Ship Address using space as Firstname and Lastname using Applepay")
	public void SpaceasbothFN_LN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using space Firstname and Lastname using Applepay")
	public void SpaceasbothFN_LN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		
		// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
				// Compare Open API
				if (CompareOAPI) {
					String strPayloadOAPI = "{\"payload\": {\"order\":"
							+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
							+ "\"email\":\"shankarc44@gmail.com\","
							+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
							+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME_LNAME") + ","
							+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
							+ "\"shippingMethod\":\"USSTD\","
							+ " \"isBillAddressEqualtoShipAddress\":\"false\","
							+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
							+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
							+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
					
					
					// Post the request
					String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
				}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Place order for an order as guest user with Ship Address using space as Lastname using Applepay")
	public void SpaceasLN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Last Name.");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress ", description = "Do Place order for an order as guest user with Bill Address using space as Firstname using Applepay")
	public void SpaceasFN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for First Name.");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_FNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress ", description = "Do Place order for an order as guest user with Bill Address using space as Lastname using Applepay")
	public void SpaceasLN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1002", "Invalid value passed for Last Name.");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Place order for an order as guest user with Ship Address using Special Character Firstname using Applepay")
	public void SpecialCharacterFN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Place order for an order as guest user with Ship Address using Special Character Firstname and Lastname using Applepay")
	public void SpecialCharacterFN_LN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using Special Character Firstname and Lastname using Applepay")
	public void SpecialCharacterFN_LN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Place order for an order as guest user with Ship Address using Special Character Lastname using Applepay")
	public void SpecialCharacterLN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using Special Character Firstname using Applepay")
	public void SpecialCharacterFN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress Special Character Lastname", description = "Do Place order for an order as guest user with Bill Address using Special Character Lastname using Applepay")
	public void SpecialCharacterLN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress ", description = "Do Place order for an order as guest user with Ship Address using Starting WithSpace Firstname using Applepay")
	public void StartingWithSpaceFN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Place order for an order as guest user with Ship Address using Starting WithSpace Firstname and Lastname using Applepay")
	public void StartingWithSpaceFN_LN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using Starting WithSpace Firstname and Lastname using Applepay")
	public void StartingWithSpaceFN_LN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Shipaddress", description = "Do Place order for an order as guest user with Ship Address using Starting WithSpace Lastname using Applepay")
	public void StartingWithSpaceLN_ShipAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress", description = "Do Place order for an order as guest user with Bill Address using Starting WithSpace Firstname using Applepay")
	public void StartingWithSpaceFN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = {"regression","functional", "fmnp273" }, enabled = true, priority = 4, testName = "Place order Unregistered User with Billaddress Starting WithSpace Lastname", description = "Do Place order for an order as guest user with Bill Address using Starting WithSpace Lastname using Applepay")
	public void StartingWithSpaceLN_BillAddress_Applepay() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME") + ","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
}
