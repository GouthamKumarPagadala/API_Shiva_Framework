package test.java.adapters.order.omniture;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Omniture")
@Stories({ "Place Order V1 User Validate Fulfuillment Type" })
public class placeOrderV1RegisteredUser {

	ResponseValidator validator;


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Registered User with shipping method USSTD/AHSTD", description = "Do PlaceOrder for an order as a registered user with shipping method USSTD/AHSTD")
	public void webExclusiveUsingExpiditedCheckOut() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "Omniture_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Omniture_access_token_adapter"));
		// getProfile
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.isEligibleForExpeditedCheckout", "false", "Profile isEligibleForExpeditedCheckout should be present");

		// PlaceOrder
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// getProfile
		String strURL1 = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strURL1);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.isEligibleForExpeditedCheckout", "true", "Profile isEligibleForExpeditedCheckout should be present");
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Registered User with shipping method USSTD/AHSTD", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder for an order as a registered user with shipping method USSTD/AHSTD")
	public void webExclusiveUsingUSSTD_or_AHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Registered User with shipping method TDD or ODD", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder for an order as a registered user with shipping method TDD or ODD")
	public void webExclusiveUsingTDDorODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With Discover Card", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder for an order using Disc card")
	public void webExclusiveUsingDiscoverCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "DISC", "Discover card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With Kohls Card", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder for an order using Kohls card")
	public void webExclusiveUsingKohlsCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD3")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With Amex Card", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder for an order using Amex card")
	public void webExclusiveUsingAmexCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "AMEX", "Amex card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order With Visa Card", dependsOnMethods = { "test.java.adapters.smoke.SmokeTest.KohlsCashBalance", "test.java.adapters.smoke.SmokeTest.signInProfile" }, description = "Do PlaceOrder for an order using Visa card")
	public void webExclusiveUsingVisaCardAndKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OMNITURE"), "1", "759", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With valid discount promoCode", 
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder for an order using PromoCode")
	public void webExclusiveUsingValidDiscountPromoCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "promoCodes should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


  	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Registered User withRegistryandAHSTD", 
			 description = "Do placeorder for an order as a registered user withRegistryandAHSTD")
	public void webExclusiveUsingRegistryandAHSTD() {

  		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "Omniture_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Omniture_access_token_adapter"));
		
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("AHSTD_AE_APO_ADD")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OMNITURE"), "2", "674", "AHSTD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_OMNITURE"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"AHSTD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "Omniture_access_token_oapi");
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("Omniture_access_token_oapi"));
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true,mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Registered User withProductOfferandODD", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile", description = "Do PlaceOrder as a registered user withProductOfferandODD")
	public void webExclusiveUsingProductOfferandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "1", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","false", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 9, testName = "ApplePay PlaceOrder With KohlsCash")
	// dependsOnMethods="test.java.adapters.smoke.SmokeTest.KohlsCashBalance",description = "Verify whether the Place Order is successful if we pass Kohls Cash as a Payment Type in the request")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void webExclusiveUsingApplepayandKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\"}}}";

		// Post the requestSKU_APPLEPAY
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Set orderNumber from response in test data
		// Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_APPLEPAY") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\""+ testData.get("RUNTIME_KOHLS_CASH_NO") +"\",\"pin\":\""+ testData.get("RUNTIME_KOHLSCASH_PIN") +"\"}],\"paymentToken\":\"" + testData.get("APAY_KOHLSCASH_TOKEN_OAPI")
					+ "\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\"}}}";

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, true);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
}