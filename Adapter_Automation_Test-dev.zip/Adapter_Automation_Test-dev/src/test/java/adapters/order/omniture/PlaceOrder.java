package test.java.adapters.order.omniture;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omniture")
@Stories({ "Place Order Unregistered User Validate Fulfuillment Type" })
public class PlaceOrder {

	ResponseValidator validator;


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order UnRegistered User with shipping method USSTD/AHSTD", description = "Do PlaceOrder for an order as guest user with shipping method USSTD/AHSTD")
	public void WebExclusiveUsingWithUSSTDorAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order UnRegistered User with shipping method TDD or ODD", description = "Do PlaceOrder for an order as guest user with shipping method TDD or ODD")
	public void WebExclusiveUsingWithTDDorODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With Discover Card", description = "Do PlaceOrder for an order using Disc card")
	public void WebExclusiveUsingWithDiscoverCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "DISC", "Discover card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With Kohls Card", description = "Do PlaceOrder for an order using Kohls card")
	public void WebExclusiveUsingWithKohlsCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD3")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "KOHLS", "Kohls card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With Amex Card", description = "Do PlaceOrder for an order using Amex card")
	public void WebExclusiveUsingWithAmexCard() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "AMEX", "Amex card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order With Visa Card", description = "Do PlaceOrder for an order using Visa card")
	public void WebExclusiveUsingWithVisaCardAndKohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID_INSTORE", testData.get("SKU_OMNITURE"), "1", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "value should be applied from KohlsCash in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Visa card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Placr Order With valid discount promoCode", description = "Do PlaceOrder for an order using PromoCode")
	public void WebExclusiveUsingWithValidDiscountPromoCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_OMNITURE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],"
				+ "\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "VISA card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
//		validator.nodeMatches("$.payload.order.cartItems[0].discounts[0].offerId", "[0-9]+", "offerId should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "promoCodes should be present in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Unregistered User withRegistryandAHSTD", description = "Do placeorder for an order as guest user withRegistryandAHSTD")
	public void WebExclusiveUsingwithRegistryandAHSTD() {
		
		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Ocb@1234";
		Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
		
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));
		
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("AHSTD_AE_APO_ADD")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true,mapheader);
		validator = new ResponseValidator(strResponse1);
		validator.validateNoErrors();
		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OMNITURE"), "2", "674", "AHSTD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_OMNITURE"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"AHSTD\"}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", "[0-9]+(\\.[0-9]+)?", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Unregistered User withVCKOHLSCASHandODD", description = "Do placeorderulation for an order as guest user withVCKOHLSCASHandODD")
	public void WebExclusive_VC_KC_ODD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OMNITURE"), "1", "674", "ODD") + "],"
				+ "\"shippingMethod\":\"ODD\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","false", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OMNITURE"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
}
