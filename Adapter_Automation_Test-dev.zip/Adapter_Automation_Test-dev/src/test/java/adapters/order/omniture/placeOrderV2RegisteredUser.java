package test.java.adapters.order.omniture;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omniture")
@Stories({ "PlaceOrder Registered User V2 Validate Fulfuillment Type" })
public class placeOrderV2RegisteredUser {

	ResponseValidator validator;


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order an V2 registered User withMASTERCardandUSSTD",
			description = "Do place order for an V2 registered user withMASTERCardandUSSTD")
	public void webExclusiveUsingWithMASTER_CardandUSSTD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withVISACardandTDDorODD",
			description = "Do place order for an V2 registered user withVISACardandTDDorODD")
	public void webExclusiveUsingWithVISA_CardandTDDorODD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withProductOfferandUSSTD",
			description = "place an order with V2 registered user withProductOfferandUSSTD")
	public void webExclusiveUsingWithProductOfferandUSSTD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("GWP_SKU"), "1", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("GWP_SKU"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("GWP_SKU"), "1", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("GWP_SKU"), "1", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withKohlsChargeCardandAHSTD",
			description = "Do Place order as V2 registered user with KohlsChargeCardandAHSTD")
	public void webExclusiveUsingWithKohlsChargeCardandAHSTD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User DiscoverCardandODD",
			description = "Do Place order as V2registered user with Discover Card and ODD")
	public void webExclusiveUsingWithDiscoverCardandODD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		// validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User with Amex CardandTDD",
			description = "Place an Order as V2 registered user withAMEXCardandTDD")
	public void webExclusiveUsingWithAMEXCardandTDD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		// validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User with Kohls cash and TDD",
			description = "Place an Order as V2 registered user with Kohlscash and TDD")
	public void webExclusiveUsingWithKohlsCashandTDD() {

		// Kohls cash script
		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// creating new profile
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "100", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "100", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
				+ "}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "100", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "100", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
					+ "},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withREGISTRYandODD ",
			description = "Place an Order as V2 registered user withREGISTRYandODD ")
	public void webExclusiveUsingWithREGISTRYandODD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :[{"
				+ JsonString.getBopusCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1", "759")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1"
				+ "},\"action\":\"add\"}]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"giftItem\":true,\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("VALID_OMNI", testData.get("SKU_NORMAL"), "1","759") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		//Commented as per NAP-458
		//validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeMatches("$.payload.order.totals.shipTotal",".+", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","false", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :[{"
					+ JsonString.getBopusCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1", "759")
					+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1"
					+ "},\"action\":\"add\"}]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"giftItem\":true,\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
					+ JsonString.getBopusCartJson("VALID_OMNI", testData.get("SKU_NORMAL"), "1","759") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Place Order Registered User with shipping method USSTD/AHSTD", description = "Do PlaceOrder for an order as a registered user with shipping method USSTD/AHSTD")
	public void webExclusiveUsingWithAsExpiditedCheckOut() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "Omniture_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Omniture_access_token_adapter"));
		// getProfile
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.isEligibleForExpeditedCheckout", "false", "Profile isEligibleForExpeditedCheckout should be present");

		// PlaceOrder
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_NORMAL"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Master card should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// getProfile
		String strURL1 = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader);

		validator = new ResponseValidator(strURL1);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.isEligibleForExpeditedCheckout", "true", "Profile isEligibleForExpeditedCheckout should be present");
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order an V2 registered User withMASTERCardandUSSTD",
			description = "Do place order for an V2 registered user withMASTERCardandUSSTD")
	public void webExclusiveUsingWithPromoCode() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.isFreeShipping","true", "isFreeShipping should be present in the response");
		// validator.nodeEquals("$.payload.order.modes[0]","INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}

}