package test.java.adapters.order.omniture;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Omniture")
@Stories({ "Order Calc Registered User V2 Validate Fulfuillment Type " })
public class OrderCalcV2RegisteredUser {

	ResponseValidator validator;


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using USSTD")
	public void WebExclusiveUsingUSSTD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using TDD")
	public void WebExclusiveUsingTDD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using AMEX")
	public void WebExclusiveUsingAMEX() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using DISCOVER")
	public void WebExclusiveUsingDISCOVER() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using KOHLS CARD")
	public void WebExclusiveUsingKOHLSCARD() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_OMNITURE"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using KOHLS CASH")
	public void WebExclusiveUsingKOHLSCash() {
		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_OMNITURE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") +
				"\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "MC", "Master card should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");

		// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using Promocode")
	public void WebExclusiveUsingPromocode() {
		String arr[]=TestData.createKohlsCash(10);
		
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_OMNITURE"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getCartJson("VALID_CVV2_V2", testData.get("SKU_OMNITURE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		
		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", "VISA", "Master card should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "value should be applied from KohlsCash in the response");
//		validator.nodeMatches("$.payload.order.cartItems[0].discounts[0].offerId", ".+", "OfferId should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
						Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

						// Update cart through OAPI
						mapheader.clear();   // clear any headers set by previous TCs
						mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
						// Post the request
						String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Post the request
			

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID", true);
		}
	}


	@Test(groups = { "omniture", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc V2Registered User Validate FulfillmentType and webExclusive", description = "Do Ordercalculation for an order as V2Registered user and validate FulfillmentType and webExclusive is returning in the response using Registry")
	public void withRegistry() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :[{"
				+ JsonString.getBopusCartJson("REGISTRY", testData.get("SKU_OMNITURE"), "3", "759")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1"
				+ "},\"action\":\"add\"}]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"shippingMethod\":\"ODD\",\"giftItem\":\"true\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("VALID_OMNI", testData.get("SKU_OMNITURE"), "3", "759") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "OCB_access_token_OAPI");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID", true);
		}
	}

}
