package test.java.adapters.order.instorefreeShipping;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("InStore FreeShip")
@Stories({ "Order Calc Unregistered User" })
public class OrderCalc {

	ResponseValidator validator;


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withAMEXCardandUSSTD",
			description = "Do Ordercalculation for an order as guest user withAMEXCardandUSSTD")
	public void AMEXCardandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "InstoreFreeShipping", "regression","functional","errorhandling" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User with MissingSkucodeValue",
			description = "Do Ordercalculation for an order as guest user with Missing Skucode valuew and verify error order1000 displayed")
	public void MissingSkucodeValue() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE","", "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter skuCode.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "InstoreFreeShipping", "regression","functional","errorhandling" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User with InvalidSkucodeValue",
			description = "Do Ordercalculation for an order as guest user with Invalid Skucode valuew and verify error order1000 displayed")
	public void InvalidSkucodeValue() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "missing required parameter email.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "InstoreFreeShipping", "regression","functional","errorhandling" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User with Skucode Outofinventory",
			description = "Do Ordercalculation for an order as guest user with Skucode out of inventory and verify error order4000 displayed")
	public void SkucodeOutOfInventory() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OUTOFINVENTORY"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER4000", "sku ("+testData.get("SKU_OUTOFINVENTORY")+") out of inventory.");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withMASTERCardandAHSTD", description = "Do Ordercalculation for an order as guest user withMASTERCardandAHSTD")
	public void MASTERCardandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withRegistryandAHSTD", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Do Ordercalculation for an order as guest user withRegistryandAHSTD")
	public void RegistryandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withRegistryandODD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Do Ordercalculation for an order as guest user withRegistryandODD")
	public void RegistryandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"ODD\","
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withAMEXCardandODD", description = "Do Ordercalculation for an order as guest user withAMEXCardandODD")
	public void AMEXCardandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withDISCOVERCardandTDD", description = "Do Ordercalculation for an order as guest user withDISCOVERCardandTDD")
	public void DISCOVERCardandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withKOHLSCardandTDD",
			description = "Do Ordercalculation for an order as guest user withKOHLSCardandTDD")
	public void KOHLSCardandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withKohlsCashandUSSTD", description = "Do Ordercalculation for an order as guest user withKohlsCashandUSSTD")
	public void KohlsCashandUSSTD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withKohlsCashandTDD", description = "Do Ordercalculation for an order as guest user withKohlsCashandTDD")
	public void KohlsCashandTDD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withGIFTCardandAHSTD", description = "Do Ordercalculation for an order as guest user withGIFTCardandAHSTD")
	public void GIFTCardandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withGIFTCardandODD", description = "Do Ordercalculation for an order as guest user withGIFTCardandODD")
	public void GIFTCardandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withBOPUSandUSSTD",
			description = "Do Ordercalculation for an order as guest user withBOPUSandUSSTD")
	public void BOPUSandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_BOPUS"), "2", "759", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping","true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "InstoreFreeShipping", "regression","functional","errorhandling"}, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withBOPUS not Eligible",
			description = "Do Ordercalculation for an order as guest user withBOPUS not eligle skucode and verify error order3015 is displayed")
	public void BopusNotEligible() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_NORMAL"), "2", "759", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER3015", "The SKU "+testData.get("SKU_NORMAL")+" is not eligible for BOPUS");
		 
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withBOPUSandTDD", description = "Do Ordercalculation for an order as guest user withBOPUSandTDD")
	public void BOPUSandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_BOPUS"), "2", "759", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withGiftEligibleItemandUSSTD", description = "Do Ordercalculation for an order as guest user withGiftEligibleItemandUSSTD")
	public void GiftEligibleItemandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withProductOfferandAHSTD", description = "Do Ordercalculation for an order as guest user withProductOfferandAHSTD")
	public void ProductOfferandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_OFFERS"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withProductOfferandODD", description = "Do Ordercalculation for an order as guest user withProductOfferandODD")
	public void ProductOfferandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withGiftEligibleItemandTDD", description = "Do Ordercalculation for an order as guest user withGiftEligibleItemandTDD")
	public void GiftEligibleItemandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withVisaCardandUSSTDandAddr1", description = "Do Ordercalculation for an order as guest user withVisaCardandUSSTDandAddr1")
	public void VisaCardandUSSTDandAddr1() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withDiscoverCardandUSSTDandAddr2", description = "Do Ordercalculation for an order as guest user withDiscoverCardandUSSTDandAddr2")
	public void DiscoverCardandUSSTDandAddr2() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withMasterCardandAHSTDandAddr1",
			description = "Do Ordercalculation for an order as guest user withMasterCardandAHSTDandAddr1")
	public void MasterCardandAHSTDandAddr1() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"

		+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"

			+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withMasterCardandAHSTDandAddr1", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Do Ordercalculation for an order as guest user withMasterCardandAHSTDandAddr1")
	public void RegistryandAHSTDandVC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + ","
					+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"

			+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withMasterCardandODDandAddr1", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred", description = "Do Ordercalculation for an order as guest user withMasterCardandODDandAddr1")
	public void RegistryandODDandVC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + ","
				+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + ","
					+ JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"

			+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@DiscontinuedTest(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = false, priority = 4, testName = "Order Calc Unregistered User withAmexCardandAHSTDandAddr2", description = "Do Ordercalculation for an order as guest user withAmexCardandAHSTDandAddr2")
	public void AmexCardAndAHSTDAndAddr2() {
		// TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "2", "674", "AHSTD") + "],"
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("AMEX_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "2", "674", "AHSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID,payload.order.cartItems[0].itemMaxAvailableCount,payload.order.cartItems[0].maxQuantityMessage,payload.order.billAddress.addr1", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withMasterCardandODDandAddr1",
			description = "Do Ordercalculation for an order as guest user withMasterCardandODDandAddr1")
	public void MasterCardAndODDAndAddr1() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withDiscoverCardandODDandAddr1",
			description = "Do Ordercalculation for an order as guest user withDiscoverCardandODDandAddr1")
	public void DiscoverCardAndODDAndAddr1() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withDiscoverCardandTDDandAddr1",
			description = "Do Ordercalculation for an order as guest user withDiscoverCardandTDDandAddr1")
	public void DiscoverCardAndTDDAndAddr1() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withVisaCardandTDDandAddr1",
			description = "Do Ordercalculation for an order as guest user withVisaCardandTDDandAddr1")
	public void VisaCardAndTDDAndAddr1() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withVCDISCOVERCardandandTDDandAddr2",
			description = "Do Ordercalculation for an order as guest user withVCDISCOVERCardandandTDDandAddr2")
	public void VCDISCOVERCardAndTDDAndAddr2() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("VCDISCOVERCardAndTDDAndAddr2") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER_VCC")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withVCKOHLSCASHandandTDD",
			description = "Do Ordercalculation for an order as guest user withVCKOHLSCASHandandTDD")
	public void VCKohlscashAndTDD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"shippingMethod\":\"TDD\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("DISCOVER_ENC_DATA")
				+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("KOHLSCASH_PIN") + "\"}]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withVCGiftCardandUSSTD",
			description = "Do Ordercalculation for an order as guest user withVCGiftCardandUSSTD")
	public void VCGiftCardandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withVCGiftCardandODD",
			description = "Do Ordercalculation for an order as guest user withVCGiftCardandODD")
	public void VCGiftCardAndODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"shippingMethod\":\"ODD\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User with VC BOPUS and ODD",
			description = "Do Ordercalculation for an order as guest user withVCBOPUSandODD")
	public void VCBOPUSAndODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_BOPUS"), "2", "674", "ODD") + "],"
				+ "\"shippingMethod\":\"ODD\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_BOPUS"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Order Calc Unregistered User withVCBOPUSandAHSTD",
			description = "Do Ordercalculation for an order as guest user withVCBOPUSandAHSTD")
	public void VCBOPUSandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("BOPUS1_SKU"), "2", "674", "AHSTD") + "],"
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("BOPUS1_SKU"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("BOPUS1_SKU"), "2", "674", "AHSTD") + "],"
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withVCKOHLSCASHandAHSTD", description = "Do Ordercalculation for an order as guest user withVCKOHLSCASHandAHSTD")
	public void VCKOHLSCASHandAHSTD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("MASTER_ENC_DATA")
				+ "},\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("KOHLSCASH_PIN") + "\"}]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withVCProductWithOfferandAHSTD",
			description = "Do Ordercalculation for an order as guest user withVCProductWithOfferandAHSTD")
	public void VCProductWithOfferandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "2", "674", "AHSTD") + "],"
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_OFFERS"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "2", "674", "AHSTD") + "],"
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withDiscoverCardandUSSTD",
			description = "Verify Ordercalculation for an order as guest user with VC Product with offer and TDD")
	public void VCProductWithOfferandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "2", "674", "TDD") + "],"
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_OFFERS"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "2", "674", "TDD") + "],"
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Verify Ordercalculation for an order as guest user with VisaCard USSTD and paymentDetais=APPLEPAY")
	public void ApplePayVisaCardandUSSTD() {

		// Create the Json Request
		String strPayload = "	{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"VISA\"}]"
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.validatebillAddress();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Verify Ordercalculation for an order as guest user with MasterCard AHSTD and paymentDetais=APPLEPAY")
	public void ApplePayMasterCardandAHSTD() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "AHSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Verify Ordercalculation for an order as guest user with AmexCard ODD and paymentDetais=APPLEPAY")
	public void ApplePayAMEXCardandODD() {

		// Create the Json Request
		String strPayload = "	{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"AMEX\"}]"
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "ODD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.validatebillAddress();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Do Ordercalculation for an order as guest user with AmexCard TDD and paymentDetais=APPLEPAY")
	public void ApplePayAMEXCardandTDD() {

		// Create the Json Request
		String strPayload = "	{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"AMEX\"}]"
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "TDD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.validatebillAddress();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Do Ordercalculation for an order as guest user with KohlsCash USSTD and paymentDetais=APPLEPAY")
	public void ApplePayKohlsCashandUSSTD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Do Ordercalculation for an order as guest user with KohlsCash ODD and paymentDetais=APPLEPAY")
	public void ApplePayKohlsCashandODD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "ODD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Do Ordercalculation for an order as guest user with KohlsCashPromoCode USSTD and paymentDetais=APPLEPAY")
	@Severity(SeverityLevel.NORMAL)
	@Issues({ @Issue("FMNP-167") })
	public void ApplePayKohlsCashPromocodeandUSSTD() {

		// Where is kohls cash used in this?
		// -Blessan

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// ,\"kohlsCash\": [{\"kohlsCashNum\": \""+testData.get("KOHLS_CASH_NO")+"\",\"pin\": \""+testData.get("KOHLSCASH_PIN")+"\"}]

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "Promocode should be present in the response");
		// validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With ShipAddresss",
			description = "Do Ordercalculation for an order as guest user with KohlsCashPromoCode ODD and paymentDetais=APPLEPAY")
	@Severity(SeverityLevel.NORMAL)
	@Issues({ @Issue("FMNP-167") })
	public void ApplePayKohlsCashPROMOCODEandODD() {

		// Where is kohls cash used in this?
		// -Blessan

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// ,\"kohlsCash\": [{\"kohlsCashNum\": \""+testData.get("KOHLS_CASH_NO")+"\",\"pin\": \""+testData.get("KOHLSCASH_PIN")+"\"}]

		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "ODD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("PROMOCODE"), "Promocode should be present in the response");
		// validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withDiscoverCardandUSSTD",
			description = "Do Ordercalculation for an order as guest user with VC USSTD and GiftElligbleItem")
	public void VC_GiftEligibleItemAndUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload.order.cartItems[0].giftItem", "true", "GiftItem should be true in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4, testName = "Order Calc Unregistered User withDiscoverCardandUSSTD",
			description = "Do Ordercalculation for an order as guest user with VC TDD and Gift Elligible Item")
	public void VC_GiftElligibleItemAndTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" :[" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload.order.cartItems[0].giftItem", "true", "GiftItem should be true in the response");

		// Compare Open API
		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
}
