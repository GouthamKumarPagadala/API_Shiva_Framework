package test.java.adapters.order.instorefreeShipping;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDER_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDER_OAPI;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("InStore FreeShip")
@Stories({ "PlaceOrder Registered User" })
public class PlaceOrderRegisteredUser {

	ResponseValidator validator;


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withVISACardandUSSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrderulation for an order as registered user withVISACardandUSSTD")
	public void VisaCardandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withMASTERCardandAHSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrderulation for an order as registered user withMASTERCardandAHSTD")
	public void MASTERCardandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.cartItems.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withAMEXCardandODD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withAMEXCardandODD")
	public void AMEXCardandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withKOHLSCardandODD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withKOHLSCardandODD")
	public void KOHLSCardandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KOHLS_CARD3")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withDISCOVERCardandTDD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withDISCOVERCardandTDD")
	public void DISCOVERCardandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withKohlsCashandUSSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withKohlsCashandUSSTD")
	public void KohlsCashandUSSTD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
					+ ",\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.paymentTypes.kohlsCash[0].valueApplied,payload.order.paymentTypes.kohlsCash[0].kohlsCashValueApplied.subtotal,payload.order.paymentTypes.kohlsCash[0].balance,payload.order.paymentTypes.creditCards[0].valueApplied,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withKohlsCashandTDD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withKohlsCashandTDD")
	public void KohlsCashandTDD() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
				+ "             ,\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}"
					+ "             ,\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.paymentTypes.kohlsCash[0].valueApplied,payload.order.paymentTypes.kohlsCash[0].kohlsCashValueApplied.subtotal,payload.order.paymentTypes.kohlsCash[0].balance,payload.order.paymentTypes.creditCards[0].valueApplied,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withGIFTCardandAHSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withGIFTCardandAHSTD")
	public void GIFTCardandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withGIFTCardandODD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withGIFTCardandODD")
	public void GIFTCardandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}"
				+ ",\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withBOPUSandUSSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withBOPUSandUSSTD")
	public void BOPUSandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_BOPUS"), "2", "9961", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withBOPUSandTDD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withBOPUSandTDD")
	public void BOPUSandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_BOPUS"), "2", "9961", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withGiftEligibleItemandUSSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withGiftEligibleItemandUSSTD")
	public void GiftEligibleItemandUSSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withProductOfferandAHSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withProductOfferandAHSTD")
	public void ProductOfferandAHSTD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_OFFERS"), "5", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withProductOfferandODD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withProductOfferandODD")
	public void ProductOfferandODD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_OFFERS"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withGiftEligibleItemandTDD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withGiftEligibleItemandTDD")
	public void GiftEligibleItemandTDD() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_GIFT", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "OrderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber,payload.order.email", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay with VisaCard in USSTD shipping methodand addr1")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayVISAandUSSTDandAddr1() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID") +"," + "\"email\":\"shankarc44@gmail.com\"," + "\"cartItems\" : ["+ JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1","674","USSTD") +"]," + "\"billAddress\" : "+ JsonString.getBillAddressJson("WI_MILWAUKEE") +"," + "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\"," + "\"shipAddress\" : "+ JsonString.getBillAddressJson("CA_MILPITAS") +"," + " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + JsonString.getPaymentTypeJson("VISA_APPLEPAY") + "],\"paymentToken\":\""+testData.get("APPLEPAY_TOKEN_OAPI_INS")+"}}}}"; // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional", "place" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withApplePayMASTERCardandAHSTDandAddr1",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Do PlaceOrder as a registered user withApplePayMASTERCardandAHSTDandAddr1")
	public void ApplePayMASTERCardandAHSTDandAddr1() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"MC\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC")
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "AHSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID") +"," + "\"email\":\"shankarc44@gmail.com\"," + "\"cartItems\" : ["+ JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1","674","AHSTD") +"]," + "\"billAddress\" : "+ JsonString.getBillAddressJson("AHSTD_AE_APO") +"," + "\"shippingMethod\":\"AHSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\"," + "\"shipAddress\" : "+ JsonString.getBillAddressJson("AHSTD_AE_APO") +"," + " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + JsonString.getPaymentTypeJson("MC_APPLEPAY") + "],\"paymentToken\":\""+testData.get("APPLEPAY_TOKEN_OAPI")+"}}}}"; // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay with AmexCard in ODD shipping methodand addr1")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayAMEXandODDandAddr1() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"AMEX\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_AMEX")
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "ODD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\": {\"order\":"
		 * 
		 * + "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID") +"," + "\"email\":\"shankarc44@gmail.com\"," + "\"cartItems\" : ["+ JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1","674","ODD") +"]," + "\"billAddress\" : "+ JsonString.getBillAddressJson("WI_MILWAUKEE") +"," + "\"shippingMethod\":\"ODD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\"," + "\"shipAddress\" : "+ JsonString.getBillAddressJson("CA_MILPITAS") +"," + " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + JsonString.getPaymentTypeJson("AMEX_APPLEPAY") + "],\"paymentToken\":\""+testData.get("APPLEPAY_TOKEN_OAPI")+"\"}}}}";
		 * 
		 * 
		 * // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay with MasterCard in TDD shipping methodand addr1")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayMASTERandTDDandAddr1() {

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_APPLEPAY"), "1", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"MC\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER_MC")
				+ "},\"modes\":[\"INGEOFENCE\"]}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_APPLEPAY"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "TDD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID") +"," + "\"email\":\"shankarc44@gmail.com\"," + "\"cartItems\" : ["+ JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("SKU_NORMAL"), "1","674","TDD") +"]," + "\"billAddress\" : "+ JsonString.getBillAddressJson("WI_MILWAUKEE") +"," + "\"shippingMethod\":\"TDD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\"," + "\"shipAddress\" : "+ JsonString.getBillAddressJson("CA_MILPITAS") +"," + " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + JsonString.getPaymentTypeJson("MC_APPLEPAY") + "],\"paymentToken\":\""+testData.get("APPLEPAY_TOKEN_OAPI")+"}}}}"; // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay with VisaCard in USSTD shipping method and Kohlscash")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayVISAandUSSTDandkohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\""+testData.get("SKU_NORMAL")+"\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\""+testData.get("KOHLS_CASH_NO")+"\",\"pin\":\""+testData.get("KOHLSCASH_PIN")+"\"}],\"paymentToken\":\""+testData.get("APAY_KOHLSCASH_TOKEN_OAPI")+"\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}"; // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay with VisaCard in TDD shipping method and Kohlscash")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayVISAandTDDandkohlsCash() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\",\"qty\":3,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"TDD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "TDD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\""+testData.get("SKU_NORMAL")+"\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"TDD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\""+testData.get("KOHLS_CASH_NO")+"\",\"pin\":\""+testData.get("KOHLSCASH_PIN")+"\"}],\"paymentToken\":\""+testData.get("APAY_KOHLSCASH_TOKEN_OAPI")+"\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";
		 * 
		 * // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "PlaceOrderRegisteredUserwithApplePayVISAandAHSTDandPromoCode",
			description = "PlaceOrderRegisteredUserwithApplePayMASTERandAHSTDandPromoCode")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayMasterandAHSTDandPromoCode() {

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"AHSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"APO\",\"state\":\"AE\",\"postalCode\":\"09211\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"APO\",\"state\": \"AE\",\"postalCode\": \"09211\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "AHSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\""+testData.get("SKU_NORMAL")+"\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"AHSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\""+testData.get("PROMOCODE")+"\"}],\"paymentToken\":\""+testData.get("APAY_KOHLSCASH_PROMO_TOKEN_OAPI")+"\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"APO\",\"state\":\"AE\",\"postalCode\":\"09211\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"APO\",\"state\": \"AE\",\"postalCode\": \"09211\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";
		 * 
		 * 
		 * 
		 * // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 7,
			testName = "PlaceOrderRegisteredUserwithApplePayVISAandODDandPromoCode",
			description = "PlaceOrderRegisteredUserwithApplePayMasterandODDandPromoCode")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("APPLP-13") })
	public void ApplePayMasterandODDandPromoCode() {

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_NORMAL") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"ODD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
				+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "ODD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		// Set orderNumber from response in test data
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		/*
		 * // Compare Open API if (CompareOAPI) { String strPayloadOAPI = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\""+testData.get("SKU_NORMAL")+"\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"ODD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\",\"cardNum\":\"4059557030507744\",\"expDate\":\"05/2020\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\""+testData.get("PROMOCODE")+"\"}],\"paymentToken\":\""+testData.get("APAY_KOHLSCASH_PROMO_TOKEN_OAPI")+"\",\"creditCards\":[{\"cardNum\":\"4059557030007604\",\"nameOnCard\":\"\",\"type\":\"VISA\",\"expDate\":\"05/2020\"}]},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"postalCode\": \"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"hardik.desai@globallogic.com\",\"modes\":[\"INGEOFENCE\"]}}}";
		 * 
		 * // Get the request String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI,strPayloadOAPI,Server.OpenApi, false); Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi"); // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true); }
		 */
	}


	@Test(groups = { "InstoreFreeShipping","PlaceOrderRegistryItem", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withRegistryandAHSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Do placeorder for an order as registered user withRegistryandAHSTD")
	public void PlaceOrderWithRegistryItemAndDiscoverCardIngeofence() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"AHSTD\",\"storeNum\":\"674\"}]"
				+ ",\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO")
				+ ", \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateshipAddressRegistrySku();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping","true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "InstoreFreeShipping","PlaceOrderRegistryItem", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withRegistryandAHSTD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Do placeorder for an order as registered user withRegistryandAHSTD")
	public void PlaceOrderWithRegistryItemAndAmexCardIngeofence() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"AHSTD\",\"storeNum\":\"674\"}]"
				+ ",\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO")
				+ ", \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateshipAddressRegistrySku();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping","true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping","PlaceOrderRegistryItem", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order Registered User withRegistryandODD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Do placeorderulation for an order as registered user withRegistryandODD")
	public void PlaceOrderWithRegistryItemAndMasterCardIngeofence() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("REGISTRY", testData.get("SKU_NORMAL"), "1") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1},\"shippingMethod\":\"ODD\",\"storeNum\":\"674\"}]"
				+ ",\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		//validator.validateshipAddress();
		validator.validateshipAddressRegistrySku();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping","false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeMatches("$.payload..shipToId", ".+", "webID should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
}
