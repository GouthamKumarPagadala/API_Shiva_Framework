package test.java.adapters.order.instorefreeShipping;

import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.GlobalVariables.CART_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER_INSTANTBUY_V2;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("InStore FreeShip")
@Stories({ "PlaceOrder Registered User V2" })
public class PlaceOrderV2RegisteredUser {

	ResponseValidator	validator;
	String				strEmail;
	String				strPaswd;
	String				strEmail1;
	String				strPaswd1;
	String				strEmailOapi;
	String				strPaswdOapi;
	String				strResponse;


	@BeforeClass(alwaysRun = true)
	public void testSetup() {

		strEmail = Utilities.getNewEmailID();
		strPaswd = "Ocb@1234";
		Utilities.createProfile(strEmail, strPaswd, Server.Adapter);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "free_shipping_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("free_shipping_token_adapter"));

	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place Order an V2 registered User withMASTERCardandUSSTD",
			description = "Do place order for an V2 registered user withMASTERCardandUSSTD")
	public void MASTERCardandUSSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}
	@Test(groups = { "InstoreFreeShipping", "regression","functional","errorhandling" }, enabled = true, priority = 4,
			testName = "Place Order an V2 registered User With InvalidCartId",
			description = "Do place order for an V2 registered user with InvalidCartId and verify error code order is displayed")
	public void InvalidCartId() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";
		mapheader.put("access_token", testData.get("free_shipping_token_adapter"));
		
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + "" + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER1000", "Missing Required Parameter CartID.");
		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + "" + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withVISACardandAHSTD",
			description = "Do place order for an V2 registered user withVISACardandAHSTD")
	public void VISACardandAHSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withGiftEligibleItemandAHSTD",
			description = "Do place order for an V2 registered user withGiftElligibleItemandAHSTD")
	public void GiftEligibleItemandAHSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withGiftEligibleItemandTDD",
			description = "Place an Order withV2 registered user withGiftEligibleItemandTDD")
	public void GiftEligibleItemandTDD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_GIFT_INSTORE", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withProductOfferandUSSTD",
			description = "place an order with V2 registered user withProductOfferandUSSTD")
	public void ProductOfferandUSSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("GWP_SKU"), "1", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("GWP_SKU"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("GWP_SKU"), "1", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("GWP_SKU"), "1", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an orde with V2 registered User withProductOfferandODD",
			description = "Place an order as V2 registered user withProductOfferandODD")
	public void ProductOfferandODD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("BOPUS1_SKU"), "1", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("BOPUS1_SKU"), "1", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("BOPUS1_SKU"), "1", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("BOPUS1_SKU"), "1", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withKohlsChargeCardandAHSTD",
			description = "Do Place order as V2 registered user with KohlsChargeCardandAHSTD")
	public void KohlsChargeCardandAHSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
				+ "\"shippingMethod\":\"AHSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "AHSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("AHSTD_AE_APO") + ","
					+ "\"shippingMethod\":\"AHSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User DiscoverCardandODD",
			description = "Do Place order as V2registered user with Discover Card and ODD")
	public void DiscoverCardandODD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		// validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("DISCOVER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}

		// Remove cart has been added since order is not getting placed for discover card
		validator.removeCart(strResponse, Server.Adapter, testData.get("free_shipping_token_adapter"));
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User with Amex CardandTDD",
			description = "Place an Order as V2 registered user withAMEXCardandTDD")
	public void AMEXCardandTDD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "1", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "1", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("AMEX")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User with Kohls cash and USSTD",

	description = "Place an Order as V2 registered user with Kohlscash and USSTD")
	public void KohlsCashandUSSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		// Kohls cash script
		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
				+ "},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
					+ "},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User with Kohls cash and TDD",
			description = "Place an Order as V2 registered user with Kohls cash and TDD")
	public void KohlsCashandTDD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
				+ "},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]"
					+ "},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User wit GiftCard and USSTD",
			description = "Place an Order as V2 registered user with Gift CardandUSSTD")
	public void GiftCardandUSSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "1", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "1", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		validator.nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User with GiftCard and ODD",

	description = "Place an Order as V2 registered user with Gift Card and ODD")
	public void GiftCardandODD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

		// Create Request

		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
				+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"ODD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		// validator.nodeEquals("$.payload.order.totals.shipTotal","0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";
			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\","
					+ "\"cartItems\" : [{\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID") + JsonString.getBopusCartJsonShippingType("VALID_INSTORE_V2", testData.get("SKU_NORMAL"), "2", "674", "ODD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"ODD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 8,
			testName = "Place an Order with V2 registered User withBOPUSandUSSTD",
			description = "Place an Order as V2 registered user with Bopus and USSTD")
	public void BOPUSandUSSTD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", "9961")
				+ "]}}}";

		// Post the request
		String strResponseUpdateCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "CART_ITEM_ID1");
		Utilities.setTestData(strResponseUpdateCart, "$.payload.cart.cartID", "CART_ID1");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("CART_ID1") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("CART_ITEM_ID1") + JsonString.getBopusCartJsonShippingType("VALID_BOPUS", testData.get("SKU_BOPUS"), "3", "9961", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].itemType", "BOPUS", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", "9961")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("CART_ID1") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("CART_ITEM_ID1") + JsonString.getBopusCartJsonShippingType("VALID_BOPUS", testData.get("SKU_BOPUS"), "3", "9961", "USSTD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "InstoreFreeShipping", "regression","functional" }, enabled = true, priority = 8,
			testName = "Place an Order with V2 registered User with BOPUS and TDD",
			description = "Place an Order as V2 registered user with Bopus and TDD")
	public void BOPUSandTDD() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", "9961")
				+ "]}}}";

		// Post the request
		String strResponseUpdateCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "CART_ITEM_ID1");
		Utilities.setTestData(strResponseUpdateCart, "$.payload.cart.cartID", "CART_ID1");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("CART_ID1") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("CART_ITEM_ID1") + JsonString.getBopusCartJsonShippingType("VALID_BOPUS", testData.get("SKU_BOPUS"), "3", "9961", "TDD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"TDD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		// validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
		validator.nodeEquals("$.payload.order.cartItems[0].itemType", "BOPUS", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "orderStatus should be submitted in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "3", "9961")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("CART_ID1") + "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("CART_ITEM_ID1") + JsonString.getBopusCartJsonShippingType("VALID_BOPUS", testData.get("SKU_BOPUS"), "3", "9961", "TDD") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ "\"shippingMethod\":\"TDD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("MASTER")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}

	
	@Test(groups = { "InstoreFreeShipping","PlaceOrderRegistryItem", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withRegistryandAHSTD",
			description = "Place an Order as V2 registered user withRegistryandAHSTD")
	public void PlaceOrderWithRegistryItemAndVisaCard() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("IL_CHICAGO_ADD")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("REGISTRY_V1", testData.get("SKU_NORMAL"), "2", "674")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1"
				+ "},\"action\":\"add\"}]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"giftItem\":\"true\",\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "2", "674") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"ODD\","
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		//validator.validateshipAddressRegistrySku();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
					+ JsonString.getBopusCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "2", "674") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}

	@Test(groups = { "InstoreFreeShipping","PlaceOrderRegistryItem", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withRegistryandAHSTD",
			description = "Place an Order as V2 registered user withRegistryandAHSTD")
	public void PlaceOrderWithNormalAndRegistryItemAndMasterCard() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("IL_CHICAGO_ADD")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("REGISTRY_V1", testData.get("SKU_NORMAL"), "2", "674")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1"
				+ "},\"action\":\"add\"}]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"giftItem\":\"true\",\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "2", "674") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"ODD\","
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		//validator.validateshipAddressRegistrySku();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
					+ JsonString.getBopusCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "2", "674") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}

		@Test(groups = { "InstoreFreeShipping","PlaceOrderRegistryItem", "regression","functional" }, enabled = true, priority = 4,
			testName = "Place an Order with V2 registered User withREGISTRYandODD ",
			description = "Place an Order as V2 registered user withREGISTRYandODD ")
	public void PlaceOrderWithBopusRegistryItemAsRegisteredUser() {

		Utilities.removeCart(Server.Adapter, testData.get("free_shipping_token_adapter"));
		// Update ShipAddress
		String strPayload1 = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("IL_CHICAGO_ADD")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload1, Server.Adapter, true, mapheader);

		Utilities.setTestData(strResponse1, "$.payload.id", "shipping_id_adapter");

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("REGISTRY_V1", testData.get("SKU_NORMAL"), "2", "674")
				+ "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1"
				+ "},\"action\":\"add\"}]}}}";
		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "ADAPTERCART_ID");
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"giftItem\":\"true\",\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
				+ JsonString.getBopusCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "2", "674") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
				+ "\"shippingMethod\":\"ODD\","
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";
		

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		//validator.validateshipAddressRegistrySku();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeMatches("$.payload.order.totals.shipTotal", ".+", "ship total should be present in the response");
		validator.nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");

		// Compare Open API
		if (CompareOAPI) {

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));

			String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getBopusCartJson("VALID_INSTORE_TDD", testData.get("SKU_NORMAL"), "2", "674")
					+ "]}}}";

			// Post the request for updateCart(ADD) using mapheader to OAPI
			String strResponseOAPIUpdateCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart1, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartItems[0].cartItemID", "ADAPTER_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIUpdateCart, "$.payload.cart.cartID", "ADAPTERCART_ID");

			// Create Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartID\":\"" + testData.get("ADAPTERCART_ID") + "\",\"cartItems\" : [{\"shippingMethod\":\"ODD\",\"cartItemID\":\"" + testData.get("ADAPTER_CART_ITEM_ID")
					+ JsonString.getBopusCartJson("REGISTRY_V2", testData.get("SKU_NORMAL"), "2", "674") + "\"shipToId\":\"" + testData.get("shipping_id_adapter") + "\",\"wantedQty\":1}}],"
					+ "\"shippingMethod\":\"ODD\","
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
					+ " \"paymentTypes\" :{\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]},\"modes\":[\"INGEOFENCE\"]"
					+ "}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.email,payload.order.cartID,payload.order.orderNumber", true);
		}
	}

}
