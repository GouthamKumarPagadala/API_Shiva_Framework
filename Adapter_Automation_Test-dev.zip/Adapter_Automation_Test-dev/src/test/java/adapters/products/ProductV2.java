package test.java.adapters.products;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.GlobalVariables.*;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Products V2")
@Stories({ "Product Details" })

public class ProductV2 {

	ResponseValidator validator;

	// Get All Runtime Sku's

	@BeforeClass(alwaysRun = true)
	public void testSetup() {
		TestData.getRunTimeData("SKU_CODE", true);
		//TestData.getRunTimeData("INSTORE_SKU_CODE", true);
		//TestData.getRunTimeData("INSTORE_BOGO_SKU", true);
		TestData.getRunTimeData("SALEPRICE_SKU", true);
		TestData.getRunTimeData("SUPPRESSED_SKU", true);
		TestData.getRunTimeData("PROMOTION_BOGO_SKU", true);
	}

	// Positive TestCases

	@Test(groups = { "regression","smokeTest", "functional", "errorhandling","YourPrice", "NAP-79",
			"V2Product","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass webID in URL, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return KC earned and Y2Y points eraned at sku and product level,Return Best Applicable offer, Price data Optimisation")
	public void GetProductWith_WebID() {
		TestData.getRunTimeData("WEB_ID", false);
		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/" 
		+ testData.get("RUNTIME_WEB_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, false, false);
		//validator.ValidateProductV2Promotion(false, true, false, false, false);
		//validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2 + "/" + testData.get("RUNTIME_SKU_CODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	//Added for Scenario#15-OPM-70#DOLLAR OFF AND PRORATED OFFER
	@Test(groups = {"ProductOffer-NAP182","YourPrice","DIE_Changes"}, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass webID in URL, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return Best Applicable offer, Price data Optimisation")
	public void GetProductWith_DollaroffWebID() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/" + testData.get("DOLLAROFF_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validateApplicableOfferAtProductLevel(strResponse);
		//validateApplicableOfferAtSkuLevel(strResponse);
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2 + "/" + testData.get("DOLLAROFF_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	
	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, 
			enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass SkuCode in URL, FEATURE = V2/Product, Rebate URL,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer, Price data Optimisation")
	public void GetProductWith_Sku() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, false, true);
		validateApplicableOfferAtProductLevel(strResponse);
		validateKCEarnedAndY2YAtProductLevel(strResponse);

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6,
			testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass SkuCode and skuDetail=true in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer, Rebate URL, Price data Optimisation")
	public void GetProductWith_Sku_SkuDetailTrue() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=True";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, false, false);
		validator.ValidateProductV2Promotion(false, false, false, true, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	validator.nodeNotEquals("$.payload.products[0].SKUS[0].UPC.ID","null","Verifying whether UPC is displayed or not");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=True";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product" ,"YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36" }, enabled = true, priority = 6, 
			testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass UPC code in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level, Return YourPriceInfo at sku and product level,Return Best Applicable offer, Rebate URL, Price data Optimisation")
	public void GetProductWith_UPC() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, false, true);
		//validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass UPC code and storeNum=759 in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWith_UPCInStore() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, true, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&storeNum=759";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass UPC code and skuDetail=true in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWith_UPC_SkudetailTrue() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36" }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass webID with skuDetails=true in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWith_WebID_SkuDetailsTrue() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID") + "?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID")
					+ "?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass webID with skuDetails=true and invFilter = false in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWith_WebID_SkuDetailsTrueAndInvFilterFalse() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID")
				+ "?skuDetail=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID")
					+ "?skuDetail=true&invFilter=false";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass SkuCode and allSkus=true and skuDetail=true in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,Rebate URL, Price data Optimisation")
	public void GetProductWith_Sku_AllSkusTrueAndSkudetailTrue() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE")
				+ "&allSkus=true&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		//validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE")
					+ "&allSkus=true&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass SkuCode and allSkus=true and skuDetail=true and invFilter=false in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level, Return YourPriceInfo at sku and product level,Return Best Applicable offer, Rebate URL, Price data Optimisation")
	public void GetProductWith_Sku_AllSkusTrueAndSkudetailTrueAndInvFilterFalse() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_INSTORE_SKUCODE")
				+ "&allSkus=true&skuDetail=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validator.ValidateProductV2Promotion(false, false, false, true, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("AVAILABLE_ONLINE_INSTORE_SKUCODE")
					+ "&allSkus=true&skuDetail=true&invFilter=false";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass SkuCode, skuDetail=true and invFilter=false in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWith_Sku_skuDetailTrueAndInvFilterFalse() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("RUNTIME_SKU_CODE")
				+ "&skuDetail=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		//validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("RUNTIME_SKU_CODE")
					+ "&skuDetail=true&invFilter=false";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID",
			description = "As a Kohls User I want to get the V2 product response when I pass UPC code and invFilter=false and skuDetail=true in URL, FEATURE = V2/Product, Rebate URL,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")
	public void GetProductWith_UPC_InvFilterFalseAndskuDetailTrue() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&invFilter=false&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&invFilter=false&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass SkuCode and storeNum in URL, FEATURE = V2/Product, Rebate URL,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")
	public void GetProductWithSkuInStore() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_INSTORE_SKUCODE") + "&storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, true, false);
		//validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("AVAILABLE_ONLINE_INSTORE_SKUCODE") + "&storeNum=759";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the V2 product response when I pass WebID and storeNum in URL, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return Best Applicable offer,Return KC earned and Y2Y points eraned at sku and product level,  Price data Optimisation")
	public void GetProductWithWebIDInStore() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID") + "?storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, true, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2 + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID")
					+ "?storeNum=759";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass UPC code, skuDetail=true & allSkus=true in URL, FEATURE = V2/Product,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWith_UPC_skuDetailTrueAndAllSkus() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&skuDetail=true&allSkus=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID") + "&skuDetail=true&allSkus=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass UPC code, skuDetail=true, allSkus=true & invFilter=false in URL, FEATURE = V2/Product, Rebate URL,Return KC earned and Y2Y points eraned at sku and product level,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")
	public void GetProductWith_UPC_skuDetailTrueAndAllSkusAndInvFilterFalse() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID")
				+ "&skuDetail=true&allSkus=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(true, false, false);
		validateApplicableOfferAtSkuLevel(strResponse);
    	validateApplicableOfferAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtProductLevel(strResponse);
    	validateKCEarnedAndY2YAtSkuLevel(strResponse);
    	

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID")
					+ "&skuDetail=true&allSkus=true&invFilter=false";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	// Negative TestCases

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", 
			description = "As a Kohls User I want to get the proper error message when I didn't pass webID in URL, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")

	public void GetProductwithoutWebID() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000", "Missing Required Parameter 'Web ID, SKU CODE, UPC'.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2 + "/";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the  proper error message when I didn't pass SkuCode in URL, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")
	public void GetProductwithoutSku() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000", "Missing Required Parameter skuCode.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the proper error message when I didn't pass UPC code in URL, FEATURE = V2/Product,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductwithoutUPC() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000", "Missing Required Parameter upc.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the  proper error message when I pass invalid parameter value in URL, FEATURE = V2/Product,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductWithInvalidParameterValue() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("RUNTIME_SKU_CODE") + "&allSkus=fals";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1002", "Invalid value passed for allSkus.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("RUNTIME_SKU_CODE") + "&allSkus=fals";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the  proper error message when I pass invalid parameter in URL, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")
	public void GetProductWithInvalidParameter() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + testData.get("RUNTIME_SKU_CODE") + "&allSk=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1001", "allSk is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + testData.get("RUNTIME_SKU_CODE") + "&allsk=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the proper error message when we pass invalid webID in URL, FEATURE = V2/Product,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductwithInvalidWebID() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2 + "/1234567";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2000", "Web ID (1234567) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2 + "/1234567";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36" }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the  proper error message when we pass invalid SkuCode in URL, FEATURE = V2/Product,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductwithInvalidSku() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER_V2 + "12345678";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2001", "SKU (12345678) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI_V2 + "12345678";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@Test(groups = { "regression", "functional", "errorhandling", "NAP-79",
			"V2Product","YourPrice","ProductOffer-NAP182","DIE_Changes","YourPrice-NAP36"  }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the proper error message when we pass invalid UPC code in URL, FEATURE = V2/Product, Rebate URL, Return YourPriceInfo at sku and product level,Return Best Applicable offer, Price data Optimisation")
	public void GetProductwithInvalidUPC() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER_V2 + "123456789012";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2002", "UPC (123456789012) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI_V2 + "123456789012";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	// Product Bulk

	@DiscontinuedTest(groups = { "regression","YourPrice", "functional", "errorhandling", "NAP-79",
			"V2Product" }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass webID and Sku in Payload, FEATURE = V2/Product,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Rebate URL, Price data Optimisation")
	public void GetProductBulkWithWebIDAndSku() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2;
		String strPayload = "{\"payload\":{\"products\":[{\"webID\":\"" + testData.get("RUNTIME_WEB_ID") + "\"},"
				+ "{\"skuCode\":\"" + testData.get("RUNTIME_SKU_CODE") + "\"}]}}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, false, false);

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2;
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}

	@DiscontinuedTest(groups = { "regression","YourPrice", "functional", "errorhandling", "NAP-79",
			"V2Product" }, enabled = true, priority = 6, testName = "SingleProductDetails With WebID", description = "As a Kohls User I want to get the V2 product response when I pass UPC and Sku in Payload, FEATURE = V2/Product, Rebate URL,Return YourPriceInfo at sku and product level,Return Best Applicable offer,  Price data Optimisation")
	public void GetProductBulkWithUPCAndSku() {

		String strURL = PRODUCT_DETAILS_ADAPTER_V2;
		String strPayload = "{\"payload\":{\"products\":[{\"upc\":\"" + testData.get("UPC_CODE") + "\"},"
				+ "{\"skuCode\":\"" + testData.get("RUNTIME_SKU_CODE") + "\"}]}}";
		// Post the request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateProductV2Response(false, false, false);

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI_V2;
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, null, true);
		}
	}
	
	
	//validation whether yourPriceInfo element is present at product level
	public void validateApplicableOfferAtProductLevel(String response){
		 validator.nodeMatches("$.payload.products[0].price.yourPriceInfo",".+","Your Price info should be displayed");
		 validator.nodeMatches("$.payload.products[0].price.yourPriceInfo.yourPrice",".+","Price info based on best applicable offer should be displayed");
		 validator.nodeMatches("$.payload.products[0].price.yourPriceInfo.yourPriceSavings",".+","Price savings after applied offer should be displayed");
		 validator.nodeMatches("$.payload.products[0].price.yourPriceInfo.appliedOffers",".+","Applied Offers should be displayed");
	
		}
	//validation whether KC Earned and yes2You awards is present at product level
	public void validateKCEarnedAndY2YAtProductLevel(String response){
			 validator.nodeMatches("$.payload.products[0].price.loyalty.pointsEarned.min",".+","Min Y2Y rewards earned should be displayed");
			 validator.nodeMatches("$.payload.products[0].price.loyalty.pointsEarned.max",".+","Max Y2Y rewards earned should be displayed");
			 validator.nodeMatches("$.payload.products[0].price.kohlsCash.kcEarned.min",".+","Min Kohlscash earned should be displayed");
			 validator.nodeMatches("$.payload.products[0].price.kohlsCash.kcEarned.max",".+","Max kohlscash rewards earned should be displayed");
			 validator.nodeMatches("$.payload.products[0].price.kohlsCash.kcEarningPeriod.startDate",".+","kcEarningPeriod should be displayed in the response");
			 validator.nodeMatches("$.payload.products[0].price.kohlsCash.kcEarningPeriod.endDate",".+","kcEarningPeriod should be displayed in the response");
			 validator.nodeMatches("$.payload.products[0].price.kohlsCash.kcRedemptionPeriod.startDate",".+","kcRedemptionPeriod should be displayed in the response");
			 validator.nodeMatches("$.payload.products[0].price.kohlsCash.kcRedemptionPeriod.endDate",".+","kcRedemptionPeriod should be displayed in the response");
		}
	//validation whether yourPriceInfo element is present at sku level
	public void validateApplicableOfferAtSkuLevel(String response){
		Object	document;
   	document = Configuration.defaultConfiguration().jsonProvider().parse(response);
   	 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
   	 int count = SKUS.size();
   	 for (int i = 0; i < count-1; i++){  
   		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.yourPriceInfo",".+","Your Price info should be displayed");
   		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.yourPriceInfo.yourPrice",".+","Price info based on best applicable offer should be displayed");
   		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.yourPriceInfo.yourPriceSavings",".+","Price savings after applied offer should be displayed");
   		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.yourPriceInfo.appliedOffers",".+","Applied Offers should be displayed");
   	 }
	}
	//validation whether KC Earned and yes2You awards is present at sku level
	public void validateKCEarnedAndY2YAtSkuLevel(String response){
			Object	document;
	   	document = Configuration.defaultConfiguration().jsonProvider().parse(response);
	   	 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
	   	 int count = SKUS.size();
	   	 for (int i = 0; i < count-1; i++){  
	   		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.pointsEarned",".+","Yes2You points earned should be displayed at sku level");
	   		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.kcEarned",".+","KC Earned should be displayed at the sku level");
	   		  }
		}
}
