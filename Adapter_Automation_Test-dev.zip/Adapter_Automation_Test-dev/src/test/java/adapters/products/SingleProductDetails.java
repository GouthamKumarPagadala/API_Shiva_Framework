package test.java.adapters.products;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_OAPI;
import static main.java.common.GlobalVariables.PRODUCTS_BY_SKU_ADAPTER;
import static main.java.common.GlobalVariables.PRODUCTS_BY_UPC_ADAPTER;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Products")
@Stories({ "Single Product Details" })
public class SingleProductDetails {

	
	ResponseValidator validator;
	

	@Test(groups = { "regression","functional", "errorhandling"}, enabled = true, priority = 6, testName = "SingleProductDetails With invalid WebID",
			description = "Checking whether the sku is eligible is available for Invalid webId")
	public void InvalidWebID() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/KJ344?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2000", "Web ID (KJ344) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/KJ344?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductWebId_saleprice_statussale",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - validate SalePriceStatus,<br /> Grouppricing")
 
	public void Get_Product_ByWebId_saleprice_status_sale() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+ testData.get("WEBID_SALEPRICESALE") +"?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			 }
		   

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI +"/"+ testData.get("WEBID_SALEPRICESALE") +"?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductWebId_saleprice_statusclerance",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - GroupPricing")
	public void Get_Product_ByWebId_saleprice_status_clearance() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+ testData.get("WEBID_SALEPRICECLEARANCE") +"?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			 }
		   

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI +"/"+ testData.get("WEBID_SALEPRICECLEARANCE") +"?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductWebId_saleprice_statusnull",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - GroupPricing")
	public void Get_Product_ByWebId_saleprice_status_null() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+ testData.get("WEBID_SALEPRICENULL") +"?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		try{
	    if(JsonPath.read(strResponse, "$.payload.products[0].price.salePrice").equals(null))
			
			{
			 validator.nodeEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price status should be present");
			     
			 }
		}
		catch(Exception e)
		{
			
		}

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/"+ testData.get("WEBID_SALEPRICENULL") +"?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductUPCId_saleprice_statussale",
			description = "\n TC Description -Verify whether User is able to view product by UPCId \n Feature - GroupPricing")
	public void Get_Product_ByUPCId_saleprice_status_sale() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?upc="+ testData.get("UPC_SALEPRICESALE") ;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			
		    }
		   

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?upc="+ testData.get("UPC_SALEPRICESALE") ;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductUPCId_saleprice_statusclearance",
			description = "\n TC Description -Verify whether User is able to view product by UPCId \n Feature - GroupPricing")
	public void Get_Product_ByUPCId_saleprice_status_clearance() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?upc="+ testData.get("UPC_SALEPRICECLEARANCE") ;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			 }
		   

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_ADAPTER +"/?upc="+ testData.get("UPC_SALEPRICECLEARANCE") ;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductUPCId_saleprice_statusnull",
			description = "\n TC Description -Verify whether User is able to view product by UPCId \n Feature - GroupPricing")
	public void Get_Product_ByUPCId_saleprice_status_null() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?upc="+ testData.get("UPC_SALEPRICENULL") ;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		try{
	    if(JsonPath.read(strResponse, "$.payload.products[0].price.salePrice").equals(null))
			
			{
			 validator.nodeEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should be null");
			     
			 }
		}
		catch(Exception e)
		{
			
		}
		   

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_ADAPTER +"/?upc="+ testData.get("UPC_SALEPRICENULL") ;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductSkuCode_saleprice_statussale",
			description = "\n TC Description -Verify whether User is able to view product by Skucode \n Feature - GroupPricing")
	public void Get_Product_BySkuCode_saleprice_status_sale() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?skuCode="+ testData.get("SKU_SALEPRICESALE") ;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			 }
		   

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?skuCode="+ testData.get("SKU_SALEPRICESALE") ;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing" }, enabled = true, priority = 12, testName = "ProductSkuCode_saleprice_statusclearance",
			description = "\n TC Description -Verify whether User is able to view product by Skucode \n Feature - GroupPricing")
	public void Get_Product_BySkuCode_saleprice_status_clearance() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?skuCode="+ testData.get("SKU_SALEPRICECLEARANCE") ;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			 }
		    

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?skuCode="+ testData.get("SKU_SALEPRICECLEARANCE") ;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}
	@Test(groups = { "GroupPricing","SmartSuppressedPricing-NAP126" }, enabled = true, priority = 12, testName = "ProductSkuCode_saleprice_statusnull",
			description = "\n TC Description -Verify whether User is able to view product by Skucode \n Feature - GroupPricing")
	public void Get_Product_BySkuCode_saleprice_status_null() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?skuCode="+ testData.get("SKU_CODE_BOGO_SALE") ;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validateSmartSuppressedPricing(strResponse);
		try{
			String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice").toString();
	    if(salePrice.equals("null"))
			
			{
			 validator.nodeEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price should be null");
			     
			 }
		}
		catch(Exception e)
		{
			
		}

	 // Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_ADAPTER +"/?skuCode="+ testData.get("SKU_SALEPRICENULL") ;
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

    }}

	@Test(groups = { "regression","functional", "errorhandling"}, enabled = true, priority = 6, testName = "SingleProductDetails With blank WebID",
			description = "Checking whether the sku is eligible is available for blank webId")
	public void EmptyValueForWebID() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000", "Missing Required Parameter 'Web ID, SKU CODE, UPC'.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling"}, enabled = true, priority = 6, testName = "SingleProductDetails With InvalidValueForSkuDeatil",
			description = "Checking whether the sku is eligible is available for Invalid value for skuDetail")
	public void InvalidValueForSkuDetail() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEB_ID") + "?skuDetail=fdsfsd";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1002", "Invalid value passed for skuDetail.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEB_ID") + "?skuDetail=fdsfsd";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling"}, enabled = true, priority = 6, testName = "SingleProductDetails With InValid skuCode",
			description = "Checking whether the sku is eligible is available for Invalid skuCode")
	public void InValidSkuCode() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=sfs2312&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1002", "Invalid value passed for skucode.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=sfs2312&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling"}, enabled = true, priority = 6, testName = "SingleProductDetails With outofstock skuCode",
			description = "Checking whether the sku is eligible is available for outofstock skuCode")
	public void SkuOutofStock() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=78904275&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2001", "SKU (78904275) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=78904275&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling"}, enabled = true, priority = 6, testName = "SingleProductDetails With Nonnumeric skuCode",
			description = "Checking whether the sku is eligible is available for nonmumeric skuCode")
	public void NonNumericSkuCode() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=sdffsd&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1002", "Invalid value passed for skucode.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=sdffsd&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "SmartSuppressedPricing-NAP126" }, enabled = true, priority = 12, testName = " GetProductDetailsbywebID SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsBywebID() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+ testData.get("WEBID_SMARTSUPPRESSED");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
	 	//
    	
    	 }

	@Test(groups = { "SmartSuppressedPricing-NAP126" }, enabled = true, priority = 12, testName = " GetProductDetailsbySkuCode SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by Skucode \n Feature - smartSuppressedPricing")
	public void GetProductDetailsBySkuCode() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SMARTSUPPRESSED_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
	 	
    	 	}

	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbyUPC SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by UPC Id \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByUPC() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER +  testData.get("SMARTSUPPRESSED_UPC");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
	 	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126","regression","smokeTest"}, enabled = true, priority = 12, testName = " GetProductDetailsbywebIDWithSkuDetailEqualToTrue SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByWebIDWithSkudetailEqualToTrue() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+ testData.get("WEBID_SMARTSUPPRESSED")+"?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	
    	
	}
	

	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbySkuCodeWithSkuDetailEqualToTrue SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by Skucode \n Feature - smartSuppressedPricing")
	public void GetProductDetailsBySkuCodeWithSkudetailEqualToTrue() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER +  testData.get("SMARTSUPPRESSED_SKUCODE")+"&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	 
    	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbyUPCWithSkuDetailEqualToTrue SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by UPCId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByUPCWithSkudetailEqualToTrue() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER +testData.get("SMARTSUPPRESSED_UPC")+"&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	  
    	
    	 	}
	
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbywebIDWithSkuDetailANDinvFilter SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByWebIDWithSkudetailAndinvFilter() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+ testData.get("WEBID_SMARTSUPPRESSED")+"?skuDetail=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	  
    	
	}
	
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbySkuCodeWithSkuDetailANDinvFilter SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by Skucode \n Feature - smartSuppressedPricing")
	public void GetProductDetailsBySkucodeWithSkudetailAndinvFilter() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER +  testData.get("SMARTSUPPRESSED_SKUCODE")+"&skuDetail=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	
    	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbyUPCWithSkuDetailANDinvFilter SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByUPCWithSkudetailAndinvFilter() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER +  testData.get("SMARTSUPPRESSED_UPC")+"&skuDetail=true&invFilter=false";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	
    	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbySkuCodeWithSkuDetailANDallSkusTrue SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by skuCode \n Feature - smartSuppressedPricing")
	public void GetProductDetailsBySkucodeWithSkudetailAndAllskusTrue() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER +  testData.get("SMARTSUPPRESSED_SKUCODE")+"&skuDetail=true&allSkus=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	 
    	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbyUPCWithSkuDetailANDallSkusTrue SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by UPCId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByUPCWithSkudetailAndAllskusTrue() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER +  testData.get("SMARTSUPPRESSED_UPC")+"&skuDetail=true&allSkus=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	
    	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbySkuCodeWithSkuDetailANDinvFilterANDallSkus SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by WebId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsBySkucodeWithSkudetailAndinvFilterAndAllskus() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SMARTSUPPRESSED_SKUCODE")+"&skuDetail=true&invFilter=false&allSkus=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	
    	
    	 }
	
	@Test(groups = { "SmartSuppressedPricing-NAP126"}, enabled = true, priority = 12, testName = " GetProductDetailsbyUPCWithSkuDetailANDinvFilterANDallSkus SmartSuppressedPricing",
			description = "\n TC Description -Verify whether User is able to view product by UPCId \n Feature - smartSuppressedPricing")
	public void GetProductDetailsByUPCWithSkudetailAndinvFilterAndAllskus() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER + testData.get("SMARTSUPPRESSED_UPC")+"&skuDetail=true&invFilter=false&allSkus=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	validateSmartSuppressedPricing(strResponse);
    	validateSmartSuppressedPricingAtSkuLevel(strResponse);
    	
    	 }
	
	
	//added for SmartSuppressedPricing NAP-126
		public void validateSmartSuppressedPricing(String response){
			String suppressed=Utilities.getJsonNodeValue(response, "$.payload.products[0].price.isSuppressed").toString();
			String promotion=Utilities.getJsonNodeValue(response, "$.payload.products[0].price.promotion");
			String clearanceprice=Utilities.getJsonNodeValue(response,"$.payload.products[0].price.clearancePrice");
   	        String saleprice=Utilities.getJsonNodeValue(response,"$.payload.products[0].price.salePrice");
   	 	if(clearanceprice.equals("null")&&promotion.equals("null")&&saleprice.equals("null"))
		{
			validator.nodeMatches("$.payload.products[0].price.isSuppressed","false|null","isSuppressed should be false");
		}
   	 	else if(suppressed.equals("true"))
   	 	{
   	      validator.nodeEquals("$.payload.products[0].price.suppressedPricingText","FOR PRICE, ADD TO BAG","isSuppressed text should be present");
		}
		}
		public void validateSmartSuppressedPricingAtSkuLevel(String response){
			Object	document;
	    	document = Configuration.defaultConfiguration().jsonProvider().parse(response);
	    	 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
	    	 int count = SKUS.size();
	    	 for (int i = 0; i < count-1; i++){  
	    		 String suppressedSkuLevel= Utilities.getJsonNodeValue(response,"$.payload.products[0].SKUS[" + i + "].price.isSuppressed").toString();
	    		 String promotion=Utilities.getJsonNodeValue(response, "$.payload.products[0].SKUS[" + i + "].price.promotion");
	 			 String clearanceprice=Utilities.getJsonNodeValue(response,"$.payload.products[0].SKUS[" + i + "].price..clearancePrice");
	    	     String saleprice=Utilities.getJsonNodeValue(response,"$.payload.products[0].SKUS[" + i + "].price.salePrice");
	    	 	if(clearanceprice.equals("null")&&promotion.equals("null")&&saleprice.equals("null"))
	    	 	{
	    			validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].price.isSuppressed","false|null","isSuppressed should be false");
	    		}
	    	 	else if(suppressedSkuLevel.equals("true"))
	    	 	{
	       	      validator.nodeEquals("$.payload.products[0].SKUS[" + i + "].price.suppressedPricingText","FOR PRICE, ADD TO BAG","isSuppressed text should be present");
	    		}
	    	 	
	    	 }}	    		
   	
		
}
