package test.java.adapters.products.bopus;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BOPUS")
@Stories({ "Single Product Details" })
public class SingleProductDetails {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "Verify isBopusEligible is true when sku is not clr, online &GWP/PWP product")
	public void ProductByWebId_Bopus() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_BOPUS") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].isBopusEligible", "true", "isBopusEligible should be true in product level in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_BOPUS") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySKUId_Bopus",
			description = "To Verify whether the User able to retrieve the boolean flag isBopusEligible tag as false for the given clearence sku in the product API response")
	public void BySkuId_ClearanceSku() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_CLEARANCE") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].price.salePriceStatus", ".+", "validating salePriceStatus should be clearance");
		validator.nodeMatches("$.payload.products[0].price.clearancePrice", ".+", "validating clearance price ");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_CLEARANCE") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "To Verify whether the User able to retrieve the boolean flag isBopusEligible tag as false for the given GWP/PWP sku in the product API response")
	public void BySkuId_GWP_PWP() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("GWP_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].productOffers[0].groupType", "GWP", "validating groupType should be GWP");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("GWP_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "To Verify whether the User able to retrieve the boolean flag isBopusEligible tag as true for all the sku's in the given webID which is not clearence, online only, store only & GWP/PWP in the product API response")
	public void BySkuId_BOGO() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("BOGO_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.promotion", "BUY 1 GET" + ".+", "validating promotion for bogo");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("BOGO_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "To Verify whether the User able to retrieve the boolean flag isBopusEligible tag as false for the given GWP/PWP sku in the product API response")
	public void ByWebId_NOT_CLR_GWP_ONLINE() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("BOPUS1_WEBID") + "?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].isBopusEligible", "true", "isBopusEligible should be true in product level in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("BOPUS1_WEBID") + "?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "To Verify whether the User able to retrieve the boolean flag isBopusEligible tag as false for all the sku's in the given webID which is  clearence in the product API response")
	public void ByWebId_CLEARANCE() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("CLEARANCE_WBID") + "?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].price.salePriceStatus", "clearance", "validating salePriceStatus should be clearance");
		validator.nodeMatches("$.payload.products[0].price.clearancePrice", ".+", "validating clearance price ");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("CLEARANCE_WBID") + "?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "To Verify whether the User able to retrieve the boolean flag isBopusEligible tag as false for all the sku's in the given webID which is  GWP/PWP in the product API response")
	public void ByWebId_GWP() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("GWP_WEBID") + "?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].productOffers[0].groupType", "GWP", "validating groupType should be GWP");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("GWP_WEBID") + "?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is true for KohlsCare sku")
	public void BySkuId_KohlsCare() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("KOHLS_CARE_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].brand", "Kohl's Cares", "validating brand is kohlsCare ");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("KOHLS_CARE_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is true for given GiftCard sku")
	public void BySkuId_GiftCard() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("GIFT_CARD_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].metaInfo[0].metaKeywords", ".+" + "Gift Card" + ".+", "validating giftCard product");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("GIFT_CARD_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is true for suppressed sku")
	public void BySkuId_Suppressed() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SUPPRESSED_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.products[0].price.isSuppressed", "true", "validating isSuppressed as true");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SUPPRESSED_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is false for sku which is KohlsCare+CLR")
	public void BySkuId_KohlsCareAndCLR() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("KOHLS_CARE_CLR_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isBopusEligibleFalseForSku("isBopusEligible should be true in product level in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("KOHLS_CARE_CLR_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "Verify isBopusEligible is true at product level if atleast one sku is eligible for bopus")
	public void ByWebId_BOPUS() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("BOPUS_WEBID") + "?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].isBopusEligible", "true", "isBopusEligible should be true in product level in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("BOPUS_WEBID") + "?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is true for given sku which is not clr, online only, storeonly & GWP/PWP")
	public void BySkuId_BOPUS() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_BOPUS") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].isBopusEligible", "true", "isBopusEligible should be true in product level in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_BOPUS") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is false given clearance sku in sku level")
	public void BySkuId_CLR() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_CLEARANCE") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].isBopusEligible", "false", "isBopusEligible should be false in product level in the response");
		validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", "validating salePriceStatus should be clearance");
		validator.nodeMatches("$.payload.products[0].price.clearancePrice", ".+", "validating clearance price ");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_CLEARANCE") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is false for online only sku in sku level")
	public void BySkuId_Online_Only() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("ONLINE_ONLY_SKU") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].isBopusEligible", "false", "isBopusEligible should be false in product level in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("ONLINE_ONLY_SKU") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 6, testName = "ProductByWebId_Bopus",
			description = "To Verify whether the Error message is getting displayed with the invalid webId.")
	public void ByWebId_InvalidWebID() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/gsdgdfg?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2000", "Web ID (gsdgdfg) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/gsdgdfg?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "To Verify whether the Error message is getting displayed with the invalid parameter.")
	public void BySkuId_InvalidParameterSku() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("ONLINE_ONLY_SKU") + "&sku=92427493&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1001", "sku is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("ONLINE_ONLY_SKU") + "&sku=92427493&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is false for online only sku in sku level")
	public void BySkuId_SkuNotFound() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + "00000000&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		// validator.nodeEquals("$.payload.products[0].isBopusEligible", "false", "isBopusEligible should be false in product level in the response");
		validator.validateExpectedErrors("PROD2001", "SKU (00000000) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + "00000000&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 6, testName = "ProductBySkuId_Bopus",
			description = "Verify isBopusEligible is false for online only sku in sku level")
	public void BySkuId_UPCNotFound() {

		String strURL = PRODUCTS_BY_UPC_ADAPTER + testData.get("UPC_NOT_FOUND") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		// validator.nodeEquals("$.payload.products[0].isBopusEligible", "false", "isBopusEligible should be false in product level in the response");
		validator.validateExpectedErrors("PROD2002", "UPC (000000000) not found.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_UPC_OAPI + testData.get("UPC_NOT_FOUND") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}
}