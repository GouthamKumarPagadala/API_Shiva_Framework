package test.java.adapters.products.hazmat;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("HAZMAT")
@Stories({ "Single Product Details" })
public class SingleProductDetails {

	ResponseValidator validator;


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductBySKU_HAZMAT_DISPOSAL",
			description = "Check whether the HTML Content Is Being Displayed")
	public void BySKU_HAZMAT_DISPOSAL() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_HAZMAT_DISPOSAL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Disposal.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_HAZMAT_DISPOSAL");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductBySKU_HAZMAT_DOCUMENTATION",
			description = "Check whether the HTML Content Is Being Displayed")
	public void BySKU_DOCUMENTATION() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_HAZMAT_Documentation");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Documentation.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_HAZMAT_Documentation");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductBySKU_HAZMAT_NO_AIR_REQUIRMENTS",
			description = "Check whether the HTML Content Is Being Displayed")
	public void BySKU_NO_AIR_REQUIRMENTS() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_HAZMAT_NO_AIR_REQUIRMENTS");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to No Air Requirements.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_HAZMAT_NO_AIR_REQUIRMENTS");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductBySKU_HAZMAT_SPECIAL_TREATMENT",
			description = "Check whether the HTML Content Is Being Displayed")
	public void BySKU_SPECIAL_TREATMENT() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_HAZMAT_SPECIAL_TREATMENTS");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Special Treatment.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_HAZMAT_SPECIAL_TREATMENTS");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductByWEBID_HAZMAT_SPECIAL_TREATMENT",
			description = "Check whether the HTML Content Is Being Displayed")
	public void ByWEBID_SPECIAL_TREATMENT() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEBID_HAZMAT_SPECIAL_TREATMENT");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Special Treatment.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEBID_HAZMAT_SPECIAL_TREATMENT");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductByWEBID_HAZMAT_DISPOSAL",
			description = "Check whether the HTML Content Is Being Displayed")
	public void ByWEBID_DISPOSAL() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEBID_HAZMAT_DISPOSAL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Disposal.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEBID_HAZMAT_DISPOSAL");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductByWEBID_HAZMAT_NO_AIR_REQUIRMENTS",
			description = "Check whether the HTML Content Is Being Displayed")
	public void ByWEBID_HAZMAT_NO_AIR_REQUIRMENTS() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEBID_HAZMAT_NO_AIR_REQUIRMENTS");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to No Air Requirements.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEBID_HAZMAT_NO_AIR_REQUIRMENTS");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductByWEBID_HAZMAT_Documentation",
			description = "Check whether the HTML Content Is Being Displayed")
	public void ByWEBID_HAZMAT_Documentation() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEBID_HAZMAT_DOCUMENTATION");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Documentation.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEBID_HAZMAT_DOCUMENTATION");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "hazmat", "regression","functional" }, enabled = true, priority = 6, testName = "ProductByWEBID_HAZMAT_Disposal",
			description = "Check whether the HTML Content Is Being Displayed")
	public void ByWEBID_HAZMAT_DISPOSAL() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEBID_HAZMAT_DISPOSAL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Disposal.*", "Hazmat HTML content should be present");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEBID_HAZMAT_DISPOSAL");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}

}
