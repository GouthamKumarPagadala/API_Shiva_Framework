package test.java.adapters.products.instore;

public class Dimensions {

}
