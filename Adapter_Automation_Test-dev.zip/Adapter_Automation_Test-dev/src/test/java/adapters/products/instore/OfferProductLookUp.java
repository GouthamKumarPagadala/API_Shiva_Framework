package test.java.adapters.products.instore;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.OFFERCODE_ADAPTER;
import static main.java.common.GlobalVariables.PRODUCTS_BY_SKU_ADAPTER;
import static main.java.common.GlobalVariables.PRODUCTS_BY_SKU_OAPI;
import static main.java.common.GlobalVariables.OFFERCODE_OAPI;
import static main.java.common.GlobalVariables.OFFERID_ADAPTER;
import static main.java.common.GlobalVariables.OFFERID_OAPI;
import static main.java.common.GlobalVariables.OFFERTYPE_ADAPTER;
import static main.java.common.GlobalVariables.OFFERTYPE_OAPI;
import static main.java.common.GlobalVariables.OFFER_LOOKUP_PRODUCT_ADAPTER;
import static main.java.common.GlobalVariables.OFFER_LOOKUP_PRODUCT_OAPI;
import static main.java.common.GlobalVariables.OFFER_PRODUCTID_ADAPTER;
import static main.java.common.GlobalVariables.INVALID_OFFER_PRODUCTID_ADAPTER;
import static main.java.common.GlobalVariables.INVALID_OFFER_PRODUCTID_OAPI;
import static main.java.common.GlobalVariables.OFFER_PRODUCTID_OAPI;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Instore")
@Stories({ "OfferProductLookup" })

public class OfferProductLookUp {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = " WebID with BOGO offer id displays BOGO offer id ",
			description = "Checking the BOGO Offer Details By using WebId")
	public void OfferIdwithBOGOId() {

		String strURL = OFFER_LOOKUP_PRODUCT_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeEquals("$.payload.products[0].webID", testData.get("AVAILABLE_ONLINE_BOGO_WEBID"), "Given productId should be present in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", ".+", "Bogo Promotion should be available in store in the response");

		// validator.nodeMatches("$.payload.products[0].offerPrice.min",".+", "productOffers endDateTime should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].id",".+", "productOffers id should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].message",".+", "productOffers message should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].begDateTime",".+", "productOffers begDateTime should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].endDateTime",".+", "productOffers endDateTime should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_LOOKUP_PRODUCT_OAPI + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = " WebID with Rebate offers displays ",
			description = "Checking the Rebate Offer Details By using WebId")
	public void RebatePricingPromotion() {

		String strURL = OFFER_LOOKUP_PRODUCT_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// $.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum
		validator.nodeEquals("$.payload.products[0].webID", testData.get("AVAILABLE_ONLINE_REBATES_WEBID"), "Given Rebate wbid should be present in the response");
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload.products[0].rebate.shortDescription", ".+", "Rebate should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].message",".+", "productOffers message should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].begDateTime",".+", "productOffers begDateTime should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].endDateTime",".+", "productOffers endDateTime should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_LOOKUP_PRODUCT_OAPI + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = " WebID with Regular  ",
			description = "Checking the Regular Price Details By using WebId")
	public void GettingRegularPrice() {

		String strURL = OFFER_LOOKUP_PRODUCT_ADAPTER + "/" + testData.get("INS3_TC2_REBATE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		validator.nodeEquals("$.payload.products[0].webID", testData.get("INS3_TC2_REBATE_WEBID"), "Given Rebate wbid should be present in the response");
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPriceType", ".+", "Regular Price type should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_LOOKUP_PRODUCT_OAPI + "/" + testData.get("INS3_TC2_REBATE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = " WebID with Tiered price  ",
			description = "Checking the Tiered Price Details By using WebId")
	public void GettingTieredPring() {

		String strURL = OFFER_LOOKUP_PRODUCT_ADAPTER + "/" + testData.get("INS3_TC4_TIERED_WEDID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// $.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum
		validator.nodeEquals("$.payload.products[0].webID", testData.get("INS3_TC4_TIERED_WEDID"), "Given Rebate wbid should be present in the response");
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPriceType", ".+", "Regular Price type should be available in store in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo.stores..price..promtion", ".+", "promotion should be present in the response");
		//validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", "BUY.+", "tiered Promotion should be available in store in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_LOOKUP_PRODUCT_OAPI + "/" + testData.get("INS3_TC4_TIERED_WEDID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 11, testName = "Offers By OfferCode",
			description = "Checking the Offer Details By using OfferCode")
	public void OfferByOfferCode() {

		String strURL = OFFERCODE_ADAPTER + testData.get("OFFER_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.offers[0].code", testData.get("OFFER_CODE"), "Given OfferCode should be present in the response");
		// validator.nodeMatches("$.payload.offers[0].id", "[0-9]+", "OfferID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+", "offerEffectiveDate of begDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+", "offerEffectiveDate of endDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].channels[0].value", ".+", "Channels should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			 String strURLOAPI=OFFERCODE_OAPI + testData.get("OFFER_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "Offers By ProductId",
			description = "Checking the Offer Details By using ProductId")
	public void OfferByProductId() {

		String strURL = OFFER_PRODUCTID_ADAPTER + testData.get("OFFER_PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].id", testData.get("OFFER_PRODUCT_ID"), "Given productId should be present in the response");
//		validator.nodeMatches("$.payload.products[0].offerPrice.min", ".+", "productOffers endDateTime should be present in the response");
		validator.nodeMatches("$.payload.products[0].productOffers[0].id", ".+", "productOffers id should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].message", ".+", "productOffers message should be present in the response");
		validator.nodeMatches("$.payload.products[0].productOffers[0].begDateTime", ".+", "productOffers begDateTime should be present in the response");
		validator.nodeMatches("$.payload.products[0].productOffers[0].endDateTime", ".+", "productOffers endDateTime should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + testData.get("OFFER_PRODUCT_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku which is eligible is available for instore")
	public void InStoreSingleProductDetailsUsingSkuIdWithBogoPromotion() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku which is eligible is available for instore")
	public void offerwithRebateSKUId() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload.products[0].rebate.shortDescription", ".+", "Rebate should be present in the response");
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		// validator.nodeMatches("$.payload.products[0].rebate.shortDescription", ".+", " rebate shortDescription should be available in store in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku which is eligible is available for instore")
	public void GettingRegularPriceUsingSKUId() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("SKU_CLEARANCE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", ".+", "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("SKU_CLEARANCE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku which is eligible is available for Tiered Promotion")
	public void GettingTieredPromotionUsingSKUId() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("TIERED_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo.stores..price..promtion", ".+", "promotion should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("TIERED_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 11, testName = "Sharable is false using OfferCode",
			description = "Checking the Sharable = false Details By using OfferCode")
	public void SHARABLEFALSEOfferCode() {

		String strURL = OFFERCODE_ADAPTER + testData.get("NON_SHARABLE_OFFERCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.offers[0].code", testData.get("NON_SHARABLE_OFFERCODE"), "Given OfferCode should be present in the response");
		// validator.nodeMatches("$.payload.offers[0].id", "[0-9]+", "OfferID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+", "offerEffectiveDate of begDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+", "offerEffectiveDate of endDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].channels[0].value", ".+", "Channels should be present in the response");
		validator.nodeEquals("$.payload.offers.[0].shareable", "false", "sharable set should be false in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERCODE_OAPI + testData.get("NON_SHARABLE_OFFERCODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 11, testName = "Sharable is true using OfferCode",
			description = "Checking the Sharable = true Details By using OfferCode")
	public void SHARABLETRUEOfferCode() {

		String strURL = OFFERCODE_ADAPTER + testData.get("SHAREABLE_OFFER_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.offers[0].code", testData.get("SHAREABLE_OFFER_CODE"), "Given OfferCode should be present in the response");
		// validator.nodeMatches("$.payload.offers[0].id", "[0-9]+", "OfferID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+", "offerEffectiveDate of begDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+", "offerEffectiveDate of endDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].channels[*].value", ".*store.*", "Channel value=Store should be present in the response");
		validator.nodeEquals("$.payload.offers.[0].shareable", "true", "sharable should be true in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERCODE_OAPI + testData.get("SHAREABLE_OFFER_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 11, testName = "verify Offer code and Offerid using offer type",
			description = "Checking the Offer  details By using OfferTypeTLD")
	public void VerifyOfferIdOfferCodeusingOfferTypeTLD() {

		String strURL = OFFERTYPE_ADAPTER + testData.get("OFFERTYPE_TLD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isStoreTrue();
		validator.nodeMatches("$.payload.offers[*].code", ".+", " OfferCode should be present in the response");
		validator.nodeMatches("$.payload.offers[1].id", "[0-9]+", "OfferID should be present in the response");
		validator.nodeMatches("$.payload.offers[1].offerEffectiveDate.begDate", ".+", "offerEffectiveDate of begDate should be present in the response");
		validator.nodeMatches("$.payload.offers[1].offerEffectiveDate.endDate", ".+", "offerEffectiveDate of endDate should be present in the response");
		validator.nodeMatches("$.payload.offers[1].channels[0].value", ".+", "Channels should be present in the response");
		validator.nodeMatches("$.payload..offers..shareable", ".+", "sharable set should be present in the response");
		validator.nodeMatches("$.payload.offers[1].channels[*].value", ".*store.*", "Channel value=Store should be present in the response");
		validator.nodeMatches("$.payload.offers[1].tenderTypes[*].value", ".*AMEX.*", "tenderTypes value=AMEX should be present in the response");
		validator.nodeMatches("$.payload.offers[1].tenderTypes[*].value", ".*MC.*", "tenderTypes value=MC should be present in the response");
		validator.nodeMatches("$.payload.offers[1].tenderTypes[*].value", ".*VISA.*", "tenderTypes value=VISA should be present in the response");
		validator.nodeMatches("$.payload.offers[1].tenderTypes[*].value", ".*DISC.*", "tenderTypes value=DISC should be present in the response");
		validator.nodeMatches("$.payload.offers[1].tenderTypes[*].value", ".*KOHLS.*", "tenderTypes value=KOHLS should be present in the response");
		validator.nodeMatches("$.payload.offers[1].corpOfferIDs[0].value", ".+", "CorpOfferIDs should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERTYPE_OAPI + testData.get("OFFERTYPE_TLD");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 11, testName = "verify Offer details using offer id",
			description = "Checking the Offer  details By using OfferID")
	public void VerifyOfferDetailsusingOfferID() {

		String strURL = OFFERID_ADAPTER + testData.get("OFFER_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isStoreTrue();
		validator.nodeMatches("$.payload..code", ".+", " OfferCode should be present in the response");
		validator.nodeMatches("$.payload.offers[0].id", "[0-9]+", "OfferID should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+", "offerEffectiveDate of begDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+", "offerEffectiveDate of endDate should be present in the response");
		validator.nodeMatches("$.payload.offers[0].channels[*].value", ".*store.*", "Channels should be present in the response");
		validator.nodeMatches("$.payload..offers..shareable", ".+", "sharable set should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + testData.get("OFFER_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the Hazardous flag returning true in the response")
	public void IsHazardousFlagisTRUE() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEBID_HAZARDOUS") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].isHazardous", "true", "isHazardous value should be true in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEBID_HAZARDOUS") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "Verifyig the shipping and return in the response",
			description = "Checking Shipping and return is returning in the response")
	public void VerifyingShippingandReturn() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("SKU_WITH_SHORT_LONG_DESC") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload..products..code", ".+", "code should be available store in the response");
		validator.nodeMatches("$.payload.products[0].shippingAndReturn", "(?s).*Our hassle-free return policy means.*", "shippingAndReturn should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].description.shortDescription", ".+", "description should be present in the response");
		validator.nodeMatches("$.payload.products[0].description.longDescription", "(?s).+", "description should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].channels[0].value", "store", "Channel value=Store should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].tenderTypes", ".+", "tenderTypes should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].corpOfferIDs[0].value", ".+", "CorpOfferIDs should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].offerType", "LID-GWP", "OfferType should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].offerEffectiveDate.begDate", ".+", "Offer begdate should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].offerEffectiveDate.endDate", ".+", "Offer enddate should be present in the response");
//		validator.nodeMatches("$.payload.products[0].productOffers[0].groupType", "GWP", "GroupType should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("SKU_WITH_SHORT_LONG_DESC") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "Verifyig the shipping and return in the response",
			description = "Checking the sharable as true using Product Offers")
	public void SharableasTrueUsingProductOffers() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("SHARABLE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].productOffers[0].sharable", "true", "sharable should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("SHARABLE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "Verifyig the shipping and return in the response",
			description = "Checking the Restricted as true using Product Offers")
	public void RestrictedasTrueUsingProductOffers() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RESTRICTED_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].productOffers[0].restricted", "true", "Restricted should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("RESTRICTED_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "Verifyig the shipping and return in the response",
			description = "Checking Group type as PWP and Offer type as LIDPWP")
	public void VeryingGroupTypeAsPWPAndOfferTypeAsLID_PWP() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("PWP_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		// LID offers with GWP/PWP is out of scope for instore
		validator.nodeNotEquals("$.payload.products[0].productOffers", "LID-PWP", "OfferType should not  be present in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers", "PWP", "GroupType should not be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("PWP_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1000WithoutanyRequiredParameter",
			description = "Veryfing whether error code1000-1 is returning in the response")
	public void OFFER1000WithoutanyRequiredParameter() {

		String strURL = OFFERCODE_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1000-1", "One of offerId or offerCode is required.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERCODE_OAPI;

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1000_8WithoutProductid",
			description = "Veryfing whether error code1000-8 is returning in the response")
	public void OFFER1000_8WithoutProductid() {

		String strURL = OFFER_PRODUCTID_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1000-8", "Missing Required Parameter productId.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI;

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1002-8withInvalidProduct",
			description = "Veryfing whether error code1002-8 is returning in the response")
	public void OFFER1002_8withInvalidProductID() {

		String strURL = OFFER_PRODUCTID_ADAPTER + "hggjh";
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1002-8", "Invalid value passed for productId.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + "hggjh";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1002-1withInvalid offerId",
			description = "Veryfing whether error code1002-1 is returning in the response")
	public void OFFER1002_1withInvalidOfferID() {

		String strURL = OFFERID_ADAPTER + "hggjh";
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1002-1", "Invalid value passed for offerId.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + "hggjh";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER3000-1withInvalid offerId",
			description = "Veryfing whether error code3000-1 is returning in the response")
	public void OFFER3000_1withOfferIDprovidedInvalid() {

		String strURL = OFFERID_ADAPTER + "54764";
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER3000-1", "The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + "54764";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER2000_4withProductNotFound",
			description = "Veryfing whether error code2000-4 is returning in the response")
	public void OFFER2000_4withProductNotFound() {

		String strURL = OFFER_PRODUCTID_ADAPTER + "1234567";
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER2000-4", "ProductID Not Found.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + "1234567";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER2000_6ProductwithNoOffers",
			description = "Veryfing whether error code2000-6 is returning in the response")
	public void OFFER2000_6ProductwithNoOffers() {

		String strURL = OFFER_PRODUCTID_ADAPTER + testData.get("WEB_ID_OUT_OF_OFFER");
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER2000-6", "No Offers found for product");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + testData.get("WEB_ID_OUT_OF_STOCK");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER3000_2InvalidOfferCode",
			description = "Veryfing whether error code3000-1 is returning in the response")
	public void OFFER3000_1InvalidOfferCode() {

		String strURL = OFFERCODE_ADAPTER + "dsfgs";
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER3000-1", "The Promo Code you entered doesn't exist. Please double-check the offer and re-enter the Code.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERCODE_OAPI + "dsfgs";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1002_2InvalidValueforChannels",
			description = "Veryfing whether error code1002-2 is returning in the response")
	public void OFFER1002_2InvalidValueforChannels() {

		String strURL = INVALID_OFFER_PRODUCTID_ADAPTER + "?offerProducts=true&channel=bhde";
		// testData.get("INS3_BOGO_WEBID")+"?offerProducts=true&channel="bhde");
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1002-2", "Invalid value passed for channel.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = INVALID_OFFER_PRODUCTID_OAPI + "?offerProducts=true&channel=bhde";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1000_8MissingRequiredParameterPRODUCTID",
			description = "Veryfing whether error code1000-8 is returning in the response")
	public void OFFER1000_8MissingRequiredParameterPRODUCTID() {

		String strURL = INVALID_OFFER_PRODUCTID_ADAPTER + "?offerProducts=true";
		// testData.get("INS3_BOGO_WEBID")+"?offerProducts=true&channel="bhde");
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1000-8", "Missing Required Parameter productId.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = INVALID_OFFER_PRODUCTID_OAPI + "?offerProducts=true";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 11, testName = "OFFER1001ProductsNotaValidParameter",
			description = "Veryfing whether error code1001 is returning in the response")
	public void OFFER1001ProductsNotaValidParameter() {

		String strURL = INVALID_OFFER_PRODUCTID_ADAPTER + "?offerProducts=true&products=bhde";
		// testData.get("INS3_BOGO_WEBID")+"?offerProducts=true&channel="bhde");
		// "?skuCode="+testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE")+"&skuDetail=true&storeNum="+testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("OFFER1001", "products is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = INVALID_OFFER_PRODUCTID_OAPI + "?offerProducts=true&products=bhde";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "offerunification" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku which is eligible is available for instore")
	public void Offer_Unification_SKU() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers[0].offerEffectiveDate.begDate", "null", "Offer BEGDATE should not be null in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers[0].offerEffectiveDate.endDate", "null", "Offer ENDDATE should not be null in the response");
		
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}

	@Test(groups = { "offerunification" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID for instore")
	public void Offer_Unification_UPC() {

		TestData.getRunTimeData("INSTORE_WEB_ID", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers[0].offerEffectiveDate.begDate", "null", "Offer BEGDATE should not be null in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers[0].offerEffectiveDate.endDate", "null", "Offer ENDDATE should not be null in the response");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}

	@Test(groups = { "offerunification"}, enabled = true, priority = 12, testName = " WebID with BOGO offer id displays BOGO offer id ",
			description = "Checking the BOGO Offer Details By using WebId")
	public void Offer_Unification_WEBID() {

		String strURL = OFFER_LOOKUP_PRODUCT_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeEquals("$.payload.products[0].webID", testData.get("AVAILABLE_ONLINE_BOGO_WEBID"), "Given productId should be present in the response");
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", "BUY 1 GET 1 FREE", "Bogo Promotion should be available in store in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers[0].offerEffectiveDate.begDate", "null", "Offer BEGDATE should not be null in the response");
		validator.nodeNotEquals("$.payload.products[0].productOffers[0].offerEffectiveDate.endDate", "null", "Offer ENDDATE should not be null in the response");
		
		// validator.nodeMatches("$.payload.products[0].offerPrice.min",".+", "productOffers endDateTime should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].id",".+", "productOffers id should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].message",".+", "productOffers message should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].begDateTime",".+", "productOffers begDateTime should be present in the response");
		// validator.nodeMatches("$.payload.products[0].productOffers[0].endDateTime",".+", "productOffers endDateTime should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_LOOKUP_PRODUCT_OAPI + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	
}
