package test.java.adapters.products.instore;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Instore")
@Stories({ "SingleProductDetails" })

public class SingleProductDetails {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku is eligible is available for instore")
	public void WebId() {

		TestData.getRunTimeData("INSTORE_WEB_ID", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("WEB_ID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("WEB_ID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Bogo promotion for instore")
	public void Bogopromotion() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", ".+", "Bogo Promotion should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("RUNTIME_INSTORE_WEB_BOGO"));
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Tiered promotion for instore")
	public void Tieredpromotion() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("INS3_TC4_TIERED_WEDID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		validator.nodeEquals("$.payload.products[0].webID", testData.get("INS3_TC4_TIERED_WEDID"), "Given Rebate wbid should be present in the response");
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", testData.get("INSTORE_STORE_NUMBER"), "Given Instore number should be present in the response");
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPriceType", ".+", "Regular Price type should be available in store in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo.stores..price..promtion", ".+", "promotion should be present in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", "BUY.+", "tiered Promotion should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("INS3_TC4_TIERED_WEDID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Rebates promotion for instore")
	public void Rebatespromotion() {

	
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].rebate.shortDescription", ".+", " rebate shortDescription should be available in store in the response");
		// validator.nodeMatches("$.payload.products[0].rebate.longDescription", "<p>.+", " rebate longDescription should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_REBATES_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("RUNTIME_INSTORE_WEB_REBATE"));
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With OutOfStock for instore")
	public void OutOfStock() {

		TestData.getRunTimeData("INSTORE_OUT_OF_STOCK", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_WEBID") + "?skuDetail=true&storeNum=9961";
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeEquals("$.payload.products[0].SKUS[0].storeInfo.stores[0].availability", "Out of Stock", "Store availability should be out of stock");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With OutStore Id for instore")
	public void OutOfStockStoreId() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].storeNum", null, "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Limited Quantity for instore")
	public void LimitedQuantity() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("LIMITEDQUANTITY_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("LIMITEDQUANTITY_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Limited Stock Instore and Online for instore")
	public void LimitedStockInstoreandOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("LIMITEDQUANTITY_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("LIMITEDQUANTITY_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Available Instore and Limited Online for instore")
	public void AvailableInstoreandLimitedOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("LIMITED_ONLINE_AVAILABLE_INSTORE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("LIMITED_ONLINE_AVAILABLE_INSTORE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Limited Instore and Available Online for instore")
	public void LimitedInstoreandAvailableOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + "976483" + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + "976483" + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With OutofStock Instore and Available Online for instore")
	public void OutofStockInstoreandAvailableOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request

		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_WEBID") + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
			System.out.println("WebID:");
			System.out.println(testData.get("AVAILABLE_ONLINE_INSTORE_WEBID1"));
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Bogo Promotion for instore")
	public void SkuIdWithBogoPromotion() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", ".+", "Bogo Promotion should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_BOGO_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId for instore")

	public void SkuId() {

		TestData.getRunTimeData("INSTORE_SKU_CODE", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Tiered Promotion for instore")
	public void SkuIdWithTieredPromotion() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_TIERED_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", "BUY.+", "tiered Promotion should be available in store in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_TIERED_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Rebates Promotion for instore")
	public void SkuIdWithRebatesPromotion() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].rebate.shortDescription", ".+", " rebate shortDescription should be available in store in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With OutofStock for instore")
	public void SkuIdWithOutofStock() {

		TestData.getRunTimeData("INSTORE_OUT_OF_STOCK", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Limited Quantity for instore")
	public void SkuIdWithLimitedQuantity() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("LIMITEDQUANTITY_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("LIMITEDQUANTITY_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Limited Stock Instore and Online for instore")
	public void SkuIdWithLimitedStockInstoreandOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("LIMITEDQUANTITY_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("LIMITEDQUANTITY_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Available Instore and LimitedOnline for instore")
	public void SkuIdWithAvailableInstoreandLimitedOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("LIMITED_ONLINE_AVAILABLE_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("LIMITED_ONLINE_AVAILABLE_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With Limited Instore and Available Online for instore")
	public void SkuIdWithLimitedInstoreandAvailableOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using SkuId With OutofStock Instore and Available Online for instore")
	public void SkuIdWithOutofStockInstoreandAvailableOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_SKUCODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Without SkuId for instore")
	public void outSkuId() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000", "Missing Required Parameter 'Web ID, SKU CODE, UPC'.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using Invalid SkuId for instore")
	public void InvalidSkuId() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + "931jghdcvhdsvjds" + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1002", "Invalid value passed for skucode.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + "931jghdcvhdsvjds" + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore", "errorhandling" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details With Invalid WebID for instore")
	public void InvalidWebID() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + "000000" + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2000", "Web ID (000000) not found.");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + "000000" + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID for instore")
	public void UPC_ID() {

		TestData.getRunTimeData("INSTORE_WEB_ID", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID with Bogo Promotion for instore")
	public void UPC_IDwithBogoPromotion() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_BOGO_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", ".+", "Bogo Promotion should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_BOGO_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID with Tiered Promotion for instore")
	public void UPC_IDwithTieredPromotion() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_TIERED_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", "BUY.+", "tiered Promotion should be available in store in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_TIERED_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID with Rebates promotion for instore")
	public void UPCIDwithRebatespromotion() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_REBATES_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].rebate.shortDescription", ".+", " rebate shortDescription should be available in store in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_REBATES_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID with OutofStock for instore")
	public void UPCIDwithOutofStock() {

		TestData.getRunTimeData("INSTORE_OUT_OF_STOCK", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID with Limited Quantity for instore")
	public void UPC_IDwithLimitedQuantity() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("LIMITEDQUANTITY_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("LIMITEDQUANTITY_UPCID");
			;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProduct Details Using UPCID with Limited Stock Instore and Online")
	public void UPC_IDwithLimitedStockInstoreandOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("LIMITEDQUANTITY_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("LIMITEDQUANTITY_UPCID");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProductDetails Using UPCID with Available Instore and Limited Online")
	public void UPC_IDwithAvailableInstoreandLimitedOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("LIMITED_ONLINE_AVAILABLE_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("LIMITED_ONLINE_AVAILABLE_INSTORE_UPCID");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProductDetails Using UPCID with Limited Instore and Available Online")
	public void UPC_IDwithLimitedInstoreandAvailableOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_LIMITED_INSTORE_UPCID");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "instore" }, enabled = false, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking SingleProductDetails Using UPCID with OutofStock Instore and Available Online")
	public void UPC_IDwithOutofStockInstoreandAvailableOnline() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload..products..SKUS..price..regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload..products..SKUS..storeInfo..stores..price..regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&upc=" + testData.get("AVAILABLE_ONLINE_OUTOFSTOCK_INSTORE_UPCID");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}
}
