package test.java.adapters.products.monetization;

import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("monetization")
@Stories({ "Single Product Details" })
public class SingleProductDetails {

	ResponseValidator validator;
	@DiscontinuedTest(groups = { "monetization","regression" }, enabled = false, priority = 12, testName = "Monetization validation using singleProductDetails using webId",
			description = "Verify whether the monetization objects are returned in product response with webID")
	public void Monetization_WebID() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("MONETIZATION_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("MONETIZATION_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@DiscontinuedTest(groups = { "monetization","regression" }, enabled = false, priority = 12, testName = "singleProductDetails using upcId",
			description = "To verify whether the monetization objects are returned in product response with UPCID")
	public void Monetization_UpcID() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?upc=" + testData.get("MONETIZATION_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?upc=" + testData.get("MONETIZATION_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@DiscontinuedTest(groups = { "monetization","regression" }, enabled = false, priority = 12, testName = "singleProductDetails using skuCode",
			description = "To verify whether the monetization objects are returned in product response with SkuCode")
	public void Monetization_SkuCode() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("MONETIZATION_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("MONETIZATION_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = {"smoke","monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using webId",
			description = "Verify whether the monetization objects brand,ageAppropriateValue,occassion,gender,sportsLeague and sportsTeam are returned in product response with webID")
	public void Monetization_WebID_For_Brand_Occasion_Gender_Sports_AgeValue_Combination() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("BRAND_AGE_OCCA_GENDER_SPORTS_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("BRAND_AGE_OCCA_GENDER_SPORTS_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using webId",
			description = "Verify whether the monetization objects AgeRange,ChildAgeRange and Fit are returned in product response with webID")
	public void Monetization_WebID_For_AgeRange_ChildAgeRange_Fit_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+testData.get("AGERANGE_CHILD_SIZE_FIT_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/"+testData.get("AGERANGE_CHILD_SIZE_FIT_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using webId",
			description = "Verify whether the monetization objects LegOpening,Trend,Feature and Activity are returned in product response with webID")
	public void Monetization_WebID_For_LegOpening_Trend_Feature_Activity_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+testData.get("LEG_TREND_FEATURE_ACTIVITY_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/"+testData.get("LEG_TREND_FEATURE_ACTIVITY_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using webId",
			description = "Verify whether the monetization objects BodyType,PersonalCategory,PersonalSubject and Silhouette are returned in product response with webID")
	public void Monetization_WebID_For_BodyType_PersonalCategory_PersonalSubject_Silhouette_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+testData.get("BODY_PERCATE_PERSUB_SILH_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/"+testData.get("BODY_PERCATE_PERSUB_SILH_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12,testName = "Monetization validation using singleProductDetails using webId",
			description = "Verify whether the monetization objects PersonaTheme,PersonaGroupCode and Silhouette are returned in product response with webID")
	public void Monetization_WebID_For_PersonaTheme_PersonaGroupCode_Silhouette_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/"+testData.get("PERTHE_PERGRP_SILH_WEBID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/"+testData.get("PERTHE_PERGRP_SILH_WEBID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using upcId",
			description = "Verify whether the monetization objects brand,ageAppropriateValue,occassion,gender,sportsLeague and sportsTeam are returned in product response with UPCID")
	public void Monetization_UpcID_For_Brand_Occasion_Gender_Sports_AgeValue_Combination() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?upc=" + testData.get("BRAND_AGE_OCCA_GENDER_SPORTS_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?upc=" + testData.get("BRAND_AGE_OCCA_GENDER_SPORTS_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using upcId",
			description = "Verify whether the monetization objects AgeRange,ChildAgeRange and Fit are returned in product response with upcID")
	public void Monetization_UpcID_For_AgeRange_ChildAgeRange_Fit_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?upc=" +testData.get("AGERANGE_CHILD_SIZE_FIT_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI +  "?upc=" +testData.get("AGERANGE_CHILD_SIZE_FIT_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using upcId",
			description = "Verify whether the monetization objects LegOpening,Trend,Feature and Activity are returned in product response with upcID")
	public void Monetization_UpcID_For_LegOpening_Trend_Feature_Activity_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?upc=" +testData.get("LEG_TREND_FEATURE_ACTIVITY_UPCID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?upc=" +testData.get("LEG_TREND_FEATURE_ACTIVITY_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using upcId",
			description = "Verify whether the monetization objects BodyType,PersonalCategory,PersonalSubject and Silhouette are returned in product response with upcID")
	public void Monetization_UpcID_For_BodyType_PersonalCategory_PersonalSubject_Silhouette_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?upc=" +testData.get("BODY_PERCATE_PERSUB_SILH_UPCID");
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?upc=" +testData.get("BODY_PERCATE_PERSUB_SILH_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using upcId",
			description = "Verify whether the monetization objects PersonaTheme,PersonaGroupCode and Silhouette are returned in product response with upcID")
	public void Monetization_UpcID_For_PersonaTheme_PersonaGroupCode_Silhouette_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER  + "?upc=" +testData.get("PERTHE_PERGRP_SILH_UPCID");
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI  + "?upc=" +testData.get("PERTHE_PERGRP_SILH_UPCID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using skucode",
			description = "Verify whether the monetization objects brand,ageAppropriateValue,occassion,gender,sportsLeague and sportsTeam are returned in product response with skucode")
	public void Monetization_SkuCode_For_Brand_Occasion_Gender_Sports_AgeValue_Combination() {

		
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("BRAND_AGE_OCCA_GENDER_SPORTS_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("BRAND_AGE_OCCA_GENDER_SPORTS_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using skucode",
			description = "Verify whether the monetization objects AgeRange,ChildAgeRange and Fit are returned in product response with upcID")
	public void Monetization_SkuCode_For_AgeRange_ChildAgeRange_Fit_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" +testData.get("AGERANGE_CHILD_SIZE_FIT_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI +  "?skuCode=" +testData.get("AGERANGE_CHILD_SIZE_FIT_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using skucode",
			description = "Verify whether the monetization objects LegOpening,Trend,Feature and Activity are returned in product response with skucode")
	public void Monetization_SkuCode_For_LegOpening_Trend_Feature_Activity_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" +testData.get("LEG_TREND_FEATURE_ACTIVITY_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" +testData.get("LEG_TREND_FEATURE_ACTIVITY_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using skucode",
			description = "Verify whether the monetization objects BodyType,PersonalCategory,PersonalSubject and Silhouette are returned in product response with skucode")
	public void Monetization_Skucode_For_BodyType_PersonalCategory_PersonalSubject_Silhouette_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" +testData.get("BODY_PERCATE_PERSUB_SILH_SKUCODE");
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" +testData.get("BODY_PERCATE_PERSUB_SILH_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "monetization","regression" }, enabled = true, priority = 12, testName = "Monetization validation using singleProductDetails using skucode",
			description = "Verify whether the monetization objects PersonaTheme,PersonaGroupCode and Silhouette are returned in product response with SkuCode")
	public void Monetization_SkuCode_For_PersonaTheme_PersonaGroupCode_Silhouette_Combination() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER  + "?skuCode=" +testData.get("PERTHE_PERGRP_SILH_SKUCODE");
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.validateMonetiaztionValueForProducts();
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI  + "?skuCode=" +testData.get("PERTHE_PERGRP_SILH_SKUCODE");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	}