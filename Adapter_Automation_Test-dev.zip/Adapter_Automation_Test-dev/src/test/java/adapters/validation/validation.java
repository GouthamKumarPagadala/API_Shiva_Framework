package test.java.adapters.validation;


import static main.java.common.GlobalVariables.CompareOAPI;

import static main.java.common.GlobalVariables.VALIDATION_ADAPTER;

import static main.java.common.GlobalVariables.VALIDATION_OAPI;

import static main.java.common.TestData.testData;


import org.testng.annotations.Test;


import main.java.common.PIILogValidation;

import main.java.common.QradarLogValidation;

import main.java.common.RestCall;

import main.java.common.Utilities;

import main.java.common.TestData.Server;

import main.java.json.JsonString;

import main.java.json.ResponseValidator;

import ru.yandex.qatools.allure.annotations.Features;

import ru.yandex.qatools.allure.annotations.Stories;


@Features("Validation")
@Stories({ "Validate Order" })

public class validation {

	
ResponseValidator validator;


	
@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Empty address1")
	public void AddressEmptyAddress1() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("EMPTY_ADDR1")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID1000", "VALID1000 Error code should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].message", "Missing Required Parameter Address Line 1.", "Missing Required Parameter Address Line 1 Error message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "Address Line 1", "Address Line 1 Invalid Element name should be present in the response");

		// Compare Open API
		
	}
	

	@Test(groups= { "VALIDATE","regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with valid Address 1")
    public void AddressValidAddress1()
{
	//Create Request
	String strPayload="{\"payload\": {\"addresses\":[{\"ID\":\"1\","
			+ JsonString.getValidationAddressJson("VALID")
			+ "}]}}";
	
	//Post Request
	String strResponse= RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);
	
	//Validate Response
	validator=new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
	validator.nodeEquals("$.payload.addresses[0].faults","null","faults should be null in the response");

}
	
	@Test(groups= { "VALIDATE","regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with EmptyCity")
    public void AddressEmptyCity()
{
	//Create Request
	String strPayload="{\"payload\": {\"addresses\":[{\"ID\":\"1\","
			+ JsonString.getValidationAddressJson("EMPTY_CITY")
			+ "}]}}";
	
	//Post Request
	String strResponse= RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);
	
	//Validate Response
	validator=new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
	validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID1000", "VALID1000 Error code should be present in the response");
	validator.nodeEquals("$.payload.addresses[0].faults[0].message", "Missing Required Parameter City.", "Missing Required Parameter City Error message should be present in the response");
	validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "City", "City Invalid Element name should be present in the response");

	


}
@Test(groups= { "VALIDATE","regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
description = "Validating with EmptyState")
    public void AddressEmptyState()
{
//Create Request
String strPayload="{\"payload\": {\"addresses\":[{\"ID\":\"1\","
+ JsonString.getValidationAddressJson("EMPTY_STATE")
+ "}]}}";

//Post Request
String strResponse= RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator=new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID1000", "VALID1000 Error code should be present in the response");
validator.nodeEquals("$.payload.addresses[0].faults[0].message", "Missing Required Parameter State.", "Missing Required Parameter State Error message should be present in the response");
validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "State", "State Invalid Element name should be present in the response");




}
@Test(groups= { "VALIDATE","regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
description = "Validating with EmptyPostalCode")
    public void AddressEmptyPostalCode()
{
//Create Request
String strPayload="{\"payload\": {\"addresses\":[{\"ID\":\"1\","
+ JsonString.getValidationAddressJson("EMPTY_POSTALCODE")
+ "}]}}";

//Post Request
String strResponse= RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

//Validate Response
validator=new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID1000", "VALID1000 Error code should be present in the response");
validator.nodeEquals("$.payload.addresses[0].faults[0].message", "Missing Required Parameter Postal Code.", "Missing Required Parameter Postal Code Error message should be present in the response");
validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "Postal Code", "Postal Code Invalid Element name should be present in the response");




}

	@Test(groups = { "VALIDATE","regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Invalid city")
	public void AddressInvalidCity() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("INVALID_CITY")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID9279", "VALID9279 Error code should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].message", "According to our system, the City and ZIP Code combination you've entered has an error. Please enter a valid City and ZIP Code combination.", "According to our system, the City and ZIP Code combination you've entered has an error. Please enter a valid City and ZIP Code combination Error message should be present in the response");
		// validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "Address Line 1", "Address Line 1 Invalid Element name should be present in the response");

		
	}


	@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Invalid state")
	public void AddressInvalidState() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("INVALID_STATE")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID1002", "VALID1002 Error code should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].message", "Invalid value passed for State.", "Invalid value passed for State Error message should be present in the response");
		// validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "Address Line 1", "Address Line 1 Invalid Element name should be present in the response");

		
	}


	@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Invalid postal code")
	public void AddressInvalidPostalCode() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("INVALID_POSTALCODE")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].code", "VALID1002", "VALID1002 Error code should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].message", "Invalid value passed for Postal Code.", "Invalid value passed for Postal Code Error message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].invalidElementName", "Postal Code", "Postal Code Invalid Element name should be present in the response");

		
	}
	
	@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Empty address1")
	public void AddressTwoValid() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "},{\"ID\":\"2\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].ID","2","message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults","null","Faults should be null in the response");
		validator.nodeEquals("$.payload.addresses[1].faults","null","Faults should be null in the response");
		
	}
	
	
	@Test(groups = { "VALIDATE","regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with valid address1 and invalid address2")
	public void AddressValid1Invalid2() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "},{\"ID\":\"2\","
				+ JsonString.getValidationAddressJson("INVALID_STATE")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].ID","2","message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults","null","Faults should be null in the response");
		validator.nodeEquals("$.payload.addresses[1].faults[0].code","VALID1002","Faults code should be  in the response");
		validator.nodeEquals("$.payload.addresses[1].faults[0].message","Invalid value passed for State.","Invalid value passed for State message should be  in the response");
	}
	@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Invalid address1 and valid address2")
	public void AddressInValid1Valid2() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("INVALID_STATE")
				+ "},{\"ID\":\"2\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].ID","2","message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].faults","null","Faults should be null in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].code","VALID1002","Faults code should be  in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].message","Invalid value passed for State.","Invalid value passed for State message should be  in the response");
	}
	
	
	

@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
description = "Validating with Valid address1 and Empty address2")
	public void AddressValid1Empty2() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "},{\"ID\":\"2\","
				+ JsonString.getValidationAddressJson("EMPTY_STATE")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].ID","2","message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults","null","Faults should be null in the response");
		validator.nodeEquals("$.payload.addresses[1].faults[0].code","VALID1000","Faults code should be  in the response");
		validator.nodeEquals("$.payload.addresses[1].faults[0].message","Missing Required Parameter State.","Missing Required Parameter State message should be  in the response");
	}
	@Test(groups = {"VALIDATE", "regression","functional","errorhandling" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with Empty address1 and valid address2")
	public void AddressEmpty1Valid2() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("EMPTY_STATE")
				+ "},{\"ID\":\"2\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].ID","2","message should be present in the response");
		validator.nodeEquals("$.payload.addresses[1].faults","null","Faults should be null in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].code","VALID1000","Faults code should be  in the response");
		validator.nodeEquals("$.payload.addresses[0].faults[0].message","Missing Required Parameter State.","Missing Required Parameter State message should be  in the response");
	}
	@Test(groups = {"AdaptersReqResLog"}, enabled = true, priority = 1, testName = "LOG Validation", 
			description = "Validating Request Response Adapters Log")
	public void LogValidation() throws Exception{
		PIILogValidation log = new PIILogValidation();
		log.main(null);
	}
	
	@Test(groups = {"QradarLog"}, enabled = true, priority = 1, testName = "LOG Validation", 
			description = "Validating Qradar Log")
	public void QradarLogValidation() throws Exception{
		QradarLogValidation log = new QradarLogValidation();
		log.main(null);
	}
}
