package test.java.adapters.smoke;

import org.apache.commons.codec.binary.Base64;
import org.eclipse.jetty.util.log.Log;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;
import test.java.adapters.Config;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map.Entry;

import ru.yandex.qatools.allure.annotations.*;

@Features("Smoke Suite")
@Stories({ "Smoke Tests" })
public class SmokeTest {

	ResponseValidator validator;



	@BeforeMethod
	public void printTestName(Method method) {

		System.out.println("\n*Executing " + this.getClass().getName() + "->" + method.getName());
	}
	@BeforeClass(alwaysRun=true)
	public void testSetup() {
		
		new TestData().createLocationAuth();
		
	}


	@Test(groups = {"NuData","PlaceOrderRegistryItem","Profile_Update","wallet_auth_GR","health_check","smoke","MasterPassCheckout","VisaCheckout","signin_nudata", "smokeTest","smoke_release", "MFPSignal","regression","functional", "vxo", "Bopus", "InstoreFreeShipping", "mfp", "omniture", "loyalty", "wallet_auth", "cvv2", "errorhandling","wallet_hash","masterpass","Nudata_captcha","Remedy","OrderCalcRegistryItem"}, enabled = true, priority = 0, testName = "Create a new Profile",
			description = "Creates a new profile")
	public void createProfile() {

		// Create the Json Request for create profile
		/*
		 * String strPayload = "{\"payload\":{\"profile\":{\"customerName\":" + JsonString.getCustomerNameJson("VALID") + "," + "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\"," + "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID") + "\"}}}";
		 */
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (strGroup.equals("health_check")){
			
			
			validator.validateExpectedErrors("PROF9163", "According to our system, there is already an account for the E-mail Address you entered. Please enter a different E-mail Address (Sign-in name).");
			return;
		}
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			/*
			 * // Create the Json Request for create profile String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":" + JsonString.getCustomerNameJson("VALID") + "," + "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\"," + "\"email\":\"" + testData.get("OAPI_EMAIL_ID") + "\"}}}";
			 */

			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("OAPI_EMAIL_ID") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}



	@Test(groups = { "NuData","PlaceOrderRegistryItem","Profile_Update","health_check","smoke", "smokeTest","smoke_release", "MFPSignal","regression","functional", "vxo","MasterPassCheckout","VisaCheckout", "Bopus", "InstoreFreeShipping", "mfp", "omniture", "loyalty", "wallet_auth","OrderCalcRegistryItem", "cvv2", "errorhandling","masterpass" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "createProfile",
			description = "Sign in the profile")
	@Severity(SeverityLevel.BLOCKER)
	public void signInProfile() {
		mapheader.clear();
		mapheader.put("nuDataChannel","iPhone");
		mapheader.put("nuDataNdpdData","nuDatatobeInserted");
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "time stamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.walletId", ".+", "walletId should be available in response");
		validator.nodeMatches("$.payload.response.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.preferences.saleAlerts", "true", "saleAlerts should be available in response");

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter_smoke");

		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "refresh_token_adapter");

		try {
			Thread.sleep(2000);
		}
		catch (InterruptedException e) {
		}

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_oapi");
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_oapi_smoke");
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "refresh_token_oapi");
		}
	}


	@Test(groups = {"smoke", "smokeTest","smoke_release", "regression","functional","health_check", "errorhandling" },
			enabled = true, priority = 1, testName = "Get Profile", 
			dependsOnMethods = {"UpdateProfileInfo","UpdatePaymentType","UpdateShipAddressPreferred"},
			description = "Get Profile Call")
	public void getProfile() {

		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
		Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		System.out.println("Author Id" + testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.profile.email", ".+", "Profile email should be present");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", ".+", "LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", ".+", "FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.updatePaymentId", ".+", "UpdatePayment ID should be available in response");
		validator.nodeMatches("$.payload.profile.updateShipAddressId", ".+", "UpdateShipAddressID should be available in response");
		validator.nodeMatches("$.payload.profile.loyaltyPostalCode", ".+", "loyaltyPostalCode should be available in response");
		validator.nodeMatches("$.payload.profile.loyaltyId", ".+", "loyaltyId should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+", "saleAlerts should be available in response");

		// Setting the shipping address id
		Utilities.setTestData(strURL, "$.payload.profile.shipAddresses[0].ID", "SHIP_ADDRESS_ID");
		// Compare Open API
		if (CompareOAPI) {

			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true);
			Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
			Utilities.setTestData(strURLOAPI, "$.payload.profile.shipAddresses[0].ID", "SHIP_ADDRESS_ID_OAPI");
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 2, testName = "Update Bill Adress", dependsOnMethods = "signInProfile",
			description = "Updating BillAddress to the Profile")
	public void UpdateBillAddress() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "mfp", "health_check", "errorhandling" }, enabled = true, priority = 5, testName = "Update Profile Info", 
			dependsOnMethods = "signInProfile",
			description = "Update Information of the Profile")
	public void UpdateProfileInfo() {

		// Create the Json Request for Cart
		/*
		 * String strPayload = "{\"payload\":{\"profile\":{\"customerName\":" + JsonString.getCustomerNameJson("UPDATE") + "}}}";
		 */

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("UPDATE")
				+ ",\"preferences\":{\"saleAlerts\":false}}}}";

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
		
		String strPayload1 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("UPDATE")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse1 = RestCall.putRequest(PROFILE_ADAPTER, strPayload1, Server.Adapter, true);
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 2, testName = "Update Shipping Address[Preferred]", 
			dependsOnMethods = "signInProfile",
			description = "Update shipAddress to the Profile with preferredAddress=true")
	public void UpdateShipAddressPreferred() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Id should be available in response");
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


@Test(groups = { "smoke","OrderCalcRegistryItem","PlaceOrderRegistryItem", "smokeTest","smoke_release", "regression","functional", "vxo","VisaCheckout", "InstoreFreeShipping", "mfp","MasterPassCheckout", "cvv2", "health_check", "errorhandling","masterpass","MFPSignal" }, enabled = true, priority = 2, 
		testName = "Update Shipping Address[Non-Preferred]",
			dependsOnMethods = "signInProfile",
			description = "Update shipAddress to the Profile with preferredAddress=false")
	public void UpdateShipAddressNonPreferred() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Set shipping id from response in test data
		Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter");
		Utilities.setTestData(strResponse, "$.payload.id", "shipping_id_adapter_smoke");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", "[0-9]+", "Ship Address ID should be present in the response");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true);
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "shipping_id_oapi");
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "shipping_id_oapi_smoke");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}



	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "errorhandling" }, enabled = true, priority = 2, 
			testName = "Update Payment Type", dependsOnMethods = "signInProfile",
			description = "Updating Payment (i.e.,Credit Card) to the profile")
	public void UpdatePaymentType() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("UPDATE_KCC")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id_delete");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id_delete");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 6, testName = "Inventory By WebId",
			description = "Get Inventory of the Product by WebID")
	public void InventoryByWebId() {

		TestData.getRunTimeData("WEB_ID", false);

		String strURL = INVENTORY_WEBID_ADAPTER + "/" + testData.get("RUNTIME_WEB_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].webID", testData.get("RUNTIME_WEB_ID"), "Given webID should be present in the response");
		validator.nodeMatches("$.payload.products[0].availability", "In Stock", "availability should be present in the response");
		validator.nodeMatches("$.payload.products[0].skus[0].stores[0]", ".+", "Stores should be available in response");
		// validator.nodeMatches("$.payload.products[0].availableStock","[0-9]+", "Stock availability should be present in the response");
		// validator.nodeEquals("$.payload.products[0].availableStock","[0-9]+", "Stock availability should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_WEBID_OAPI + "/" + testData.get("RUNTIME_WEB_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 7, testName = "Inventory By SKU",
			description = "Get Inventory of the Product by SkuID")
	public void InventoryBySku() {

		TestData.getRunTimeData("SKU_CODE", false);

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("RUNTIME_SKU_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.skus[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.skus[0].stores[0].availability", "In Stock", "availability should be present in the response");
		validator.nodeMatches("$.payload.skus[0].stores[0].availableStock", "[0-9]+", "stock availability should be present in the response");
		validator.nodeEquals("$.payload.skus[0].stores[0].channel", "web", "stock availability should be present in the response");
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("RUNTIME_SKU_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "health_check" }, enabled = true, priority = 8, testName = "Price By WebId",
			description = "Get Price of the product by WebID")
	public void PriceByWebId() {

		TestData.getRunTimeData("WEB_ID", false);
        
		String strURL = PRICE_WEB_ADAPTER + "/" + testData.get("RUNTIME_WEB_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].webID", testData.get("RUNTIME_WEB_ID"), "Given webID should be present in the response");
		validator.validatepriceDetails();

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = PRICE_WEB_OAPI + "/" + testData.get("RUNTIME_WEB_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.products.stores.prices.purchaseEndDateTime,payload.products.stores.prices.purchaseBegDateTime,payload.products.stores.prices.displayEndDateTime,payload.products.stores.prices.displayBegDateTime", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "health_check" }, enabled = true, priority = 9, testName = "Price By SKU",
			description = "Get the Price of the Product by SkuID")
	public void PriceBySku() {

		TestData.getRunTimeData("SKU_CODE", false);

		String strURL = PRICE_SKU_ADAPTER + "/" + testData.get("RUNTIME_SKU_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].webID", ".+", "Prices should be present in the response");
		validator.validatepriceDetails();

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			strURL = PRICE_SKU_OAPI + "/" + testData.get("RUNTIME_SKU_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURL, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.products.stores.prices.purchaseEndDateTime,payload.products.stores.prices.purchaseBegDateTime,payload.products.stores.prices.displayEndDateTime,payload.products.stores.prices.displayBegDateTime", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "health_check" }, enabled = true, priority = 12, testName = "productsForCategoryID [All Categories]",
			description = "Checking the products available in the all the categories")
	public void ProductForCategoryAll() {

		// Post the request
		String strResponse = RestCall.getRequest(CATALOG_ADAPTER, Server.Adapter, false);
		System.out.println("Adapter: " + strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeNotEquals("$.count", "0", "Categories should be present in the response");
		validator.nodeEquals("$.limit", "96", "Limit should be available in response");
		validator.nodeMatches("$.payload.sorts[0]", ".+", "Sorts should be present in the response");
		validator.nodeMatches("$.payload.dimensions[0]", ".+", "Dimensions should be present in the response");
		validator.nodeMatches("$.payload.products[0]", ".+", "Products should be present in the response");
		JSONArray products = JsonPath.read(strResponse, "$.payload.products");
		int productsSize = products.size();
		for (int i = 0; i < productsSize; i++) {
			validator.nodeMatches("$.payload.products[" + i + "].webID", "[0-9a-zA-Z]+", "webID should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].productTitle", "(?s).*[\n\r- ].*", "productTitle should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image", ".+", "image should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image.url", ".+", "image URL should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image.height", "[0-9]+", "image height should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image.width", "[0-9]+", "image width should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice should be displayed");
//			validator.nodeMatches("$.payload.products[" + i + "].prices[0].salePrice.minPrice", ".+", "sale minPrice should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].regularPriceType", ".+", "regularPriceType should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].statusCode", "[0-9]+", "statusCode should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].priceCode", ".+", "priceCode  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].salePriceStatus", ".+|null", "salePriceStatus  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].isSuppressed", "true|false", "isSuppressed  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].displayBegDateTime", "[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+", "displayBegDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].displayEndDateTime", "[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+", "displayEndDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].purchaseBegDateTime", "[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+", "purchaseBegDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].purchaseEndDateTime", "[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+", "purchaseEndDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].isCurrentPrice", "true|false", "isCurrentPrice  should be displayed");
			//validator.nodeMatches("$.payload.products[" + i + "].prices[0].isPriceInstore", "true|false|null", "isInstorePrice  should be displayed");
		}
		// Compare Open API
		if (CompareOAPI) {
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CATALOG_OAPI, Server.OpenApi, false);
			System.out.println(strResponseOAPI);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "health_check" }, enabled = true, priority = 12, testName = "productsForCategoryID [Single]",
			description = "Checking the products available for single categories.")
	public void ProductForCategorySingle() {

		// Get Runtime CategoryID
		TestData.getRunTimeData("CATEGORY_ID", false);

		String strURL = CATALOG_ADAPTER + "/" + testData.get("RUNTIME_CATEGORY_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should be present in the response");
		validator.nodeEquals("$.limit", "96", "Limit should be available in response");
		validator.nodeMatches("$.payload.sorts[0]", ".+", "Sorts should be present in the response");
		validator.nodeMatches("$.payload.dimensions[0]", ".+", "Dimensions should be present in the response");
		validator.nodeMatches("$.payload.products[0]", ".+", "Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("RUNTIME_CATEGORY_ID");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "Bopus", "mfp", "health_check", "errorhandling" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Adding a new item to the cart")
	public void UpdateCart() {
		
		Utilities.removeCart(Server.Adapter,testData.get("access_token_adapter_smoke"));
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_smoke"));
		
		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("RUNTIME_SKU_CODE"), "1")
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		Utilities.setTestData(strResponse, "$.payload.cart.cartItems[0].cartItemID", "CART_ITEM_ID");
		Utilities.setTestData(strResponse, "$.payload.cart.cartID", "CART_ID");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_smoke"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true, mapheader);
			validator = new ResponseValidator(strResponseOAPI);
			Utilities.setTestData(strResponseOAPI, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPI, "$.payload.cart.cartID", "OAPICART_ID");

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
	}

	
	@Test(groups = {"smoke_release","regression","functional" }, enabled = true, priority = 2, testName = "Update Cart with Multiple Items", dependsOnMethods = "signInProfile",
			description = "Adds multiple new item to the cart")
	public void UpdateCartWithMultipleItems() {
		
		//Utilities.removeCart(Server.Adapter,testData.get("access_token_adapter_smoke"));
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_smoke"));
		TestData.getRunTimeData("SKU_CODE", false);
		
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"))
				+","
				+ JsonString.getBopusCartJson("VALID_GIFT", testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		
		String cartItemId=Utilities.getJsonNodeValue(strResponse, "$.payload.cart.cartItems[?(@.giftItem=='fales')].cartItemID");
		String strCartItemId=cartItemId.substring(2,12);
		
		String cartItemId1=Utilities.getJsonNodeValue(strResponse, "$.payload.cart.cartItems[?(@.giftItem=='true')].cartItemID");
		String strCartItemId1=cartItemId1.substring(2,12);
		testData.put("CART_ITEM_ID1", strCartItemId);
		testData.put("CART_ITEM_ID2", strCartItemId1);

		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_smoke"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true, mapheader);
			validator = new ResponseValidator(strResponseOAPI);
			String cartItemIdOapi=Utilities.getJsonNodeValue(strResponse, "$.payload.cart.cartItems[?(@.giftItem=='fales')].cartItemID");
			String strCartItemIdOapi=cartItemIdOapi.substring(2,12);
			
			String cartItemIdOapi1=Utilities.getJsonNodeValue(strResponse, "$.payload.cart.cartItems[?(@.giftItem=='true')].cartItemID");
			String strCartItemIdOapi1=cartItemIdOapi1.substring(2,12);
			testData.put("OAPI_CART_ITEM_ID1", strCartItemIdOapi);
			testData.put("OAPI_CART_ITEM_ID2", strCartItemIdOapi1);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"smoke", "smokeTest","smoke_release", "regression","functional", "mfp", "Bopus", "health_check", "errorhandling" }, enabled = true, priority = 3, testName = "Get Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateCart",
			description = "Gets a Users cart")
	public void GetCart() {

		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "mfp", "health_check" }, enabled = true, priority = 4, testName = "Order Calc",
			description = "Do Ordercalculation for an order as Guest User")
	public void OrderCalcGuestUser() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest", "regression","functional", "mfp","health_check" }, enabled = true, priority = 4, testName = "Order Calc", dependsOnMethods = "signInProfile",
			description = "Do Ordercalculation for an order")
	public void OrderCalc() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}
	
	
	@Test(groups = { "smoke_release" }, enabled = true, priority = 4, testName = "Order Calc",
			dependsOnMethods = {"UpdateCartWithMultipleItems"},
			description = "Do Ordercalculation for an order")
	public void OrderCalcWithMultipleItems() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2")
				+","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"))
				+","
				+ JsonString.getBopusCartJson("VALID_GIFT", testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		// Verifying cart Details
					validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
					validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "shippingMethod should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[2].cartItemID", "[0-9]+", "cartItemID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[2].webID", "[0-9]+", "webID should be present in the response");
					validator.nodeEquals("$.payload.order.cartItems[?(@.giftItem=='true')].skuCode","[\""+ testData.get("SKU_BOPUS")+"\"]", "Given Sku code should be present in the response");
					validator.nodeEquals("$.payload.order.cartItems[?(@.itemType=='OTHERS')].skuCode","[\""+ testData.get("RUNTIME_SKU_CODE")+"\"]", "Given Sku code should be present in the response");
					//validator.nodeEquals("$.payload.order.cartItems[?(@.giftItem=='false'].skuCode","[\""+ testData.get("SKU_BOPUS")+"\"]", "Given Sku code should be present in the response");
					
					// Verifying Order Details
					
					validator.nodeEquals("$.payload.order.email", testData.get("ADAPTER_EMAIL_ID"), "EmaildID should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[?(@.itemType=='OTHERS')].fulFillmentType", ".+", "fulFillmentType should be present in the response");
					validator.nodeMatches("$.payload.order.cartItems[?(@.itemType=='OTHERS')].webExclusive", ".+", "webExclusive should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "vxo" }, enabled = true, priority = 4, testName = "VXO-Order Calc",
			description = "Do Ordercalculation for an order with Visacheckout")
	public void VxoOrderCalc() {

		// Skipping Testcase in production
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("VXO Testcase cannot be executed in Production");
		}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "Bopus", "mfp", "health_check", "errorhandling" }, enabled = true, priority = 5,
			testName = "Place Order", dependsOnMethods = { "UpdateCart", "GetCart" },
			description = "Do Place Order")
	@Severity(SeverityLevel.BLOCKER)
	public void PlaceOrder() {

		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
			validator.validateNoErrors();
			validator.validateCustomerInfo();
			validator.validatebillAddress();
			validator.validateshipAddress();
			// Verifying cart Details
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "shippingMethod should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
			// Verifying Order Details
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
			validator.nodeEquals("$.payload.order.email", testData.get("ADAPTER_EMAIL_ID"), "EmaildID should be present in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
			validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		}

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	
	@Test(groups = { "smoke_release" }, enabled = true, priority = 5,
			testName = "Place Order", 
			description = "Do Place Order with promocode kohlscash and giftcard")
	@Severity(SeverityLevel.BLOCKER)
	public void PlaceOrderWithPromocode_Kohlscash_Giftcard() {

		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		TestData.getRunTimeData("SKU_CODE", false);
		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		
	

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "Invalid Credit Card provided, verify credit card information.");
			return;
		} else {
			validator.validateNoErrors();
			validator.validateCustomerInfo();
			validator.validatebillAddress();
			validator.validateshipAddress();
			// Verifying cart Details
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "shippingMethod should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
			// Verifying Order Details
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		//	validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		//	validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

			
		}

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);
			
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	
	@Test(groups = { "smoke_release" }, enabled = true, priority = 5,
			testName = "Place Order",  
			description = "Do Place Order with promocode kohlscash and giftcard")
	@Severity(SeverityLevel.BLOCKER)
	public void PlaceOrderWithGWP_Promocode_Kohlscash_Giftcard() {

		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		TestData.getRunTimeData("SKU_CODE", false);
		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "," + JsonString.getCartJson("VALID","95647822", "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
				+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
				+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\": \"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}]}}}}";

		
	

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "Invalid Credit Card provided, verify credit card information.");
			return;
		} else {
			validator.validateNoErrors();
			validator.validateCustomerInfo();
			validator.validatebillAddress();
			validator.validateshipAddress();
			// Verifying cart Details
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "shippingMethod should be present in the response");
		//	validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
			// Verifying Order Details
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
			
		//	validator.nodeMatches("$.payload.order.cartItems[0].fulFillmentType", ".+", "fulFillmentType should be present in the response");
		//	validator.nodeMatches("$.payload.order.cartItems[0].webExclusive", ".+", "webExclusive should be present in the response");

			
		}

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);
			
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	
	@Test(groups = { "smoke_release","regression","functional"}, enabled = true, priority = 5,
			testName = "Place Order", dependsOnMethods = { "UpdateCartWithMultipleItems", "GetCart" },
			description = "Do Place Order")
	@Severity(SeverityLevel.BLOCKER)
	public void PlaceOrderWithMultipleItems() {

		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2")
				+","
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"))
				+","
				+ JsonString.getBopusCartJson("VALID_GIFT", testData.get("SKU_BOPUS"), "1",testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "Invalid Credit Card provided, verify credit card information.");
			return;
		} else {
			validator.validateNoErrors();
			validator.validateCustomerInfo();
			validator.validatebillAddress();
			validator.validateshipAddress();
			// Verifying cart Details
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "shippingMethod should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[1].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[2].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[2].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[?(@.giftItem=='true')].skuCode","[\""+ testData.get("SKU_BOPUS")+"\"]", "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[?(@.itemType=='OTHERS')].skuCode","[\""+ testData.get("RUNTIME_SKU_CODE")+"\"]", "Given Sku code should be present in the response");
			//validator.nodeEquals("$.payload.order.cartItems[?(@.giftItem=='false'].skuCode","[\""+ testData.get("SKU_BOPUS")+"\"]", "Given Sku code should be present in the response");
			
			// Verifying Order Details
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
			validator.nodeEquals("$.payload.order.email", testData.get("ADAPTER_EMAIL_ID"), "EmaildID should be present in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
			validator.nodeMatches("$.payload.order.cartItems[?(@.itemType=='OTHERS')].fulFillmentType", ".+", "fulFillmentType should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[?(@.itemType=='OTHERS')].webExclusive", ".+", "webExclusive should be present in the response");

			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_adapter");
		}

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, true);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "order_number_oapi");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartID,payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "vxo" },
			enabled = true, priority = 5, testName = "VXO-Place Order",
			description = "Do Place Order with Visa checkout")
	public void VxoPlaceOrder() {

		// Skipping Testcase in production
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("PlaceOrder cannot be executed in Production");
		}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		// Verifying cart Details
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "shippingMethod should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].qty", "2", "Given Sku code should be present in the response");
		// Verifying Order Details
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "]}}}}";

			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, 
			enabled = true, priority = 10, testName = "Offers By OfferID",
			description = "Checking the Offer Details By using OfferID")
	public void OfferByOfferId() {
//		String strOfferID=Utilities.offerId();
		String strURL = OFFERID_ADAPTER + testData.get("OFFER_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);

		if (validator.validateDataErrors("OFFER3000-1", "Invalid Offer ID provided")) {
			validator.nodeMatches("$.payload.offers[0].id", testData.get("OFFER_ID"), "Given OfferID should be present in the response");
			validator.nodeMatches("$.payload..code", ".+", "OfferCode should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+", "Offer BegDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+", "Offer EndDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].channels[0].value", ".+", "Channel value should be present in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + testData.get("OFFER_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 11, testName = "Offers By OfferCode",
			description = "Checking the Offer Details By using OfferCode")
	public void OfferByOfferCode() {
//		String offerID=Utilities.offerId();
		String strURL = OFFERCODE_ADAPTER + testData.get("OFFER_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (validator.validateDataErrors("OFFER3000-2", "Invalid Offer code provided.")) {
			validator.nodeEquals("$.payload.offers[0].code", testData.get("OFFER_CODE"), "Given OfferCode should be present in the response");
			// validator.nodeMatches("$.payload.offers[0].id", "[0-9]+", "OfferID should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+", "offerEffectiveDate of begDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+", "offerEffectiveDate of endDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].channels[0].value", ".+", "Channels should be present in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			 String strURLOAPI=OFFERCODE_OAPI+testData.get("OFFER_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 12, testName = "Offers By ProductId",
			description = "Checking the Offer Details By using ProductId")
	public void OfferByProductId() {

		String strURL = OFFER_PRODUCTID_ADAPTER + testData.get("OFFER_PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (validator.validateDataErrors("OFFER2000-4", "ProductID Not Found")) {
			validator.nodeEquals("$.payload.products[0].id", testData.get("OFFER_PRODUCT_ID"), "Given productId should be present in the response");
			validator.nodeMatches("$.payload.products[0].offerPrice.min", ".+", "productOffers endDateTime should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].id", ".+", "productOffers id should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].message", ".+", "productOffers message should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].begDateTime", ".+", "productOffers begDateTime should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].endDateTime", ".+", "productOffers endDateTime should be present in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + testData.get("OFFER_PRODUCT_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 13, testName = "Submit Question",
			description = "Submitting the Questions for clarifcation")
	public void SubmitQuestion() {

		// Create Request
		String strPayload = "contextdatavalue_stateOfResidence=AZ&"
				+ "score=" + testData.get("SCORE") + "&"
				+ "action=" + testData.get("ACTION") + "&"
				+ "city=" + testData.get("CITY") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
				+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
				+ "Rating=" + testData.get("RATING") + "&"
				+ "CampaignId=" + testData.get("CAMPAIGN_ID") + "&"
				+ "authorId=" + testData.get("AUTHOR_ID") + "&"
				+ "User=" + testData.get("USER") + "&"
				+ "UserNickname=Sachin" + Utilities.getRandom()
				+ "&QuestionSummary=Is this product is really good.";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", ".+", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Question.QuestionSummary", "Is this product is really good.", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Form[0].Id", ".+", "Form Id  should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "Has Errors should be false in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=9ngrf7rngkhm4a7r6n4uvxaq&contextdatavalue_stateOfResidence=AZ&" + "AuthorId:2253999807330641"
					+ "score=" + testData.get("SCORE") + "&"
					+ "action=" + testData.get("ACTION") + "&"
					+ "city=" + testData.get("CITY") + "&"
					+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
					+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "Rating=" + testData.get("RATING") + "&"
					+ "CampaignId=" + testData.get("CAMPAIGN_ID") + "&"
					+ "authorId=" + testData.get("AUTHOR_ID") + "&"
					+ "User=" + testData.get("USER") + "&"
					+ "UserNickname=Sachin" + Utilities.getRandom()
					+ "&QuestionSummary=Is this product is really good.";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_QUESTION_BAZZARVOICE, strPayloadBazVoice, Server.BazaarVoice, false);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Question.SubmissionTime,payload.Data.Fields.usernickname.Value", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 14, testName = "Submit Answer",
			description = "Submitting the Answers ")
	public void SubmitAnswer() {

		// Create Request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
				+ "UserId=" + testData.get("USER_ID") + "&"
				+ "AnswerText=Frankly speaking, I dont know&"
				+ "UserNickname=Sachin" + System.nanoTime();

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", ".+", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Answer.AnswerText", "Frankly speaking, I dont know", "AnswerText should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "Submission Id  should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors  should be false in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&QuestionId=498352&passkey=9ngrf7rngkhm4a7r6n4uvxaq&action=" + testData.get("ACTION") + "&"
					+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
					+ "UserId=" + testData.get("USER_ID") + "&"
					+ "AnswerText=Frankly speaking, I dont know&"
					+ "UserNickname=Sachin" + System.nanoTime();
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_ANSWER_BAZZARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 15, testName = "get QA For Product",
			description = "Getting the Question and Answers By using ProductId")
	public void GetQAForProduct() {

		String strURL = GETQA_PRODUCT_ADAPTER_FILTER + testData.get("PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results", ".+", "Results should be present in the response");
		validator.nodeMatches("$.payload.Results[0].QuestionSummary", ".+", "Question Summary should be present in the response");
		validator.nodeMatches("$.payload.Results[0].SubmissionId", ".+", "Submission Id should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", ".+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[0].UserNickname", ".+", "UserNickName Summary should be present in the response");
		// Compare Bazzar Voice
		if (CompareOAPI) {

			// Create the Json Request

			String strURLBAZAARVOICE = GETQA_PRODUCT_BAZZ + "passkey=9ngrf7rngkhm4a7r6n4uvxaq&"
					+ "apiversion=5.4&"
					+ "&ProductId=" + testData.get("PRODUCT_ID");
			// Post the request
			String strResponseBAZZ = RestCall.getRequest(strURLBAZAARVOICE, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseBAZZ + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Results.SubmissionTime", true);
		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 16, testName = "get Submit Answer Form ",

	description = "Getting Submitted Answer form By using ProductId and Question Id")
	public void GetSubmitAnswerForm() {

		// Get the request
		String strURL = GET_SUBMIT_ANSFORM_ADAPTER + testData.get("QUESTION_ID") + "&ProductId=" + testData.get("PRODUCT_ID_BAZAAR");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", ".+", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors  should be false in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&QuestionId=" + testData.get("QUESTION_ID") + "&ProductId=" + testData.get("PRODUCT_ID_BAZAAR");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 16, testName = "get Submit Question Form ",

	description = "Getting Submitted Question form By using ProductId ")
	public void GetSubmitQuestionForm() {

		String strURL = GET_SUBMIT_QFORM_ADAPTER + testData.get("PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", ".+", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors  should be false in the response");
		validator.nodeMatches("$.payload.Question.SendEmailAlertWhenPublished", "true", "SendEmailAlertWhenPublished should be present in the response");
		validator.nodeMatches("$.payload.Question.SendEmailAlertWhenAnswered", "true", "SendEmailAlertWhenAnswered should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&ProductId=" + testData.get("PRODUCT_ID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Question.SubmissionTime,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 17, testName = "ConfigProperties",
			description = "Configuring the apps")
	public void ConfigProperties() {

		String strURL = CONFIG_ADAPTER; //+ testData.get("CONFIG");

		// Post the request for config adapter
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		Utilities.getEnabledFeatures(strResponse);

		// Post the request fro messages.log
		// String strResponseMessagesLog = RestCall.simpleGetRequest(MESSAGES_LOG, Server.Adapter, false);
		// Utilities.getMFPVersion(strResponseMessagesLog);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.config.appAndroidVersion", ".+", "appAndroidVersion should be present in the response");
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 17, testName = "getCacheFlushStatus",
			description = "")
	public void GetCacheFlushStatus() {

		String strURL = CACHEFLUSH_CATALOG_ADAPTER + testData.get("CATALOG");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.catalogs", ".+", "Catalogs should be present in the response");

		// Compare Adapter Response two time
			// Create the Json Request for create profile
			// Post the request
			String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponse1, "", true);
		}
	


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 4, testName = "Sale Alert", dependsOnMethods = "UpdateCart",
			description = "")
	public void SaleAlert() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{"
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"address\" : " + JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Subscribed successfully", "message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			// String strURLOAPI=SALEALERT_OAPI+"/"+testData.get("RUNTIME_WEBID1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "health_check" }, enabled = true, priority = 6, testName = "Retrieve Order For User", dependsOnMethods = "PlaceOrder",
			description = "Checking the Order Details By using Access Token")
	public void RetrieveOrderForUser() {
		//Validation for health check
			
		if (strGroup.equals("health_check")){
			String strURL = RETRIEVE_ORDER_ADAPTER + "/12345678" ;
			// Post the request
			String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, true);
			validator = new ResponseValidator(strResponse1);
			validator.validateExpectedErrors("ORDER9252", "This Order Number does not exist. Please double-check the number you entered and try again. If you continue to have problems, please call Customer Service toll free at 1-866-887-8884.");
			return;
		}
		// Skipping Testcase in production
		else if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("Place Order cannot be executed in Production. Hence skipping Retrieve Order");
		}

		// Post the request
		String strResponse = RestCall.getRequest(RETRIEVE_ORDERS_ADAPTER, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.orders[0].orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.orders[0].status", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.orders[0].dateTime", ".+", "Order placed time should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.getRequest(RETRIEVE_ORDERS_OAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 7, testName = "Recommendation",
			description = "Checking the frequently bought product details")
	public void Recommendation() {
		
		TestData.getRunTimeData("WEB_ID", false);
		String strURL = RECOMMENDATION_ADAPTER + testData.get("RECOMEND_TYPE") + "&webID=" + testData.get("RUNTIME_WEB_ID");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.payload.recommendations";
		System.out.println("json recommendations=" + json);
		 validator.nodeMatches("$.payload.recommendations[0]", ".+", "Verifying recommendation tye is same as passed in the request");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = RECOMMENDATION_OAPI + testData.get("RECOMEND_TYPE") + "&webID=" + testData.get("RUNTIME_WEB_ID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			 Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 7, testName = "Stores",
			description = "Checking the stores near by the radius and postalCode")
	public void StoreByOpenSearch() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.stores[0].storeName", ".+", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.stores[0].storeNum", ".+", "Store Number should be present in the response");
		validator.nodeMatches("$.payload.stores[0].storeHours", ".+", "Store Hours should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "health_check" }, enabled = true, priority = 7, testName = "cms",
			description = "Checking the page details")
	public void CMS() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store Name should be present in the response");
		validator.nodeEquals("$.payload.poolName", "nativehome", "Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success", "Response Message should be available in the response");
		validator.nodeMatches("$.payload.entries[0]", ".+", "Entries should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CMS_SKAVA + "&pageName=" + testData.get("SKAVA_PAGE_NAME");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.Skava, false);
			String strResponseSkava = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseSkava =" + strResponseSkava);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseSkava, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 7, testName = "cms",
			description = "Checking the Author details")
	public void AuthorsById() {

		String strURL = AUTHORS_ID_ADAPTER + "AuthorId:2253999807330641";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].AuthorId", "[0-9]+", "AuthorId should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = AUTHORS_ID_BAZAARVOICE + "AuthorId:2253999807330641" + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 2, testName = "Delete Shipping Address[Non-Prefered]", dependsOnMethods = "UpdateShipAddressNonPreferred",
			description = "Deleting a non-prefered shipping address")
	public void deleteShippingAddress() {

		Utilities.signInProfile(testData.get("ADAPTER_EMAIL_ID"), testData.get("ADAPTER_EMAIL_PSWD"), Server.Adapter, "access_token_adapters");

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapters"));
		String strURL = PROFILE_SHIPPING_ADDRESS_ADAPTER + "/" + testData.get("shipping_id_adapter_smoke");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(testData.get("OAPI_EMAIL_ID"), testData.get("OAPI_EMAIL_PSWD"), Server.OpenApi, "access_token_oapi");

			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_oapi"));
			// Get the request
			String strURLOAPI = PROFILE_SHIPPING_ADDRESS_OAPI + "/" + testData.get("shipping_id_oapi_smoke");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 200);
			// String strResponseBazaarVoice = "{\"payload\":" +strResponseOAPI +"}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 2, testName = "Delete Payment details", dependsOnMethods = { "UpdatePaymentType", "signInProfile" },
			description = "Deleting a non-prefered shipping address")
	public void deletePaymentType() {

		Utilities.signInProfile(testData.get("ADAPTER_EMAIL_ID"), testData.get("ADAPTER_EMAIL_PSWD"), Server.Adapter, "access_token_adapters");

		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapters"));
		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + testData.get("adapter_payment_id_delete");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(testData.get("OAPI_EMAIL_ID"), testData.get("OAPI_EMAIL_PSWD"), Server.OpenApi, "access_token_oapi");

			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_oapi"));
			// Get the request
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + testData.get("openAPI_payment_id_delete");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 14, testName = "Delete Payment details",
			description = "Resetting the password using emailID")
	public void forgotPassword() {

		String strURL = FORGOT_PASSWORD + testData.get("PASSWORD_RESET_EMAIL");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Email to change password has been sent", "Verify whether the email change password message is displayed in response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = FORGOT_PASSWORD_OAPI + testData.get("PASSWORD_RESET_EMAIL");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension",
			description = "Checking the products available in the all the categories.")
	public void ProductForDimension() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("DIMENSION_ID") + "?limit=24&offset=1&sortID=3";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("DIMENSION_ID") + "?limit=24&offset=1&sortID=3";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 14, testName = "Submit Review", dependsOnMethods = "getProfile",
			description = "Submitting the Answers ")
	public void SubmitReview() {

		System.out.println("Author Id2" + testData.get("author_id_adapter"));
		// Create Request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserNickname=Razia" + System.nanoTime()
				+ "&SendEmailAlertWhenCommented=true&"
				+ "Title=diff&"
				+ "IsRecommended=true&Rating_Quality=2&"
				+ "city=" + testData.get("WI_BILLING_CITY") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
				// + "UserId=Razia"+System.nanoTime()
				+ "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
				+ "authorId=" + testData.get("author_id_adapter") + "&"
				+ "ReviewText=Very good product.&"
				+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
				+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
				+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
				+ "contextdatavalue_Age=18to24";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Review.SubmissionTime", ".+", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Review.SendEmailAlertWhenPublished", "true", "SendEmailAlertWhenPublished should be present in the response");
		validator.nodeMatches("$.payload.Review.SendEmailAlertWhenCommented", "true", "SendEmailAlertWhenCommented should be present in the response");
		validator.nodeMatches("$.payload.Review.ReviewText", "Very good product.", "ReviewText should be present in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "UserNickname=Razia" + System.nanoTime()
					+ "&SendEmailAlertWhenCommented=true&"
					+ "Title=diff&"
					+ "IsRecommended=true&Rating_Quality=2&"
					+ "city=" + testData.get("WI_BILLING_CITY") + "&"
					+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
					+ "UserId=Razia" + System.nanoTime()
					+ "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
					+ "authorId=" + testData.get("author_id_openapi") + "&"
					+ "ReviewText=Very good product.&"
					+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
					+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
					+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
					+ "contextdatavalue_Age=18to24";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 14, testName = "Submit Feedback",
			description = "Submitting the Answers ")
	public void SubmitFeedback() {

		// Create Request
		String strPayload = "action=" + testData.get("ACTION") + "&"
				+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
				+ "ContentId=" + testData.get("CONTENT_ID") + "&"
				+ "UserId=" + testData.get("author_id_adapter") + "&"
				+ "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&"
				+ "Vote=" + testData.get("VOTE");

		// Prod has diffrent content ID, so using different payload
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			strPayload = "ContentType=question&ContentId=1564686&UserId=5678&FeedbackType=helpfulness&Vote=Positive";
		}

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.Answer.SubmissionTime", ".+", "Submission Time should be present in the response");
		// validator.nodeMatches("$.payload.SubmissionId", ".+", "Submission Id should be present in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
					+ "ContentId=" + testData.get("CONTENT_ID") + "&"
					+ "UserId=" + testData.get("author_id_openapi") + "&"
					+ "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&"
					+ "Vote=" + testData.get("VOTE");

			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_FEEDBACK_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 16, testName = "get Reviews For Product",
			description = "Getting Submitted Answer form By using ProductId and Question Id")
	public void getReviewsForProduct() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 14, testName = "Show Review",
			description = "Submitting the Answers ")
	public void ShowReview() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "apple_pay" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc",
			description = "Performing orderCalc with Apple pay")
	public void applepayOrderCalc() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		// Compare Open API
		if (CompareOAPI) {
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID") +"," + "\"email\":\"shankarc44@gmail.com\"," + "\"cartItems\" : ["+ JsonString.getCartJson("","VALID", testData.get("SKU_NORMAL"), "2") +"]," + "\"billAddress\" : "+ JsonString.getBillAddressJson("WI_MILWAUKEE") +"," + "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + JsonString.getPaymentTypeJson("VISA") + "]}}}}";
			 */
			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release","regression","functional","apple_pay" }, enabled = true, priority = 7, testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay")
	@Severity(SeverityLevel.BLOCKER)

	public void applepayPlaceOrder() {
		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER3020", "The calculated Order total is different from the authorized amount.");
		} else {
			validator.validateNoErrors();
			validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateCustomerInfo();
			
			// Set orderNumber from response in test data
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_adapter");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_oapi");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE1");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "apple_pay" }, enabled = true, priority = 6, testName = "Retrieve Order By Order id", dependsOnMethods = "applepayPlaceOrder",
			description = "Checking the Order Details By using order Id")
	public void ApplepayRetrieveOrderByOrderId() {

		// Skipping Testcase in production
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("Place Order cannot be executed in Production. Hence skipping Retrieve Order");
		}

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("applepay_order_number_adapter") + "?postalCode=" + testData.get("APY_POSTAL_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
		Utilities.setTestData(strResponse, "$.payload..cardNum", "card_number_adapter");
		// String cardNum=testData.get("card_number_adapters");
		System.out.println(testData.get("card_number_adapters"));
		String cardNum = testData.get("card_number_adapter").substring(14, 18);
		System.out.println(cardNum);
		validator.nodeEquals("$.payload..cardNum", "[\"xxxxxxxxxxxx" + cardNum + "\"]", "last 4 digit of the card number should be displayed");
		validator.nodeEquals("$.payload..type", "[\"VISA\"]", "card type should be displayed");
		validator.nodeEquals("$.payload..paymentDetails", "[\"APPLEPAY\"]", "paymentDetails should be APPLEPAY");
		Utilities.setTestData(strResponse, "$.payload.order.paymentTypes.creditCards[0].valueApplied", "value_applied_adapter");
		Utilities.setTestData(strResponse, "$.payload.order.totals.orderTotal", "order_total_adapter");
		// Assert.assertSame(testData.get("value_applied_adapter"), testData.get("order_total_adapter"));
		//Assert.assertEquals(testData.get("value_applied_adapter"), testData.get("order_total_adapter"));
		Assert.assertTrue(testData.get("order_total_adapter").contains(testData.get("value_applied_adapter")), "Expected : '" + testData.get("value_applied_adapter") + "'... Actual : '" + testData.get("order_total_adapter") + "'");
		validator.nodeEquals("$.payload.order.orderNumber", testData.get("applepay_order_number_adapter"), "order number should be as same");
		// validator.nodeEquals("$.payload.order.shipments[0].shipAddress.postalCode",testData.get("APY_POSTAL_CODE"),"PostalCode should be same" );
		// validator.nodeEquals("payload..securityCode",,"PostalCode should be same" );
		validator.nodeEquals("$.payload..securityCode", "[null]", " Security Code should not be present");
		// Utilities.setTestData(strResponse, "$.payload..securityCode","security_code_adapter");
		// Assert.assertNull("security_code_adapter");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("applepay_order_number_oapi") + "?postalCode=" + testData.get("APY_POSTAL_CODE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.originatorID", true);
		}
	}


	@Test(groups = { "smoke","smoke_release", "regression","functional" }, enabled = true, priority = 16, testName = "Wallet Auth V1 Sign In Profile",
			dependsOnMethods = "createProfile",
			description = "Wallet Auth Signs in to the profile")
	@Severity(SeverityLevel.BLOCKER)
	public void walletAuthV1signInProfile() {

		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Ocb@1234";
		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

		// Create the Json Request for Sign In
		String strURL = "grant_type=password&userId=" + strEmail + "&password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strURLOAPI, Server.OpenApi, false);

		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 14, testName = "Wallet Auth V2 Sign In Profile",
			dependsOnMethods = "signInProfile",
			description = "Wallet Auth Signs in to the profile")
	@Severity(SeverityLevel.BLOCKER)
	public void walletAuthV2signInProfile() {

		// Create the Json Request for Sign In
		String strURL = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		// String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);
		String strResponse1 = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse1, "$.payload.response.signIn.refresh_token", "refresh_token_adapter1");
		Utilities.setTestData(strResponse1, "$.payload.response.wallet.token", "wallet_token_adapter");

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.token", ".+", "Token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.walletId", "[0-9]+", "WalletID should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strURLOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "refresh_token_oapi1");
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" },
			enabled = true, priority = 6, testName = "InStore SingleProductDetails",
			description = "Checking whether the sku is eligible is available for instore")
	public void InStoreSingleProductDetails() {

		TestData.getRunTimeData("INSTORE_SKU_CODE", false);
		
		String strSku = testData.get("RUNTIME_INSTORE_SKU_CODE") == null ? testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") : testData.get("RUNTIME_INSTORE_SKU_CODE");

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("RUNTIME_INSTORE_SKU_CODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.regularPrice", ".+", "Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("RUNTIME_INSTORE_SKU_CODE") + "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 14, testName = "Instore Products for Dimension",
			description = "Verifying whether the product is available in online and store")
	public void InstoreProductsForDimension() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("DIMENSION_ID_01") + "?limit=10&offset=" + testData.get("PRODUCT_OFFSET") + "&sortID=" + testData.get("PRODUCT_SORT_ID") + "&storeNum=" + testData.get("STORE_NUM_01") + "&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		// Changed nodevalidateprice to node matches
		validator.nodeMatches("$.payload.products[0].prices[0].isPriceInstore", ".+", "Verify whether the online price is not getting displayed as null in response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("DIMENSION_ID_01") + "?limit=10&offset=" + testData.get("PRODUCT_OFFSET") + "&sortID=" + testData.get("PRODUCT_SORT_ID") + "&storeNum=" + testData.get("STORE_NUM_01") + "&inStoreEnabled=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 6, testName = "InStore OfferProductLookUp",
			description = "Checking whether the sku is eligible is available for instore and offer is available in productOffers")
	public void InStoreOfferProductLookUp() {

		TestData.getRunTimeData("INSTORE_WEB_ID", false);

		String strWebID = testData.get("RUNTIME_INSTORE_WEB_ID") == null ? testData.get("AVAILABLE_ONLINE_BOGO_WEBID") : testData.get("RUNTIME_INSTORE_WEB_REBATE");

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RUNTIME_INSTORE_WEB_ID") + "?storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.regularPrice", ".+", "Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", ".+", "Bogo Promotion should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + strWebID + "?storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&skuDetail=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@DiscontinuedTest(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = false, priority = 16, testName = "Refresh Token V2",
			dependsOnMethods = {"walletAuthV2signInProfile","test.java.adapters.smoke.SmokeTest.RetrieveOrderUsingOrderID"},
			description = "Refresh token version v2")
	public void RefreshTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("refresh_token_adapter1") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("wallet_token_adapter").replaceAll("\\+", "%2B").replaceAll("/", "%2F");

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
		// String strResponse1 = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Set the access token in testData

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		// validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("refresh_token_oapi1") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 6, testName = "Bopus Sku Level is Bopus Level",
			description = "Checking whether the sku is eligible for bopus in sku level")
	public void BOPUSSKULevelIsBopusEligible() {

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuDetail=true&allSkus=true&skuCode=" + testData.get("SKU_BOPUS");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].isBopusEligible", "true", "Bopus Eligible should be true in sku level in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuDetail=true&allSkus=true&skuCode=" + testData.get("SKU_BOPUS");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 4, testName = "Bopus Order Calc",
			description = "Do Ordercalculation for an order with bopus skucode")
	public void BopusOrderCalc() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "]}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	//	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"cartItems\" : ["+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"),"1", testData.get("BOPUS_STORE")) +"]}}}";
			 */
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@DiscontinuedTest(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = false, priority = 4, testName = "Get Profile suing v2 access token", dependsOnMethods = "RefreshTokenV2",
			description = "Get Profile")
	public void getProfileWithV2AccessToken() {

		// Post the request
		String strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeEquals("$.payload.profile.email", testData.get("ADAPTER_EMAIL_ID"), "Profile email should be present");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", ".+", "LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", ".*", "FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+", "saleAlerts should be available in response");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strResponseOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true);
		}
	}
	
	@Test(groups = { "health_check" }, enabled = true, priority = 56, testName = "Refresh Token",
			dependsOnMethods = {"test.java.adapters.smoke.SmokeTest.RetrieveOrderUsingOrderID","getProfile"},
			description = "Refresh token version")
	public void RefreshToken() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("refresh_token_adapter");

		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.access_token", ".+", "Access token should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("refresh_token_oapi");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}

	}
	
	
	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 16, testName = "Refresh Token V1",
			dependsOnMethods = "walletAuthV2signInProfile",
			description = "Refresh token version v1")
	public void RefreshTokenV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("refresh_token_adapter");

		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.access_token", ".+", "Access token should be available in response");
		Utilities.setTestData(strResponse, "$.payload.access_token", "access_token_adapter");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("refresh_token_oapi");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_oapi");
		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "apple_pay", "vxo", "InstoreFreeShipping", "omniture", "bopus","health_check" }, enabled = true, priority = 1, testName = "Kohls Cash Balance",
			description = "Kohls cash script")

	public void KohlsCashBalance() {

		// Create URL Request
		String strURL = BALANCE_ADAPTER + "/" + testData.get("SMOKE_KOHLS_CASH_NUMBER") + "/" + "balance";

		// Get Request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (validator.validateDataErrors("BALA9004", "We're sorry, the Kohl's Cash or Rewards you entered is not valid.Please check the number and try again.")) {
			validator.nodeMatches("$.payload.kohlsCash.balance", ".+", "KohlsCash balance should be available");
			validator.nodeMatches("$.payload.kohlsCash.validDates.startDate", ".+", "KohlsCash startDate should be available");
			validator.nodeMatches("$.payload.kohlsCash.validDates.endDate", ".+", "KohlsCash endDate should be available");
		}

	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional" }, enabled = true, priority = 4, testName = "InStoreFreeShipping Order Calc",
			description = "Do Ordercalculation for an order in Instore mode")
	public void InStoreFreeshippingOrderCalc() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strOrderCalcRequest = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_BOPUS"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strOrderCalcRequest, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	//	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "User is in Instore mode");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strOrderCalcRequest, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional","health_check" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with valid address")
	public void validateOrderByAddressValidAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("VALID")
				+ "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(VALIDATION_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "smoke", "smokeTest","smoke_release", "regression","functional", "errorhandling" }, enabled = true, priority = 50, testName = "Refresh Token V1",
			dependsOnMethods = "getProfile",
			description = "Refresh token version v1")
	public void RevokeToken() {

		// Post the request
		String strResponse = RestCall.deleteRequest(V2_REFRESH_TOKEN, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.message", "User Token Expired Successfully", "User Token  Expired Successfully message should be displayed ");
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
		validator = new ResponseValidator(strURL);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "access token expired");

		// Sign in again to get new access token as old access token is revoked
		Utilities.signInProfile(testData.get("ADAPTER_EMAIL_ID"), testData.get("ADAPTER_EMAIL_PSWD"), Server.Adapter, "access_token_adapter");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.deleteRequest(V1_SIGNIN_PROFILE_OAPI, Server.OpenApi, true);

			// Sign in again to get new access token as old access token is revoked
			Utilities.signInProfile(testData.get("OAPI_EMAIL_ID"), testData.get("OAPI_EMAIL_PSWD"), Server.OpenApi, "access_token_oapi");
		}

	}


	@Test(groups = { "regression","functional", "syndicate_content", "smoke", "smokeTest","smoke_release" }, enabled = true, priority = 0, testName = "Syndicated contest - Flag is true",
			description = "Bazaar voice Syndicated contest when flag is true")
	@TestCaseId("ShowRiview_Syndicated_FlagTrue")
	public void syndicateContentFlagTrue() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Limit=6&Offset=0&Filter=IsSyndicated:true";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[1].IsSyndicated", "true", "IsSyndicated should be True");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.Name", ".+", "Name should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.LogoImageUrl", ".+", "LogoImagineUrl should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.ContentLink", ".+", "ContentLink shouldnt be null");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Limit=6&Offset=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}

	}
	

	@Test(groups = { "hazmat", "regression","functional", "smoke", "smokeTest","smoke_release" }, enabled = true, priority = 6, testName = "ProductBySKU_HAZMAT_Transportation",
			description = "Check whether the HTML Content Is Being Displayed")
	public void HazmatProductBySKU_Transportation() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_HAZMAT_TRANSPORTATION");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.products[0].productDetails", "(?s).*This content is related to Transportation.*", "Hazmat HTML content should be present");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_HAZMAT_TRANSPORTATION");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}
	
	
	@Test(groups = { "regression","functional", "qna", "health_check" }, enabled = true, priority = 14, testName = "QuestionAndAnswerDetail",
			description = "Kohls application user should able to view total number of Questions and Answers on the product description page")
	public void totalNumberOfQuestionAndAnswerDetail() {

		// Get the request
		String strURL = GET_QA_PRODUCT_ADAPTER + "?Sort=HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_COUNT_PRODUCT_ID") + "&search=men&Include=Answers";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateQuestionDetailForQAndA("Validating Question Details");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Limit", "5", "Limit should be present as 5 in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GETQA_PRODUCT_BAZZ + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&Sort=HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_COUNT_PRODUCT_ID") + "&search=men&Include=Answers";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}
	

	@Test(groups = { "regression","functional","health_check" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Checking the products available in the all the categories and Channel")
	public void CategoriesChannel() {

		String strURL = CATEGORY_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATEGORY_OAPI + "?channel=mobile";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	

	@Test(groups = { "regression","functional", "mfp", "health_check" }, enabled = true, priority = 6, testName = "Retrieve Order UsingOrderID", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.PlaceOrder",
			description = "Checking the Order Details UsingOrderID")
	public void RetrieveOrderUsingOrderID() {

		String strURL = RETRIEVE_ORDER_ADAPTER + "/" + testData.get("order_number_adapter");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (strGroup.equals("health_check")){
			
			validator.validateExpectedErrors("ORDER9252", "This Order Number does not exist. Please double-check the number you entered and try again. If you continue to have problems, please call Customer Service toll free at 1-866-887-8884.");
			return;
		}
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/" + testData.get("order_number_oapi");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.orders.originatorID,payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}


	@Test(groups = { "regression","functional","health_check" }, enabled = true, priority = 6, testName = "SingleProductDetails With Valid skuCode",
			description = "Checking whether the sku is eligible is available for valid skuCode")
	public void ProductsBySku() {
		TestData.getRunTimeData("SKU_CODE", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("RUNTIME_SKU_CODE") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.regularPrice", ".+", "Regular Price should be available in online in the response");
		// validator.nodeEquals("$.payload.products[0].webID", testData.get("WEB_ID"), "WebID should be available in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + testData.get("RUNTIME_SKU_CODE") + "&skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	
	@Test(groups = { "regression","functional","health_check" }, enabled = true, priority = 6, testName = "SingleProductDetails With Valid WebID",
			description = "Checking whether the sku is eligible is available for valid webId")
	public void singleProductDetails_ValidWebID() {
		TestData.getRunTimeData("WEB_ID", false);
		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RUNTIME_WEB_ID") + "?skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.regularPrice", ".+", "Regular Price should be available in online in the response");
		validator.nodeEquals("$.payload.products[0].webID", testData.get("RUNTIME_WEB_ID"), "WebID should be available in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + testData.get("RUNTIME_WEB_ID") + "?skuDetail=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	

	@Test(groups = { "regression","functional","health_check" }, enabled = true, priority = 12, testName = "productsForDimension CategoryID",
			description = "Checking the products available for particular category")
	public void CategoryID() {

		String strURL = CATEGORY_ADAPTER + "/" + testData.get("CATEGORY_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeNotEquals("$.payload.categories[*].name", ".+", "Categories should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATEGORY_OAPI + "/" + testData.get("CATEGORY_ID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = {"health_check" }, enabled = true, priority = 12, testName = "Service Metadata",
			description = "Checking the service meta data information")
	public void getServiceMetadata() {

		
		// Post the request
		String strResponse = RestCall.getRequest(METADATA_ADAPTER, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.projects[0].name", "kohls", "Checking whether the project name is KOHLS");
		validator.nodeEquals("$.name", "rest", "Checking whether the service name is rest");
		JSONArray urls = JsonPath.read(strResponse, "$..formParameters");
		int sizeOfurls=urls.size();
		System.out.println("Urls size =" + sizeOfurls);
		JSONArray urls1 = JsonPath.read(strResponse, "$..pathParameters");
		int sizeOfurls1=urls1.size();
		JSONArray parameterType = JsonPath.read(strResponse, "$..parameterType");
		int sizeOfparameter=parameterType.size();
		for(int j=0;j<sizeOfurls;j++){
			String strParameter=(String) parameterType.get(j);
			System.out.println("Parameter Type :"+strParameter);
							
					//validator.nodeMatches("$.urls["+j+"].formParameters[0].javaType", ".+", "Validating the java type for the url");
					//.nodeMatches("$.urls["+j+"].formParameters[0].parameterType", ".+", "Validating the parameter tpye for the url");
					validator.nodeMatches("$.urls["+j+"].method", ".+", "Validating the method type[" + j + "]");
					validator.nodeMatches("$.urls["+j+"].javaClass", ".+", "Validating the java class[" + j + "]");
					validator.nodeMatches("$.urls["+j+"].javaMethodName", ".+", "Validating the java method name[" + j + "]");
					validator.nodeMatches("$.urls["+j+"].uri", ".+", "Validating the uri[" + j + "]");
					
			
			}
		}
	
	
	@Test(groups = {"health_check" }, enabled = true, priority = 12, testName = "Get Cache Flush status",
			description = "Checking the service meta data information")
	public void getCacheFlushStatus() {

		
		// Post the request
		String strResponse = RestCall.getRequest(CACHESTATUS_CATALOG_ADAPTER, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		}
	

	@Test(groups = "health_check", enabled = true, priority = 25, testName = "Remove Cart", dependsOnMethods = "UpdateCart",
			description = "Remove the cart items for the user")
	public void RemoveCart() {
		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
	}
	
	//R3 2016 Scope Projects
	
		@Test(groups = { "geofence", "errorhandling","smoke", "smokeTest","smoke_release" }, enabled = true, priority = 2, testName = "GeoFence - All Stores",
			
			description = "Verify whether all the stores in the quadrants are getting displayed & Verify whether the added stores in the quadrants are getting displayed in the response")
	public void getAllStoresInQuadrants() {

		// Post the request
		String strResponse = RestCall.getRequest(GEOFENCE_STORES_ADAPTERS, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateResponseHeaders("EXPIRES_GT_CURRENT_DATE", "Expires header date should be greter than current date");
		validator.validateStoreLatLong("Validate each store is within the lat/long quadrants");
		
		//delete store if already exist
		String strURL = GEOFENCE_STORES_ADAPTERS +"/"+ testData.get("GEO_STORE_NUM");
		
		/*if(testData.get("STORENUM_EXISTS")!=null)
		{
		// Post the request
		String strResponse1 = RestCall.deleteRequest(strURL, Server.Adapter, false,202);
		}*/
	}
		
	@Test(groups = {"smoke", "smokeTest","Config","monetization"}, enabled = true, priority = 17, testName = "ConfigMonetization",
				description = "Adapter Monetization configuration")
	public void ConfigMonetization() {

			String strURL = CONFIG_MONETIZATION ;

			// Post the request for config adapter
			String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);
			Utilities.getEnabledFeatures(strResponse);

			// Post the request for messages.log
			// String strResponseMessagesLog = RestCall.simpleGetRequest(MESSAGES_LOG, Server.Adapter, false);
			// Utilities.getMFPVersion(strResponseMessagesLog);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			if (testData.get("OAPI_Environemnt").equals("Prod")) {
				validator.nodeEquals("$.payload.env", "prod", "Environment should be test");
				validator.nodeEquals("$.payload.networkId", "17763952", "Network ID should be17763952.");
				validator.nodeEquals("$.payload.channel", "mobileapp", "Channel should be mobileapp");
				return;
			} else {
			validator.nodeEquals("$.payload.channel", "mobileapp", "Channel should be mobileapp");
			validator.nodeEquals("$.payload.env", "test", "Environment should be test");
			validator.nodeEquals("$.payload.networkId", "17763952", "Network ID should be17763952.");
			
			/*Madhu 3/22/2016: Added home page,PMP, PDP, COL,Search, Zero search, oc, Store locator, deals  validation
			 * Requirment ref :https://confluence.globallogic.com/display/Kohls/Monetization+-+Google+DFP*/
			
			validator.nodeEquals("$.payload.home.adUnit", "/homepage", "Adunit is Home page");
			validator.nodeMatches("$.payload.home.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.home.size", "[\"banner\"]", "Size should be Banner");
			validator.nodeEquals("$.payload.home.dimensions", "[[320,50]]", "Dimention should be 320, 50 in home page");
			validator.nodeEquals("$.payload.home.pos", "[\"middle\"]", "Ad should be displayed in the middle of home page");
			validator.nodeEquals("$.payload.home.pgtype", "home", "Page type should be Home");
			
			validator.nodeEquals("$.payload.pmp.isEnabled", "true", "Adunit is PMP");
			validator.nodeEquals("$.payload.pmp.size", "[\"banner\"]", "Type of add is Banner");
			validator.nodeEquals("$.payload.pmp.dimensions", "[[320,50]]", "Dimention should be 320, 50 in PMP page");
			validator.nodeEquals("$.payload.pmp.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of PMP");
			validator.nodeEquals("$.payload.pmp.pgtype", "pmp", "Page type should be PMP");
			
			validator.nodeEquals("$.payload.col.isEnabled", "true", "Adunit is in collection page");
			validator.nodeEquals("$.payload.col.size", "[\"banner\"]", "Type of add is Banner in collection page");
			validator.nodeEquals("$.payload.col.dimensions", "[[320,50]]", "Dimention should be 320, 50 in collection page");
			validator.nodeEquals("$.payload.col.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of collection page");
			validator.nodeEquals("$.payload.col.pgtype", "col", "Page type should be Collection");
			
			validator.nodeEquals("$.payload.pdp.isEnabled", "true", "Adunit is in PDP page");
			validator.nodeEquals("$.payload.pdp.size", "[\"banner\"]", "Type of add is Banner in PDP page");
			validator.nodeEquals("$.payload.pdp.dimensions", "[[320,50]]", "Dimention should be 320, 50 in PDP page");
			validator.nodeEquals("$.payload.pdp.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of PDP page");
			validator.nodeEquals("$.payload.pdp.pgtype", "pdp", "Page type should be PDP");
						
			validator.nodeEquals("$.payload.search.isEnabled", "true", "Adunit in search bar page");
			validator.nodeEquals("$.payload.search.size", "[\"banner\"]", "Type of add is Banner in Search bar");
			validator.nodeEquals("$.payload.search.dimensions", "[[320,50]]", "Dimention should be 320, 50 in search page");
			validator.nodeEquals("$.payload.search.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of Search page");
			validator.nodeEquals("$.payload.search.pgtype", "search", "Page type should be search page");

			validator.nodeEquals("$.payload.zerosearch.adUnit", "/zerosearch", "Adunit in search bar page when search result is zero");
			validator.nodeEquals("$.payload.zerosearch.size", "[\"banner\"]", "Type of ad is Banner in Search bar");
			validator.nodeEquals("$.payload.zerosearch.dimensions", "[[320,50]]", "Dimention should be 320, 50 in zero search page");
			validator.nodeEquals("$.payload.zerosearch.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of zero Search page");
			validator.nodeEquals("$.payload.zerosearch.pgtype", "zerosearch", "When the user searches for any product and zero product found");

			validator.nodeEquals("$.payload.oc.adUnit", "/order_confirmation", "Adunit in order confirmation page");
			validator.nodeMatches("$.payload.oc.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.oc.size", "[\"banner\"]", "Type of ad is Banner in confirmation page");
			validator.nodeEquals("$.payload.oc.dimensions", "[[320,50]]", "Dimention should be 320, 50 in order confirmation page");
			validator.nodeEquals("$.payload.oc.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of confirmation page");
			validator.nodeEquals("$.payload.oc.pgtype", "oc", "Page type should be oc");
				
			validator.nodeEquals("$.payload.store_locator.adUnit", "/store_locator", "Adunit in store locator page");
			validator.nodeMatches("$.payload.store_locator.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.store_locator.size", "[\"banner\"]", "Type of ad is Banner in store locator page");
			validator.nodeEquals("$.payload.store_locator.dimensions", "[[320,50]]", "Dimention should be 320, 50 in order confirmation page");
			validator.nodeEquals("$.payload.store_locator.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of confirmation page");
			validator.nodeEquals("$.payload.store_locator.pgtype", "store_locator", "Page type should be store_locator");
			
			validator.nodeEquals("$.payload.deals.adUnit", "/ROS", "Adunit in ros");
			validator.nodeMatches("$.payload.deals.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.deals.dimensions", "[[320,50]]", "Dimention should be 320, 50 in deals page");
			validator.nodeEquals("$.payload.deals.pos", "[\"middle\"]", "Ad should be displayed at the middle of the page");
			validator.nodeEquals("$.payload.deals.pgtype", "sevent", "Page type should be sevent");
			validator.nodeEquals("$.payload.deals.pgname", "coupons-deals.jsp","Page name should be pgname");
							
		}}
	
	
	@Test(groups = { "visualnav","smoke", "smokeTest","smoke_release" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Five Tile",
			description = "Validate whether visualNavTiles object with array of 5 visualNavTile is getting displayed in the response while passing a keyword with 5 Tile in the request")
	@TestCaseId("VN_5")
	public void catalogWith5TileKeyword() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("5_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload.visualNavTiles.visualNavTile");
		int strVisualNavTileSize = visualNavTile.size();
		Assert.assertEquals(strVisualNavTileSize, 5);
	//	validator.nodeMatches("$.payload.visualNavTiles.visualNavTitle", ".+", "visualNavTile should present in the response");
	//	validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTitle", "null", "visualNavTile should not be null present in the response");
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
		//	validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("5_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}
	
	
	@Test(groups = { "smoke", "smokeTest","smoke_release"}, enabled = true, priority = 1, 
			testName = "recommendation_PDP without limit in channel iosApp",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1")
	public void recommendationPDP_withoutLimit_Channel_iosApp() {
		
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
					"&plids=Horizontal1"
					+ "&ccp=" + testData.get("CCP");
			
			mapheader.put("User-Agent","Platform");
			// Get the request
			String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
			int strproductIDsSize = productIDs.size();
			
//			Assert.assertEquals(strproductIDsSize, 4);
			for (int i = 0; i < strproductIDsSize; i++) {
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
				validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
			}		
			validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID sould be" + testData.get("EDE_CID_ios"));
			validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
			validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
		}
		else{
		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		mapheader.put("User-Agent","Platform");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID sould be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
		}
	}
	
	
	@Test(groups = {"smoke", "smokeTest","smoke_release"}, enabled = true, priority = 1, testName = "recommendation_PDP without limit in channel AndroidApp",
			description = "A Kohls application user wants to get recommendations for PDP page in channel AndroidApp and placement identification Horizontal1")
	public void recommendationPDP_withoutLimit_Channel_AndroidApp() {
		
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1"
		+ "&ccp=" + testData.get("CCP");
		
		mapheader.put("User-Agent","Platform");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID sould be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
	}
		else{
			String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
					"&plids=Horizontal1"
					+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
					// Get the request
					String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

					// Validate Response
					validator = new ResponseValidator(strResponse);
					validator.validateNoErrors();
					JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
					int strproductIDsSize = productIDs.size();
//					Assert.assertEquals(strproductIDsSize, 4);
					for (int i = 0; i < strproductIDsSize; i++) {
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
						validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
					}
					
					validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID sould be" + testData.get("EDE_CID_Android"));
					validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
					validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
		}
	}
	
	
	@Test(groups = { "bopusphase2","Bopus","regression", "smoke", "smokeTest" }, enabled = true, priority = 4, testName = "placeOrder_valid_bopusItem_pickUpPersonDetail",
			description = "Kohls application user wants to verify whether alternatePickUpPerson information and bopus item is provided in the request then the information needs to be persisted as part of order and returned in the response.")
	public void placeOrder_valid_bopusItem_pickUpPersonDetail() {
		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDER_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}}
	
	
	@Test(groups = {"bopusphase2","Bopus","regression", "smoke", "smokeTest"}, enabled = true, priority = 2, testName = "placeOrderV2_valid_bopusItem",
			description = "A kohls application user wants to Relogin the same user to verify whether place order request BOPUS item are persistent")
	public void placeOrderV2_valid_bopusItem() {
		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		// Create a new profile through OAPI
		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Bopusph2@123";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "Bopus_access_token_oapi");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Bopus_access_token_oapi"));
		
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
				
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "CART_ID");
		String cartItemId0=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].cartItemID");
		String cartItemWebID=Utilities.getJsonNodeValue(strResponseOAPIAddCart, "$.payload.cart.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].webID");
		cartItemId0=cartItemId0.substring(2,12);
		
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "Bopus_access_token_adapter");

		// Update cart through Adapter
		mapheader.clear();
		mapheader.put("access_token", testData.get("Bopus_access_token_adapter"));
		// Update cart through Adapter
		
		String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\",\"alternatePickUpPersons\":["
				 +JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") +"\",\"cartID\":\"" + testData.get("CART_ID")
				+ "\",\"cartItems\" : [{\"cartItemID\":\"" + cartItemId0 + JsonString.getBopusCartJson("VALID_V2", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		
		String strResponsePlaceOrderAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponsePlaceOrderAdapter);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		//validator.nodeMatches("$.payload.order.cartItems[1].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		//validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_NORMAL") +"')].itemType", "OTHERS", "itemType should be present in the response");
		validator.nodeContains("$.payload.order.cartItems[?(@.skuCode=='"+ testData.get("SKU_BOPUS") +"')].itemType", "BOPUS", "itemType should be present in the response");
		validator.storeAddresses("StoreAddress is not null");
		validator.searchstore("$.payload..storeName", "Store Name should be present in the response");
		validator.searchstore("$.payload..storeNum", "Store Name should be present in the response");
		validator.searchstore("$.payload..name", "Store Name should be present in the response");
		validator.searchstore("$.payload..open", "Store Name should be present in the response");
		validator.searchstore("$.payload..close", "Store Name should be present in the response");
		validator.searchstore("$.payload..addr1", "Store Name should be present in the response");
		validator.searchstore("$.payload..city", "Store Name should be present in the response");
		validator.searchstore("$.payload..state", "Store Name should be present in the response");
		validator.searchstore("$.payload..postalCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..countryCode", "Store Name should be present in the response");
		validator.searchstore("$.payload..type", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.order.alternatePickUpPersons[0]",".*","alternatePickUp field should not be null");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",testData.get("CUSTOMER_FIRSTNAME"),"alternatepickupperson firstname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",testData.get("CUSTOMER_LASTNAME"),"alternatepickupperson lastname should be same");
		validator.nodeEquals("$.payload.order.alternatePickUpPersons[0].email","razzirazzu@gmail.com","alternatepickupperson email should be same");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", ".+", "Value should be applied in the response");
		// validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].valueApplied", ".+", "Value should be applied in the response");
//		validator.nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", ".+", "Value should be applied in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "order Status should be submitted");
		Utilities.setTestData(strResponsePlaceOrderAdapter, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS_PLACE_ORDER");
		// GetCart from Adapter
		String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

		// Compare the Getcart from Adapter and OAPI
		// GetCart response from OAPI
		mapheader.put("access_token", testData.get("Bopus_access_token_oapi"));
		String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

	}}
	
	
	@Test(groups = { "bopusphase2","regression", "smoke", "smokeTest"}, enabled = true, priority = 6, testName = "retrieveOrder_validOrderNumber_access_token",
			dependsOnMethods = "placeOrderV2_valid_bopusItem",
			description = "Kohls applicaiton user wants to verify whether the textNotificationNumber details are getting populated in order details page when orderNumber and access_token is provided in the request")
	public void retrieveOrder_validOrderNumber_access_token() {

		mapheader.put("access_token", testData.get("Bopus_access_token_adapter"));
		
		String strURL = RETRIEVE_ORDER_ADAPTER + "/"+testData.get("ORDER_NUMBER_BOPUS_PLACE_ORDER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			
			validator.validateExpectedErrors("ORDER9252", "This Order Number does not exist. Please double-check the number you entered and try again. If you continue to have problems, please call Customer Service toll free at 1-866-887-8884.");
			return;
		}
else{
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
		validator.nodeMatches("$.payload.order.orderStatus", "Submitted||In Fulfillment", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.order.dateTime", ".+", "Order placed time should be present in the response");
		

		// Compare Open API
//		if (CompareOAPI) {
//			String strURLOAPI = RETRIEVE_ORDER_OAPI + "/8333005479?postalCde=10011";
//
//			// Get the request
//			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, true, 400);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
//		}
	}}
	
	
	@Test(groups = {"bopusphase2","Bopus","regression", "smoke", "smokeTest"}, enabled = true, priority = 4, testName = "updateOrder_alternatePickUpPersons",
			description = "Kohls applicaiton user wants to verify whether the alternatePickUp details are added when valid details passed with orderNumber, email, postalCode, action as ADD_ALT_PICKUP and alternatePickUpPersons in the request")
	public void updateOrder_alternatePickUpPersons() {

		// Skipping Testcase in production
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("PlaceOrder cannot be executed in Production");
		}
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]}}}}";

		
		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS_VALID");
		
		// Create Request
				String strPayloadUpdateOrder ="{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS") + "\","
						+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS") + "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
						+ ",\"alternatePickUpPersons\":[" +JsonString.getAlternatePickUpJson("VALID") + "]}}";

				// Post Request
				String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder, Server.Adapter, false);
				
//				Validate Response
				validator = new ResponseValidator(strResponseUpdateOrder);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully", "Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
				
		// Compare Open API
//		if (CompareOAPI) {
//			// Post the request
//			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
//			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);
//
//			// Compare the result
//			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
//		}
	}}
	
	//R8 projects scope
	
	@Test(groups = { "smoke", "smokeTest","regression","functional", "msm750" }, enabled = true, priority = 12, testName = "productsForDimension sortIDAsFeatured(1)",
			description = "Checking the products available While passing the sort as 1")
	public void sortIDAsPercentage7() {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=7";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");
		validator.nodeMatches("$.payload.sorts[6].ID", ".+", "sort ID should be 4 ");
		validator.nodeMatches("$.payload.sorts[6].active", ".+", "sort ID 7 should be active");		
		validator.nodeMatches("$.payload.sorts[6].name",".+","proper name should be displayed in response");
		validator.nodeMatches("$.payload.dimensions[1].name",".+","proper name should be displayed in response");
		validator.nodeMatches("$.payload.dimensions[1].label",".+","proper name should be displayed in response");
		validator.nodeMatches("$.payload.dimensions[2].name",".+","proper name should be displayed in response");
		validator.nodeMatches("$.payload.dimensions[2].label",".+","proper name should be displayed in response");
		
		

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=7";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 12, testName = "productsForDimension sortIDAsFeatured(1)",
			description = "Checking the products available While passing the sort as 1")
	public void CreateprofileWithinvalidPassword() {
	
		
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "123";
		
		// Create the Json Request for create profile
				String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID") + ","
						+ "\"password\":\"" + strPaswd  + "\","
								+ "\"email\":\"" + strEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";
			
				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateExpectedErrors("PROF9998", "The provided password does not meet the requirements.");

				// Compare Open API
				if (CompareOAPI) {
					String strEmailoapi = Utilities.getNewEmailID();
					
					
					// Create the Json Request for create profile
					String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
							+ JsonString.getCustomerNameJson("VALID") + ","
							+ "\"password\":\"" + strPaswd  + "\","
									+ "\"email\":\"" + strEmailoapi + "\",\"preferences\":{\"saleAlerts\":true}}}}";
					
					// Post the request
					String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
				}	
	
	}
	
	@DiscontinuedTest(groups = {"smoke", "smokeTest"}, enabled = false, priority = 2, testName = "OCB orderCalc with Single PromoCode",
			description = "Verify whether User is able to do V2 orderCalc with single promocode")

    public void OCB2_OrderCalc_SinglePromoCode() {
		
		
		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("OCB2 Testcase cannot be executed in Production");
				}


		TestData.getRunTimeData("SKU_CODE", false);
		
// Create a new profile through OAPI
	String strOCBEmail = Utilities.getNewEmailID();
	String strOCBPaswd = "Qwerty#1";
	Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.OpenApi);
	
// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'	
				
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.OpenApi, "ocbphase2_access_token_OAPI_singlepromo");
			
			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
			String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
					+ JsonString.getCartJson("VALID_ADD", testData.get("RUNTIME_SKU_CODE"), "1")
					+ "]}}}";
			
			//Validation UpdateCart Response
			String strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, Server.OpenApi, true, mapheader);
			validator = new ResponseValidator(strResponseOAPIAddCart);
			validator.validateNoErrors();
			Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID_singlepromo");
			Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPICARTITEM_ID_singlepromo");
			validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			

	// SiginIn to Adapter using the above created OCB profile
			Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "ocbphase2_access_token_adapter_singlepromo");
			
			
			//Update cart through Adapter
			mapheader.clear();
			mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));
			
	// Updating single PromoCode to the cart through Adapter
	
	String strPayloadAddCart1 = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
	+"\",\"paymentTypes\":{\"promoCodes\":{\"promoCode\":[{\"code\":\""+testData.get("OCB_Promocode")+"\",\"action\":\"add\"}]}}}}}";

	// Post the request for updateCart(ADD) with Single PromoCode using mapheader to Adapter
	String strResponseAddCart1 = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart1, Server.Adapter, true, mapheader);
	validator = new ResponseValidator(strResponseAddCart1);
	validator.validateNoErrors();
	validator.nodeMatches("$.payload.cart.cartID", "[0-9]+", "cartID should be present in the response");
	validator.nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code", ".*"+testData.get("OCB_Promocode")+".*", "Given Promocode should be present in the response");
	
	//Validating CartItem Details 
	validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
	validator.nodeEquals("$.payload.cart.cartItems[0].qty", "1", "Given Sku code should be present in the response");
	validator.nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
	validator.nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

mapheader.clear();
mapheader.put("access_token", testData.get("ocbphase2_access_token_adapter_singlepromo"));

// Update cart through Adapter

String strPayloadPlaceOrder = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\",\"cartID\":\"" + testData.get("OAPICART_ID_singlepromo")
	+ "\",\"cartItems\" : [{\"cartItemID\":\"" + testData.get("OAPICARTITEM_ID_singlepromo") + JsonString.getCartJson("VALID_CVV2_V2", testData.get("RUNTIME_SKU_CODE"), "1") + "],"
	+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"creditCards\" : ["
	+ JsonString.getPaymentTypeJson("AMEX")
	+ "],\"promoCodes\":[{\"code\":\"" + testData.get("OCB_Promocode") + "\"}]}}}}";

String strResponsePlaceOrderAdapter = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayloadPlaceOrder, Server.Adapter, true, mapheader);
validator = new ResponseValidator(strResponsePlaceOrderAdapter);
validator.validateNoErrors();
// validator.validateCartResponse();
validator.validatebillAddress();
validator.validateshipAddress();
validator.validateCustomerInfo();
validator.validatePaymentInfo();
validator.validateTotal();
validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");

validator.nodeMatches("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("OCB_Promocode"), "Given Promocode should be present in the response");


// GetCart from Adapter
String strResponseGetcart = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);

// Compare the Getcart from Adapter and OAPI
// GetCart response from OAPI
mapheader.put("access_token", testData.get("ocbphase2_access_token_OAPI_singlepromo"));
String strResponseOAPIGetCart = RestCall.getRequest(CART_OAPI, Server.OpenApi, true, mapheader);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponseGetcart, strResponseOAPIGetCart, "", true);

}
	
	@Test(groups = {"IPK","smoke", "smokeTest"}, enabled = true, priority = 1, testName = "Validate CategoryImageUrl in catalog V2 adapter",
			description = "Kohls iPad and Kiosk application user should get the categoryimageURL in catalog response")
	public void IPK_CategoryV2_ImageUrl() {

		String strURL = CATEGORY_V2_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeNotEquals("$.payload.categories[?(@.name=='For Home')].categoryImageUrl", null, "Category Image URL Should displayed in response");
		validator.nodeNotEquals("$.payload.categories[?(@.name=='small appliances')].categoryImageUrl", null, "Category Image URL Should displayed in response");
		validator.nodeNotEquals("$.payload.categories[?(@.name=='Mixers')].categoryImageUrl", null, "Category Image URL Should displayed in response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATEGORY_V2_OAPI;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "ipad_content","IPK" }, enabled = true, priority = 12, testName = "Content",
			description = "Kohls application user should get the response With all the valid parameters")
	public void Content_IPK() {

		String strURL = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=production";
		
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.module", "screensaver", "module should not be a null");
		validator.nodeMatches("$.payload.data..time", ".+", "module should not be a null");
		for(int i =1;i<=4;i++){
		validator.nodeEquals("$.payload.data["+i+"].type", "image", "Should contain Type");
		validator.nodeNotEquals("$.payload.data["+i+"].url", null, "Should not be Null");
		}
		
	}
	
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 2, testName = "Instore + Visa Card",
			description = "Relogin the same user and Verify whether user able to do order calc checkout for persisted CartItems with V2 end point and Payment method as PINPAD")
	public void OrderCalcV2_IPK() {
		TestData.getRunTimeData("SKU_CODE", false);
		
		String strPayloadOrderCalc = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID_INSTORE", testData.get("RUNTIME_SKU_CODE"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\":{\"paymentMethod\":\"PINPAD\"},\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		
		
		String strurl = ORDERCALC_ADAPTER_V2;
		
		String strResponseOrderCalcAdapter = RestCall.postRequest(strurl, strPayloadOrderCalc, Server.Adapter, false);
		validator = new ResponseValidator(strResponseOrderCalcAdapter);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "PINPAD","paymentmethod should be PINPAD");
		//validator.nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
		if (CompareOAPI) {
			
			String strurloapi = ORDERCALC_OAPI_V2;
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strurloapi, strPayloadOrderCalc, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseOrderCalcAdapter, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
	}
	}
	
	@Test(groups = {"smoke", "smokeTest"}, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", 
			description = "Verify whether payment details getting retrieved from MASTERPASS checkout registry using bopus item to placeorder response successfully")
	public void MasterPass_VISA_Bopus() {

		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		String strURL=PLACEORDERV2_ADAPTER+"&brandID=nativeapp"; ;
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE")) + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
				+ "]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp"; ;
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	}
	
//r9 PROJECTS
	
	@Test(groups = { "cmsappmessages","smoke", "smokeTest" }, enabled = true, priority = 12, testName = "Cmsappmessages",
			description = "Kohls application user should get the response With all the valid parameters")
	public void cmsappmessages() {

		String strURL = CMSAPPMESSAGES_ADAPTER;	 
		
	//	mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.save_on_next_order", ".+", "save order shoul be in response");
		validator.nodeMatches("$.payload.share_friend_reward", ".+", "share reward shoul be in response");
		validator.nodeMatches("$.payload.signup_email_message_1", ".+", "signup email shoul be in response");
		validator.nodeMatches("$.payload.follow_social_channel", ".+", "follow social channel shoul be in response");
		validator.nodeMatches("$.payload.theknot", ".+", "knot should be in response");
		validator.nodeMatches("$.payload.open_account_and_save", ".+", "open acc should be in response");
		validator.nodeMatches("$.payload.special_offer_in_year", ".+", "specialoffer should be in response");
		validator.nodeMatches("$.payload.account_created", ".+", "account created should be in response");
		validator.nodeMatches("$.payload.share_points_per_day", ".+", "share points should be in response");
		validator.nodeMatches("$.payload.reward_friend_join", ".+", "reward friend join should be in response");
		validator.nodeMatches("$.payload.signup_email_message_2", ".+", "signup email should be in response");
		
		
		
		
		
		
		//validator.ValidtaePosLocationResponse();
		
	}

//R12 projects
	
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 1, testName = "Password Verfication Positive Scenario",
			description = "Verfiy whether Proper Success Message is getting dispayed or not when we are passing proper EmaiId and password which is match with provided accesstoken in request")
	public void Password_Verification() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "PWD_access_token_adapter");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("PWD_access_token_adapter"));
					
		String strPayload = "userId=" + strEmail+ "&password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader,200);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Verification Success", "Password Verification Done");
		
	
	}
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 4, testName = "Get Profile with KCC Card with KP provision status = false",
			description = "Get Profile with KCC Card KP Provision = false")
	public void UpdateProfileWithKCC() {
		
		String Email = Utilities.getNewEmailID();
		String Paswd = "Kp@12345";
		Utilities.createProfile(Email, Paswd, Server.Adapter);
		
		Utilities.signInProfile(Email, Paswd, Server.Adapter, "Access_Token");
		

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Access_Token"));
		
		//Adding Payment to Profile
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KOHLS_CARD_UPDATE")
				+ ",\"preferredPaymentType\":\"true\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true,mapheader);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				
		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true,mapheader);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 2, testName = "PlaceOrder V2 with shipCount = 1",
			description = "Verify whether the user is getting all MFP signal attributes as part of response")
	public void MFPSignal_shipcount_1() {

		TestData.getRunTimeData("SKU_CODE", false);
		
		String strPayloadPLACEORDER = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [{\"shippingMethod\" : \"USSTD"+ JsonString.getCartJson("VALID_V2", testData.get("RUNTIME_SKU_CODE"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		String strResponsePLACEORDERAdapter = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayloadPLACEORDER, Server.Adapter, false);
		validator = new ResponseValidator(strResponsePLACEORDERAdapter);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462", "we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validateCustomerInfo();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.validateMFPSignalResponse("1",strPayloadPLACEORDER);
		}
		if (CompareOAPI) {
			// Compare the response from Adapter and OAPI
			String strResponseOAPIPlaceOrder = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadPLACEORDER, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponsePLACEORDERAdapter, strResponseOAPIPlaceOrder, "$.payload.order.orderNumber,$.payload.order.cartItems[0].cartItemID,$.payload.order.cartItems[0].shipmentGroupID,$.payload.order.shippingMethods[0].shipmentGroupID", true);
			}
			
		}
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc",
			description = "Performing orderCalc with Apple pay")
	public void applepayOrderCalc_V2() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		// Compare Open API
		if (CompareOAPI) {
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID") +"," + "\"email\":\"shankarc44@gmail.com\"," + "\"cartItems\" : ["+ JsonString.getCartJson("","VALID", testData.get("SKU_NORMAL"), "2") +"]," + "\"billAddress\" : "+ JsonString.getBillAddressJson("WI_MILWAUKEE") +"," + "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : [" + JsonString.getPaymentTypeJson("VISA") + "]}}}}";
			 */
			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 7, testName = "ApplePay PlaceOrder",
			description = "Placing an order with Apple pay")
	@Severity(SeverityLevel.BLOCKER)

	public void applepayPlaceOrder_V2() {
		// Skipping Testcase in production
				if (testData.get("OAPI_Environemnt").equals("Prod")) {
					throw new SkipException("PlaceOrder cannot be executed in Production");
				}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER")
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER3020", "The calculated Order total is different from the authorized amount.");
		} else {
			validator.validateNoErrors();
			validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateCustomerInfo();
			
			// Set orderNumber from response in test data
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_adapter");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY")
					+ "],\"paymentToken\":\"" + testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_oapi");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE1");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	@Test(groups = { "smoke", "smokeTest" }, enabled = true, priority = 4, testName = "InStoreFreeShipping Order Calc",
			description = "Do Ordercalculation for an order in Instore mode")
	public void InStoreFreeshippingOrderCalc_V2() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strOrderCalcRequest = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getBopusCartJsonShippingType("VALID", testData.get("SKU_BOPUS"), "2", "674", "USSTD") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]"
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strOrderCalcRequest, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_BOPUS"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	//	validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "User is in Instore mode");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strOrderCalcRequest, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	//R17.2
	
	@Test(groups= { "smoke", "smokeTest" }, enabled = true, priority = 4, testName = "Validate Address",
			description = "Validating with valid Address 1")
    public void HTTPSCall_AddressValidAddress1()
{
	//Create Request
	String strPayload="{\"payload\": {\"addresses\":[{\"ID\":\"1\","
			+ JsonString.getValidationAddressJson("VALID")
			+ "}]}}";
	
	//Post Request
	String strResponse= RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);
	
	//Validate Response
	validator=new ResponseValidator(strResponse);
	validator.validateNoErrors();
	validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
	validator.nodeEquals("$.payload.addresses[0].faults","null","faults should be null in the response");

}
	
	
	@Test(groups = {"smoke", "smokeTest"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withoutLimit_Channel_iosApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel iosApp and placement identification Horizontal")
	public void experiencesZeroSearch_withoutLimit_Channel_iosApp() {
		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
				"&plids=Horizontal"
				+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID sould be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");
	}
}
