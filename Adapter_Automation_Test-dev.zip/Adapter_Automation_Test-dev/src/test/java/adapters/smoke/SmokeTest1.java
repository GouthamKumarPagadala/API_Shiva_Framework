package test.java.adapters.smoke;

import static main.java.common.GlobalVariables.*;
import org.apache.commons.codec.binary.Base64;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import com.jayway.jsonpath.JsonPath;
import net.minidev.json.JSONArray;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Smoke Suite")
@Stories({ "Smoke Tests" })
public class SmokeTest1 {

	ResponseValidator validator;

	String userId = Utilities.getNewEmailID();
	String password = "Qwerty@123";

	/* Profile Scenario's */
	

	@TestCaseId("TC_SMOKE_CreateProfile_01")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 0, testName = "Create new Kohls Profile", description = "API Version - V1/profile \r\n TC Description - Create a kohls user profile succussfully \r\n Feature - Create account Sales alert Strong Password")
	public void Create_New_Kohls_Profile() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":" + JsonString.getCustomerNameJson("VALID")
				+ "," + "\"password\":\"" + password + "\"," + "\"email\":\"" + userId
				+ "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully",
				"Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {
			String openAPI_UserId = Utilities.getNewEmailID();

			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + "," + "\"password\":\"" + password + "\","
					+ "\"email\":\"" + openAPI_UserId + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@TestCaseId("TC_SMOKE_SignInProfile_02")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 1, testName = "SignIn Profile", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.Create_New_Kohls_Profile", description = "API Version - V2/profile<br /> TC Description - SignIn to the existing kohls profile succussfully<br /> Feature - SignIn Profile<br /> Sales Alert<br /> Wallet token")
	@Severity(SeverityLevel.BLOCKER)
	public void SignInProfile() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + userId + "&password=" + password;

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.walletId", "[0-9]+",
				"WalletID should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.preferences.saleAlerts", "true",
				"saleAlerts should be available in response");

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter_smoke");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "refresh_token_adapter");
		Utilities.setTestData(strResponse, "$.payload.response.wallet.token", "wallet_token_adapter");

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
		}

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret="
					+ testData.get("OPEN_API_SECRET_KEY") + "&userId=" + userId + "&password=" + password;
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi,
					false);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_oapi");
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_oapi_smoke");
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "refresh_token_oapi");
		}
	}

	@TestCaseId("TC_SMOKE_RefreshToken_03")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 2, testName = "Refresh Token", dependsOnMethods = "SignInProfile", description = "API Version - V2/profile<br /> TC Description - Refresh the token succussfully<br /> Feature - V2 Refresh Token")
	public void RefreshToken() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("refresh_token_adapter")
				+ "&email=" + userId + "&wallet_token="
				+ testData.get("wallet_token_adapter").replaceAll("\\+", "%2B").replaceAll("/", "%2F");

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		Utilities.setTestData(strResponse, "$.payload.access_token", "access_token_adapter");
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		// validator.nodeMatches("$.payload.response.signIn.token_type", ".+",
		// "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret="
					+ testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("refresh_token_oapi1")
					+ "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi,
					false);

		}

	}

	@TestCaseId("TC_SMOKE_Profile_PasswordVerification_04")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 1, testName = "Password Verfication", description = "API Version - V1/profile<br /> TC Description - Verify the existing user profile with valid password<br /> Feature - Password verification<br /> Storng password", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.SignInProfile")
	public void PasswordVerification() {

		String strPayload = "userId=" + userId + "&password=" + password;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Verification Success", "Password Verification Done");

	}

	@TestCaseId("TC_SMOKE_Profile_UpdateInfo_05")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 1, testName = "Update customer Profile", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.SignInProfile", description = "API Version - V1/profile<br /> TC Description - Update user profile with first and last name.<br /> Feature - Update profile")
	public void UpdateProfileInfo() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":" + JsonString.getCustomerNameJson("UPDATE")
				+ ",\"preferences\":{\"saleAlerts\":false}}}}";

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}

	@TestCaseId("TC_SMOKE_Profile_BillAddress_06")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 1, testName = "Update Bill Adress", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.SignInProfile", description = "API Version - V1/profile/billAddress<br /> TC Description - Adds a BillAddress to kohls user profile succussfully<br /> Feature - Update BillAddress")
	public void UpdateBillAddressToProfile() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":" + JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@TestCaseId("TC_SMOKE_Profile_ShipAddress_06")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 1, testName = "Update Shipping Address", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.SignInProfile", description = "API Version - V1/profile/shipAddress<br /> TC Description - Add a ShipAddress to kohls user profile succussfully<br /> Feature - Update ShipAddress")
	public void UpdateShipAddressToProfile() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":" + JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Id should be available in response");
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi,
					true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}

	@TestCaseId("TC_SMOKE_Profile_Payment_07")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 1, testName = "Update Payment Type", dependsOnMethods = "SignInProfile", description = "API Version - V1/profile/paymentType<br /> TC Description - Add a PaymentType(CC) to kohls user profile succussfully<br /> Feature - Update PaymentType")
	public void UpdatePaymentDetailsToProfile() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":" + JsonString.getPaymentTypeJson("UPDATE_KCC")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id_delete");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id_delete");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}

	@TestCaseId("TC_SMOKE_Profile_RetrieveInfo_08")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 3, testName = "Retrieve Profile Details", dependsOnMethods = {
					"UpdateProfileInfo", "UpdatePaymentDetailsToProfile", "UpdateShipAddressToProfile",
					"UpdateBillAddressToProfile" }, description = "API Version - V1/profile<br /> TC Description - Retrieves the Information of kohls user profile succussfully<br /> Feature - Get Profile Details")
	public void GetProfile() {

		// sign-In to the Profile
		Utilities.signInProfile(userId, password, Server.Adapter, "access_token_adapter");
		// Post the request
		String strPayload = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
		Utilities.setTestData(strPayload, "$.payload.profile.id", "author_id_adapter");

		// Validate Response
		validator = new ResponseValidator(strPayload);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.profile.email", ".+", "Profile email should be present");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "",
				"MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", "NewLastNameChandran",
				"LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", "NewNameShank",
				"FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.updatePaymentId", ".+",
				"UpdatePayment ID should be available in response");
		validator.nodeMatches("$.payload.profile.updateShipAddressId", ".+",
				"UpdateShipAddressID should be available in response");
		validator.nodeMatches("$.payload.profile.loyaltyPostalCode", ".+",
				"loyaltyPostalCode should be available in response");
		validator.nodeMatches("$.payload.profile.loyaltyId", ".+", "loyaltyId should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+",
				"saleAlerts should be available in response");
		validator.validateKPStatus(strPayload);
		// Setting the shipping address id
		Utilities.setTestData(strPayload, "$.payload.profile.shipAddresses[0].ID", "SHIP_ADDRESS_ID");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strPayloadOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true);
			Utilities.setTestData(strPayloadOAPI, "$.payload.profile.id", "author_id_openapi");
		}
	}

	@TestCaseId("TC_SMOKE_Profile_SubscribeSaleAlert_09")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "Subscribe Sale Alert", description = "API Version - v1/subscribe/saleAlerts<br /> TC Description - Subscribe Sale Alerts for kohls user profile succussfully<br /> Feature - Subscribe Sale Alerts")
	public void SubscribeSaleAlert() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{" + "\"email\":\"shankarc44@gmail.com\"," + "\"address\" : "
				+ JsonString.getBillAddressJson("IL_CHICAGO") + "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Subscribed successfully",
				"message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}

	@TestCaseId("TC_SMOKE_Profile_ForgotPassword_10")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 5, testName = "Forgot Password", description = "API Version - /v1/profile/forgotPassword<br /> TC Description - Kohls User gets a mail succussfully if he forgot password<br /> Feature - Forgot Password")
	public void UserForgotPassword() {

		String strURL = FORGOT_PASSWORD + userId;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Email to change password has been sent",
				"Verify whether the email change password message is displayed in response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = FORGOT_PASSWORD_OAPI + testData.get("PASSWORD_RESET_EMAIL");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@TestCaseId("TC_SMOKE_Profile_DeleteShipAddress_11")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 5, testName = "Delete Shipping Address", dependsOnMethods = "UpdateShipAddressToProfile", description = "API Version - v1/profile/shipAddress<br /> TC Description - Kohls user deletes shipAddress from User's Profile succussfully<br /> Feature - Delete ShipAddress")
	public void DeleteShippingAddress() {

		// Create the Json Request for Cart
		String strPayloadAddAddress = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE") + ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse1 = RestCall.simplePostRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayloadAddAddress,
				Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.validateNoErrors();
		Utilities.setTestData(strResponse1, "$.payload.id", "ShipAddressID");

		String strURL = PROFILE_SHIPPING_ADDRESS_ADAPTER + "/" + testData.get("ShipAddressID");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_SHIPPING_ADDRESS_OAPI + "/" + testData.get("shipping_id_oapi_smoke");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 200);
			// String strResponseBazaarVoice = "{\"payload\":" +strResponseOAPI
			// +"}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@TestCaseId("TC_SMOKE_Profile_DeletePayment_12")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 5, testName = "Delete Payment details", dependsOnMethods = {
					"UpdatePaymentDetailsToProfile", "SignInProfile",
					"GetProfile" }, description = "API Version - v1/profile/payments<br /> TC Description - Kohls user deletes payment details from User's Profile succussfully<br /> Feature - Delete Payment Details")
	public void DeletePaymentDetails() {

		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + testData.get("adapter_payment_id_delete");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		// Compare Open API
		if (CompareOAPI) {
			Utilities.signInProfile(testData.get("OAPI_EMAIL_ID"), testData.get("OAPI_EMAIL_PSWD"), Server.OpenApi,
					"access_token_oapi");

			// Get the request
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + testData.get("openAPI_payment_id_delete");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 200);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	/* Cart Scenario's */

	@TestCaseId("TC_SMOKE_Cart_AddToCart_13")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 2, testName = "Update Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.SignInProfile", description = "API Version - v1/cart<br /> TC Description - Kohls user able to add products to cart succussfully<br /> Feature - Update Cart")
	public void AddItemToCart() {

		TestData.getRunTimeData("SKU_CODE", true);

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("RUNTIME_SKU_CODE"), "1") + "]}}}";

		// Post the request
		String strResponse = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"),
				"Given Sku code should be present in the response");
		Utilities.setTestData(strResponse, "$.payload.cart.cartItems[0].cartItemID", "CART_ITEM_ID");
		Utilities.setTestData(strResponse, "$.payload.cart.cartID", "CART_ID");

		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(CART_OAPI, strPayload, Server.OpenApi, true);
			validator = new ResponseValidator(strResponseOAPI);
			Utilities.setTestData(strResponseOAPI, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPI, "$.payload.cart.cartID", "OAPICART_ID");

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.cart.cartItems[0].qty", true);
		}
	}

	@TestCaseId("TC_SMOKE_Cart_RetrieveCartItems_14")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 2, testName = "Get Cart", dependsOnMethods = "test.java.adapters.smoke.SmokeTest1.AddItemToCart", description = "API Version - v1/cart<br /> TC Description - Kohls user able to retrieve cart details succussfully<br /> Feature - Retrieve Cart")
	public void GetCartItems() {

		String strResponse = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCartResponse();
		validator.nodeEquals("$.payload.cart.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"),
				"Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CART_OAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.cart.cartID,payload.cart.cartItems.cartItemID", true);
		}
	}

	@TestCaseId("TC_SMOKE_Cart_RemoveCartItems_15")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 25, testName = "Remove Cart", dependsOnMethods = "GetCartItems", description = "API Version - v1/cart<br /> TC Description - As a Kohls user I want to remove cartItems from cart that was added earlier succussfully<br /> Feature - Remove Cart Items")
	public void RemoveCart() {
		Utilities.removeCart(Server.Adapter, testData.get("access_token_adapter"));
	}

	@TestCaseId("TC_SMOKE_SimultaneousCartUpdate_69")
	@Test(groups = { "qa_smoke"}, enabled = true, testName = "Add online Item to Cart and Update it to Bopus Item", description = "API Version - v1/cart<br /> TC Description - Verify whether the user is able to Add online Item to Cart and Update it to Bopus Item<br /> Feature - Simultaneous cart Update") 
			
	public void OnlineItemToBopusItem() {

		
		String strOCBPaswd = "Ocb@1234";
		String strOCBEmail = Utilities.getNewEmailID();
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter");

		// Add through Adapter
		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";

		// Post the request for updateCart(ADD) using mapheader to OAPI
		String strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
		Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");

		// Update cart through Adapter
		strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\""+testData.get("OAPICART_ID")+"\",\"cartItems\" :[{\"cartItemID\":\""+testData.get("OAPI_CART_ITEM_ID")+"\","
				+ "\"bopusItem\":\"true\",\"storeNum\":\""+testData.get("BOPUS_NORMAL_STORE")+""
				+ JsonString.getCartJson("UPDATE_ACTION", testData.get("BOPUS_NORMAL_SKU"), "1")
				+ "]}}}";
		String strResponseUpdateCartAdapter = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, Server.Adapter, true, mapheader);
		validator = new ResponseValidator(strResponseUpdateCartAdapter);
		validator.validateNoErrors();
		validator.validateCartResponse(testData.get("BOPUS_NORMAL_SKU"), "1", true, testData.get("BOPUS_NORMAL_STORE"));
	}
	
	@TestCaseId("TC_SMOKE_BZV_GetProductReview_16")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Get Review by AuthorID", description = "API Version - v1/bzv/review<br /> TC Description - Kohls user wants reviews of a product based on AuthorID succussfully<br /> Feature - Get Review by AuthorID")
	public void BVZ_Get_Product_reviews_By_AuthorID() {
		String strURL = AUTHORS_ID_ADAPTER + "AuthorId:2253999807330641";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].AuthorId", "[0-9]+", "AuthorId should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = AUTHORS_ID_BAZAARVOICE + "AuthorId:2253999807330641" + "&passkey="
					+ testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}
	
		
	/* Recommendations Services */

	@TestCaseId("TC_SMOKE_EDE_RecommendationIOS_17")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 1, testName = "EDE recomandation for IOS", description = "API Version - v1/ede/recommendations<br /> TC Description - As a Kohls User I want to get EDE recomandation for IOS succussfully<br /> Feature - Recommendations")
	public void EDE_Recommendation_Ios() {
		String strURL = RECOMMENDATION_EDE_ADAPTER + "?cid=" + testData.get("EDE_CID_ios") + "&pgid="
				+ testData.get("PGID") + "&plids=Horizontal1" + "&ccp="
				+ Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=", "%3D");

		mapheader.put("User-Agent", "Platform");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();

		// Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+",
					"id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+",
					"productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice",
					".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+",
					"displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime",
					".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+",
					"displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime",
					".+", "purchaseEndDateTime for the product should be displayed");
		}
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"),
				"CID sould be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
	}

	@TestCaseId("TC_SMOKE_EDE_RecommendationAndroid_18")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "EDE recomandation for Android", description = "API Version - v1/ede/recommendations<br /> TC Description - As a Kohls User I want to get EDE recomandation for Android succussfully<br /> Feature - Recommendations")
	public void EDE_Recommendation_Android() {
		String strURL = RECOMMENDATION_EDE_ADAPTER + "?cid=" + testData.get("EDE_CID_Android") + "&pgid="
				+ testData.get("PGID") + "&plids=Horizontal1" + "&ccp="
				+ Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=", "%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		// Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+",
					"id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+",
					"productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice",
					".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+",
					"displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime",
					".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+",
					"displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime",
					".+", "purchaseEndDateTime for the product should be displayed");
		}

		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"),
				"CID sould be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
	}

	@TestCaseId("TC_SMOKE_EDE_ExperienceZeroSearch_19")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Experiences ZeroSearch", description = "API Version - v1/ede/experiences<br /> TC Description - As a Kohls user i want to Get experiences for ZeroSearch succussfully<br /> Feature - EDE Experiences")
	public void EDE_Experiences_Zerosearch_Android() {
		String strURL = EXPERIENCES_EDE_ADAPTER + "?cid=" + testData.get("EXPERIENCE_CID1") + "&pgid="
				+ testData.get("EXPERIENCE_PGID") + "&plids=Horizontal" + "&ccp="
				+ Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=", "%3D");

		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		// Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+",
					"id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+",
					"productTitle for the product should not null");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+",
					"regular minPrice for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+",
					"displayBegDateTime for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+",
					"purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+",
					"displayEndDateTime for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+",
					"purchaseEndDateTime for the product should be displayed");
		}
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"),
				"CID sould be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"),
				"Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");

	}

	@TestCaseId("TC_SMOKE_Recommendation_20")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "Recommendation", description = "API Version - v1/recommendation<br /> TC Description - Kohls user will get the recommendation products succussfully<br /> Feature - Get recommendation")
	public void Recommendation() {

		// TestData.getRunTimeData("WEB_ID", true);
		String strURL = RECOMMENDATION_ADAPTER + testData.get("RECOMEND_TYPE") + "&webID="
				+ testData.get("RECOMMENDATION_WEBID");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.payload.recommendations";
		System.out.println("json recommendations=" + json);
		validator.nodeMatches("$.payload.recommendations[0]", ".+",
				"Verifying recommendation tye is same as passed in the request");

	}

	@TestCaseId("TC_SMOKE_ValidateAddress_21")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "Validate Address", description = "API Version - v1/validation<br /> TC Description - Kohls user validates the Address succussfully<br /> Feature - Address validation")
	public void ValidateAddress() {
		// Create Request
		String strPayload = "{\"payload\": {\"addresses\":[{\"ID\":\"1\","
				+ JsonString.getValidationAddressJson("VALID") + "}]}}";

		// Post Request
		String strResponse = RestCall.postRequest(VALIDATION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.addresses[0].ID", "1", "message should be present in the response");
		validator.nodeEquals("$.payload.addresses[0].faults", "null", "faults should be null in the response");

	}

	@TestCaseId("TC_SMOKE_KohlsCashBalance_22")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "Kohls Cash Balance", description = "API Version - v1/balance<br /> TC Description - Kohls user wants to get the balance of KohlsCash succussfully<br /> Feature - Balance KohlsCash")

	public void Check_Kohls_Cash_Balance() {

		String arr[] = TestData.createKohlsCash(10);
		// Create URL Request
		String strURL = BALANCE_ADAPTER + "/" + arr[0] + "/" + "balance";

		// Get Request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateKohlsCashBalance(arr[0]);
	}

	/* CMS Details */

	@TestCaseId("TC_SMOKE_CMS_HomePageDetails_23")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "cms", description = "API Version - v1/cms<br /> TC Description - Kohls user wants to get Content Management System page details succussfully<br /> Feature - Content Management System Page Details")
	public void CMS_Homepage_PageDetials() {

		String strURL = CMS_ADAPTER + testData.get("CMS_HOME_CAMPAIGN") + "&pageName=" + testData.get("CMS_PAGE_NAME");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.totalEntries[0]", "[[0-9]+]", "Store
		// Name should be present in the response");
		validator.nodeEquals("$.payload.poolName", "nativehome",
				"Verifying page name is same as passed in the request");
		validator.nodeEquals("$.payload.responseMessage", "Success",
				"Response Message should be available in the response");
		validator.nodeMatches("$.payload.entries[0]", ".+", "Entries should be present in the response");

	}

	@TestCaseId("TC_SMOKE_CMS_HomePageAppMsg_24")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Cmsappmessages", description = "API Version - v1/resources/appmessages<br /> TC Description - As a Kohls user I want to get Content Management System appmessages succussfully<br /> Feature - Content Management System Appmessages")
	public void CMS_Homepage_AppMessages() {

		String strURL = CMSAPPMESSAGES_ADAPTER;

		// mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.save_on_next_order", ".+", "save order shoul be in response");
		validator.nodeMatches("$.payload.share_friend_reward", ".+", "share reward shoul be in response");
		validator.nodeMatches("$.payload.signup_email_message_1", ".+", "signup email shoul be in response");
		validator.nodeMatches("$.payload.follow_social_channel", ".+", "follow social channel shoul be in response");
		validator.nodeMatches("$.payload.theknot", ".+", "knot should be in response");
		validator.nodeMatches("$.payload.open_account_and_save", ".+", "open acc should be in response");
		validator.nodeMatches("$.payload.special_offer_in_year", ".+", "specialoffer should be in response");
		validator.nodeMatches("$.payload.account_created", ".+", "account created should be in response");
		validator.nodeMatches("$.payload.share_points_per_day", ".+", "share points should be in response");
		validator.nodeMatches("$.payload.reward_friend_join", ".+", "reward friend join should be in response");
		validator.nodeMatches("$.payload.signup_email_message_2", ".+", "signup email should be in response");

	}

	@TestCaseId("TC_SMOKE_Product_GetProductDetails_25")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "productsForDimension", description = "API Version - v1/catalog<br /> TC Description - As a Kohls user I want to get Products based on Category ID succussfully<br /> Feature - PMP with Particular Category")
	public void Get_Product_with_Dimention() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("DIMENSION_ID") + "?limit=24&offset=1&sortID=3";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("DIMENSION_ID") + "?limit=24&offset=1&sortID=3";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@TestCaseId("TC_SMOKE_Catalog_GetCatalogDetails_26")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 12, testName = "productsForCategoryID [All Categories]", description = "API Version - v1/catalog<br /> TC Description - As a Kohls user I want to get details of catalog page succussfully<br /> Feature - Get Catalog Page,<br /> Grouppricing,<br /> SuppressedPricing")
	public void GetCatalogDetails() {

		// Post the request
		String strResponse = RestCall.getRequest(CATALOG_ADAPTER, Server.Adapter, false);
		System.out.println("Adapter: " + strResponse);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		int count = JsonPath.read(strResponse, "$.limit");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
    	  
    	  String suppressed= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].prices[0].isSuppressed").toString();
          String WebId= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].webID").toString();
        	 if(suppressed.equals("true"))
     	 {
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed text should be present as it is suppressed Product - "+WebId);
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].promotion","null","Promotion should be null as it is suppressed product");
     	 }
     	 else if(suppressed.equals("false"))
     	 {
        	validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","null","Suppressed text should be null- "+WebId);
        	
        }
      	//System.out.println(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices"));
      	if(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices").equals("[]"))
	        	continue;
      	String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePrice").toString();
      	//System.out.println(salePriceStatus);
      	//validating SuppressedPrice 
      	             
	       if(salePrice.equals("null"))
			
			{
	    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
			
			}
	       
	       else
	       {
	    	   validator.nodeNotEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null"); 
	       }
	    }}
		catch(Exception e)
			{
			
			
			}
	 
		validator.nodeNotEquals("$.count", "0", "Categories should be present in the response");
		validator.nodeEquals("$.limit", "96", "Limit should be available in response");
		validator.nodeMatches("$.payload.sorts[0]", ".+", "Sorts should be present in the response");
		validator.nodeMatches("$.payload.dimensions[0]", ".+", "Dimensions should be present in the response");
		validator.nodeMatches("$.payload.products[0]", ".+", "Products should be present in the response");
		JSONArray products = JsonPath.read(strResponse, "$.payload.products");
		int productsSize = products.size();
		for (int i = 0; i < productsSize; i++) {
			validator.nodeMatches("$.payload.products[" + i + "].webID", "[0-9a-zA-Z]+", "webID should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].productTitle", ".*",
					"productTitle should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image", ".+", "image should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image.url", ".+", "image URL should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image.height", "[0-9]+",
					"image height should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].image.width", "[0-9]+",
					"image width should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].regularPrice.minPrice", ".+",
					"regular minPrice should be displayed");
			// validator.nodeMatches("$.payload.products[" + i +
			// "].prices[0].salePrice.minPrice", ".+", "sale minPrice should be
			// displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].regularPriceType", ".+",
					"regularPriceType should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].statusCode", "[0-9]+",
					"statusCode should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].priceCode", ".+",
					"priceCode  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].salePriceStatus", ".+|null",
					"salePriceStatus  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].isSuppressed", "true|false",
					"isSuppressed  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].displayBegDateTime",
					"[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+",
					"displayBegDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].displayEndDateTime",
					"[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+",
					"displayEndDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].purchaseBegDateTime",
					"[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+",
					"purchaseBegDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].purchaseEndDateTime",
					"[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} -[0-9]{4}+",
					"purchaseEndDateTime  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].isCurrentPrice", "true|false",
					"isCurrentPrice  should be displayed");
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].isPriceInstore", "true|false",
					"isInstorePrice  should be displayed");
		}
		// Compare Open API
		if (CompareOAPI) {
			// Get the request
			String strResponseOAPI = RestCall.getRequest(CATALOG_OAPI, Server.OpenApi, false);
			System.out.println(strResponseOAPI);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}

	@TestCaseId("TC_SMOKE_Product_InstoreLookUp_27")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 6, testName = "InStore SingleProductDetails", description = "API Version - v1/products<br /> TC Description - As a Kohls user I want to Lookup the Product is available in InStore  succussfully<br /> Feature - InStore Product Lookup")
	public void Instore_Product_lookup() {

		TestData.getRunTimeData("INSTORE_SKU_CODE", false);

		String strSku = testData.get("RUNTIME_INSTORE_SKU_CODE") == null
				? testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE") : testData.get("RUNTIME_INSTORE_SKU_CODE");

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "?skuCode=" + testData.get("AVAILABLE_ONLINE_REBATES_SKUCODE")
				+ "&skuDetail=true&storeNum=" + testData.get("INSTORE_STORE_NUMBER");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.regularPrice", ".+",
				"Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.regularPrice", ".+",
				"Regular Price should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "?skuCode=" + strSku + "&skuDetail=true&storeNum="
					+ testData.get("INSTORE_STORE_NUMBER");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@TestCaseId("TC_SMOKE_Product_InstoreOfferLookUp_28")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 6, testName = "InStore Offer ProductDetails", description = "API Version - v1/products<br /> TC Description - As a Kohls user I want to Lookup the offer Product is available in InStore succussfully<br /> Feature - InStore Offer Product Lookup,<br /> Grouppricing")
	public void InStore_Offer_Product_LookUp() {

		// TestData.getRunTimeData("INSTORE_REBATE_WEB", false);

		String strWebID = testData.get("RUNTIME_INSTORE_WEB_REBATE") == null
				? testData.get("AVAILABLE_ONLINE_BOGO_WEBID") : testData.get("RUNTIME_INSTORE_WEB_REBATE");

		String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("AVAILABLE_ONLINE_BOGO_WEBID")
				+ "?storeNum=" + testData.get("INSTORE_STORE_NUMBER") + "&skuDetail=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.salePrice");
	    if(salePrice!="null")
			
			{
			 validator.nodeNotEquals("$.payload.products[0].price.salePriceStatus", "null", " sale price Status should not be null");
			     
			 }
		validator.nodeMatches("$.payload.products[0].SKUS[0].price.regularPrice", ".+",
				"Regular Price should be available in online in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.regularPrice", ".+",
				"Regular Price should be available in store in the response");
		validator.nodeMatches("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion", ".+",
				"Bogo Promotion should be available in store in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = SINGLE_PRODUCT_DETAILS_OAPI + "/" + strWebID + "?storeNum="
					+ testData.get("INSTORE_STORE_NUMBER") + "&skuDetail=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}

	@TestCaseId("TC_SMOKE_Product_InstoreProductLookUpByDimension_29")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 14, testName = "Instore Products for Dimension", description = "API Version - v1/catalog<br /> TC Description - As a Kohls user I want to get Instore product details while passing dimension value succussfully<br /> Feature - Get Instore Product by Dimension")
	public void InstoreProductsByDimension() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("DIMENSION_ID_01") + "?limit=10&offset="
				+ testData.get("PRODUCT_OFFSET") + "&sortID=" + testData.get("PRODUCT_SORT_ID") + "&storeNum="
				+ testData.get("STORE_NUM_01") + "&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		// Changed nodevalidateprice to node matches
		validator.nodeMatches("$.payload.products[0].prices[0].isPriceInstore", ".+",
				"Verify whether the online price is not getting displayed as null in response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("DIMENSION_ID_01") + "?limit=10&offset="
					+ testData.get("PRODUCT_OFFSET") + "&sortID=" + testData.get("PRODUCT_SORT_ID") + "&storeNum="
					+ testData.get("STORE_NUM_01") + "&inStoreEnabled=true";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	/* Bazaar Voice Scenario's */

	@TestCaseId("TC_SMOKE_BZV_SubmitReview_30")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Submit Review", dependsOnMethods = "GetProfile", description = "API Version - v1/bzv/reviews<br /> TC Description - As a Kohls user I want to submit the review for a product succussfully<br /> Feature - Submit Review")
	public void SubmitReview() {

		System.out.println("Author Id2" + testData.get("author_id_adapter_smoke1"));
		// Create Request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserNickname=Razia" + System.nanoTime() + "&SendEmailAlertWhenCommented=true&" + "Title=diff&"
				+ "IsRecommended=true&Rating_Quality=2&" + "city=" + testData.get("WI_BILLING_CITY") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
				// + "UserId=Razia"+System.nanoTime()
				+ "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&" + "authorId="
				+ testData.get("author_id_adapter") + "&" + "ReviewText=Very good product.&" + "UserLocation="
				+ testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
				+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
				+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
				+ "contextdatavalue_Age=18to24";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Review.SubmissionTime", ".+",
				"Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Review.SendEmailAlertWhenPublished", "true",
				"SendEmailAlertWhenPublished should be present in the response");
		validator.nodeMatches("$.payload.Review.SendEmailAlertWhenCommented", "true",
				"SendEmailAlertWhenCommented should be present in the response");
		validator.nodeMatches("$.payload.Review.ReviewText", "Very good product.",
				"ReviewText should be present in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action="
					+ testData.get("ACTION") + "&" + "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "UserNickname=Razia" + System.nanoTime() + "&SendEmailAlertWhenCommented=true&" + "Title=diff&"
					+ "IsRecommended=true&Rating_Quality=2&" + "city=" + testData.get("WI_BILLING_CITY") + "&"
					+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&" + "UserId=Razia" + System.nanoTime()
					+ "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&" + "authorId="
					+ testData.get("author_id_openapi") + "&" + "ReviewText=Very good product.&" + "UserLocation="
					+ testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
					+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
					+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
					+ "contextdatavalue_Age=18to24";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice,
					Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar,
					"payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_SubmitFeedback_31")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 14, testName = "Submit Feedback", description = "API Version - v1/bzv/feedback<br /> TC Description - As a Kohls user I want to submit the feedback for a product succussfully<br /> Feature - Submit Feedback")
	public void SubmitFeedback() {

		// Create Request
		String strPayload = "action=" + testData.get("ACTION") + "&" + "ContentType="
				+ testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&" + "ContentId=" + testData.get("CONTENT_ID") + "&"
				+ "UserId=" + testData.get("author_id_adapter") + "&" + "FeedbackType=" + testData.get("FEEDBACK_TYPE")
				+ "&" + "Vote=" + testData.get("VOTE");

		// Prod has diffrent content ID, so using different payload
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			strPayload = "ContentType=question&ContentId=1564686&UserId=5678&FeedbackType=helpfulness&Vote=Positive";
		}

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action="
					+ testData.get("ACTION") + "&" + "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
					+ "ContentId=" + testData.get("CONTENT_ID") + "&" + "UserId=" + testData.get("author_id_openapi")
					+ "&" + "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&" + "Vote=" + testData.get("VOTE");

			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_FEEDBACK_BAZAARVOICE, strPayloadBazVoice,
					Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar,
					"payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId",
					true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_SubmitQuestion_32")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 13, testName = "Submit Question", description = "API Version - v1/bzv/questions<br /> TC Description - As a Kohls user I want to submit a Question for a product succussfully<br /> Feature - Submit Question")
	public void BVZ_Submit_Question() {

		// Create Request
		String strPayload = "contextdatavalue_stateOfResidence=AZ&" + "score=" + testData.get("SCORE") + "&" + "action="
				+ testData.get("ACTION") + "&" + "city=" + testData.get("CITY") + "&" + "UserEmail="
				+ testData.get("ADAPTER_EMAIL_ID") + "&" + "ProductId=" + testData.get("PRODUCT_ID") + "&" + "Rating="
				+ testData.get("RATING") + "&" + "CampaignId=" + testData.get("CAMPAIGN_ID") + "&" + "authorId="
				+ testData.get("AUTHOR_ID") + "&" + "User=" + testData.get("USER") + "&" + "UserNickname=Sachin"
				+ Utilities.getRandom() + "&QuestionSummary=Is this product is really good.";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", ".+",
				"Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Question.QuestionSummary", "Is this product is really good.",
				"Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Form[0].Id", ".+", "Form Id  should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "Has Errors should be false in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=9ngrf7rngkhm4a7r6n4uvxaq&contextdatavalue_stateOfResidence=AZ&"
					+ "AuthorId:2253999807330641" + "score=" + testData.get("SCORE") + "&" + "action="
					+ testData.get("ACTION") + "&" + "city=" + testData.get("CITY") + "&" + "UserEmail="
					+ testData.get("ADAPTER_EMAIL_ID") + "&" + "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "Rating=" + testData.get("RATING") + "&" + "CampaignId=" + testData.get("CAMPAIGN_ID") + "&"
					+ "authorId=" + testData.get("AUTHOR_ID") + "&" + "User=" + testData.get("USER") + "&"
					+ "UserNickname=Sachin" + Utilities.getRandom()
					+ "&QuestionSummary=Is this product is really good.";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_QUESTION_BAZZARVOICE, strPayloadBazVoice,
					Server.BazaarVoice, false);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar,
					"payload.Question.SubmissionTime,payload.Data.Fields.usernickname.Value", true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_SubmitAnswer_33")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 14, testName = "Submit Answer", description = "API Version - v1/bzv/Answers<br /> TC Description - As a Kohls user I want to submit Answer for a product succussfully<br /> Feature - Submit Answer")
	public void BVZ_Submit_Answer() {

		// Create Request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&" + "UserId=" + testData.get("USER_ID") + "&"
				+ "AnswerText=Frankly speaking, I dont know&" + "UserNickname=Sachin" + System.nanoTime();

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", ".+",
				"Submission Time should be present in the response");
		validator.nodeMatches("$.payload.Answer.AnswerText", "Frankly speaking, I dont know",
				"AnswerText should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "Submission Id  should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors  should be false in the response");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&QuestionId=498352&passkey=9ngrf7rngkhm4a7r6n4uvxaq&action="
					+ testData.get("ACTION") + "&" + "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&" + "UserId="
					+ testData.get("USER_ID") + "&" + "AnswerText=Frankly speaking, I dont know&"
					+ "UserNickname=Sachin" + System.nanoTime();
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_ANSWER_BAZZARVOICE, strPayloadBazVoice,
					Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse,
			// strResponseBazaar,
			// "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId",
			// true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_GetProductReview_34")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "get Reviews For Product", description = "API Version - v1/bzv/reviews<br /> TC Description - As a Kohls user I want to get reviews for a product succussfully<br /> Feature - Get Reviews")
	public void BVZ_Get_Product_Reviews() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"),
				"Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR")
					+ "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice,
					"payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_GetProductQA_35")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "get QA For Product", description = "API Version - v1/bzv/QandAs<br /> TC Description - As a Kohls user I want to get Questions and Answers for a product succussfully<br /> Feature - Get Questions and Answers")
	public void BVZ_Get_Product_QA() {

		String strURL = GETQA_PRODUCT_ADAPTER_FILTER + testData.get("PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results", ".+", "Results should be present in the response");
		validator.nodeMatches("$.payload.Results[0].QuestionSummary", ".+",
				"Question Summary should be present in the response");
		validator.nodeMatches("$.payload.Results[0].SubmissionId", ".+",
				"Submission Id should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", ".+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[0].UserNickname", ".+",
				"UserNickName Summary should be present in the response");
		// Compare Bazzar Voice
		if (CompareOAPI) {

			// Create the Json Request

			String strURLBAZAARVOICE = GETQA_PRODUCT_BAZZ + "passkey=9ngrf7rngkhm4a7r6n4uvxaq&" + "apiversion=5.4&"
					+ "&ProductId=" + testData.get("PRODUCT_ID");
			// Post the request
			String strResponseBAZZ = RestCall.getRequest(strURLBAZAARVOICE, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseBAZZ + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice,
					"payload.Results.SubmissionTime", true);
		}

	}

	@TestCaseId("TC_SMOKE_BZV_SubmitAnswerForm_36")
	@Test(groups = { "qa_smoke" }, enabled = true, testName = "get Submit Answer Form ",

			description = "API Version - v1/bzv/answerform<br /> TC Description - As a Kohls user I want to get Answer Form for a product based on QuestionID succussfully<br /> Feature - Get Answer Form")
	public void GetSubmitAnswerForm() {

		// Get the request
		String strURL = GET_SUBMIT_ANSFORM_ADAPTER + testData.get("QUESTION_ID") + "&ProductId="
				+ testData.get("PRODUCT_ID_BAZAAR");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", ".+",
				"Submission Time should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors  should be false in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "passkey=" + testData.get("BAZAAR_VOICE_PASSKEY")
					+ "&apiversion=5.4" + "&QuestionId=" + testData.get("QUESTION_ID") + "&ProductId="
					+ testData.get("PRODUCT_ID_BAZAAR");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse,
			// strResponseBazaarVoice,
			// "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId",
			// true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_SubmitQuestionForm_37")
	@Test(groups = { "qa_smoke" }, enabled = true, testName = "get Submitted Question Form ",

			description = "API Version - v1/bzv/questionform<br /> TC Description - As a Kohls user I want to get Question Form for a product succussfully<br /> Feature - Get Question Form")
	public void GetSubmitQuestionForm() {

		String strURL = GET_SUBMIT_QFORM_ADAPTER + testData.get("PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", ".+",
				"Submission Time should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors  should be false in the response");
		validator.nodeMatches("$.payload.Question.SendEmailAlertWhenPublished", "true",
				"SendEmailAlertWhenPublished should be present in the response");
		validator.nodeMatches("$.payload.Question.SendEmailAlertWhenAnswered", "true",
				"SendEmailAlertWhenAnswered should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "passkey=" + testData.get("BAZAAR_VOICE_PASSKEY")
					+ "&apiversion=5.4" + "&ProductId=" + testData.get("PRODUCT_ID");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse,
			// strResponseBazaarVoice,
			// "payload.Question.SubmissionTime,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId",
			// true);
		}
	}

	@TestCaseId("TC_SMOKE_BZV_SyndicateContentAsTrue_38")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 0, testName = "Syndicated contest - Flag is true", description = "API Version - v1/bzv/webID<br /> TC Description - As a Kohls user I want to get Bazaar Voice Synticate Content for a product succussfully<br /> Feature - Get Synticate Content")
	public void BVZ_SyndicateContent_Flag_True() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR")
				+ "&Limit=6&Offset=0&Filter=IsSyndicated:true";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"),
				"Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[1].IsSyndicated", "true", "IsSyndicated should be True");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.Name", ".+", "Name should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.LogoImageUrl", ".+",
				"LogoImagineUrl should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.ContentLink", ".+",
				"ContentLink shouldnt be null");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR")
					+ "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Limit=6&Offset=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice,
					"payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}

	}

	@TestCaseId("TC_SMOKE_Caching_GetCacheFlushStatus_39")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "getCacheFlushStatus", description = "API Version - v1/caching/stats<br /> TC Description - As a Kohls user I want to get cache flush status succussfully<br /> Feature - Get Cache Flush Status")
	public void GetCacheFlushStatus() {

		String strURL = CACHEFLUSH_CATALOG_ADAPTER + testData.get("CATALOG");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.catalogs", ".+", "Catalogs should be present in the response");

		// Post the request
		String strResponse1 = RestCall.getRequest(strURL, Server.Adapter, false);

		// Compare the result
		Utilities.compareAdaterOpenApiResponse(strResponse, strResponse1, "", true);
	}

	@TestCaseId("TC_SMOKE_Resource_ConfigFileMonetization_40")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "ConfigMonetization", description = "API Version - v1/resources/monetization<br /> TC Description - As a Kohls user I want to get monetization details succussfully<br /> Feature - Get Monetization")
	public void ConfigFile_Monetization() {

		String strURL = CONFIG_MONETIZATION;

		// Post the request for config adapter
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true);
		Utilities.getEnabledFeatures(strResponse);

		// Post the request for messages.log
		// String strResponseMessagesLog =
		// RestCall.simpleGetRequest(MESSAGES_LOG, Server.Adapter, false);
		// Utilities.getMFPVersion(strResponseMessagesLog);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.nodeEquals("$.payload.env", "prod", "Environment should be test");
			validator.nodeEquals("$.payload.networkId", "17763952", "Network ID should be17763952.");
			validator.nodeEquals("$.payload.channel", "mobileapp", "Channel should be mobileapp");
			return;
		} else {
			validator.nodeEquals("$.payload.channel", "mobileapp", "Channel should be mobileapp");
			validator.nodeEquals("$.payload.env", "test", "Environment should be test");
			validator.nodeEquals("$.payload.networkId", "17763952", "Network ID should be17763952.");

			validator.nodeEquals("$.payload.home.adUnit", "/homepage", "Adunit is Home page");
			validator.nodeMatches("$.payload.home.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.home.size", "[\"banner\"]", "Size should be Banner");
			validator.nodeEquals("$.payload.home.dimensions", "[[320,50]]", "Dimention should be 320, 50 in home page");
			validator.nodeEquals("$.payload.home.pos", "[\"middle\"]",
					"Ad should be displayed in the middle of home page");
			validator.nodeEquals("$.payload.home.pgtype", "home", "Page type should be Home");

			validator.nodeEquals("$.payload.pmp.isEnabled", "true", "Adunit is PMP");
			validator.nodeEquals("$.payload.pmp.size", "[\"banner\"]", "Type of add is Banner");
			validator.nodeEquals("$.payload.pmp.dimensions", "[[320,50]]", "Dimention should be 320, 50 in PMP page");
			validator.nodeEquals("$.payload.pmp.pos", "[\"bottom\"]", "Ad should be displayed in the Bottom of PMP");
			validator.nodeEquals("$.payload.pmp.pgtype", "pmp", "Page type should be PMP");

			validator.nodeEquals("$.payload.col.isEnabled", "true", "Adunit is in collection page");
			validator.nodeEquals("$.payload.col.size", "[\"banner\"]", "Type of add is Banner in collection page");
			validator.nodeEquals("$.payload.col.dimensions", "[[320,50]]",
					"Dimention should be 320, 50 in collection page");
			validator.nodeEquals("$.payload.col.pos", "[\"bottom\"]",
					"Ad should be displayed in the Bottom of collection page");
			validator.nodeEquals("$.payload.col.pgtype", "col", "Page type should be Collection");

			validator.nodeEquals("$.payload.pdp.isEnabled", "true", "Adunit is in PDP page");
			validator.nodeEquals("$.payload.pdp.size", "[\"banner\"]", "Type of add is Banner in PDP page");
			validator.nodeEquals("$.payload.pdp.dimensions", "[[320,50]]", "Dimention should be 320, 50 in PDP page");
			validator.nodeEquals("$.payload.pdp.pos", "[\"bottom\"]",
					"Ad should be displayed in the Bottom of PDP page");
			validator.nodeEquals("$.payload.pdp.pgtype", "pdp", "Page type should be PDP");

			validator.nodeEquals("$.payload.search.isEnabled", "true", "Adunit in search bar page");
			validator.nodeEquals("$.payload.search.size", "[\"banner\"]", "Type of add is Banner in Search bar");
			validator.nodeEquals("$.payload.search.dimensions", "[[320,50]]",
					"Dimention should be 320, 50 in search page");
			validator.nodeEquals("$.payload.search.pos", "[\"bottom\"]",
					"Ad should be displayed in the Bottom of Search page");
			validator.nodeEquals("$.payload.search.pgtype", "search", "Page type should be search page");

			validator.nodeEquals("$.payload.zerosearch.adUnit", "/zerosearch",
					"Adunit in search bar page when search result is zero");
			validator.nodeEquals("$.payload.zerosearch.size", "[\"banner\"]", "Type of ad is Banner in Search bar");
			validator.nodeEquals("$.payload.zerosearch.dimensions", "[[320,50]]",
					"Dimention should be 320, 50 in zero search page");
			validator.nodeEquals("$.payload.zerosearch.pos", "[\"bottom\"]",
					"Ad should be displayed in the Bottom of zero Search page");
			validator.nodeEquals("$.payload.zerosearch.pgtype", "zerosearch",
					"When the user searches for any product and zero product found");

			validator.nodeEquals("$.payload.oc.adUnit", "/order_confirmation", "Adunit in order confirmation page");
			validator.nodeMatches("$.payload.oc.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.oc.size", "[\"banner\"]", "Type of ad is Banner in confirmation page");
			validator.nodeEquals("$.payload.oc.dimensions", "[[320,50]]",
					"Dimention should be 320, 50 in order confirmation page");
			validator.nodeEquals("$.payload.oc.pos", "[\"bottom\"]",
					"Ad should be displayed in the Bottom of confirmation page");
			validator.nodeEquals("$.payload.oc.pgtype", "oc", "Page type should be oc");

			validator.nodeEquals("$.payload.store_locator.adUnit", "/store_locator", "Adunit in store locator page");
			validator.nodeMatches("$.payload.store_locator.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.store_locator.size", "[\"banner\"]",
					"Type of ad is Banner in store locator page");
			validator.nodeEquals("$.payload.store_locator.dimensions", "[[320,50]]",
					"Dimention should be 320, 50 in order confirmation page");
			validator.nodeEquals("$.payload.store_locator.pos", "[\"bottom\"]",
					"Ad should be displayed in the Bottom of confirmation page");
			validator.nodeEquals("$.payload.store_locator.pgtype", "store_locator",
					"Page type should be store_locator");

			validator.nodeEquals("$.payload.deals.adUnit", "/ROS", "Adunit in ros");
			validator.nodeMatches("$.payload.deals.isEnabled", "true|false", "Value should be true or false");
			validator.nodeEquals("$.payload.deals.dimensions", "[[320,50]]",
					"Dimention should be 320, 50 in deals page");
			validator.nodeEquals("$.payload.deals.pos", "[\"middle\"]",
					"Ad should be displayed at the middle of the page");
			validator.nodeEquals("$.payload.deals.pgtype", "sevent", "Page type should be sevent");
			validator.nodeEquals("$.payload.deals.pgname", "coupons-deals.jsp", "Page name should be pgname");

		}
	}

	@TestCaseId("TC_SMOKE_Config_ConfigFileClient_41")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 17, testName = "ConfigProperties", description = "API Version - v1/configures/client<br /> TC Description - As a Kohls user I want to get client config Property details succussfully<br /> Feature - Get Client Config properties")
	public void Config_File_Client() {

		String strURL = CONFIG_ADAPTER; // + testData.get("CONFIG");

		// Post the request for config adapter
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		Utilities.getEnabledFeatures(strResponse);

		// Post the request fro messages.log
		// String strResponseMessagesLog =
		// RestCall.simpleGetRequest(MESSAGES_LOG, Server.Adapter, false);
		// Utilities.getMFPVersion(strResponseMessagesLog);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.config.appAndroidVersion", ".+",
				"appAndroidVersion should be present in the response");
	}

	/* Price Scenario's */
	@TestCaseId("TC_SMOKE_Price_ByWebID_42")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "Price By WebId", description = "API Version - v1/price<br /> TC Description - As a Kohls user I want to get price details of a Product succussfully<br /> Feature - Get Price by WebID,<br /> Grouppricing,<br /> SuppressedPricingText")
	public void Get_Price_By_WebID() {

		TestData.getRunTimeData("WEB_ID", false);

		String strURL = PRICE_WEB_ADAPTER + "/" + testData.get("RUNTIME_WEB_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.products[0].webID", testData.get("RUNTIME_WEB_ID"),
				"Given webID should be present in the response");
		validator.validatepriceDetails();
		String isSuppressed = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].isSuppressed").toString();
		if(isSuppressed.equalsIgnoreCase("true"))
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed Text should be FOR PRICE, ADD TO BAG for suppressed price sku's");
		}
		else
		{
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","null","Suppressed Text should be null for Non suppressed price sku's");
		}
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice");
		if(salePrice!="null")
		{
		validator.nodeNotEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should not be null in the response");
		}

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = PRICE_WEB_OAPI + "/" + testData.get("RUNTIME_WEB_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.products.stores.prices.purchaseEndDateTime,payload.products.stores.prices.purchaseBegDateTime,payload.products.stores.prices.displayEndDateTime,payload.products.stores.prices.displayBegDateTime",
					true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Price_BySku_43")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Price By SKU", description = "API Version - v1/price<br /> TC Description - As a Kohls user I want to get price details of a Product succussfully<br /> Feature - Get Price by SkuCode,<br /> Grouppricing,<br /> SuppressedPricingText")
	public void Get_Price_By_SKU() {

		TestData.getRunTimeData("SKU_CODE", false);

		String strURL = PRICE_SKU_ADAPTER + "/" + testData.get("RUNTIME_SKU_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].webID", ".+", "Prices should be present in the response");
		validator.validatepriceDetails();
		String isSuppressed = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].isSuppressed").toString();
		if(isSuppressed.equalsIgnoreCase("true"))
		{
		validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed Text should be FOR PRICE, ADD TO BAG for suppressed price sku's");
		}else{
			validator.nodeEquals("$.payload.products[0].stores[0].prices[0].suppressedPricingText","null","Suppressed Text should be null for Non suppressed price sku's");
		}
		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].stores[0].prices[0].salePrice");
		if(salePrice!="null")
		{
		validator.nodeNotEquals("$.payload.products[0].stores[0].prices[0].salePriceStatus","null","sale price status should not be null in the response");
		}

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			strURL = PRICE_SKU_OAPI + "/" + testData.get("RUNTIME_SKU_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURL, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.products.stores.prices.purchaseEndDateTime,payload.products.stores.prices.purchaseBegDateTime,payload.products.stores.prices.displayEndDateTime,payload.products.stores.prices.displayBegDateTime",
					true);
		}
	}
	

	/* Offer Scenario's */

	@TestCaseId("TC_SMOKE_Offer_ByOfferID_44")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Offers By OfferID", description = "API Version - v1/offers<br /> TC Description - As a Kohls user I want to get details of a Offer succussfully<br /> Feature - Get Offer Details by offerID.")
	public void Check_Offer_Details_By_Offer_ID() {

		String strURL = OFFERID_ADAPTER + testData.get("OFFER_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("OFFER3000-1", "Invalid Offer ID provided.");
		} else {
			validator.validateNoErrors();
			validator.nodeMatches("$.payload.offers[0].id", testData.get("OFFER_ID"),
					"Given OfferID should be present in the response");
			validator.nodeMatches("$.payload..code", ".+", "OfferCode should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+",
					"Offer BegDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+",
					"Offer EndDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].channels[0].value", ".+",
					"Channel value should be present in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERID_OAPI + testData.get("OFFER_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Offer_ByOfferCode_45")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, testName = "Offers By OfferCode", description = "API Version - v1/offers<br /> TC Description - As a Kohls user I want to get details of a Offer succussfully<br /> Feature - Get Offer Details by offerCode.")
	public void Check_Offer_Details_By_Offer_Code() {

		String strURL = OFFERCODE_ADAPTER + testData.get("OFFER_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("OFFER3000-2", "Invalid Offer Code provided.");
		} else {
			validator.nodeEquals("$.payload.offers[0].code", testData.get("OFFER_CODE"),
					"Given OfferCode should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.begDate", ".+",
					"offerEffectiveDate of begDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].offerEffectiveDate.endDate", ".+",
					"offerEffectiveDate of endDate should be present in the response");
			validator.nodeMatches("$.payload.offers[0].channels[0].value", ".+",
					"Channels should be present in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFERCODE_OAPI + testData.get("OFFER_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Offer_ByProductID_46")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "Offers By ProductId", description = "API Version - v1/offers/product<br /> TC Description - As a Kohls user I want to get details of a Offer Product succussfully<br /> Feature - Get Offer Product Details")
	public void Check_Offer_Details_By_Product_ID() {

		String strURL = OFFER_PRODUCTID_ADAPTER + testData.get("OFFER_PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("OFFER2000-4", "ProductID Not Found");
		} else {
			validator.validateNoErrors();
			validator.nodeEquals("$.payload.products[0].id", testData.get("OFFER_PRODUCT_ID"),
					"Given productId should be present in the response");
			validator.nodeMatches("$.payload.products[0].offerPrice.min", ".+",
					"productOffers endDateTime should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].id", ".+",
					"productOffers id should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].message", ".+",
					"productOffers message should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].begDateTime", ".+",
					"productOffers begDateTime should be present in the response");
			validator.nodeMatches("$.payload.products[0].productOffers[0].endDateTime", ".+",
					"productOffers endDateTime should be present in the response");
		}
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strURLOAPI = OFFER_PRODUCTID_OAPI + testData.get("OFFER_PRODUCT_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);

		}
	}
	

	/* Hazmat Product Details */

	@TestCaseId("TC_SMOKE_Product_GetDetails_47")
	@Test(groups = {
			"qa_smoke" }, enabled = true, testName = "API Version - v1/products<br /> TC Description - As a Kohls user I want to get details of a Hazmat Product succussfully<br /> Feature - Get Hazmat Product Details", description = "API Version - v1/products<br /> TC Description - As a Kohls user I want to get details of a Hazmat Product succussfully<br /> Feature - Get Hazmat Product Details")
	public void GetProductDetails() {

		String strURL = PRODUCTS_BY_SKU_ADAPTER + testData.get("SKU_HAZMAT_TRANSPORTATION");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		validator.nodeMatches("$.payload.products[0].productDetails",
				"(?s).*This content is related to Transportation.*", "Hazmat HTML content should be present");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PRODUCTS_BY_SKU_OAPI + testData.get("SKU_HAZMAT_TRANSPORTATION");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}

	}
	

	/* Inventory Scenario's */

	@TestCaseId("TC_SMOKE_GIV_ByWebID_48")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 6, testName = "Inventory By WebId", description = "API Version - v1/inventory<br /> TC Description - As a Kohls user I want to get inventory details of a Product by webID succussfully<br /> Feature - Get Inventory Details")
	public void InventoryByWebId() {

		TestData.getRunTimeData("WEB_ID", false);

		String strURL = INVENTORY_WEBID_ADAPTER + "/" + testData.get("RUNTIME_WEB_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].webID", testData.get("RUNTIME_WEB_ID"),
				"Given webID should be present in the response");
		validator.nodeMatches("$.payload.products[0].availability", "In Stock",
				"availability should be present in the response");
		validator.nodeMatches("$.payload.products[0].skus[0].stores[0]", ".+",
				"Stores should be available in response");
		// validator.nodeMatches("$.payload.products[0].availableStock","[0-9]+",
		// "Stock availability should be present in the response");
		// validator.nodeEquals("$.payload.products[0].availableStock","[0-9]+",
		// "Stock availability should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_WEBID_OAPI + "/" + testData.get("RUNTIME_WEB_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_GIV_BySku_49")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 7, testName = "Inventory By SKU", description = "API Version - v1/inventory<br /> TC Description - As a Kohls user I want to get inventory details of a Product by skuID succussfully<br /> Feature - Get Inventory Details")
	public void InventoryBySku() {

		TestData.getRunTimeData("SKU_CODE", false);

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("RUNTIME_SKU_CODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.skus[0].skuCode", testData.get("RUNTIME_SKU_CODE"),
				"Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.skus[0].stores[0].availability", "In Stock",
				"availability should be present in the response");
		validator.nodeMatches("$.payload.skus[0].stores[0].availableStock", "[0-9]+",
				"stock availability should be present in the response");
		validator.nodeEquals("$.payload.skus[0].stores[0].channel", "web",
				"stock availability should be present in the response");
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("RUNTIME_SKU_CODE");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	

	/* Order Scenario's */

	@TestCaseId("TC_SMOKE_Order_OrderCalcAsGuest_50")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 4, testName = "Order Calc", description = "API Version - v1/order/calculation<br /> TC Description - Kohls user performs order calculation as a Guest User with cartItems and AMEX Card succussfully<br /> Feature - Order Calculation,<br /> cardType=VISA,<br /> Grouppricing")
	public void GuestUser_Order_Clac() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("VISA") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateOrderResponse(false, false, testData.get("RUNTIME_SKU_CODE"), "USSTD");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_PlaceOrderAsGuest_51")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "Order Calc", description = "API Version - v1/order/calculation<br /> TC Description - Kohls user performs order calculation as a Guest User with cartItems and AMEX Card succussfully<br /> Feature - Order Calculation,<br /> itemType=BOPUS,<br /> cardType=AMEX,<br /> Grouppricing")
	public void GuestUser_Place_Order() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : ["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]," + "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("AMEX") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateOrderResponse(false, false, testData.get("SKU_BOPUS"), "USSTD");
		Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "ORDER_NUMBER_BOPUS");
		Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "POSTAL_CODE_BOPUS");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_OrderCalcAsRegUser_52")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "OrderCalc As Registered User", dependsOnMethods = {
					"SignInProfile",
					"RemoveCart" }, description = "API Version - v2/order/calculation<br /> TC Description - As a Kohls user I want perform as orderCalculation  succussfully<br /> Feature - OrderCalculation,<br /> cardType=Amex,<br /> Grouppricing")
	public void RegisteredUser_Order_Clac() {

		TestData.getRunTimeData("SKU_CODE", false);
		Utilities.removeAllItemCart(Server.Adapter, testData.get("access_token_adapter"));
		Utilities.AddItemtoCart(testData.get("RUNTIME_SKU_CODE"), "2", Server.Adapter);
		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""
				+ testData.get("OAPICART_ID") + "\"," + "\"cartItems\" : [{\"cartItemID\":\""
				+ testData.get("OAPI_CART_ITEM_ID") + "\",\"shippingMethod\": \"USSTD"
				+ JsonString.getCartJson("VALID_V2", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateOrderResponse(false, true, testData.get("RUNTIME_SKU_CODE"), "USSTD");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_PlaceOrderAsRegUser_53")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "PlaceOrder As Registered User", dependsOnMethods = {
					"SignInProfile", "RemoveCart",
					"RegisteredUser_Order_Clac" }, description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to place an order succussfully<br /> Feature - PlaceOrder,<br /> cardType=MC,<br /> Grouppricing")
	public void RegisteredUser_Place_Order() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\",\"cartID\":\""
				+ testData.get("OAPICART_ID") + "\"," + "\"cartItems\" : [{\"cartItemID\":\""
				+ testData.get("OAPI_CART_ITEM_ID") + "\",\"shippingMethod\": \"USSTD"
				+ JsonString.getCartJson("VALID_V2", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateOrderResponse(true, true, testData.get("RUNTIME_SKU_CODE"), "USSTD");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_GetOrderDetails_54")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 6, testName = "Retrieve Order For User", dependsOnMethods = "RegisteredUser_Place_Order", description = "API Version - v1/orders<br /> TC Description - As a Kohls user I want to retrieve order details that I placed earlier  succussfully<br /> Feature - RetrieveOrder Details")
	public void RetrieveOrderDetails() {
		// Validation for health check

		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("Place Order cannot be executed in Production. Hence skipping Retrieve Order");
		}

		// Post the request
		String strResponse = RestCall.getRequest(RETRIEVE_ORDERS_ADAPTER, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		validator.nodeMatches("$.payload.orders[0].orderNumber", "[0-9]+",
				"Order Number should be present in the response");
		validator.nodeEquals("$.payload.orders[0].status", "Submitted", "Order status should be 'Submitted'");
		validator.nodeMatches("$.payload.orders[0].dateTime", ".+",
				"Order placed time should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.getRequest(RETRIEVE_ORDERS_OAPI, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.orders.dateTime,payload.orders.orderNumber", true);
		}
	}
	
	/*start date for offer and KC */
	
	@TestCaseId("TC_SMOKE_Order_Instore_OrderCalc_70")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 4, testName = "OrderCalc with PaymentDetails=ApplePay with Discover Card and GiftCard + PromoCode + KohlsCash", description = "API Version - v2/order<br /> TC Description -Verify whether user able to do OrderCalc with paymentDetails=APPLEPAY while passing the request with Discover Card and GiftCard + PromoCode + KohlsCash.<br /> Feature - Applepay OrderCalc,<br /> StartDate For offer")
	
	public void ApplePay_Amex_GC_Promo_KC() {

				String arr[]=TestData.createKohlsCash(10);
			// Create the Json Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"false\","
						+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
						+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("AMEX")
						+ "],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]"
								+ ",\"promoCodes\":[{\"code\":\"" + testData.get("PROMOCODE") + "\"}]"
										+ ",\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

			// Post the request
			String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			validator.validateOrderApplePayResponse();
			validator.validateOrderResponse(false, false, testData.get("SKU_NORMAL"), "USSTD");
			validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
			validator.validatebillAddress();
			validator.validateCustomerInfo();
			validator.validateshipAddress();
			validator.validateOrderPromoCode(testData.get("PROMOCODE"), false);
			validator.validateOrderGiftCard(testData.get("GIFT_CARD_NUMBER"), false);
			validator.validateOrderKohlsCash(arr[0], false);

			// Compare Open API
			if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
			}
			}

	/* Instore Free Shipping Order Scenario's */

	@TestCaseId("TC_SMOKE_Order_Instore_OrderCalc_55")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 4, testName = "InStoreFreeShipping Order Calc", description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to perform orderCalculation for an order from INSTORE MODE succussfully<br /> Feature - InStoreFree Shipping Order,<br /> Grouppricing")
	public void Instore_Freeshipping_Order_calc() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strOrderCalcRequest = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]" + "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strOrderCalcRequest, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo("AMEX");
		validator.validateTotal();
		validator.validateOrderInstoreResponse(false, true, true);
		validator.validateOrderResponse(false, false, testData.get("RUNTIME_SKU_CODE"), "USSTD");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strOrderCalcRequest, Server.OpenApi,
					false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID",
					true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_Instore_PlaceOrder_56")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "InStoreFreeShipping Place Order", description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to place an order from INSTORE MODE succussfully<br /> Feature - InStoreFree Shipping Order")
	public void Instore_Freeshipping_Place_Order() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strOrderCalcRequest = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : [" + JsonString.getPaymentTypeJson("AMEX")
				+ "]},\"modes\":[\"INGEOFENCE\"]" + "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strOrderCalcRequest, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo("AMEX");
		validator.validateTotal();
		validator.validateOrderInstoreResponse(true, true, true);
		validator.validateOrderResponse(true, false, testData.get("RUNTIME_SKU_CODE"), "USSTD");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strOrderCalcRequest, Server.OpenApi,
					false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID",
					true);
		}
	}
	

	/* Visa Checkout Scenario's */

	@TestCaseId("TC_SMOKE_Order_VXO_OrderCalc_57")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 4, testName = "VXO-Order Calc", description = "API Version - v1/order/calculation<br /> TC Description - As a Kohls user I want to perform an orderCalculation with paymentMethod as VISA CHECKOUT succussfully<br /> Feature - Order Calculation,<br /> PaymentMethod=VisaCheckout,<br /> Grouppricing")
	public void VISA_Order_calc() {

		// Skipping Testcase in production
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("VXO Testcase cannot be executed in Production");
		}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA") + "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatesaleprice();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"),
				"Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+",
				"cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+",
				"webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD",
				"Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "
					+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2")
					+ "]," + "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA") + "]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID",
					true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_VXO_PlaceOrder_58")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 5, testName = "VXO-Place Order", description = "API Version - v1/order<br /> TC Description - As a Kohls user I want to place an order with paymentMethod as VISA CHECKOUT succussfully<br /> Feature - Place Order,<br /> PaymentMethod=VisaCheckout,<br /> Grouppricing")
	public void VISA_Place_Order() {

		// Skipping Testcase in production
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			throw new SkipException("VXO Testcase cannot be executed in Production");
		}

		TestData.getRunTimeData("SKU_CODE", false);

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA") + "}}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateCustomerInfo();
		validator.validatesaleprice();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		// Verifying cart Details
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+",
				"cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+",
				"webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD",
				"shippingMethod should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"),
				"Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].qty", "2",
				"Given Sku code should be present in the response");
		// Verifying Order Details
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+",
				"Order Number should be present in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Submitted'");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "
					+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2")
					+ "]," + "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA") + "]}}}}";

			// Post the request
			String strURLOAPI = PLACEORDER_OAPI + "&channel=mobile";
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	

	/* ApplePay Scenario's */

	@TestCaseId("TC_SMOKE_Order_ApplePay_OrderCalc_59")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc", description = "API Version - v2/order/calculation<br /> TC Description - As a Kohls user I want to perform an orderderCalculation with paymentMethod as APPLEPAY succussfully<br /> Feature - OrderCalc,<br /> paymentType=ApplePay,<br /> cardType=MasterCard,<br /> Grouppricing")
	public void Applepay_OrderCalc() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER") + "]}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatesaleprice();
		validator.validateCustomerInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("RUNTIME_SKU_CODE"),
				"Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+",
				"cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+",
				"webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD",
				"Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY",
				"paymentDetails should be present as 'APPLEPAY' in the response");
		// Compare Open API
		if (CompareOAPI) {
			/*
			 * String strOrderCalcRequestOAPI = "{\"payload\": {\"order\":" +
			 * "{\"customerName\" : "+ JsonString.getCustomerNameJson("VALID")
			 * +"," + "\"email\":\"shankarc44@gmail.com\"," +
			 * "\"cartItems\" : ["+ JsonString.getCartJson("","VALID",
			 * testData.get("SKU_NORMAL"), "2") +"]," + "\"billAddress\" : "+
			 * JsonString.getBillAddressJson("WI_MILWAUKEE") +"," +
			 * "\"shippingMethod\":\"USSTD\"," +
			 * " \"isBillAddressEqualtoShipAddress\":\"true\"," +
			 * " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
			 * + JsonString.getPaymentTypeJson("VISA") + "]}}}}";
			 */
			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID",
					true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_ApplePay_PlaceOrder_60")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 7, testName = "ApplePay PlaceOrder", description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to perform place an order with paymentMethod as APPLEPAY succussfully<br /> Feature - PlaceOrder,<br /> PaymentType=ApplePay,<br /> cardType=Visa,<br /> Grouppricing")
	@Severity(SeverityLevel.BLOCKER)

	public void Applepay_PlaceOrder() {

		TestData.getRunTimeData("SKU_CODE", false);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : ["
				+ JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
				+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ "{\"type\":\"visa\"}],\"paymentToken\":" + testData.get("APPLEPAY_TOKEN_ADAPTER") + "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// In Prod validate Invalid credit card error
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER3020",
					"The calculated Order total is different from the authorized amount.");
		} else {
			validator.validateNoErrors();
			validator.validatesaleprice();
			validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"),
					"Given Sku code should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+",
					"cartItemID should be present in the response");
			validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+",
					"webID should be present in the response");
			validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD",
					"Given Sku code should be present in the response");
			validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY",
					"paymentDetails should be present as 'APPLEPAY' in the response");
			validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
			validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+",
					"Order Number should be present in the response");
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateCustomerInfo();

			// Set orderNumber from response in test data
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_adapter");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strPayloadOAPI = "{\"payload\": {\"order\":" + "{\"customerName\" : "
					+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : ["
					+ JsonString.getCartJson("PLACE_ORDER_VALID", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "1") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\"," + " \"isBillAddressEqualtoShipAddress\":\"false\","
					+ "\"shipAddress\" : " + JsonString.getBillAddressJson("CA_MILPITAS") + ","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA_APPLEPAY") + "],\"paymentToken\":\""
					+ testData.get("APAY_PROMO_TOKEN_OAPI") + "\"}}}}";
			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponse, "$.payload.order.orderNumber", "applepay_order_number_oapi");
			Utilities.setTestData(strResponse, "$.payload.order.billAddress.postalCode", "APY_POSTAL_CODE1");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
		}
	}
	

	/* MasterPass Scenario's */

	@TestCaseId("TC_SMOKE_Order_MasterPass_PlaceOrder_61")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to place an order with paymentMethod as MASTERPASS succussfully<br /> Feature - PlaceOrder<br /> paymentMethod=MASTERPASS,<br /> cardType=VISA,<br /> Grouppricing")
	public void MasterPass_Place_Order() {

		TestData.getRunTimeData("SKU_CODE", false);

		String strURL = PLACEORDERV2_ADAPTER + "&brandID=nativeapp";

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"presentationDetails\" :{"
				+ "\"paymentMethod\":\"MASTERPASS\"," + "\"transactionID\":\"442305669\"}," + "\"creditCards\" : [{"
				+ "\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\"," + "\"type\":\"VISA\","
				+ "\"expDate\":\"03/2018\"}" + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462",
					"we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validatesaleprice();
			validator.validateshipAddress();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.validateMasterPassResponse();
			validator.validateOrderResponse(true, false, testData.get("RUNTIME_SKU_CODE"), "USSTD");
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI = PLACEORDERV2_OAPI + "&brandID=nativeapp";
				;
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
						"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
			}
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_MasterPass_OrderCalc_62")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 4, testName = "Master Pass Placeorderorder V2 with BrandId ", description = "API Version - v2/order/calculation<br /> TC Description - As a Kohls user I want to perform an order Calculation with paymentMethod as MASTERPASS succussfully<br /> Feature - OrderCalculation<br /> paymentMethod=MASTERPASS,<br /> cardType=Amex,<br /> Grouppricing")
	public void MasterPass_Order_Calc() {

		TestData.getRunTimeData("SKU_CODE", false);

		String strURL = ORDERCALC_ADAPTER_V2 + "&brandID=nativeapp";

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("RUNTIME_SKU_CODE"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"presentationDetails\" :{"
				+ "\"paymentMethod\":\"MASTERPASS\"," + "\"transactionID\":\"442305669\"}," + "\"creditCards\" : [{"
				+ "\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\"," + "\"type\":\"AMEX\","
				+ "\"expDate\":\"03/2018\"}" + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462",
					"we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
			validator.validateNoErrors();
			// validator.validateCartResponse();
			validator.validatebillAddress();
			validator.validateshipAddress();
			validator.validatesaleprice();
			validator.validatePaymentInfo();
			validator.validateTotal();
			validator.validateMasterPassResponse();
			validator.validateOrderResponse(false, false, testData.get("RUNTIME_SKU_CODE"), "USSTD");
			// Compare Open API
			if (CompareOAPI) {
				String strURLOAPI = ORDERCALC_OAPI_V2 + "&brandID=nativeapp";
				;
				// Post the request
				String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

				// Compare the result
				Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
						"payload.order.orderNumber,payload.order.cartItems.cartItemID", true);
			}
		}
	}
	

	/* Bopus Order With Alternate Pickup Details */

	@TestCaseId("TC_SMOKE_Order_BopusAlternatePickUp_PlaceOrder_63")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 4, testName = "PlaceOrder V2 with BopusAlternate Pickup Notification number", description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to place an Bopus order with Alternate Pickup Details succussfully<br /> Feature - Place Order,<br /> AlternatePickupDetails")
	public void PlaceOrderWithAlternatePickUpDetails() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":" + "{\"customerName\" : "
				+ JsonString.getCustomerNameJson("VALID") + "," + "\"email\":\"shankarc44@gmail.com\""
				+ ",\"alternatePickUpPersons\":[" + JsonString.getAlternatePickUpJson("VALID") + "],"
				+ "\"textNotificationNumber\": \"" + testData.get("BOPUS_PHONE_NUMBER") + "\"," + "\"cartItems\" : ["
				+ JsonString.getBopusCartJson("VALID", testData.get("SKU_BOPUS"), "1", testData.get("BOPUS_STORE"))
				+ "]," + "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\"," + " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX") + "]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		if (testData.get("OAPI_Environemnt").equals("Prod")) {
			validator.validateExpectedErrors("ORDER9462",
					"we're unable to process your credit card at this time. please contact us at 800-564-5740 so that we can process your order.");
			return;
		} else {
			validator.validateNoErrors();
			validator.validatesaleprice();
			validator.validateOrderResponse(true, false, testData.get("SKU_BOPUS"), "USSTD");
			validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
			validator.validatebillAddress();
			validator.validateBopusItem(testData.get("SKU_BOPUS"), testData.get("BOPUS_STORE"));
			validator.validateBopusAlternatePickup(testData.get("CUSTOMER_FIRSTNAME"),
					testData.get("CUSTOMER_LASTNAME"), "razzirazzu@gmail.com");
			validator.validateBopusAlternatePickupNotificationNumber(testData.get("BOPUS_PHONE_NUMBER"));
		}
		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,
					"payload.order.cartItems.cartItemID,payload.order.orderNumber", true);
		}
	}
	

	@TestCaseId("TC_SMOKE_Order_BopusAlternatePickUp_UpdateOrder_64")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 6, testName = "Bopus Order - Update AlternatePickup Details", dependsOnMethods = "GuestUser_Place_Order", description = "API Version - v2/order<br /> TC Description - As a Kohls user I want to Update an Bopus order with Alternate Pickup Details succussfully<br /> Feature - Place Order,<br /> Update AlternatePickupDetails")
	public void UpdateOrderAlternatePickupDetails() {

		// Create Request
		String strPayloadUpdateOrder = "{\"payload\": {\"orderNumber\":\"" + testData.get("ORDER_NUMBER_BOPUS") + "\","
				+ "\"postalCode\":\"" + testData.get("POSTAL_CODE_BOPUS")
				+ "\",\"email\":\"shankarc44@gmail.com\",\"action\":\"ADD_ALT_PICKUP\""
				+ ",\"alternatePickUpPersons\":[" + JsonString.getAlternatePickUpJson("VALID") + "]}}";

		// Post Request
		String strResponseUpdateOrder = RestCall.putRequest(RETRIEVE_ORDER_ADAPTER, strPayloadUpdateOrder,
				Server.Adapter, false);

		validator = new ResponseValidator(strResponseUpdateOrder);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Alternate PickUp Information is updated successfully",
				"Verifying the message as 'Alternate PickUp Information is updated successfully' is getting displayed in response");
	}
	

	/* EDE Experience Service */

	@TestCaseId("TC_SMOKE_Experience_ZeroSearch_IOS_65")
	@Test(groups = {
			"qa_smoke" }, enabled = true, priority = 1, testName = "experiencesZeroSearch_withoutLimit_Channel_iosApp", description = "API Version - v1/ede/experiences<br /> TC Description - As a Kohls user I want get experiences based on given product succussfully<br /> Feature - EDE Experiences Search")
	public void ExperiencesZeroSearch_iosApp() {
		String strURL = EXPERIENCES_EDE_ADAPTER + "?cid=" + testData.get("EXPERIENCE_CID1") + "&pgid="
				+ testData.get("EXPERIENCE_PGID") + "&plids=Horizontal" + "&ccp="
				+ Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=", "%3D");

		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		// Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+",
					"id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+",
					"productTitle for the product should not null");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+",
					"regular minPrice for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+",
					"displayBegDateTime for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+",
					"purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+",
					"displayEndDateTime for the product should be displayed");
			validator.nodeMatches(
					"$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+",
					"purchaseEndDateTime for the product should be displayed");
		}
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"),
				"CID sould be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"),
				"Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");
	}
	

	/* All Store's */
	@TestCaseId("TC_SMOKE_GetAllStores_66")
	@Test(groups = { "qa_smoke", "devops_smoke" }, enabled = true, priority = 2, testName = "GeoFence - All Stores",

			description = "API Version - v1/locations <br /> TC Description - As a Kohls user I want get all store location details succussfully<br /> Feature - Get All Store Location")
	public void GetAllStores() {

		// Post the request
		String strResponse = RestCall.getRequest(GEOFENCE_STORES_ADAPTERS, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateResponseHeaders("EXPIRES_GT_CURRENT_DATE",
				"Expires header date should be greter than current date");
		validator.validateStoreLatLong("Validate each store is within the lat/long quadrants");

		// delete store if already exist
		String strURL = GEOFENCE_STORES_ADAPTERS + "/" + testData.get("GEO_STORE_NUM");

		/*
		 * if(testData.get("STORENUM_EXISTS")!=null) { // Post the request
		 * String strResponse1 = RestCall.deleteRequest(strURL, Server.Adapter,
		 * false,202); }
		 */
	}
	

	@TestCaseId("TC_SMOKE_GetStoresByPostalCode_67")
	@Test(groups = { "qa_smoke",
			"devops_smoke" }, enabled = true, priority = 7, testName = "Stores", description = "API Version - v1/stores <br /> TC Description - As a Kohls user I want get all near by store location details succussfully<br /> Feature - Get Stores neary by ZipCode Location")
	public void StoreSearchByZipCode() {

		String strURL = STORESBYOPENSEARCH_ADAPTER + testData.get("STORE_POSTAL_CODE") + "&radius=25";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.stores[0].storeName", ".+", "Store Name should be present in the response");
		validator.nodeMatches("$.payload.stores[0].storeNum", ".+", "Store Number should be present in the response");
		validator.nodeMatches("$.payload.stores[0].storeHours", ".+", "Store Hours should be present in the response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = STORESBYOPENSEARCH_OAPI + testData.get("STORE_POSTAL_CODE") + "&radius=25";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}
