package test.java.adapters.recommendations;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.RECOMMENDATION_EDE_ADAPTER;
import static main.java.common.GlobalVariables.RECOMMENDATION_OAPI;
import static main.java.common.TestData.testData;

import org.apache.commons.codec.binary.Base64;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Recommendation")
@Stories({ "ede" })
public class recommendation {
	
	ResponseValidator validator;
	
		@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP without limit in channel iosApp",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1")
	public void recommendationPDP_withoutLimit_Channel_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID sould be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 1",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 1")
	public void recommendationPDP_withLimitOne_Channel_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID should be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 2",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 2")
	public void recommendationPDP_withLimitTwo_Channel_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID should be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 3",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 3")
	public void recommendationPDP_withLimitThree_Channel_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID should be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 4",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 4")
	public void recommendationPDP_withLimitFour_Channel_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID should be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP without limit in channel AndroidApp",
			description = "A Kohls application user wants to get recommendations for PDP page in channel AndroidApp and placement identification Horizontal1")
	public void recommendationPDP_withoutLimit_Channel_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID sould be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID sould be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid sould be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 1",
			description = "A Kohls application user wants to get recommendations for PDP page in channel AndroidApp and placement identification Horizontal1/limit as 1")
	public void recommendationPDP_withLimitOne_Channel_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID should be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 2",
			description = "A Kohls application user wants to get recommendations for PDP page in channel AndroidApp and placement identification Horizontal1/limit as 2")
	public void recommendationPDP_withLimitTwo_Channel_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID should be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 3",
			description = "A Kohls application user wants to get recommendations for PDP page in channel AndroidApp and placement identification Horizontal1/limit as 3")
	public void recommendationPDP_withLimitThree_Channel_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID should be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 4",
			description = "A Kohls application user wants to get recommendations for PDP page in channel AndroidApp and placement identification Horizontal1/limit as 4")
	public void recommendationPDP_withLimitFour_Channel_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID should be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_withoutChannel",
			description = "A Kohls applicaiton user wants to get error code EDE-1000 and message Missing mandatory parameter cid for PDP in placement identification Horizontal1 and without channel")
	public void recommendation_withoutChannel() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid=&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1000", "Missing mandatory parameter cid.");		
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_without pgid",
			description = "A Kohls applicaiton user wants to get error code EDE-1001 and message Missing mandatory parameter pgid without page name")
	public void recommendation_withoutPGID() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid=" +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1001", "Missing mandatory parameter pgid.");		
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_without plid",
			description = "A Kohls applicaiton user wants to get error code EDE-1002 and message Missing mandatory parameter plids without placement identification details")
	public void recommendation_withoutPLID() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1002", "Missing mandatory parameter plids.");		
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_invalid limit in plid",
			description = "A Kohls applicaiton user wants to get error code EDE-1100 and message Malformed placement IDs when passing invalid limit value for placement identificaiton details (plids)")
	public void recommendation_withInvalidLimitInPLID() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7Cj&ccp=" + Base64.encodeBase64String(testData.get("CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1100", "Malformed placement IDs.");		
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_invalid value for ccp",
			description = "A Kohls applicaiton user wants to get error code EDE-1200 and message Malformed CCP when passing invalid value for channel context paramter (CCP)")
	public void recommendation_withInvalidValueForCCP() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
				"&plids=Horizontal1%7C"+testData.get("LIMIT_4")
				+ "&ccp=fff";
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1200", "Malformed CCP.");		
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 1",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 1")
	public void recommendationPDP_withLimitOne_channel_CCP_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCPS").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID should be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 2",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 2")
	public void recommendationPDP_withLimitTwo_channel_CCP_iosApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_ios") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCPS").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_ios"), "CID should be" + testData.get("EDE_CID_ios"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 3",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 3")
	public void recommendationPDP_withLimitThree_channel_CCP_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCPS").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID should be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
	@Test(groups = {"regression","functional", "ede"}, enabled = true, priority = 1, testName = "recommendation_PDP with limit as 4",
			description = "A Kohls application user wants to get recommendations for PDP page in channel iosApp and placement identification Horizontal1/limit as 4")
	public void recommendationPDP_withLimitFour_channel_CCP_AndroidApp() {
		

		String strURL = RECOMMENDATION_EDE_ADAPTER +"?cid="+ testData.get("EDE_CID_Android") +"&pgid="+  testData.get("PGID") +
		"&plids=Horizontal1%7C"+testData.get("LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("CCPS").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.recommendations[0].products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
			int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.recommendations[0].products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EDE_CID_Android"), "CID should be" + testData.get("EDE_CID_Android"));
		validator.nodeEquals("$.payload.pgid", testData.get("PGID"), "Page ID should be " + testData.get("PGID"));
		validator.nodeEquals("$.payload.recommendations[0].plid", "Horizontal1", "Plid should be Horizontal1");
	}
}