package test.java.adapters.experiences;


import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.EXPERIENCES_EDE_ADAPTER;

import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.apache.commons.codec.binary.Base64;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Experiences")
@Stories({ "EDE Experiences" })
public class experiences {
	
	ResponseValidator validator;
	
		@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withoutLimit_Channel_iosApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel iosApp and placement identification Horizontal")
	public void experiencesZeroSearch_withoutLimit_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID sould be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitOne_Channel_iosApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel iosApp and placement identification Horizontal/limit as 1")
	public void experiencesZeroSearch_withLimitOne_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = " experiencesZeroSearch_withLimitTwo_Channel_iosAp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel iosApp and placement identification Horizontal/limit as 2")
	public void experiencesZeroSearch_withLimitTwo_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitThree_Channel_iosApp",
			description = "A Kohls  application user wants to get experiences for ZeroSearch page in channel iosApp and placement identification Horizontal/limit as 3")
	public void experiencesZeroSearch_withLimitThree_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitFour_Channel_iosApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel iosApp and placement identification Horizontal/limit as 4")
	public void experiencesZeroSearch_withLimitFour_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withoutLimit_Channel_iosApp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal")
	public void experiencesAddcart_withoutLimit_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID sould be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitOne_Channel_iosApp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 1")
	public void experiencesAddcart_withLimitOne_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = " experiencesZeroSearch_withLimitTwo_Channel_iosAp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 2")
	public void experiencesAddcart_withLimitTwo_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitThree_Channel_iosApp",
			description = "A Kohls  application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 3")
	public void experiencesAddcart_withLimitThree_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitFour_Channel_iosApp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 4")
	public void experiencesAddcart_withLimitFour_Channel_iosApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID1") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID1"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withoutLimit_Channel_AndroidApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel AndroidApp and placement identification Horizontal")
	public void experiencesZeroSearch_withoutLimit_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID sould be" + testData.get("EXPERIENCE_CID2"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitOne_Channel_AndroidApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel AndroidApp and placement identification Horizontal/limit as 1")
	public void experiencesZeroSearch_withLimitOne_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID2"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitTwo_Channel_AndroidApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel AndroidApp and placement identification Horizontal/limit as 2")
	public void experiencesZeroSearch_withLimitTwo_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID2"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitThree_Channel_AndroidApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel AndroidApp and placement identification Horizontal/limit as 3")
	public void experiencesZeroSearch_withLimitThree_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID2"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_CID2"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitFour_Channel_AndroidApp",
			description = "A Kohls application user wants to get experiences for ZeroSearch page in channel AndroidApp and placement identification Horizontal/limit as 4")
	public void experiencesZeroSearch_withLimitFour_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID2"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withoutLimit_Channel_iosApp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal")
	public void experiencesAddcart_withoutLimit_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal"
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
//		Assert.assertEquals(strproductIDsSize, 4);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID sould be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID sould be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid sould be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitOne_Channel_iosApp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 1")
	public void experiencesAddcart_withLimitOne_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_1")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 1;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = " experiencesZeroSearch_withLimitTwo_Channel_iosAp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 2")
	public void experiencesAddcart_withLimitTwo_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_2")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 2;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitThree_Channel_iosApp",
			description = "A Kohls  application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 3")
	public void experiencesAddcart_withLimitThree_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_3")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 3;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiencesZeroSearch_withLimitFour_Channel_iosApp",
			description = "A Kohls application user wants to get experiences forAddcart page in channel iosApp and placement identification Horizontal/limit as 4")
	public void experiencesAddcart_withLimitFour_Channel_AndroidApp() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID1") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP1").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray productIDs = JsonPath.read(strResponse, "$.payload.experiences[0].expPayload.products");
		int strproductIDsSize = productIDs.size();
		//validating whether the products limit/list is one
		int AvailableProductCount = 4;
		System.out.println("Available Product Count in the response is "+AvailableProductCount);
		Assert.assertEquals(AvailableProductCount, strproductIDsSize);
		for (int i = 0; i < strproductIDsSize; i++) {
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].id", "[0-9]+", "id for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].productTitle", ".+", "productTitle for the product should not null");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].regularPrice.minPrice", ".+", "regular minPrice for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayBegDateTime", ".+", "displayBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseBegDateTime", ".+", "purchaseBegDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].displayEndDateTime", ".+", "displayEndDateTime for the product should be displayed");
			validator.nodeMatches("$.payload.experiences[0].expPayload.products[" + i + "].prices[0].purchaseEndDateTime", ".+", "purchaseEndDateTime for the product should be displayed");
		}
		
		validator.nodeEquals("$.payload.cid", testData.get("EXPERIENCE_CID2"), "CID should be" + testData.get("EXPERIENCE_CID1"));
		validator.nodeEquals("$.payload.pgid", testData.get("EXPERIENCE_PGID1"), "Page ID should be " + testData.get("EXPERIENCE_PGID"));
		validator.nodeEquals("$.payload.experiences[0].plid", "Horizontal", "Plid should be Horizontal");
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiences_withoutChannelID",
			description = "A Kohls applicaiton user wants to get error code EDE-1000 and message Missing mandatory parameter cid for ZeroSearch in placement identification Horizontal and without channel")
	public void experiencesZeroSearch_withoutChannelID() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid=&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1000", "Missing mandatory parameter cid.");		
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiences_withoutPGID",
			description = "A Kohls applicaiton user wants to get error code EDE-1001 and message Missing mandatory parameter pgid without page name")
	public void experiencesZeroSearch_withoutPGID() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid=" +
		"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
		+ "&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1001", "Missing mandatory parameter pgid.");		
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiences_withoutPLID",
			description = "A Kohls applicaiton user wants to get error code EDE-1002 and message Missing mandatory parameter plids without placement identification details")
	public void experiencesZeroSearch_withoutPLID() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1002", "Missing mandatory parameter plids.");		
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiences_withInvalidLimitInPLID",
			description = "A Kohls applicaiton user wants to get error code EDE-1100 and message Malformed placement IDs when passing invalid limit value for placement identificaiton details")
	public void experiencesZeroSearch_withInvalidLimitInPLID() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
		"&plids=Horizontal%7Cj&ccp=" + Base64.encodeBase64String(testData.get("EXPERIENCE_CCP").getBytes()).replaceAll("=","%3D");
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1100", "Malformed placement IDs.");		
	}
	@Test(groups = {"experiences","functional1", "ede1","regression"}, enabled = true, priority = 1, testName = "experiences_withInvalidValueForCCP",
			description = "A Kohls applicaiton user wants to get error code EDE-1200 and message Malformed CCP when passing invalid value for channel context paramter (CCP)")
	public void experiencesZeroSearch_withInvalidValueForCCP() {
		

		String strURL = EXPERIENCES_EDE_ADAPTER +"?cid="+ testData.get("EXPERIENCE_CID2") +"&pgid="+  testData.get("EXPERIENCE_PGID") +
				"&plids=Horizontal%7C"+testData.get("EXPERIENCE_LIMIT_4")
				+ "&ccp=fff";
		
		// Get the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("EDE-1200", "Malformed CCP.");		
	}
	
}
