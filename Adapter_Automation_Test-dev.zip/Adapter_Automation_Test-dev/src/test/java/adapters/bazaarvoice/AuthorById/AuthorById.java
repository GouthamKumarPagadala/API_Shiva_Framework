package test.java.adapters.bazaarvoice.AuthorById;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.AUTHORS_ID_ADAPTER;
import static main.java.common.GlobalVariables.AUTHORS_ID_BAZAARVOICE;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.GlobalVariables.CMS_ADAPTER;
import static main.java.common.GlobalVariables.CMS_SKAVA;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "AuthorById" })
public class AuthorById {

	ResponseValidator validator;


	@Test(groups = { "regression","functional" }, enabled = true, priority = 7, testName = "Invalid AuthorByID",
			description = "Checking the INVALIDAUTHORSBYID details")
	public void INVALIDAUTHORSBYID() {

		String strURL = AUTHORS_ID_ADAPTER + "AuthorId:QWASER2253999807330641";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = AUTHORS_ID_BAZAARVOICE + "AuthorId:QWASER2253999807330641" + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}
}