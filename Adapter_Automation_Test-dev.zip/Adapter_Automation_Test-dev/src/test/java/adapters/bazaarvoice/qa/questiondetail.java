package test.java.adapters.bazaarvoice.qa;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;
import java.util.TimeZone;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "Question Detail" })
public class questiondetail {

	ResponseValidator validator;



	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "LimitFiveSortBestAnswer",
			description = "Kohls application user should able to view only maximum of 5 Questions in intial screen and should not be able to see any products details on the PDP")
	public void limitFiveSortBestAnswer() {

		// Get the request
		String strURL = GET_QA_PRODUCT_ADAPTER + "?Sort=HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_LIMIT_5_PRODUCT_ID");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateQuestionDetailForQAndA("Validating Question Details");
		validator.nodeMatches("$.payload.TotalResults", "[[1-9]+]", "TotalResults should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Limit", "5", "Limit should be present as 5 in the response");
		JSONArray TotalAnswer = JsonPath.read(strResponse, "$.payload.Includes..Id");
		System.out.println("TotalAnswer1 =" + TotalAnswer);
		System.out.println("TotalAnswer size =" + TotalAnswer.size());

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GETQA_PRODUCT_BAZZ + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&Sort=HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_LIMIT_5_PRODUCT_ID") + "&Include=Answers";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "BestAnswerFirstForEachQuestion",
			description = "Kohls application user should able to view Best Answers first for each question on the PDP")
	public void bestAnswerFirstForEachQuestion() {

		// Get the request
		String strURL = GET_QA_PRODUCT_ADAPTER + "?Sort=HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_BEST_ANSWER_PRODUCT_ID");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateQuestionDetailForQAndA("Validating Question Details");
		validator.nodeMatches("$.payload.TotalResults", "[[1-9]+]", "TotalResults should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Limit", "5", "Limit should be present as 5 in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GETQA_PRODUCT_BAZZ + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&Sort=HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_BEST_ANSWER_PRODUCT_ID") + "&Include=Answers";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "positiveFeedback",
			description = "Kohls application user should able to view the positive feedback on the PDP")
	public void positiveFeedback() {

		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(GET_QA_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeEquals("$.payload.Errors", "[]", "Errors should be null in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.Vote", testData.get("VOTE"), "Vote should be present in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.AuthorId", testData.get("USER_ID"), "AuthorId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "positiveFeedback",
			description = "Kohls application user should able to view the negative feedback on the PDP")
	public void negativeFeedback() {

		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE_NEGATIVE") + "&ReasonText=" + testData.get("REASON_TEXT");
		String strResponse = RestCall.postRequest(GET_QA_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeEquals("$.payload.Errors", "[]", "Errors should be null in the response");
		validator.nodeEquals("$.payload.Feedback.Inappropriate.ReasonText", testData.get("REASON_TEXT"), "ReasonText should be present in the response");
		validator.nodeEquals("$.payload.Feedback.Inappropriate.AuthorId", testData.get("USER_ID"), "AuthorId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE_NEGATIVE") + "&ReasonText=" + testData.get("REASON_TEXT");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "QuestionAndAnswerDetail",
			description = "Kohls application user will get the sorting logic which is defined by the server.Based on newest question submission date")
	public void sortSubmissionTime() throws Exception {

		// Get the request
		String strURL = GET_QA_PRODUCT_ADAPTER + "?Sort=submissiontime:desc,HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_COUNT_PRODUCT_ID") + "&search=men&Include=Answers";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateQuestionDetailForQAndA("Validating Question Details");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Limit", "5", "Limit should be present as 5 in the response");

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		String strLatestSubmissionTime = Utilities.getJsonNodeValue(strResponse, "$.payload.Results[0].SubmissionTime");
		String strOldSubmissionTime = Utilities.getJsonNodeValue(strResponse, "$.payload.Results[1].SubmissionTime");

		Date LatestSubmissionTime = dateFormat.parse(strLatestSubmissionTime);
		Date OldSubmissionTime = dateFormat.parse(strOldSubmissionTime);
		System.out.println("LatestSubmissionTime=" + LatestSubmissionTime + "end=" + OldSubmissionTime);
		int com=LatestSubmissionTime.compareTo(OldSubmissionTime);
		if (com>0) {
			System.out.println("Latest date is greater than Old date");
		}
			else if (com==0) {
				System.out.println("Latest date is equal to Old date");
		} else {
			Assert.fail("Latest date is not greater than Old date");
		}
		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GETQA_PRODUCT_BAZZ + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&Sort=submissiontime:desc,HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_COUNT_PRODUCT_ID") + "&search=men&Include=Answers";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "invalidSortParameter",
			description = "Kohls application user will get the sorting logic which is defined by the server.Based on newest question submission date")
	public void invalidSortParameter() throws Exception {

		// Get the request
		String strURL = GET_QA_PRODUCT_ADAPTER + "?Sort=submissiontime:desc,HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_COUNT_PRODUCT_ID") + "&search=men&Include=Answers";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.ValidateQuestionDetailForQAndA("Validating Question Details");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Limit", "5", "Limit should be present as 5 in the response");

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		String strLatestSubmissionTime = Utilities.getJsonNodeValue(strResponse, "$.payload.Results[0].SubmissionTime");
		String strOldSubmissionTime = Utilities.getJsonNodeValue(strResponse, "$.payload.Results[1].SubmissionTime");

		Date LatestSubmissionTime = dateFormat.parse(strLatestSubmissionTime);
		Date OldSubmissionTime = dateFormat.parse(strOldSubmissionTime);
		System.out.println("LatestSubmissionTime=" + LatestSubmissionTime + "end=" + OldSubmissionTime);
		int com=LatestSubmissionTime.compareTo(OldSubmissionTime);
		if (com>0) {
			System.out.println("Latest date is greater than Old date");
		}
			else if (com==0) {
				System.out.println("Latest date is equal to Old date");
		} else {
			Assert.fail("Latest date is not greater than Old date");
		}
		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GETQA_PRODUCT_BAZZ + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&Sort=submissiontime:desc,HasBestAnswer:desc&Limit=5&Offset=0&Filter=ProductId:" + testData.get("Q_A_COUNT_PRODUCT_ID") + "&search=men&Include=Answers";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAgeUnder18",
			description = "Kohls application user want to view preview of the question for the age group Under18")
	public void previewfeedbackWithAgeUnder18() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAge25To34",
			description = "Kohls application user want to view preview of the question for the age group 25to34")
	public void previewfeedbackWithAge25To34() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_25TO34"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAge35To44",
			description = "Kohls application user want to view preview of the question for the age group 35to44")
	public void previewfeedbackWithAge35To44() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_35TO44"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAge45To54",
			description = "Kohls application user want to view preview of the question for the age group 45to54")
	public void previewfeedbackWithAge45To54() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_45TO54"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAge55To65",
			description = "Kohls application user want to view preview of the question for the age group 55to65")
	public void previewfeedbackWithAge55To65() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_55TO65"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAgeOver65",
			description = "Kohls application user want to view preview of the question for the age group Over65")
	public void previewfeedbackWithAgeOver65() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackWithAgeInvalidValue",
			description = "Kohls application user want to view preview of the question for the age group Invalid Value")
	public void previewfeedbackWithAgeInvalidValue() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrorsOrder[0]", "contextdatavalue_Age", "FieldErrorsOrder should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Field", "contextdatavalue_Age", "Field should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Message", "The option you selected for How old are you? has been removed.  Please make a different selection.", "Error Message should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Code", "ERROR_FORM_INVALID_OPTION", "Error Code should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAgeUnder18",
			description = "Kohls application user want to view preview of the question for the age group Under18")
	public void submitFeedbackWithAgeUnder18() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAge25To34",
			description = "Kohls application user want to view preview of the question for the age group 25to34")
	public void submitFeedbackWithAge25To34() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAge35To44",
			description = "Kohls application user want to view preview of the question for the age group 35to44")
	public void submitFeedbackWithAge35To44() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAge45To54",
			description = "Kohls application user want to view preview of the question for the age group 45to54")
	public void submitFeedbackWithAge45To54() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAge55To65",
			description = "Kohls application user want to view preview of the question for the age group 55to65")
	public void submitFeedbackWithAge55To65() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAgeOver65",
			description = "Kohls application user want to view preview of the question for the age group Over65")
	public void submitFeedbackWithAgeOver65() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithAgeInvalidValue",
			description = "Kohls application user want to view preview of the question for the age group Invalid Value")
	public void submitFeedbackWithAgeInvalidValue() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.questionsummary.Value", testData.get("QUESTION_SUMMARY"), "questionsummary should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrorsOrder[0]", "contextdatavalue_Age", "FieldErrorsOrder should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Field", "contextdatavalue_Age", "Field should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Message", "The option you selected for How old are you? has been removed.  Please make a different selection.", "Error Message should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Code", "ERROR_FORM_INVALID_OPTION", "Error Code should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Question.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna"}, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAgeUnder18",
			description = "Kohls application user want to view submit of the answer for the age group Under18")
	public void submitFeedbackForAnswerWithAgeUnder18() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAge19To24",
			description = "Kohls application user want to view submit of the answer for the age group 19to24")
	public void submitFeedbackForAnswerWithAge19To24() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_19TO24");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_19TO24");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAge25To34",
			description = "Kohls application user want to view submit of the answer for the age group 25to34")
	public void submitFeedbackForAnswerWithAge25To34() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAge35To44",
			description = "Kohls application user want to view submit of the answer for the age group 35to44")
	public void submitFeedbackForAnswerWithAge35To44() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAge45To54",
			description = "Kohls application user want to view submit of the answer for the age group 45to54")
	public void submitFeedbackForAnswerWithAge45To54() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAge55To65",
			description = "Kohls application user want to view submit of the answer for the age group 55to65")
	public void submitFeedbackForAnswerWithAge55To65() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAgeOver65",
			description = "Kohls application user want to view submit of the answer for the age group Over65")
	public void submitFeedbackForAnswerWithAgeOver65() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeMatches("$.payload.AuthorSubmissionToken", ".+", "AuthorSubmissionToken should be present in the response");
		validator.nodeMatches("$.payload.SubmissionId", ".+", "SubmissionId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackForAnswerWithAgeInvalidValue",
			description = "Kohls application user want to view submit of the answer for the age group Invalid Value")
	public void submitFeedbackForAnswerWithAgeInvalidValue() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrorsOrder[0]", "contextdatavalue_Age", "FieldErrorsOrder should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Field", "contextdatavalue_Age", "Field should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Message", "The option you selected for How old are you? has been removed.  Please make a different selection.", "Error Message should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Code", "ERROR_FORM_INVALID_OPTION", "Error Code should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAgeUnder18",
			description = "Kohls application user want to view preview of the answer for the age group Under18")
	public void previewfeedbackForAnswerWithAgeUnder18() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAge19to24",
			description = "Kohls application user want to view preview of the answer for the age group 19To24")
	public void previewfeedbackForAnswerWithAge19To24() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_19TO24");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_19TO24"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_19TO24");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAge25To34",
			description = "Kohls application user want to view preview of the answer for the age group 25to34")
	public void previewfeedbackForAnswerWithAge25To34() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_25TO34"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_25TO34");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAge35To44",
			description = "Kohls application user want to view preview of the answer for the age group 35to44")
	public void previewfeedbackForAnswerWithAge35To44() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_35TO44"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_35TO44");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAge45To54",
			description = "Kohls application user want to view preview of the answer for the age group 45to54")
	public void previewfeedbackForAnswerWithAge45To54() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_45TO54"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_45TO54");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAge55To65",
			description = "Kohls application user want to view preview of the answer for the age group 55to65")
	public void previewfeedbackForAnswerWithAge55To65() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_55TO65"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAgeOver65",
			description = "Kohls application user want to view preview of the answer for the age group Over65")
	public void previewfeedbackForAnswerWithAgeOver65() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.contextdatavalue_Age.Value", testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65"), "contextdatavalue_Age should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_OVER_65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "previewfeedbackForAnswerWithAgeInvalidValue",
			description = "Kohls application user want to view preview of the answer for the age group Invalid Value")
	public void previewfeedbackForAnswerWithAgeInvalidValue() throws Exception {

		// Payload request
		String strPayload = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
		String strResponse = RestCall.postRequest(POST_ANSWER_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Answer.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.Answer.AnswerText", testData.get("ANSWER_TEXT"), "Answertext should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.userlocation.Value", testData.get("USER_LOCATION"), "userlocation should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.usernickname.Value", testData.get("USER_NICK_NAME"), "usernickname should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.useremail.Value", testData.get("BAZAAR_VOICE_EMAIL"), "useremail should be present in the response");
		validator.nodeEquals("$.payload.Data.Fields.answertext.Value", testData.get("ANSWER_TEXT"), "answertext should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrorsOrder[0]", "contextdatavalue_Age", "FieldErrorsOrder should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Field", "contextdatavalue_Age", "Field should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Message", "The option you selected for How old are you? has been removed.  Please make a different selection.", "Error Message should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.contextdatavalue_Age.Code", "ERROR_FORM_INVALID_OPTION", "Error Code should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_ANSFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=preview&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_INVALID");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.Form.Id,payload.Answer.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "NegativeVoteForFeedback",
			description = "Kohls application user should able to view negative feedback on the PDP")
	public void negativeVoteForFeedback() {

		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE_NEGATIVE");
		String strResponse = RestCall.postRequest(GET_QA_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeEquals("$.payload.Errors", "[]", "Errors should be null in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.Vote", testData.get("VOTE_NEGATIVE"), "Vote should be present in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.AuthorId", testData.get("USER_ID"), "AuthorId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE_NEGATIVE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "UndoVoteForFeedback",
			description = "Kohls application user should able to view undo vote on the PDP")
	public void undoVoteForFeedback() {

		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE_UNDO");
		String strResponse = RestCall.postRequest(GET_QA_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeEquals("$.payload.Errors", "[]", "Errors should be null in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.Vote", testData.get("VOTE_UNDO"), "Vote should be present in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.AuthorId", testData.get("USER_ID"), "AuthorId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK_ANSWER") + "&ContentId=" + testData.get("CONTENT_ID_ANSWER") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE_UNDO");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna","errorhandling" }, enabled = true, priority = 14, testName = "SubmitFeedback",
			description = "Kohls application user want to submit feedback with valid data")
	public void submitFeedback() {

		// URL
		String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeEquals("$.payload.Errors", "[]", "Errors should be null in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.Vote", testData.get("VOTE"), "Vote should be present in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.AuthorId", testData.get("USER_ID"), "AuthorId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submit";
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna", "errorhandling" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithOutContentType",
			description = "Kohls application user want to submit feedback without ContentType")
	public void submitFeedbackWithOutContentType() {

		// URL
		String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
		// Payload request
		String strPayload = "ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeNotEquals("$.payload.Errors", "[]", "Errors should not be null in the response");
		validator.validateExpectedErrors("ERROR_BAD_REQUEST", "Missing or unknown value for contenttype");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submti";
			// payload request
			String strPayloadOAPI = "ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna", "errorhandling" }, enabled = true, priority = 14, testName = "SubmitFeedbackWithInvalidFeedbackType",
			description = "Kohls application user want to submit feedback with InvalidValueFeedback")
	public void submitFeedbackWithInvalidFeedbackType() {

		// URL
		String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=ljkfdslfk&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeNotEquals("$.payload.Errors", "[]", "Errors should not be null in the response");
		validator.validateExpectedErrors("ERROR_BAD_REQUEST", "400 - Parameter 'feedbacktype' has invalid value: ljkfdslfk");
//NAP-481 Fix
		

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submti";
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=ljkfdslfk&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "SubmitFeedbackInvalidUserId",
			description = "Kohls application user want to submit feedback with valid data")
	public void submitFeedbackInvalidUserId() {

		// URL
		String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=safdfa454&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.HasErrors", "false", "HasErrors should be present as false in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeEquals("$.payload.Errors", "[]", "Errors should be null in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.Vote", testData.get("VOTE"), "Vote should be present in the response");
		validator.nodeEquals("$.payload.Feedback.Helpfulness.AuthorId", "safdfa454", "AuthorId should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submti";
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=safdfa454&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna", "errorhandling" }, enabled = true, priority = 14, testName = "SubmitFeedbackContentIdAsZero",
			description = "Kohls application user want to submit feedback with valid data")
	public void submitFeedbackContentIdAsZero() {

		// URL
		String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=0&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeNotEquals("$.payload.Errors", "[]", "Errors should not be null in the response");
		validator.validateExpectedErrors("ERROR_PARAM_INVALID_PARAMETERS", "The specified contentId is invalid for the REVIEW ContentType");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submti";
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=0&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@Test(groups = { "regression","functional", "qna", "errorhandling" }, enabled = true, priority = 14, testName = "SubmitFeedbackEmptyFeedbackValue",
			description = "Kohls application user want to submit feedback with empty value feedback")
	public void submitFeedbackEmptyFeedbackValue() {

		// URL
		String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
		// Payload request
		String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=&Vote=" + testData.get("VOTE");
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.FormErrors", "{}", "FormErrors should be null in the response");
		validator.nodeNotEquals("$.payload.Errors", "[]", "Errors should not be null in the response");
		validator.validateExpectedErrors("ERROR_UNSUPPORTED", "Unsupported feedback type / content type");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submti";
			// payload request
			String strPayloadOAPI = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=&Vote=" + testData.get("VOTE");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "qna" }, enabled = true, priority = 14, testName = "DuplicateSubmitFeedback",
			description = "Kohls application user will post the answer by giving action as submit for the already submitted nickname")
	public void duplicateSubmitFeedback() throws Exception {

		// Payload request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
		String strResponse = RestCall.postRequest(POST_QUESTION_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Question.SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeEquals("$.payload.Question.QuestionSummary", testData.get("QUESTION_SUMMARY"), "QuestionSummary should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.usernickname.Field", "usernickname", "Field of usernickname should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.usernickname.Message", "Someone has already used that nickname", "Message of usernickname should be present in the response");
		validator.nodeEquals("$.payload.FormErrors.FieldErrors.usernickname.Code", "ERROR_FORM_DUPLICATE", "Code of usernickname should be present in the response");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_SUBMIT_QFORM_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY");
			// payload request
			String strPayloadOAPI = "ProductId=" + testData.get("PRODUCT_ID_BAZAAR") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&QuestionSummary=" + testData.get("QUESTION_SUMMARY") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_55TO65");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Question.SubmissionTime", true);
		}
	}


	@DiscontinuedTest(groups = { "regression","functional", "qna", "errorhandling" }, enabled = true, priority = 14, testName = "DuplicateSubmitFeedbackForAnswer",dependsOnMethods = "submitFeedback",
			description = "Kohls application user want to submit duplicate feedback")
	public void duplicateSubmitFeedbackForAnswer() throws Exception {

		// URL
				String strURL = GET_QA_FEEDBACK_ADAPTER + "?action=submit";
				// Payload request
				String strPayload = "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&ContentId=" + testData.get("CONTENT_ID") + "&UserId=" + testData.get("USER_ID") + "&FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&Vote=" + testData.get("VOTE");
				String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.HasErrors", "true", "HasErrors should be present as true in the response");
		validator.nodeNotEquals("$.payload.Errors", "[]", "Errors should not be present as null in the response");
		validator.validateExpectedErrors("ERROR_DUPLICATE_SUBMISSION", "Duplicate feedback submission");

		// Compare BazaarVoice
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = SUBMIT_FEEDBACK_BAZAARVOICE + "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=submit";
			// payload request
			String strPayloadOAPI = "QuestionId=" + testData.get("QUESTION_ID") + "&Action=submit&usernickname=" + testData.get("USER_NICK_NAME") + "&useremail=" + testData.get("BAZAAR_VOICE_EMAIL") + "&AnswerText=" + testData.get("ANSWER_TEXT") + "&UserLocation=" + testData.get("USER_LOCATION") + "&ContextDataValue_Age=" + testData.get("CONTEXT_DATA_AGE_VALUE_UNDER_18");
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayloadOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";
			System.out.println("strResponseBazaarVoice=" + strResponseBazaarVoice);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.SubmissionId,payload.Answer.SubmissionTime", true);
		}
	}
}