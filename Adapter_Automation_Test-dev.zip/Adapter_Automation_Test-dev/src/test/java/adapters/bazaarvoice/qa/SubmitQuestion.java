package test.java.adapters.bazaarvoice.qa;

public class SubmitQuestion {

}
