package test.java.adapters.bazaarvoice.review;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.GETQA_PRODUCT_ADAPTER;
import static main.java.common.GlobalVariables.GETQA_PRODUCT_BAZZ;
import static main.java.common.GlobalVariables.GET_REVIEWS_PRODUCT_ADAPTER;
import static main.java.common.GlobalVariables.GET_REVIEWS_PRODUCT_BAZAARVOICE;
import static main.java.common.GlobalVariables.SUBMIT_REVIEW_ADAPTER;
import static main.java.common.GlobalVariables.SUBMIT_REVIEW_BAZAARVOICE;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.GlobalVariables.CMS_ADAPTER;
import static main.java.common.GlobalVariables.CMS_SKAVA;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "SubmitReview" })
public class SubmitReview {

	ResponseValidator validator;


	/*
	 * @Test(groups = {"regression","functional"}, enabled=true, priority=14,testName = "Submit Review", dependsOnMethods="test.java.adapters.smoke.SmokeTest.getProfile", description = "Submitting the Answers ")
	 * 
	 * public void SubmitReview(){ System.out.println("Author Id2"+testData.get("author_id_adapter"));
	 * 
	 * // Create Request String strPayload ="ProductId="+testData.get("PRODUCT_ID")+"&"+"action="+testData.get("ACTION")+"&" + "UserNickname=Razia"+System.nanoTime() + "&SendEmailAlertWhenCommented=true&" + "Title=diff&" + "IsRecommended=true&Rating_Quality=2&" + "city="+testData.get("WI_BILLING_CITY")+"&" + "UserEmail="+testData.get("ADAPTER_EMAIL_ID")+"&" // + "UserId=Razia"+System.nanoTime() + "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&" + "authorId="+testData.get("author_id_adapter")+"&" + "ReviewText=Very good product.&" + "UserLocation="+testData.get("CUSTOMER_FIRSTNAME")+""+testData.get("WI_BILLING_STATE")+"&" + "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&" + "contextdatavalue_stateOfResidence="+testData.get("WI_BILLING_STATE")+"&" + "contextdatavalue_Age=18to24";
	 * 
	 * // Post Request String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);
	 * 
	 * //Validate Response validator = new ResponseValidator(strResponse); validator.validateNoErrors(); validator.nodeMatches("$.payload.Review.SubmissionTime", ".+", "Submission Time should be present in the response"); validator.nodeMatches("$.payload.Review.SendEmailAlertWhenPublished", "true", "SendEmailAlertWhenPublished should be present in the response"); validator.nodeMatches("$.payload.Review.SendEmailAlertWhenCommented", "true", "SendEmailAlertWhenCommented should be present in the response"); validator.nodeMatches("$.payload.Review.ReviewText", "Very good product.", "ReviewText should be present in the response"); if (CompareOAPI) { String strPayloadBazVoice = "apiversion=5.4&passkey="+testData.get("BAZAAR_VOICE_PASSKEY")+"&action="+testData.get("ACTION")+"&" + "ProductId="+testData.get("PRODUCT_ID")+"&" + "UserNickname=Razia"+System.nanoTime() + "&SendEmailAlertWhenCommented=true&" + "Title=diff&" + "IsRecommended=true&Rating_Quality=2&" + "city="+testData.get("WI_BILLING_CITY")+"&" + "UserEmail="+testData.get("ADAPTER_EMAIL_ID")+"&" + "UserId=Razia"+System.nanoTime() + "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&" + "authorId="+testData.get("author_id_openapi")+"&" + "ReviewText=Very good product.&" + "UserLocation="+testData.get("CUSTOMER_FIRSTNAME")+""+testData.get("WI_BILLING_STATE")+"&" + "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&" + "contextdatavalue_stateOfResidence="+testData.get("WI_BILLING_STATE")+"&" + "contextdatavalue_Age=18to24"; // Post the request String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice , Server.BazaarVoice, true); String strResponseBazaar = "{\"payload\":" +strResponseBazzarVoice +"}"; // Compare the result Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true); } }
	 * 
	 * 
	 */ @Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 14, testName = "Submit Preview NickName Null", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.getProfile",
			description = "Submitting the Answers ")

	public void NickNameNull() {

		System.out.println("Author Id2" + testData.get("author_id_adapter"));

		// Create Request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID") + "&" + "action=" + testData.get("ACTION") + "&"

		+ "&SendEmailAlertWhenCommented=true&"
				+ "Title=diff&"
				+ "IsRecommended=true&Rating_Quality=2&"
				+ "city=" + testData.get("WI_BILLING_CITY") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
				// + "UserId=Razia"+System.nanoTime()
				+ "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
				+ "authorId=" + testData.get("author_id_adapter") + "&"
				+ "ReviewText=Very good product.&"
				+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
				+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
				+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
				+ "contextdatavalue_Age=18to24";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.FormErrors.FieldErrors.usernickname.Code", "ERROR_FORM_REQUIRED", "nick name mull");
		validator.nodeMatches("$.payload.FormErrors.FieldErrors.usernickname.Message", "You must enter a nickname.", "nick name null.");

		// validator.nodeMatches("$.payload.Review.ReviewText", "Very good product.", "ReviewText should be present in the response");

		// validator.nodeMatches("$.payload.Errors.Message",".+", "Error Message should be present in the response");
		// validator.nodeMatches("$.payload.Errors.Code",".+", "Error code should be present in the response");
		// validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be True");
		//
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "&SendEmailAlertWhenCommented=true&"
					+ "Title=diff&"
					+ "IsRecommended=true&Rating_Quality=2&"
					+ "city=" + testData.get("WI_BILLING_CITY") + "&"
					+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
					+ "UserId=Razia" + System.nanoTime()
					+ "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
					+ "authorId=" + testData.get("author_id_openapi") + "&"
					+ "ReviewText=Very good product.&"
					+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
					+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
					+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
					+ "contextdatavalue_Age=18to24";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "Submit Review Reveiw TextNull", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.getProfile",
			description = "Submitting the Answers ")

	public void ReviewTextNull() {

		System.out.println("Author Id2" + testData.get("author_id_adapter"));

		// Create Request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserNickname=Razia" + System.nanoTime()
				+ "&SendEmailAlertWhenCommented=true&"
				+ "Title=diff&"
				+ "IsRecommended=true&Rating_Quality=2&"
				+ "city=" + testData.get("WI_BILLING_CITY") + "&"
				+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
				// + "UserId=Razia"+System.nanoTime()
				+ "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
				+ "authorId=" + testData.get("author_id_adapter") + "&"
				+ "ReviewText=" + "" + "&"
				+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
				+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
				+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
				+ "contextdatavalue_Age=18to24";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		// validator.nodeMatches("$.payload.Errors[0].Message",".+", "Error Message should be present in the response");
		// validator.nodeMatches("$.payload.Errors[0].Code",".+", "Error code should be present in the response");
		// validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be False");

		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "UserNickname=Razia" + System.nanoTime()
					+ "&SendEmailAlertWhenCommented=true&"
					+ "Title=diff&"
					+ "IsRecommended=true&Rating_Quality=2&"
					+ "city=" + testData.get("WI_BILLING_CITY") + "&"
					+ "UserEmail=" + testData.get("ADAPTER_EMAIL_ID") + "&"
					+ "UserId=Razia" + System.nanoTime()
					+ "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
					+ "authorId=" + testData.get("author_id_openapi") + "&"

			+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
					+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
					+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
					+ "contextdatavalue_Age=18to24";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 14, testName = "Submit Review EmptyUserMail", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.getProfile",
			description = "Submitting the Answers ")

	public void EmptyUserMail() {

		System.out.println("Author Id2" + testData.get("author_id_adapter"));

		// Create Request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserNickname=Razia" + System.nanoTime()
				+ "&SendEmailAlertWhenCommented=true&"
				+ "Title=diff&"
				+ "IsRecommended=true&Rating_Quality=2&"
				+ "city=" + testData.get("WI_BILLING_CITY") + "&"
				+ "UserEmail=" + testData.get("") + "&"
				// + "UserId=Razia"+System.nanoTime()
				+ "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
				+ "authorId=" + testData.get("author_id_adapter") + "&"
				+ "ReviewText=Very good product.&"
				+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
				+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
				+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
				+ "contextdatavalue_Age=18to24";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateExpectedErrors("ERROR_FORM_INVALID_EMAILADDRESS","Your email address is not in the proper format.");
		validator.nodeMatches("$.payload.FormErrors.FieldErrors.useremail.Code", "ERROR_FORM_INVALID_EMAILADDRESS", "Your email address is not in the proper format.");
		validator.nodeMatches("$.payload.FormErrors.FieldErrors.useremail.Message", "Your email address is not in the proper format.", "email address invalid format.");

		// validator.validateNoErrors();
		// validator.nodeMatches("$.payload.Errors[0].Message",".+", "Error Message should be present in the response");
		// validator.nodeMatches("$.payload.Errors[0].Code",".+", "Error code should be present in the response");
		// validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be False");

		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "UserNickname=Razia" + System.nanoTime()
					+ "&SendEmailAlertWhenCommented=true&"
					+ "Title=diff&"
					+ "IsRecommended=true&Rating_Quality=2&"
					+ "city=" + testData.get("WI_BILLING_CITY") + "&"
					+ "UserEmail=" + testData.get("") + "&"
					+ "UserId=Razia" + System.nanoTime()
					+ "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
					+ "authorId=" + testData.get("author_id_openapi") + "&"
					+ "ReviewText=Very good product.&"
					+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
					+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
					+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
					+ "contextdatavalue_Age=18to24";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 14, testName = "Submit Review InvalidUserMail", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.getProfile",
			description = "Submitting the Answers ")

	public void InvalidUserMail() {

		System.out.println("Author Id2" + testData.get("author_id_adapter"));

		// Create Request
		String strPayload = "ProductId=" + testData.get("PRODUCT_ID") + "&" + "action=" + testData.get("ACTION") + "&"
				+ "UserNickname=Razia" + System.nanoTime()
				+ "&SendEmailAlertWhenCommented=true&"
				+ "Title=diff&"
				+ "IsRecommended=true&Rating_Quality=2&"
				+ "city=" + testData.get("WI_BILLING_CITY") + "&"
				+ "UserEmail=" + testData.get("INVALID_ADAPTER_EMAIL_ID") + "&"
				// + "UserId=Razia"+System.nanoTime()
				+ "tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
				+ "authorId=" + testData.get("author_id_adapter") + "&"
				+ "ReviewText=Very good product.&"
				+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
				+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
				+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
				+ "contextdatavalue_Age=18to24";

		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_REVIEW_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.FormErrors.FieldErrors.useremail.Code", "ERROR_FORM_INVALID_EMAILADDRESS", "Your email address is not in the proper format.");
		validator.nodeMatches("$.payload.FormErrors.FieldErrors.useremail.Message", "Your email address is not in the proper format.", "email address invalid format.");

		// validator.validateNoErrors();
		// validator.nodeMatches("$.payload.Errors[0].Message",".+", "Error Message should be present in the response");
		// validator.nodeMatches("$.payload.Errors[0].Code",".+", "Error code should be present in the response");
		// validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be False");

		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ProductId=" + testData.get("PRODUCT_ID") + "&"
					+ "UserNickname=Razia" + System.nanoTime()
					+ "&SendEmailAlertWhenCommented=true&"
					+ "Title=diff&"
					+ "IsRecommended=true&Rating_Quality=2&"
					+ "city=" + testData.get("WI_BILLING_CITY") + "&"
					+ "UserEmail=" + testData.get("INVALID_ADAPTER_EMAIL_ID") + "&"
					+ "UserId=Razia" + System.nanoTime()
					+ "&tag_Con_1=good&CampaignId=BV_MOBILE_RATING_SUMMARY&Rating_Style=3&Rating=4&"
					+ "authorId=" + testData.get("author_id_openapi") + "&"
					+ "ReviewText=Very good product.&"
					+ "UserLocation=" + testData.get("CUSTOMER_FIRSTNAME") + "" + testData.get("WI_BILLING_STATE") + "&"
					+ "tag_Pro_1=notgood&SendEmailAlertWhenPublished=true&Rating_Value=4&"
					+ "contextdatavalue_stateOfResidence=" + testData.get("WI_BILLING_STATE") + "&"
					+ "contextdatavalue_Age=18to24";
			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_REVIEW_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Form.Id,payload.Data.Fields.usernickname.Value,payload.Review.SubmissionTime", true);
		}
	}

}