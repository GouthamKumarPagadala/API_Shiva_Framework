package test.java.adapters.bazaarvoice.review;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.GET_REVIEWS_PRODUCT_ADAPTER;
import static main.java.common.GlobalVariables.GET_REVIEWS_PRODUCT_BAZAARVOICE;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("BazaarVoice")
@Stories({ "Syndicate Content" })

public class SyndicateContent {

	ResponseValidator validator;


	@BeforeClass(alwaysRun = true)
	public void testSetup() {

	}


	@Test(groups = { "regression","functional", "syndicate_content" }, enabled = true, priority = 0, testName = "Syndicated contest - No Flag Sent as Filter",
			description = "Bazaar voice Syndicated contest when No Flag Sent as Filter")
	@TestCaseId("ShowRiview_Syndicated_NoFlag")
	public void syndicateContentNoFlag() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Limit=6&Offset=0";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[*].IsSyndicated", ".*(true|false).*", "Response should have True and Flase");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.Name", ".+", "Name should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.LogoImageUrl", ".+", "LogoImagineUrl should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.ContentLink", ".+", "ContentLink shouldnt be null");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Limit=6&Offset=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "syndicate_content" }, enabled = true, priority = 0, testName = "Syndicated contest - Flag is true",
			description = "Bazaar voice Syndicated contest when flag is true")
	@TestCaseId("ShowRiview_Syndicated_FlagTrue")
	public void syndicateContentFlagTrue() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Limit=6&Offset=0&Filter=IsSyndicated:true";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[1].IsSyndicated", "true", "IsSyndicated should be True");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.Name", ".+", "Name should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.LogoImageUrl", ".+", "LogoImagineUrl should not be null");
		validator.nodeMatches("$.payload.Results[1].SyndicationSource.ContentLink", ".+", "ContentLink shouldnt be null");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Limit=6&Offset=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}

	}


	@Test(groups = { "regression","functional", "syndicate_content" }, enabled = true, priority = 0, testName = "Syndicated contest - No Flag Sent as Filter",
			description = "Bazaar voice Syndicated contest when No Flag Sent as Filter")
	@TestCaseId("ShowRiview_Syndicated_FlagFalse")
	public void syndicateContentFalse() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR_SYNDICATEFALSE") + "&Limit=6&Offset=0";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR_SYNDICATEFALSE"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[*].IsSyndicated", ".*(false).*", "IsSyndicated should be True");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR_SYNDICATEFALSE") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Limit=6&Offset=0";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}
}
