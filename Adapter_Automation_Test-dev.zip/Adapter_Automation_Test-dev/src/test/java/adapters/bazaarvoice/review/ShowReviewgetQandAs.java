package test.java.adapters.bazaarvoice.review;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.GETQA_PRODUCT_ADAPTER;
import static main.java.common.GlobalVariables.GETQA_PRODUCT_BAZZ;
import static main.java.common.GlobalVariables.GET_REVIEWS_PRODUCT_ADAPTER;
import static main.java.common.GlobalVariables.GET_REVIEWS_PRODUCT_BAZAARVOICE;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.GlobalVariables.CMS_ADAPTER;
import static main.java.common.GlobalVariables.CMS_SKAVA;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "Show Review" })
public class ShowReviewgetQandAs {

	ResponseValidator validator;


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "OnlyProductID",
			description = "reviewing the answers ")
	public void onlyProductID() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR");
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results[0].ProductId", testData.get("PRODUCT_ID_BAZAAR"), "Product ID should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "SortValueasDesc",
			description = " ")
	public void sortValueAsDesc() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:desc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Includes.Products", ".+", "Products should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:desc";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "SortValueasAsc",
			description = " ")
	public void sortValueAsAsc() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:asc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Includes.Products", ".+", "Products should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:asc";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 14, testName = "Invalid Sort Value",
			description = " ")
	public void invalidSortValue() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:fsfsde23";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		validator.validateExpectedErrors("ERROR_PARAM_INVALID_SORT_ATTRIBUTE", "Invalid sort order: ASC or DESC must be specified for sort SubmissionTime");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:fsfsde23";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 14, testName = "Invalid Stat Value",
			description = " ")
	public void invalidStateValue() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Include=products" + "&Stats=fsdsef" + "&Sort=SubmissionTime:asc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		validator.validateExpectedErrors("ERROR_PARAM_INVALID_PARAMETERS", "Invalid stat type: fsdsef");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Include=products" + "&Stats=fsdsef" + "&Sort=SubmissionTime:asc";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "Invalid Prod",
			description = " ")
	public void invalidProd() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:34fsdse" + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:asc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.nodeMatches("$.payload.Errors[0].Message",".+", "Error Message should be present in the response");
		// validator.nodeMatches("$.payload.Errors[0].Code",".+", "Error code should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:34fsdse" + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Include=products" + "&Stats=Reviews" + "&Sort=SubmissionTime:asc";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 14, testName = "Invalid Include Value",
			description = " ")
	public void invalidIncludeValue() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Include=fsdse23" + "&Stats=Reviews" + "&Sort=SubmissionTime:asc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERROR_PARAM_INVALID_INCLUDED", "Invalid included type: fsdse23");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4" + "&Include=fsdse23" + "&Stats=Reviews" + "&Sort=SubmissionTime:asc";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "test2" }, enabled = true, priority = 15, testName = "get QA For Product",
			description = "Getting the Question and Answers By using ProductId")
	public void GetQAForProduct() {

		String strURL = GETQA_PRODUCT_ADAPTER + testData.get("PRODUCT_ID");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Results", ".+", "Results should be present in the response");
		validator.nodeMatches("$.payload.Results[0].QuestionSummary", ".+", "Question Summary should be present in the response");
		validator.nodeMatches("$.payload.Results[0].SubmissionId", ".+", "Submission Id should be present in the response");
		validator.nodeMatches("$.payload.Results[0].SubmissionTime", ".+", "Submission Time should be present in the response");
		validator.nodeMatches("$.payload.TotalResults", "[0-9]+", "TotalResults should be present in the response");
		validator.nodeMatches("$.payload.Results[0].UserNickname", ".+", "UserNickName Summary should be present in the response");
		// Compare Bazzar Voice
		if (CompareOAPI) {

			// Create the Json Request

			String strURLBAZAARVOICE = GETQA_PRODUCT_BAZZ + "passkey=9ngrf7rngkhm4a7r6n4uvxaq&"
					+ "apiversion=5.4&"
					+ "&ProductId=" + testData.get("PRODUCT_ID");
			// Post the request
			String strResponseBAZZ = RestCall.getRequest(strURLBAZAARVOICE, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseBAZZ + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "", true);
		}

	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "showReview",
			description = "IsSyndicated : false, when we do not pass any syndication filter in the request")
	public void SyndicatedcontentFalseWithFilterProductID() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "IsSyndicated:false&ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&Limit=6&Offset&0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isSyndicatedFalse();
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "IsSyndicated:false&ProductId:" + testData.get("PRODUCT_ID_BAZAAR") + "&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&apiversion=5.4&Limit=6&Offset&0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "showReview",
			description = "IsSyndicated : true, when we pass Filter with IsSyndicated as true in the request")
	public void SyndicatedcontentTrueWithFilterTrue() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "IsSyndicated:true&Limit=6&Offset=0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isSyndicatedTrue();
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "IsSyndicated:true&Limit=6&Offset=0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc&passkey=9ngrf7rngkhm4a7r6n4uvxaq&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "showReview",
			description = "isSyndicated:false, when passing the filter with isSyndicated as false in the request")
	public void SyndicatedcontentFalseWithFilterFalse() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "IsSyndicated:false&Limit=6&Offset=0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isSyndicatedFalse();
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "IsSyndicated:false&Limit=6&Offset=0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc&passkey=9ngrf7rngkhm4a7r6n4uvxaq&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "showReview",
			description = "IsSyndicated : true, when we pass Filter with IsSyndicated as true in the request")
	public void SyndicatedcontentFalseWihtoutFilter() {

		// Get the request
		String strURL = GET_REVIEWS_PRODUCT_ADAPTER + "&Limit=6&Offset=0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.isSyndicatedFalse();
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = GET_REVIEWS_PRODUCT_BAZAARVOICE + "&Limit=6&Offset=0&Include=Products&Stats=Reviews&Sort=SubmissionTime:desc&passkey=9ngrf7rngkhm4a7r6n4uvxaq&apiversion=5.4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.BazaarVoice, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponseOAPI + "}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaarVoice, "payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}

}