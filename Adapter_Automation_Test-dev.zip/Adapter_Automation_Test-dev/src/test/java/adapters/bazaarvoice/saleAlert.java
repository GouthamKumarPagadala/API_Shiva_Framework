package test.java.adapters.bazaarvoice;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.SALEALERT_ADAPTER;
import static main.java.common.GlobalVariables.SALEALERT_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "Sale Alert" })
public class saleAlert {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "salesalert" }, enabled = true, priority = 4, testName = "Sale Alert",
			description = "Subscribing the EmailID with valid EmailID")
	public void ValidEmailID() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{"
				+ "\"email\":\"raaz123@gmail.com\","
				+ "\"address\" : " + JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Subscribed successfully", "message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "salesalert", "errorhandling" }, enabled = true, priority = 4, testName = "Sale Alert",
			description = "Subscribing the EmailID with Invalid EmailID")
	public void InValidEmailID() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{"
				+ "\"email\":\"razia.gmail.com\","
				+ "\"address\" : " + JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("SALE1002", "Invalid value passed for Email.");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "salesalert" }, enabled = true, priority = 4, testName = "Sale Alert",
			description = "Subscribing the EmailID with valid EmailID and with Blank Address")
	public void ValidEmailIDWithBlankAddress() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{"
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"address\" : " + JsonString.getBillAddressJson("EMPTY_ADDRESS")
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Subscribed successfully", "message should be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			// String strURLOAPI=SALEALERT_OAPI+"/"+testData.get("RUNTIME_WEBID1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "salesalert", "errorhandling" }, enabled = true, priority = 4, testName = "Sale Alert",
			description = "Subscribing the EmailID with Invalid EmailID Parameter")
	public void EmailIDParameterInvalid() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{"
				+ "\"emailID\":\"shankarc44@gmail.com\","
				+ "\"address\" : " + JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR2700", "Invalid JSON: Unrecognized field emailID");

		// Compare Open API
		if (CompareOAPI) {

			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "salesalert", "errorhandling" }, enabled = true, priority = 4, testName = "Sale Alert",
			description = "Subscribing the EmailID with empty value in EmailID")
	public void EmailIDNull() {

		// Create Request
		String strPayload = "{\"payload\": {\"subscriber\":{"
				+ "\"email\":\"\","
				+ "\"address\" : " + JsonString.getBillAddressJson("IL_CHICAGO")
				+ "}}}";

		// Post Request
		String strResponse = RestCall.postRequest(SALEALERT_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("SALE1000", "Missing Required Parameter email");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			// String strURLOAPI=SALEALERT_OAPI+"/"+testData.get("RUNTIME_WEBID1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(SALEALERT_OAPI, strPayload, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}

	}
}
