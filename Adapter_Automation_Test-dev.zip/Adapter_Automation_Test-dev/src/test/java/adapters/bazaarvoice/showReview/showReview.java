package test.java.adapters.bazaarvoice.showReview;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.SUBMIT_FEEDBACK_ADAPTER;
import static main.java.common.GlobalVariables.SUBMIT_FEEDBACK_BAZAARVOICE;
import static main.java.common.GlobalVariables.AUTHORS_ID_ADAPTER;
import static main.java.common.GlobalVariables.AUTHORS_ID_BAZAARVOICE;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.GlobalVariables.CMS_ADAPTER;
import static main.java.common.GlobalVariables.CMS_SKAVA;
import static main.java.common.GlobalVariables.SHOW_REVIEW_ADAPTER;
import static main.java.common.GlobalVariables.SHOW_REVIEW_BAZAARVOICE;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "ShowReview" })

public class showReview {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "syndicated_content" }, enabled = true,
			priority = 14,
			testName = "ShowReview_FilterWithProductID",
			description = "ShowReview FilterWithProductID")
	public void FilterWithProductID() {

		String strUrl1 = SHOW_REVIEW_ADAPTER + "Filter=ProductId:" + testData.get("REVIEW_PRODUCT") + "&Limit=6&Offset=0";
		// Post the request
		String strResponse1 = RestCall.getRequest(strUrl1, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.nodeEquals("$.payload.Results[0].IsSyndicated", "false", "IsSyndicated Item value should be false in the response");

		if (CompareOAPI) {
			String strUrl2 = SHOW_REVIEW_BAZAARVOICE + "Filter=ProductId:" + testData.get("REVIEW_PRODUCT");
			// Post the request
			String strResponse2 = RestCall.getRequest(strUrl2, Server.Adapter, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponse2 + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse1, strResponseBazaarVoice, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "syndicated_content" }, enabled = true,
			priority = 14,
			testName = "ShowReview_SyndicatedFilterTrue",
			description = "ShowReview When Syndicated Content is True")
	public void SyndicatedFilterTrue() {

		String strUrl1 = SHOW_REVIEW_ADAPTER + "Filter=IsSyndicated:true&Limit=6&Offset=0";
		// Post the request
		String strResponse1 = RestCall.getRequest(strUrl1, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.nodeEquals("$.payload.Results[0].IsSyndicated", "true", "IsSyndicated Item value should be true in the response");

		if (CompareOAPI) {
			String strUrl2 = SHOW_REVIEW_BAZAARVOICE + "Filter=IsSyndicated:true&Limit=6&Offset=0";
			// Post the request
			String strResponse2 = RestCall.getRequest(strUrl2, Server.Adapter, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponse2 + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse1, strResponseBazaarVoice, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "syndicated_content" }, enabled = true,
			priority = 14,
			testName = "ShowReview_SyndicatedFilterFalse",
			description = "ShowReview When Syndicated Content is False")
	public void SyndicatedFilterFalse() {

		String strUrl1 = SHOW_REVIEW_ADAPTER + "Filter=IsSyndicated:false&Limit=6&Offset=0";
		// Post the request
		String strResponse1 = RestCall.getRequest(strUrl1, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.nodeEquals("$.payload.Results[0].IsSyndicated", "false", "IsSyndicated Item value should be false in the response");

		if (CompareOAPI) {
			String strUrl2 = SHOW_REVIEW_BAZAARVOICE + "Filter=IsSyndicated:false&Limit=6&Offset=0";
			// Post the request
			String strResponse2 = RestCall.getRequest(strUrl2, Server.Adapter, false);
			String strResponseBazaarVoice = "{\"payload\":" + strResponse2 + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse1, strResponseBazaarVoice, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional", "syndicated_content" }, enabled = true,
			priority = 14,
			testName = "ShowReview_Without SyndicatedFilter",
			description = "ShowReview Without Syndicated Filter")
	public void WithoutSyndicatedFilter() {

		String strUrl1 = SHOW_REVIEW_ADAPTER + "Limit=6&Offset=0";
		// Post the request
		String strResponse1 = RestCall.getRequest(strUrl1, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse1);
		validator.nodeEquals("$.payload.Results[0].IsSyndicated", "false", "IsSyndicated Item value should be false in the response");

		if (CompareOAPI) {
			String strUrl2 = SHOW_REVIEW_BAZAARVOICE + "Limit=6&Offset=0";
			// Post the request
			String strResponse2 = RestCall.getRequest(strUrl2, Server.Adapter, false);

			String strResponseBazaarVoice = "{\"payload\":" + strResponse2 + "}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse1, strResponseBazaarVoice, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}
}
