package test.java.adapters.bazaarvoice.feedback;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.SUBMIT_FEEDBACK_ADAPTER;
import static main.java.common.GlobalVariables.SUBMIT_FEEDBACK_BAZAARVOICE;
import static main.java.common.GlobalVariables.AUTHORS_ID_ADAPTER;
import static main.java.common.GlobalVariables.AUTHORS_ID_BAZAARVOICE;
import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.BALANCE_OAPI;
import static main.java.common.GlobalVariables.CMS_ADAPTER;
import static main.java.common.GlobalVariables.CMS_SKAVA;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("BazaarVoice")
@Stories({ "SubmitFeedback" })
public class SubmitFeedback {

	ResponseValidator validator;


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 14, testName = "EMPTYFEDDBACK and CONTENT TYPE",
			description = "Submitting the Answers ")
	public void EmptyFeddbackContent() {

		// Create Request
		String strPayload = "action=" + testData.get("ACTION") + "&"
				+ "ContentId=" + testData.get("CONTENT_ID") + "&"
				+ "UserId=" + testData.get("author_id_adapter") + "&"
				+ "Vote=" + testData.get("VOTE");
		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();

		validator.nodeMatches("$.payload.Errors[0].Message", ".+", "Error Message should be present in the response");
		validator.nodeMatches("$.payload.Errors[0].Code", ".+", "Error code should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be False");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ContentId=" + testData.get("CONTENT_ID") + "&"
					+ "UserId=" + testData.get("author_id_openapi") + "&"
					+ "Vote=" + testData.get("VOTE");

			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_FEEDBACK_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 14, testName = "NO Value for Feedback",
			description = "Submitting the Answers ")
	public void NOVALUEFEEDBACK() {

		// Create Request
		String strPayload = "action=" + testData.get("ACTION") + "&"
				+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
				+ "ContentId=" + testData.get("CONTENT_ID") + "&"
				+ "UserId=" + testData.get("author_id_adapter") + "&"
				+ "FeedbackType=NO" + "&"
				+ "Vote=" + testData.get("VOTE");
		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();
		validator.nodeMatches("$.payload.Errors[0].Message", ".+", "Error Message should be present in the response");
		validator.nodeMatches("$.payload.Errors[0].Code", ".+", "Error code should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be False");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
					+ "ContentId=" + testData.get("CONTENT_ID") + "&"
					+ "UserId=" + testData.get("author_id_openapi") + "&"
					+ "FeedbackType=NO" + "&"
					+ "Vote=" + testData.get("VOTE");

			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_FEEDBACK_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 14, testName = "Invalid UserID",
			description = "Submitting the Answers ")
	public void INVALIDUSERID() {

		// Create Request
		String strPayload = "action=" + testData.get("ACTION") + "&"
				+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
				+ "ContentId=" + testData.get("CONTENT_ID") + "&"
				+ "UserId=as34." + "&"
				+ "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&"
				+ "Vote=" + testData.get("VOTE");
		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.Feedback.Helpfulness.Vote", ".+", "Vote should be present in the response");
		validator.nodeMatches("$.payload.Feedback.Helpfulness.AuthorId", ".+", "AuthorId should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "false", "HasErrors should be False");
		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
					+ "ContentId=" + testData.get("CONTENT_ID") + "&"
					+ "UserId=as34." + "&"
					+ "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&"
					+ "Vote=" + testData.get("VOTE");

			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_FEEDBACK_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}


	@Test(groups = { "regression","functional","errorhandling" }, enabled = true, priority = 14, testName = "ContentId as Zero",
			description = "Submitting the Answers ")
	public void ContentIDASZERO() {

		// Create Request
		String strPayload = "action=" + testData.get("ACTION") + "&"
				+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
				+ "ContentId=0" + "&"
				+ "UserId=" + testData.get("author_id_adapter") + "&"
				+ "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&"
				+ "Vote=" + testData.get("VOTE");
		// Post Request
		String strResponse = RestCall.postRequest(SUBMIT_FEEDBACK_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateNoErrors();

		validator.nodeMatches("$.payload.Errors[0].Message", ".+", "Error Message should be present in the response");
		validator.nodeMatches("$.payload.Errors[0].Code", ".+", "Error code should be present in the response");
		validator.nodeMatches("$.payload.HasErrors", "true", "HasErrors should be False");

		if (CompareOAPI) {
			String strPayloadBazVoice = "apiversion=5.4&passkey=" + testData.get("BAZAAR_VOICE_PASSKEY") + "&action=" + testData.get("ACTION") + "&"
					+ "ContentType=" + testData.get("CONTENT_TYPE_SUBMITFEEDBACK") + "&"
					+ "ContentId=0" + "&"
					+ "UserId=" + testData.get("author_id_openapi") + "&"
					+ "FeedbackType=" + testData.get("FEEDBACK_TYPE") + "&"
					+ "Vote=" + testData.get("VOTE");

			// Post the request
			String strResponseBazzarVoice = RestCall.postRequest(SUBMIT_FEEDBACK_BAZAARVOICE, strPayloadBazVoice, Server.BazaarVoice, true);
			String strResponseBazaar = "{\"payload\":" + strResponseBazzarVoice + "}";
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseBazaar, "payload.Data.Fields.usernickname.Value,payload.Data.Fields.useremail.Value,payload.AuthorSubmissionToken,payload.Answer.SubmissionTime,payload.SubmissionId", true);
		}
	}

}
