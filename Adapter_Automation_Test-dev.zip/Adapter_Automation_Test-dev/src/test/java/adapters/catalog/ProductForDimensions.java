package test.java.adapters.catalog;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Catalog")
@Stories({ "Product for Dimensions" })
public class ProductForDimensions {

	ResponseValidator validator;
	String strEmail = Utilities.getNewEmailID();
	String strPaswd = "Pass@123";
	@BeforeClass(alwaysRun = true)
	public void testSetup(){
		// Create a new profile through OAPI
				
				Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);

				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfileV2(strEmail, strPaswd, Server.OpenApi, "access_token_oapi","X-Profile-Id");
						
				
				// SiginIn to Adapter using the above created OCB profile
				Utilities.signInProfileV2(strEmail, strPaswd, Server.Adapter, "access_token_adapter","X-Profile-Id");
	}


	@Test(groups = { "regression","functional", "errorhandling","DIE_Changes","CatalogChanges-NAP146","Personalized-NAP362" }, enabled = true, priority = 12, testName = "productsForDimension",
			description = "Checking the products available while passing invalid dimension id")
	public void InvalidCategoryID() {

		String strURL = CATALOG_ADAPTER + "/jhhjd13";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		//validator.validateExpectedErrors("CATA1002", "Invalid value passed for dimensionValueID.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/jhhjd13";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","smokeTest","functional","GroupPricing","SuppresedPrice","Promotion-NAP118","SmartSuppressedPricing-NAP126","CatalogChanges-NAP146","Personalized-NAP362","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate SalePriceStatus,<br /> Suppressedpricing,<br /> catalog DIE changes,<br /> Promotion Array,<br /> Grouppricing,<br /> SmartSuppressedPricing  ")
	 
	public void SearchCatalogWithStoreNum() {

		String strURL = CATALOG_ADAPTER + "?storeNum=647&limit=24&isDefaultStore=true&channel=tablet&zipcode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		int count = JsonPath.read(strResponse, "$.limit");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      	//System.out.println(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices"));
      	if(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices").equals("[]"))
	        	continue;
      	String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePrice").toString();
      	 if(salePrice.equals("null"))
 			
			{
	    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
			
			}
	       
	       else
	       {
	    	   validator.nodeNotEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null"); 
	       }
      	//validating SuppressedPrice 
      	String suppressed= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].prices[0].isSuppressed").toString();
        String WebId= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].webID").toString();
      	 if(suppressed.equals("true"))
   	 {
   	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed text should be present as it is suppressed Product - "+WebId);
   	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].promotion","null","Promotion should be null as it is suppressed product");
   	 }
   	 
   		validateSmartSuppressedPricing(i,WebId,strResponse);      	
      	 
     	// Promotion Array Validation
      	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.group", ".*",
					"group should be displayed under Promotion");
      	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.tieredPrice", ".*",
					"tieredPrice should be displayed under Promotion");
      	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.bogo", ".*",
					"bogo should be displayed under Promotion");
      //DIE catalog validation
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");

	        
	      
	    }}
		catch(Exception e)
			{
			
			
			}
	 }


	@Test(groups = { "regression","functional","SuppresedPrice","GroupPricing","Promotion-NAP118","SmartSuppressedPricing-NAP126","CatalogChanges-NAP146","Personalized-NAP362","DIE_Changes" }, enabled = true, priority = 12, testName = "productsForDimension locations",
			description = "Checking the products available by passing webId \n Feature - validate SalePriceStatus,<br /> Suppressedpricing,<br /> Catalog DIE changes,<br /> Promotion Array,<br /> Grouppricing,<br /> SmartSuppressedPricing  ")
	public void SearchCatalogByWebid() {

		String strURL = CATALOG_ADAPTER + "/1149154/?storeNum=647&isDefaultStore=false&channel=tablet&zipcode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		int count = JsonPath.read(strResponse, "$.limit");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      	//System.out.println(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices"));
    	  if(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices").equals("[]"))
	        	continue;
    	String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePrice").toString();
    	
    	if(salePrice.equals("null"))
			
		{
    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
		
		}
       
       else
       {
    	   validator.nodeNotEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null"); 
       }
    	//validating SuppressedPrice 
    	String suppressed= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].prices[0].isSuppressed").toString();
        String WebId= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].webID").toString();
      	 if(suppressed.equals("true"))
   	 {
   	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed text should be present as it is suppressed Product - "+WebId);
   	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].promotion","null","Promotion should be null as it is suppressed product");
   	 }
      	validateSmartSuppressedPricing(i,WebId,strResponse); 
      // Promotion Array Validation
       	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.group", ".*",
 					"group should be displayed under Promotion");
       	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.tieredPrice", ".*",
 					"tieredPrice should be displayed under Promotion");
       	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.bogo", ".*",
 					"bogo should be displayed under Promotion");
      //DIE catalog validation
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");

	        
	       if(salePrice.equals("null"))
			
			{
	    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
			
			}
	       
	       else
	       {
	    	   validator.nodeNotEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null"); 
	       }
	    }}
		catch(Exception e)
			{
			
			
			}
	 }



	@Test(groups = { "regression","functional","SuppresedPrice","GroupPricing","Promotion-NAP118","SmartSuppressedPricing-NAP126","DIE_Changes","CatalogChanges-NAP146","Personalized-NAP362" }, enabled = true, priority = 12, testName = "productsForDimension kohlsCharge",
			description = "Checking the products available by passing skucode \n Feature - validate SalePriceStatus,<br /> Suppressedpricing,<br /> Catalog DIE_Changes,<br /> Promotion Array,<br /> Grouppricing,<br /> SmartSuppressedPricing ")
	public void SearchCatalogBySku() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=93375672&offset=1&storeNum=647&isDefaultStore=true&limit=12&zipcode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
			
      for (int i = 0; i < count-1; i++){
      
    	  String suppressed= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].prices[0].isSuppressed").toString();
          String WebId= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].webID").toString();
        	 if(suppressed.equals("true"))
     	 {
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed text should be present as it is suppressed Product - "+WebId);
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].promotion","null","Promotion should be null as it is suppressed product");
     	 }
        	 validateSmartSuppressedPricing(i,WebId,strResponse); 
        	// Promotion Array Validation
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.group", ".*",
     					"group should be displayed under Promotion");
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.tieredPrice", ".*",
     					"tieredPrice should be displayed under Promotion");
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.bogo", ".*",
     					"bogo should be displayed under Promotion");
          //DIE catalog validation
           	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
 					"isAvailableforShip node should be displayed under Product level");
        	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
 					"isAvailableforPickUp node should be displayed under Product level");
  
  	        
    	String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePrice").toString();
    	
    	
	       if(salePrice.equals("null"))
			
			{
	    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
			
			}
	       
	       else
	       {
	    	   validator.nodeNotEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null"); 
	       }
	    }}
		catch(Exception e)
			{
			
			
			}
	 }
		

	@Test(groups = { "regression","functional","SuppresedPrice","CatalogChanges-NAP146","Personalized-NAP362","DIE_Changes","GroupPricing","Promotion-NAP118","SmartSuppressedPricing-NAP126" }, enabled = true, priority = 12, testName = "productsForDimension kohlsCash",
			description = "Checking the products available by passing Dimension ID \n Feature - validate SalePriceStatus,<br /> Suppressedpricing,<br /> Promotion Array,<br /> catalog DIE Chnages,<br /> Grouppricing,<br /> SmartSuppressedPricing  ")
	public void SearchCatalogByDimensionId() {

		String strURL = CATALOG_ADAPTER + "/Department:Bed%20%26%20Bath?isDefaultStore=true&channel=android&storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		int count = JsonPath.read(strResponse, "$.limit");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      	//System.out.println(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices"));
    	  if(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices").equals("[]"))
	        	continue;
    	//validating SuppressedPrice 
    	  String suppressed= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].prices[0].isSuppressed").toString();
          String WebId= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].webID").toString();
        	 if(suppressed.equals("true"))
     	 {
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed text should be present as it is suppressed Product - "+WebId);
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].promotion","null","Promotion should be null as it is suppressed product");
     	 }
        	 validateSmartSuppressedPricing(i,WebId,strResponse); 
        	// Promotion Array Validation
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.group", ".*",
     					"group should be displayed under Promotion");
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.tieredPrice", ".*",
     					"tieredPrice should be displayed under Promotion");
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.bogo", ".*",
     					"bogo should be displayed under Promotion");
//DIE catalog validation
           	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
 					"isAvailableforShip node should be displayed under Product level");
        	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
 					"isAvailableforPickUp node should be displayed under Product level");
           
  	        
    	String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePrice").toString();
    	
	       
	       if(salePrice.equals("null"))
			
			{
	    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
			
			}
	       
	       else 
	       {
	    	   String salePriceStatus = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePriceStatus").toString();
	    	  Assert.assertNotNull(salePriceStatus, "sale prie status sould not be null");
	      
	       }
	    }}
		catch(Exception e)
			{
			
			
			}
	 }
	

	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension rewards",
			description = "Checking the products available in rewards")
	public void Rewards() {

		String strURL = CATALOG_ADAPTER + "?limit=24&offset=1&sortID=3&keyword=rewards";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeMatches(json, "[0-9]+", "Categories should be present in the response");
		

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "?limit=24&offset=1&sortID=3&keyword=rewards";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension InvalidKeyword",
			description = "Checking the products available while passing Invalid keyword")
	public void InvalidKeyword() {

		String strURL = CATALOG_ADAPTER + "?limit=24&offset=1&sortID=3&keyword=fsfhkj%20kjhsfe&channel=android&zipcode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeEquals(json, "0", "Categories should not be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "?limit=24&offset=1&sortID=3&keyword=fsfhkj%20kjhsf";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension productsForAllCategories",
			description = "Checking the products available for all categories")
	public void productsForAllCategories() {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=3";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=3";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling","DIE_Changes","CatalogChanges-NAP146","Personalized-NAP362" }, enabled = true, priority = 12, testName = "productsForDimension OffsetAsZero",
			description = "Checking the error code while passing the offset as zero")
	public void OffsetAsZero() {

		String strURL = CATALOG_ADAPTER + "?limit=24&offset=0&sortID=3";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for offset.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "?limit=24&offset=0&sortID=3";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 12, testName = "productsForDimension Negativelimit",
			description = "Checking the error code while passing the limit as negative")
	public void NegativeLimitProductsForDimensions() {

		String strURL = CATALOG_ADAPTER + "?limit=-24&offset=1&sortID=3";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for limit.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "?limit=-24&offset=1&sortID=3";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling","DIE_Changes","CatalogChanges-NAP146","Personalized-NAP362" }, enabled = true, priority = 12, testName = "productsForDimension LimitGreaterThan99",
			description = "Checking the error code while passing the limit more than 99")
	public void LimitGreaterThan99() {

		String strURL = CATALOG_ADAPTER + "?limit=121&offset=1&sortID=3";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for limit.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "?limit=121&offset=1&sortID=3";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension sortIDAsLowToHigh(4)",
			description = "Checking the products available While passing the sort as 4")
	public void sortIDAsLowToHigh4() {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=4";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");
		validator.nodeEquals("$.payload.sorts[3].ID", "4", "sort ID should be 4 ");
		validator.nodeEquals("$.payload.sorts[3].active", "true", "sort ID 4 should be active");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=4";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension sortIDAsHighToLow(5)",
			description = "Checking the products available While passing the sort as 5")
	public void sortIDAsHighToLow5() {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=5";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");
		validator.nodeEquals("$.payload.sorts[4].ID", "5", "sort ID should be 4 ");
		validator.nodeEquals("$.payload.sorts[4].active", "true", "sort ID 4 should be active");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=5";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "productsForDimension sortIDAsFeatured(1)",
			description = "Checking the products available While passing the sort as 1")
	public void sortIDAsFeatured1() {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=1";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");
		validator.nodeEquals("$.payload.sorts[0].ID", "1", "sort ID should be 4 ");
		validator.nodeEquals("$.payload.sorts[0].active", "true", "sort ID 4 should be active");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=1";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "msm750" }, enabled = true, priority = 12, testName = "productsForDimension sortIDAsFeatured(1)",
			description = "Checking the products available While passing the sort as 7")
	public void Discount_baseCatalog () {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=7";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");
		validator.nodeMatches("$.payload.sorts[3].ID", ".+", "sort ID should be 4 ");
		validator.nodeMatches("$.payload.sorts[3].active", ".+", "sort ID 7 should be active");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=7";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

		    
	@Test(groups = { "GroupPricing","SuppresedPrice","DIE_Changes","CatalogChanges-NAP146","Personalized-NAP362","Promotion-NAP118","SmartSuppressedPricing-NAP126" }, enabled = true, priority = 12, testName = "Catalog_saleprice_status",
			description = "Verify whether User is able to view catalog by keyword search \n Feature - validate SalePriceStatus,<br /> Suppressedpricing,<br /> catalog DIE changes,<br /> Promotion Array,<br /> Grouppricing,<br /> SmartSuppressedPricing  ")
	public void SearchCatalogByKeyword() {

		String strURL = CATALOG_ADAPTER +"?keyword=women&storeNum=647&isDefaultStore=false&channel=android&zipcode=95035";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		int count = JsonPath.read(strResponse, "$.limit");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      	//System.out.println(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices"));
    	  if(Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices").equals("[]"))
	        	continue;
    	//validating SuppressedPrice 
    	  String suppressed= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].prices[0].isSuppressed").toString();
          String WebId= Utilities.getJsonNodeValue(strResponse,"$.payload.products[" + i + "].webID").toString();
        	 if(suppressed.equals("true"))
     	 {
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","Suppressed text should be present as it is suppressed Product - "+WebId);
     	  validator.nodeEquals("$.payload.products[" + i + "].prices[0].promotion","null","Promotion should be null as it is suppressed product");
     	 }
     	 
     		validateSmartSuppressedPricing(i,WebId,strResponse);
        	
        	 
        	// Promotion Array Validation
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.group", ".*",
     					"group should be displayed under Promotion");
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.tieredPrice", ".*",
     					"tieredPrice should be displayed under Promotion");
           	validator.nodeMatches("$.payload.products[" + i + "].prices[0].promotions.bogo", ".*",
     					"bogo should be displayed under Promotion");
          //DIE catalog validation
           	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
 					"isAvailableforShip node should be displayed under Product level");
        	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
 					"isAvailableforPickUp node should be displayed under Product level");
  
  	        
    	String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].prices[0].salePrice").toString();
    	
	        
	       if(salePrice.equals("null"))
			
			{
	    	 validator.nodeEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null");
			
			}
	       
	       else
	       {
	    	   validator.nodeNotEquals("$.payload.products[" + i + "].prices[0].salePriceStatus", "null", " sale price status should be null"); 
	       }
	    }}
		catch(Exception e)
			{
			
			
			}
	 }
		
	
	@Test(groups = { "regression","functional", "msm750" ,"DIE_Changes","CatalogChanges-NAP146","Personalized-NAP362"}, enabled = true, priority = 12, testName = "productsForDimension sortIDAsFeatured(1)",
			description = "Checking the products available While passing the sort as 1")
	public void Discount_DimensionID() {

		String strURL = CATALOG_ADAPTER + "/0?limit=24&offset=1&sortID=7";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should not be present in the response");
		validator.nodeMatches("$.payload.sorts[3].ID", ".+", "sort ID should be 7 ");
		validator.nodeMatches("$.payload.sorts[3].active", ".+", "sort ID 7 should be active");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/0?limit=24&offset=1&sortID=7";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	//added for SmartSuppressedPricing NAP-126
	public void validateSmartSuppressedPricing(int i,String WebId,String response){
	
		String suppressed=Utilities.getJsonNodeValue(response, "$.payload.products[" + i + "].prices[0].suppressedPricingText");
		String promotion=Utilities.getJsonNodeValue(response,"$.payload.products[" + i + "].prices[0].promotion");
		String saleprice=Utilities.getJsonNodeValue(response,"$.payload.products[" + i + "].prices[0].salePriceStatus");
		if(suppressed.equals("null")&&promotion.equals("null")&&saleprice.equals("null"))
		{
			validator.nodeEquals("$.payload.products[" + i + "].prices[0].isSuppressed","false","isSuppressed should be false");
		}
		else if(suppressed.equals("true"))
		{
			
			validator.nodeMatches("$.payload.products[" + i + "].prices[0].suppressedPricingText","FOR PRICE, ADD TO BAG","FOR PRICE, ADD TO BAG should be present");
		}
	}
}
