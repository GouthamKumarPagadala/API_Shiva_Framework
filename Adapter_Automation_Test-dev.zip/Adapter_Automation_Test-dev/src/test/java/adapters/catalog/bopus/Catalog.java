package test.java.adapters.catalog.bopus;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.CATEGORY_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_OAPI;
import static main.java.common.GlobalVariables.CATEGORY_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Catalog")
@Stories({ "Bopus Phase2" })

public class Catalog {

	ResponseValidator validator;
	String[] storeNums={"647","976","761","759","994","6081"};
	//String[] keywords={"men", "shirts", "shorts", "rig"};

	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_InStoreEnabled_False_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, keyword and one storeNumber")
	public void Search_Keyword_With_InStoreEnabled_False_StoreNumber() {

		//String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("SEARCH_KEYWORD_1") +"&sortID=3&limit=24&offset=1&storeNum=" + testData.get("ACTIVE_STORE_NUM_1");
		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=false&keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		//validator.nodeEquals("$.payload.searchTerm", testData.get("SEARCH_KEYWORD_1"), "Keyword searched should present in the response");
		//validator.nodeEquals("$.payload.activeStores[0].storeNum",testData.get("ACTIVE_STORE_NUM_1"),"store num should be present");
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.activeStores[0].storeNum",storeNums[0],"store num should be present");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=false&keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Search_categoryID_With_StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?inStoreEnabled=false&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.activeStores[0].storeNum",storeNums[0],"store num should be present");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?inStoreEnabled=false&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_2StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, keyword and two storeNumber's")
	public void Search_Keyword_With_2StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("SHIRTS_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
//		validator.nodeEquals("$.payload.searchTerm", testData.get(""), "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("SHIRTS_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeMatches("$.payload.activeStores[*].storeNum",".*"+storeNums[0]+".*","store num should be present");
		validator.nodeMatches("$.payload.activeStores[*].storeNum",".*"+testData.get("CATALOG_STORE2")+".*","store num should be present");
		
		

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("SHIRTS_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_2StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and two storeNumber's")
	public void Search_categoryID_With_2StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		//validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeMatches("$.payload.activeStores[*].storeNum",".*"+storeNums[0]+".*","store num should be present");
		validator.nodeMatches("$.payload.activeStores[*].storeNum",".*"+testData.get("CATALOG_STORE2")+".*","store num should be present");
		
		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_3StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, keyword and 3  storeNumbers")
	public void Search_Keyword_With_3StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("JEWELRY_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("JEWELRY_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter>3;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}
		
		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("JEWELRY_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_3StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and 3 storeNumbers")
	public void Search_categoryID_With_3StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>3;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}
		
		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_4StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, keyword and 4 storeNumbers")
	public void Search_Keyword_With_4StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOYS_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOYS_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter>4;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOYS_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_4StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and 4 storeNumbers")
	public void Search_categoryID_With_4StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>4;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_5StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, keyword and 5 storeNumbers")
	public void Search_Keyword_With_5StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOPS_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4")+","+testData.get("CATALOG_STORE5");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter>5;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOPS_KEYWORD")+"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4")+","+testData.get("CATALOG_STORE5");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_5StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and 5 storeNumbers")
	public void Search_categoryID_With_5StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4")+","+testData.get("CATALOG_STORE5");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>5;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4")+","+testData.get("CATALOG_STORE5");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_Invalid_StoreNumber",
			description = "Kohls application use wants to check error message as invalid value passed for storeNumbers when an invalid storeNumbers in the request")
	public void Search_Keyword_With_Invalid_StoreNumber() {

		//String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("SEARCH_KEYWORD_1") +"&sortID=3&limit=24&offset=1&storeNum=" + testData.get("ACTIVE_STORE_NUM_1");
		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=413445fshg";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for storeNum.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=413445fshg";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Invalid_categoryID_With_StoreNumber",
			description = "Kohls application use wants to check when an invalid categoryID passed in the request and the product count is zero")
	public void Search_Invalid_categoryID_With_StoreNumber() {
		
		String invalidDimensionID="qwretrtgvvff";
		//String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("SEARCH_KEYWORD_1") +"&sortID=3&limit=24&offset=1&storeNum=" + testData.get("ACTIVE_STORE_NUM_1");
		String strURL = CATALOG_ADAPTER + "/"+invalidDimensionID+"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		//validator.validateExpectedErrors("CATA1002", "Invalid value passed for dimensionValueID.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/"+invalidDimensionID+"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_InvalidKeyword_With_StoreNumber",
			description = "Kohls application use wants to check when an invalid keyword passed in the request and the product count is zero")
	public void Search_InvalidKeyword_With_StoreNumber() {
		
		String invalidKeyword="fsfsdf";
		String strURL = CATALOG_ADAPTER + "?keyword="+invalidKeyword+"&sortID=3&limit=24&offset=1&storeNum="+storeNums[0];
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm",invalidKeyword , "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.activeStores[0].storeNum",storeNums[0],"store num should be present");

		//validator.validateExpectedErrors("CATA1002", "Invalid value passed for keyword.");
		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+invalidKeyword+"&sortID=3&limit=24&offset=1&storeNum="+storeNums[0];
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_With_InStoreEnabled_True_StoreNumber",
			description = "Kohls application user should get the error message 'Invalid value passed' when inStoreEnabled is true and limit, offset, sortID, keyword and two storeNumber")
	public void Search_Keyword_With_InStoreEnabled_True_StoreNumber() {

		//String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("SEARCH_KEYWORD_1") +"&sortID=3&limit=24&offset=1&storeNum=" + testData.get("ACTIVE_STORE_NUM_1");
		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for storeNum.");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_With_6StoreNumber",
			description = "Kohls application use should get the product details when valid details passed for limit, offset, sortID, keyword and 6 storeNumbers")
	public void Search_keyword_With_6StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4")+","+testData.get("CATALOG_STORE5")+",000";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>6;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("BOPUS_DIMENSION_ID") +"?sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+testData.get("CATALOG_STORE4")+","+testData.get("CATALOG_STORE5")+",000";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_Keyword_sortID1_With_StoreNumber",
			description = "Kohls application user should get the product details when valid details are passed for limit, offset, sortID=1, keyword and storeNumber")
	public void Search_Keyword_sortID1_With_StoreNumber() {

		testData.put("sortID1", "1");
		System.out.println(testData.get("sortID1"));
		int intSortID=Integer.parseInt(testData.get("sortID1"));
		System.out.println(intSortID);
		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID="+testData.get("sortID1")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].active","true" , "sort is active or not");
		

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID="+testData.get("sortID1")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_sortID2_With_StoreNumber",
			description = "Kohls application user should get the product details when valid details are passed for limit, offset, sortID=2, keyword and storeNumbers")
	public void Search_keyword_sortID2_With_StoreNumber() {

		testData.put("sortID2", "2");
	//	System.out.println(testData.get("sortID2"));
		int intSortID=Integer.parseInt(testData.get("sortID2"));
	//	System.out.println(intSortID);
		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("SHIRTS_KEYWORD") +"&sortID="+testData.get("sortID2")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("SHIRTS_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].active","true" , "sort is active or not");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("SHIRTS_KEYWORD") +"&sortID="+testData.get("sortID2")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_sortID3_With_StoreNumber",
			description = "Kohls application user should get the product details when valid details are passed for limit, offset, sortID=3, keyword and storeNumbers")
	public void Search_keyword_sortID3_With_StoreNumber() {

		testData.put("sortID3", "3");
    //  System.out.println(testData.get("sortI31"));
		int intSortID=Integer.parseInt(testData.get("sortID3"));
	//	System.out.println(intSortID);
		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("JEWELRY_KEYWORD") +"&sortID="+testData.get("sortID3")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.searchTerm", testData.get("JEWELRY_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].active","true" , "sort is active or not");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("JEWELRY_KEYWORD") +"&sortID="+testData.get("sortID3")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_sortID4_With_StoreNumber",
			description = "Kohls application user should get the product details when valid details are passed for limit, offset, sortID=4, keyword and storeNumbers")
	public void Search_keyword_sortID4_With_StoreNumber() {

		    testData.put("sortID4", "4");
	    //  System.out.println(testData.get("sortID4"));
			int intSortID=Integer.parseInt(testData.get("sortID4"));
		//	System.out.println(intSortID);
			String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID="+testData.get("sortID4")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Post the request
			String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
			validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
			validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
			validator.nodeEquals("$.payload.searchTerm", testData.get("TOYS_KEYWORD"), "Keyword searched should present in the response");
			validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].active","true" , "sort is active or not");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID="+testData.get("sortID4")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_sortID9_With_StoreNumber",
			description = "Kohls application use wants to check error message as invalid vlaue passed for sortID when an sortID=9 passed in the request")
	public void Search_keyword_sortID9_With_StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID=9&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for sortID.");

		// Compare Open API
		if (CompareOAPI) {

			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID=9&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_Limit100_With_StoreNumber",
			description = "Kohls application use wants to check error message as invalid vlaue passed for limit when an limit=100 passed in the request")
	public void Search_keyword_Limit121_With_StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=121&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for limit.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=121&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_keyword_Offset_Zero_With_StoreNumber",
			description = "Kohls application use wants to check error code CATA1002 and message as invalid vlaue passed for offset when an offset=0 passed in the request")
	public void Search_keyword_Offset_Zero_With_StoreNumber() {

		String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=2&limit=24&offset=0&storeNum=" +testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for offset.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=2&limit=24&offset=0&storeNum=" +testData.get("CATALOG_STORE1");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Filter_categoryID_With_1StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.activeStores[0].storeNum",storeNums[0],"store num should be present");

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Filter_categoryID_With_2StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("SHIRTS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
		
		
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>2;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("SHIRTS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Filter_categoryID_With_3StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("JEWELRY_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3");
		
		
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>3;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("JEWELRY_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Filter_categoryID_With_4StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4");
		
		
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>4;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Filter_categoryID_With_5StoreNumber() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5");
		
		
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		for(int counter=0;counter>5;counter++){
			validator.nodeEquals("$.payload.activeStores["+counter+"].storeNum",storeNums[counter],"store num should be present");
			}

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("FILTER_CATEGORY_ID") + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum="  +testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2")+","+testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "Search_categoryID_With_StoreNumber",
			description = "Kohls application user should get the product and activeStores details when valid details are passed for limit, offset, sortID, categoryID and one storeNumber")
	public void Filter_categoryID_With_SizeId() {

		String strURL = CATALOG_ADAPTER + "/"+ testData.get("FILTER_CATEGORY_ID_SIZE") + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
		
		
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
		validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
		validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
		validator.nodeEquals("$.payload.activeStores[0].storeNum",storeNums[0],"store num should be present");

		// Compare Open API
		if (CompareOAPI) {
			
			String strURLOAPI = CATALOG_OAPI + "/"+ testData.get("FILTER_CATEGORY_ID_SIZE") + "?keyword="+ testData.get("TOPS_KEYWORD") +"&sortID=3&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "BOPUS_ShopMyStore","regression", "msm750" }, enabled = true, priority = 12, testName = "Search_keyword_sortID4_With_StoreNumber",
			description = "Kohls application user should get the product details when valid details are passed for limit, offset, sortID=4, keyword and storeNumbers")
	public void Search_keyword_sortID7_With_StoreNumber() {

		    testData.put("sortID7", "7");
	    //  System.out.println(testData.get("sortID4"));
			int intSortID=Integer.parseInt(testData.get("sortID7"));
		//	System.out.println(intSortID);
			String strURL = CATALOG_ADAPTER + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID="+testData.get("sortID7")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Post the request
			String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			validator.nodeMatches("$.count", "0||[0-9]+", "Products should present in the response");
			validator.nodeEquals("$.limit", "24", "limit value should be 24 in the response");
			validator.nodeEquals("$.offset", "1", "offset value should be 1 in the response");
			validator.nodeEquals("$.payload.searchTerm", testData.get("TOYS_KEYWORD"), "Keyword searched should present in the response");
			validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].active","true" , "sort is active or not");
			validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].name","Percent Off","proper name should be displayed in response");
			validator.nodeEquals("$.payload.sorts["+(intSortID-1)+"].ID","7","proper name should be displayed in response");
			// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword="+ testData.get("TOYS_KEYWORD") +"&sortID="+testData.get("sortID7")+"&limit=24&offset=1&storeNum=" +testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


}