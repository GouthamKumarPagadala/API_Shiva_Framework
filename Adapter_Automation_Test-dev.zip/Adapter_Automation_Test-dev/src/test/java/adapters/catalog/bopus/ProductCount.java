package test.java.adapters.catalog.bopus;

import static main.java.common.GlobalVariables.PRODUCT_CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.PRODUCT_CATALOG_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Catalog")
@Stories({ "ProductCountOfCatalog" })

public class ProductCount {
ResponseValidator validator;
String[] storeNums={"647","976","761","759","994","6081"};
//String[] keywords={"men", "shirts", "shorts", "rig"};

	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Single StoreNum_Keyword",
			description = "Kohls application user should get the available product count when valid details are passed for keyword and 1 storeNumber")
	public void ProductCount_Single_StoreNum_Keyword() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_TOP")+"?keyword="+ testData.get("TOPS_KEYWORD") +"&storeNum=" + testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		validator.nodeEquals("$.payload.stores[0].storeNum",testData.get("CATALOG_STORE1"),"verifing store num");
		validator.nodeMatches("$.payload.stores[0].availableProductCount","[0-9]+","there should be more than 1 product available");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_TOP")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Two StoreNum_Keyword",
			description = "Kohls application user should get the available product count when valid details are passed for keyword and 2 storeNumbers")
	public void ProductCount_Two_StoreNum_Keyword() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_SHIRTS")+"?keyword="+  testData.get("SHIRTS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.searchTerm", testData.get("SHIRTS_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter<2;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_SHIRTS")+"?keyword="+  testData.get("SHIRTS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Three StoreNum_Keyword",
			description = "Kohls application user should get the available product count when valid details are passed for keyword and 3 storeNumbers")
	public void ProductCount_Three_StoreNum_Keyword() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_JEWELRY")+"?keyword="+ testData.get("JEWELRY_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.searchTerm", testData.get("JEWELRY_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter<3;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}


		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_JEWELRY")+"?keyword="+ testData.get("JEWELRY_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Four StoreNum_Keyword",
			description = "Kohls application user should get the available product count when valid details are passed for keyword and 4 storeNumbers")
	public void ProductCount_Four_StoreNum_Keyword() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_TOYS")+"?keyword="+ testData.get("TOYS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOYS_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter<4;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}


		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI  + "/"+testData.get("BOPUS_DIMENSION_TOYS")+"?keyword="+ testData.get("TOYS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Five StoreNum_Keyword",
			description = "Kohls application user should get the available product count when valid details are passed for keyword and 5 storeNumbers")
	public void ProductCount_Five_StoreNum_Keyword() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_TOP")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter<5;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_TOP")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Six StoreNum_Keyword",
			description = "Kohls application user should get the available product count when valid details are passed for keyword and 6 storeNumbers")
	public void ProductCount_Six_StoreNum_Keyword() {
		
		
		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_TOP")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5")+","+ storeNums[5];
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.searchTerm", testData.get("TOPS_KEYWORD"), "Keyword searched should present in the response");
		for(int counter=0;counter<5;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_TOP")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5")+","+ storeNums[5];
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Single StoreNum_CategoryID",
			description = "Kohls application user should get the available product count when valid details are passed for categoryID=543653453453 and 1 storeNumber")
	public void ProductCount_Single_StoreNum_CategoryID() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.stores[0].storeNum",testData.get("CATALOG_STORE1"),"verifing store num");
		validator.nodeMatches("$.payload.stores[0].availableProductCount","[0-9]+","there should be more than 1 product available");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Two StoreNum_CategoryID",
			description = "Kohls application user should get the available product count when valid details are passed for categoryID=543653453453 and 2 storeNumbers")
	public void ProductCount_Two_StoreNum_CategoryID() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for(int counter=0;counter<2;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+testData.get("CATALOG_STORE2");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Three StoreNum_CategoryID",
			description = "Kohls application user should get the available product count when valid details are passed for categoryID=543653453453 and 3 storeNumbers")
	public void ProductCount_Three_StoreNum_CategoryID() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for(int counter=0;counter<3;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Four StoreNum_CategoryID",
			description = "Kohls application user should get the available product count when valid details are passed for categoryID=543653453453 and 4 storeNumbers")
	public void ProductCount_Four_StoreNum_CategoryID() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for(int counter=0;counter<4;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Five StoreNum_CategoryID",
			description = "Kohls application user should get the available product count when valid details are passed for categoryID=543653453453 and 5 storeNumbers")
	public void ProductCount_Five_StoreNum_CategoryID() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		for(int counter=0;counter<5;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","Product count should be 0 or greater than 0");
			
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "ProductCount_Six StoreNum_CategoryID",
			description = "Kohls application user should get the available product count when valid details are passed for categoryID=543653453453 and 6 storeNumbers")
	public void ProductCount_Six_StoreNum_CategoryID() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5")+","+ storeNums[5];
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();		
		for(int counter=0;counter<5;counter++){
			validator.nodeMatches("$.payload.stores[*].storeNum",".*"+storeNums[counter]+".*","verifing store num");
			validator.nodeMatches("$.payload.stores["+counter+"].availableProductCount","[0-9]+","there should be more than 1 product available");		
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/" + testData.get("BOPUS_DIMENSION_ID") + "?storeNum=" + testData.get("CATALOG_STORE1")+","+ testData.get("CATALOG_STORE2")+","+ testData.get("CATALOG_STORE3")+","+ testData.get("CATALOG_STORE4")+","+ testData.get("CATALOG_STORE5")+","+ storeNums[5];
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression" }, enabled = true, priority = 12, testName = "EmptyValueForStoreNum",
			description = "Kohls application user wants to check error code CATA1002 and message as Invalid value passed for storeNum when an empty value passed for storeNumber in the request")
	public void EmptyValueForStoreNum() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for storeNum.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "productCount_WithOut StoreNum parameter",
			description = "Kohls application user wants to check error code CATA1004 and message as Store Number is a required field when only keyword passed in the request")
	public void productCount_WithOut_StoreNum_Parameter() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1004", "Store Number is a required field.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "Invalid_Value_For_StoreNum",
			description = "Kohls application user wants to check error code CATA1002 and message as invalid value passed for storeNum when an invalid storeNumbers in the request")
	public void Invalid_Value_For_StoreNum() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=fsdf";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "invalid value passed for storeNum.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&storeNum=fsdf";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "BOPUS_ShopMyStore","regression"}, enabled = true, priority = 12, testName = "invalid parameter Name streNum",
			description = "Kohls application user wants to check error code CATA1001 and message as streNum is not a valid parameter when an invalid parameter streNum in the request")
	public void invalid_Parameter_Name_streNum() {

		String strURL = PRODUCT_CATALOG_ADAPTER + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&streNum=" + testData.get("CATALOG_STORE1");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1001", "streNum is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = PRODUCT_CATALOG_OAPI + "/"+testData.get("BOPUS_DIMENSION_ID")+"?keyword="+ testData.get("TOPS_KEYWORD")+"&streNum=" + testData.get("CATALOG_STORE1");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
}