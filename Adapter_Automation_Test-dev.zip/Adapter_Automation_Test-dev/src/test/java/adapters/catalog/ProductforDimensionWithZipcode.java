package test.java.adapters.catalog;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Catalog")
@Stories({ "Product for Dimensions - Platform to extract zip code" })
public class ProductforDimensionWithZipcode {
	ResponseValidator validator;
	
	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithStoreNumAndZipcode() {

		String strURL = CATALOG_ADAPTER + "?keyword=1167424&zipcode=94588&storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.activeStores[0].storeNum","759","Physical store number passed in the request should be displayed");
		
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[0].value",".+", "As isDefaultstore is true,instore number passed in request should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[1].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
      
      }
		  }
    	catch(Exception e)
		{
		}
		
		}
	
	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithStoreNum() {

		String strURL = CATALOG_ADAPTER + "?keyword=1167424&storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.activeStores[0].storeNum","759","Physical store number passed in the request should be displayed");
		
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[0].value",".+", "As isDefaultstore is true,instore number passed in request should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[1].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
      
      }
		  }
    	catch(Exception e)
		{
		}
		
		}
	
	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithMultipleStoreNumberAndZipcode() {

		String strURL = CATALOG_ADAPTER + "?keyword=92609108&zipcode=94588&storeNum=759,647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.activeStores[0].storeNum",".+","Physical store number 1 passed in the request should be displayed");
		validator.nodeMatches("$.payload.activeStores[1].storeNum",".+","Physical store number passed in the request should be displayed");
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", "true|False",
					"isAvailableforPickUp node should be true if it is Bopus product else it should be falseat product level");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[0].value",".+", "As isDefaultstore is true,instore number 1 passed in request should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[1].value",".+", "As isDefaultstore is true ,instore number  2 should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[2].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
      }
		  }
    	catch(Exception e)
		{
		}
		
		}

	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithBopusOnlyProductAndDefaultstoreAsFalse() {

		String strURL = CATALOG_ADAPTER + "?keyword=1939660&zipcode=94588&storeNum=759&isDefaultStore=false";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.activeStores[0].storeNum","759","Physical store number  passed in the request should be displayed");
		
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeEquals("$.payload.products[" + i + "].isAvailableforShip", "false",
					"isAvailableforShip node should be false as isDefaultstore is false in request");
    	validator.nodeEquals("$.payload.products[" + i + "].isAvailableforPickUp", "true|False",
					"isAvailableforPickUp node should be true if it is Bopus product else it should be falseat product level");
    	validator.nodeEquals("$.payload.products[" + i + "].storeNumbers[0].value","759", "As isDefaultstore is false,only instore numberpassed in request should be present in the response");
    	 }
		  }
    	catch(Exception e)
		{
		}
		
		}

	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithBopusOnlyProductAndDefaultstoreAsTrue() {

		String strURL = CATALOG_ADAPTER + "?keyword=1009798&zipcode=94588&storeNum=759&isDefaultStore=false";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.activeStores[0].storeNum","759","Physical store number  passed in the request should be displayed");
		
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeEquals("$.payload.products[" + i + "].isAvailableforShip", "false",
					"isAvailableforShip node should be false as isDefaultstore is false in request");
    	validator.nodeEquals("$.payload.products[" + i + "].isAvailableforPickUp", "true",
					"isAvailableforPickUp node should be true if it is Bopus product else it should be falseat product level");
    	validator.nodeEquals("$.payload.products[" + i + "].storeNumbers[0].value","759", "As isDefaultstore is false,only instore numberpassed in request should be present in the response");
    	 }
		  }
    	catch(Exception e)
		{
		}
		
		}

	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithKeywordAndMultipleStores() {

		String strURL = CATALOG_ADAPTER + "?keyword=shockspray&storeNum=647,761,994,977,759&zipcode=48051";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.activeStores[0].storeNum",".+","Physical store number passed in the request should be displayed");
		validator.nodeMatches("$.payload.activeStores[1].storeNum",".+","Physical store number passed in the request should be displayed");
		validator.nodeMatches("$.payload.activeStores[2].storeNum",".+","Physical store number passed in the request should be displayed");
		validator.nodeMatches("$.payload.activeStores[3].storeNum",".+","Webstore number passed in the request as defaultstore is true");
		validator.nodeMatches("$.payload.activeStores[4].storeNum",".+","Physical store number passed in the request should be displayed");
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[0].value",".+", "As isDefaultstore is true,instore number passed in request should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[1].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[2].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[3].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[4].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
      }
		  }
    	catch(Exception e)
		{
		}
		
		}
	
	@Test(groups = { "regression","NAP-127","DIE_Changes"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithKeywordAndMultipleStoresWithDefaultStoreAsFalse() {

		String strURL = CATALOG_ADAPTER + "?keyword=shockspray&storeNum=647,761,994,977,759&zipcode=48051&isDefaultStore=false";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.activeStores[0].storeNum","647","Physical store number passed in the request should be displayed");
		validator.nodeEquals("$.payload.activeStores[1].storeNum","761","Physical store number passed in the request should be displayed");
		validator.nodeEquals("$.payload.activeStores[2].storeNum","994","Physical store number passed in the request should be displayed");
		validator.nodeEquals("$.payload.activeStores[3].storeNum","977","Physical store number passed in the request should be displayed");
		validator.nodeEquals("$.payload.activeStores[4].storeNum","759","Physical store number passed in the request should be displayed");
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[0].value",".+", "As isDefaultstore is true,instore number passed in request should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[1].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[2].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[3].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
    	validator.nodeMatches("$.payload.products[" + i + "].storeNumbers[4].value",".+", "As isDefaultstore is true ,webstore number should be present in the response");
      }
		  }
    	catch(Exception e)
		{
		}
		
		}
	
	@Test(groups = { "regression","NAP-127","DIE_Changes","smokeTest"}, enabled = true, priority = 12, testName = "productsForDimension storeHours",
			description =  "\n TC Description - Checking the products available in store by passing store number \n Feature - validate Whether webstore and instore number is retrieved when Product is available for Bopus and online purchase ,<br /> catalog DIE_Changes  ")
	 
	public void SearchCatalogWithKeywordAndDefaultStoreAsTrue() {

		String strURL = CATALOG_ADAPTER + "?keyword=shockspray&storeNum=647&isDefaultStore=true";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		 //DIE catalog validation
		int count = JsonPath.read(strResponse, "$.count");
		Assert.assertNotEquals(count, null, "Validating the count is not null when retreieving the catalog");
		try
		  {
      for (int i = 0; i < count-1; i++){
      
       	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforShip", ".+",
					"isAvailableforShip node should be displayed under Product level");
    	validator.nodeMatches("$.payload.products[" + i + "].isAvailableforPickUp", ".+",
					"isAvailableforPickUp node should be displayed under Product level");
    	    }
		  }
    	catch(Exception e)
		{
		}
	}






}
 
