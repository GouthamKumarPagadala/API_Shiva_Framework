package test.java.adapters.catalog.Instore;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.CATEGORY_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_OAPI;
import static main.java.common.GlobalVariables.CATEGORY_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Instore")
@Stories({ "Product for Dimensions" })
public class ProductForDimensions {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Verify search using Category search for a product available both online and in-store, price range of in-store is displayed]")
	public void CategoriesAvailableOnlineAndInstore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_AVAILABLE_ONLINE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=647&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_AVAILABLE_ONLINE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=647&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Verify search using Category search for a product available in-store, price range of in-store is displayed")
	public void CategoriesAvailableInstore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=759&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=759&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "BOGO promotions to be displayed for Category search with in-store inventory availability")
	public void CategoriesBogoAvailableInstore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_BOGO_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_BOGO_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Tiered Pricing promotions to be displayed for Category search with in-store inventory availability")
	public void CategoriesTieredAvailableInstore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_TIERED_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_TIERED_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Group promotions to be displayed for Category search with in-store inventory availability")
	public void CategoriesGroupPromotionAvailableInstore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_GROUP_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_GROUP_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Search using Category search with special characters")
	public void CategoriesSpecialCharacters() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("CATEGORY_KEYWORD") + "&limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("CATEGORY_KEYWORD") + "&limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Verify search using Category for a product. Products available online only are not displayed")
	public void CategoriesProductsNull() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_PRODUCTS_NULL") + "?limit=10&offset=1&sortID=3&storeNum=873&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_PRODUCTS_NULL") + "?limit=10&offset=1&sortID=3&storeNum=873&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Verify default sorting as best-selling")
	public void CategoriesSortBestSelling() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_TIERED_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=" + testData.get("CATEGORY_SORT_BESTSELLING") + "&storeNum=694&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_TIERED_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=" + testData.get("CATEGORY_SORT_BESTSELLING") + "&storeNum=694&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Verify sorting based on sortID")
	public void CategoriesSortID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_AVAILABLE_ONLINE_INSTORE") + "?limit=10&offset=1&sortID=1&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_AVAILABLE_ONLINE_INSTORE") + "?limit=10&offset=1&sortID=1&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "instore" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Clearance promotions to be displayed for category search with in-store inventory availability")
	public void CategoriesClearanceAvailableInstore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_CLEARANCE_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_CLEARANCE_AVAILABLE_INSTORE") + "?limit=10&offset=1&sortID=3&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "regression","functional", "instore", "msm750" }, enabled = true, priority = 12, testName = "productsForDimension All Categories Channel",
			description = "Verify sorting based on sortID")
	public void CategoriesSortID7() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("CATEGORY_AVAILABLE_ONLINE_INSTORE") + "?limit=10&offset=1&sortID=7&storeNum=743&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.categories[*].name", ".+", "Categories should be present in the response");
		validator.ValidatePriceForCategory("Products should be present in the response");
		validator.nodeEquals("$.payload.sorts[6].active","true" , "sort is active or not");
		validator.nodeEquals("$.payload.sorts[6].name","Percent Off","proper name should be displayed in response");
		validator.nodeEquals("$.payload.sorts[6].ID","7","proper name should be displayed in response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("CATEGORY_AVAILABLE_ONLINE_INSTORE") + "?limit=10&offset=1&sortID=7&storeNum=743&inStoreEnabled=true";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

}