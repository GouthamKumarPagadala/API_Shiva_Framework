package test.java.adapters.catalog;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Catalog")
@Stories({ "Product for Dimensions - Special Chars" })
public class ProductForDimensionWithSpecialCharacters {

	ResponseValidator validator;


	@Test(groups = { "regression","functional" }, enabled = true, priority = 12, testName = "ProductsForDimension Special Chars",
			description = "Checking the products available for keyword fro speacial chars",
			dataProvider = "data_keywords")
	public void specialCharKeywords(String strKeyword) {

		// Encode the keyword using URL encoder
		strKeyword = Utilities.urlEncodeString(strKeyword);
		String strURL = CATALOG_ADAPTER + "?keyword=" + strKeyword + "&limit=24&offset=1&sortID=3";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeMatches(json, "[0-9]+", "Products should be present in the response for given keyword search");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + strKeyword + "&limit=24&offset=1&sortID=3";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.products.productTitle,payload.dimensions.dimensionValue.name", true);
		}
	}


	@DataProvider(name = "data_keywords")
	public Object[][] data_keywords() {

		// Return Special characters

		return new Object[][] {
				{ "Cooking Utensils & Tools" },
				{ "Kids' Bedding" },
				{ "Deep-Pocket Sheets" },
				{ "Apt. 9" },
				{ "Plus Size (0X-3X)" },
				{ "Petite (5'4\" & Under)" },
				{ "Women's Swimwear" },
				{ "$7.99 Graphic Tees" },
				{ "$Toys" },
				{ "Toddler Boys (2T-5T)" },
				{ "Boys' Shoes & Sandals" },
				{ "Big Girls (7-16)" },
				{ "2 Years" },
				{ "#Children" },
				{ "40% OFF" }
		};

	}

}
