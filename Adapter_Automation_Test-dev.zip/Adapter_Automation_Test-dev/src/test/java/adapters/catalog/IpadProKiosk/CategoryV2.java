/*package test.java.adapters.catalog.IpadProKiosk;

import static main.java.common.GlobalVariables.CATEGORY_V2_ADAPTER	;
import static main.java.common.GlobalVariables.CATEGORY_ADAPTER;
import static main.java.common.GlobalVariables.CATEGORY_V2_OAPI;
import static main.java.common.GlobalVariables.CATEGORY_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("IPAD")
@Stories({ "Category V2" })

public class CategoryV2 {
	
	
	ResponseValidator validator;
	
	@Test(groups = { "ipad_categoryv2", "IPK"}, enabled = true, priority = 12, testName = "Search_CategoryImageUrl in L1 Menu",
			description = "Kohls application user should get the categoryimageURL in response when valid details are passed in request")
	public void Search_L1_CategoryImageUrl() {

		String strURL = CATEGORY_V2_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeNotEquals("$.payload.categories[?(@.name=='For Home')].categoryImageUrl", null, "Category Image URL Should displayed in response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATEGORY_V2_OAPI;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "ipad_categoryv2", "IPK" }, enabled = true, priority = 12, testName = "Search_CategoryImageUrl in L2 Menu",
			description = "Kohls application user should get the categoryimageURL in response when valid details are passed in request ")
	public void Search_L2_CategoryImageUrl() {

		String strURL = CATEGORY_V2_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeNotEquals("$.payload.categories[?(@.name=='small appliances')].categoryImageUrl", null, "Category Image URL Should displayed in response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATEGORY_V2_OAPI;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "ipad_categoryv2", "IPK" }, enabled = true, priority = 12, testName = "Search_CategoryImageUrl in L3 Menu",
			description = "Kohls application user should get the categoryimageURL in response when valid details are passed in request ")
	public void Search_L3_CategoryImageUrl() {

		String strURL = CATEGORY_V2_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeNotEquals("$.payload.categories[?(@.name=='Mixers')].categoryImageUrl", null, "Category Image URL Should displayed in response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATEGORY_V2_OAPI;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	
	
	
	

	
	
	
}*/