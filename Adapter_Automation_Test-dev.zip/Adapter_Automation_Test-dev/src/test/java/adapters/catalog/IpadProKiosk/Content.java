/*package test.java.adapters.catalog.IpadProKiosk;

import static main.java.common.GlobalVariables.CONTENT_ADAPTER;
import static main.java.common.GlobalVariables.CONTENT_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("IPAD")
@Stories({ "Content" })

public class Content {

ResponseValidator validator;
	
	@Test(groups = { "ipad_content","IPK" }, enabled = true, priority = 12, testName = "Content",
			description = "Kohls application user should get the response With all the valid parameters")
	public void Content() {

		String strURL = CONTENT_ADAPTER	 + "?channel=" + testData.get("ENDLESS_AISLE") + "&environment=stage&previewdate=" + testData.get("PREVIEW_DATE");
		
		mapheader.put("User-Agent", "Platform");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
//		validator.nodeEquals("$.module", "screensaver", "module should not be a null");
//		validator.nodeMatches("$.data.time", ".+", "module should not be a null");
		validator.nodeMatches("$.contentResponse.payload.properties.property.key", null, "key should not be a null");
		validator.nodeMatches("$.contentResponse.payload.properties.property.value", null, "value should not be a null");
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CONTENT_OAPI + "channel=ipadpro&environment=stage&previewdate=YYYY-MM-DD_HH:MI:SS";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}
*/