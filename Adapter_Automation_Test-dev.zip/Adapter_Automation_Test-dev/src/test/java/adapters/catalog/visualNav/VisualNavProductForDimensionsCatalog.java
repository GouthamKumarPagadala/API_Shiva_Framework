package test.java.adapters.catalog.visualNav;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("Catalog")
@Stories({ "VisualNav" })
public class VisualNavProductForDimensionsCatalog {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisualNav_Object_Catalog",
			description = "Validate whether visualNavTiles object is getting displayed in the response")
	@TestCaseId("VN_1")
	public void catalog() {

		String strURL = CATALOG_ADAPTER;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI;
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword",
			description = "Validate whether visualNavTiles object is getting displayed in the response while passing a keyword in the request")
	@TestCaseId("VN_2")
	public void catalogWithKeyword() {

		// String strURL = CATALOG_ADAPTER +"?inStoreEnabled=true&keyword=" + testData.get("3_TILE_KEYWORD") + "&storeNum=" +testData.get("STORE_NUM_VISUAL_NAV");
		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("5_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		Assert.assertNotEquals(strVisualNavTileSize, null, "Validating the visualNavTiles are not null");
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("5_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Four Tile",
			description = "Validate whether 4 visualNavTiles objects are  getting displayed in the response while passing a keyword with 4 Tile in the request")
	@TestCaseId("VN_4")
	public void catalogWith4TileKeyword() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("4_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("4_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Five Tile",
			description = "Validate whether 5 visualNavTiles objects are getting displayed in the response while passing a keyword with 5 Tile in the request")
	@TestCaseId("VN_5")
	public void catalogWith5TileKeyword() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("5_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("5_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Six Tile",
			description = "Validate whether 6 visualNavTiles objects are getting displayed in the response while passing a keyword with 6 Tile in the request")
	@TestCaseId("VN_6")
	public void catalogWith6TileKeyword() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("6_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("6_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_One Tile",
			description = "Validate whether 1 visualNavTiles objects are getting displayed in the response while passing a keyword with 1 Tile in the request")
	@TestCaseId("VN_7")
	public void catalogWith1TileKeyword() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("1_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("1_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Second Tile",
			description = "Validate whether 2 visualNavTiles object are getting displayed in the response while passing a keyword with 2 Tile in the request")
	@TestCaseId("VN_8")
	public void catalogWith2TileKeyword() {

		String strURL = CATALOG_ADAPTER + "?keyword=" + testData.get("2_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?keyword=" + testData.get("2_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "visualnav", "errorhandling" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Invalid_Param",
			description = "Validate whether proper error messgae is getting displayed in the response while passing a invalid parameter for keyword in the request")
	@TestCaseId("VN_9")
	public void invalidParameter() {

		String strURL = CATALOG_ADAPTER + "?kyword=" + testData.get("3_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1001", "kyword is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?kyword=" + testData.get("3_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "visualnav", "errorhandling" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Invalid_Param_Value",
			description = "Validate whether proper error messgae is getting displayed in the response while passing a invalid value passed for parameter limit in the request")
	@TestCaseId("VN_10")
	public void invalidParameterValue() {

		String strURL = CATALOG_ADAPTER + "?limit=-1&keyword=" + testData.get("3_TILE_KEYWORD");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for limit.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?limit=-1&keyword=" + testData.get("3_TILE_KEYWORD");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisualNav_Catalog_dimensionID",
			description = "Validate whether visualNavTiles object is getting displayed in the response while passing the dimensionID in the request url")
	@TestCaseId("VN_11")
	public void catalogWithDimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		Assert.assertNotEquals(strVisualNavTileSize, null, "Verifying visualNavTiles are getting displayed");
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Three Tile",
			description = "Validate whether 3 visualNavTiles objects are getting displayed in the response while passing a dimensionID with 3 Tile in the request")
	@TestCaseId("VN_12")
	public void catalogWith3DimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("3_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].id", ".+", "id for the visualNavTile should be displayed");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("3_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Four Tile",
			description = "Validate whether 4 visualNavTiles objects are getting displayed in the response while passing a dimensionID with 4 Tile in the request")
	@TestCaseId("VN_13")
	public void catalogWith4DimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("4_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("4_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Five Tile",
			description = "Validate whether 5 visualNavTiles objects are getting displayed in the response while passing a dimensionID with 5 Tile in the request")
	@TestCaseId("VN_14")
	public void catalogWith5DimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Six Tile",
			description = "Validate whether 5 visualNavTiles objects are getting displayed in the response while passing a dimensionID with 6 Tile in the request")
	@TestCaseId("VN_15")
	public void catalogWith6DimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("6_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>=6||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("6_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_One Tile",
			description = "Validate whether 1 visualNavTiles object is getting displayed in the response while passing a dimensionID with 1 Tile in the request")
	@TestCaseId("VN_16")
	public void catalogWith1DimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("1_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("1_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Second Tile",
			description = "Validate whether visualNavTiles object with array of 2 visualNavTile is getting displayed in the response while passing a dimensionID with 2 Tile in the request")
	@TestCaseId("VN_17")
	public void catalogWith2DimensionID() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("2_TILE_DIMENSION_ID") + "?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("2_TILE_DIMENSION_ID") + "?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "visualnav", "errorhandling" }, enabled = true, priority = 12, testName = "VisualNav_Catalog_Invalid_dimensionID",
			description = "Validate whether error message is getting displayed in the response while passing the invalid dimensionID in the request url")
	@TestCaseId("VN_18")
	public void invalidDimensionValue() {

		String strURL = CATALOG_ADAPTER + "/7unjklj434?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("CATA1002", "Invalid value passed for dimensionValueID.");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/7unjklj434?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@DiscontinuedTest(groups = { "visualnav", "errorhandling" }, enabled = false, priority = 12, testName = "VisualNav_Catalog_Invalid_url",
			description = "Validate whether error message is getting displayed in the response while passing the invalid catalog url")
	@TestCaseId("VN_20")
	public void invalidURL() {

		String strURL = CATALOG_ADAPTER + "fd/7unjklj434?offset=1&limit=12";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0002", "We encountered issue processing your request, please try again later");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "fd/7unjklj434?offset=1&limit=12";
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 404);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Two Tile",
			description = "Validate whether 2 visualNavTiles objects are getting displayed in the response while passing a keyword with 2 Tile in the request")
	@TestCaseId("VN_46")
	public void catalogWith2TileKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("2_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("2_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Six Tile",
			description = "Validate whether 6 visualNavTiles objects are is getting displayed in the response while passing a keyword with 6 Tile in the request")
	@TestCaseId("VN_44")
	public void catalogWith6TileKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("6_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("6_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_One Tile",
			description = "Validate whether 1 visualNavTiles object is getting displayed in the response while passing a keyword with 1 Tile in the request")
	@TestCaseId("VN_45")
	public void catalogWith1TileKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("1_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("1_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Five Tile",
			description = "Validate whether visualNavTiles object with array of 5 visualNavTile is getting displayed in the response while passing a keyword with 5 Tile in the request")
	@TestCaseId("VN_43")
	public void catalogWith5TileKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("5_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		;
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("5_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Four Tile",
			description = "Validate whether visualNavTiles object with array of 4 visualNavTile is getting displayed in the response while passing a keyword with 4 Tile in the request")
	@TestCaseId("VN_42")
	public void catalogWith4TileKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("4_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("4_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Three Tile",
			description = "Validate whether visualNavTiles object with array of 3 visualNavTile is getting displayed in the response while passing a keyword with 3 Tile in the request")
	@TestCaseId("VN_41")
	public void catalogWith3TileKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("3_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("3_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");

			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_Keyword_Instore",
			description = "Validate whether visualNavTiles object is getting displayed in the response while passing a keyword in the request with instore enabled")
	@TestCaseId("VN_40")
	public void catalogWithKeyword_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&keyword=" + testData.get("5_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&keyword=" + testData.get("5_TILE_KEYWORD") + "&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_With_Instore",
			description = "Validate whether visualNavTiles object is getting displayed in the response while passing in the request")
	@TestCaseId("VN_39")
	public void catalog_Instore() {

		String strURL = CATALOG_ADAPTER + "?inStoreEnabled=true&storeNum=647";

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		String json = "$.count";
		validator.nodeNotEquals(json, "0", "Categories should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "?inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisualNav_Catalog_dimensionID_Instore",
			description = "Validate whether visualNavTiles object is getting displayed in the response while passing the dimensionID in the request url")
	@TestCaseId("VN_47")
	public void catalogWithDimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");

		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		Assert.assertNotEquals(strVisualNavTileSize, null, "Verifying visualNavTiles are getting displayed");
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Three Tile_Instore",
			description = "Validate whether visualNavTiles object with array of 3 visualNavTile is getting displayed in the response while passing a dimensionID with 3 Tile in the request")
	@TestCaseId("VN_48")
	public void catalogWith3DimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("3_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].id", ".+", "id for the visualNavTile should be displayed");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("3_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Four Tile_Instore",
			description = "Validate whether visualNavTiles object with array of 4 visualNavTile is getting displayed in the response while passing a dimensionID with 4 Tile in the request")
	@TestCaseId("VN_49")
	public void catalogWith4DimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("4_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("4_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Five Tile_Instore",
			description = "Validate whether visualNavTiles object with array of 5 visualNavTile is getting displayed in the response while passing a dimensionID with 5 Tile in the request")
	@TestCaseId("VN_50")
	public void catalogWith5DimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("5_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_Six Tile_Instore",
			description = "Validate whether visualNavTiles object with array of 5 visualNavTile is getting displayed in the response while passing a dimensionID with 6 Tile in the request")
	@TestCaseId("VN_51")
	public void catalogWith6DimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("6_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		Assert.assertEquals(strVisualNavTileSize, 5, "Verifying 5 visualNavTiles are getting displayed");
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("6_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_one Tile_Instore",
			description = "Validate whether visualNavTiles object with array of 0 visualNavTile is getting displayed in the response while passing a dimensionID with 1 Tile in the request")
	@TestCaseId("VN_52")
	public void catalogWith1DimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("1_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("1_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name", true);
		}
	}


	@Test(groups = { "regression","functional", "visualnav" }, enabled = true, priority = 12, testName = "VisNav_Object_Catalog_dimensionID_second Tile_Instore",
			description = "Validate whether visualNavTiles object with array of 0 visualNavTile is getting displayed in the response while passing a dimensionID with 2 Tile in the request")
	@TestCaseId("VN_53")
	public void catalogWith2DimensionID_Instore() {

		String strURL = CATALOG_ADAPTER + "/" + testData.get("2_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		JSONArray visualNavTile = JsonPath.read(strResponse, "$.payload..navLabel");
		int strVisualNavTileSize = visualNavTile.size();
		if(strVisualNavTileSize>5||strVisualNavTileSize==0)
		{
			Assert.fail("Visual NAv Tile is not displayed or exceeded 5");
		}
		
		
		for (int i = 0; i < strVisualNavTileSize; i++) {
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", ".+", "navLink for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLink", "null", "navLink for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", ".+", "navLabel for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].navLabel", "null", "navLabel for the visualNavTile should not null");
			validator.nodeMatches("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", ".+", "imageUrl for the visualNavTile should be displayed");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].imageUrl", "null", "imageUrl for the visualNavTile should not null");
			validator.nodeNotEquals("$.payload.visualNavTiles.visualNavTile[" + i + "].id", "null", "id should not be null for the visualNavTile object");
		}

		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI = CATALOG_OAPI + "/" + testData.get("2_TILE_DIMENSION_ID") + "?offset=1&limit=12&inStoreEnabled=true&storeNum=" + testData.get("STORE_NUM_VISUAL_NAV");
			// Get the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.dimensions.dimensionValues.name,payload.products.productTitle", true);
		}
	}
}