package test.java.adapters.catalog.monetization;

import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_OAPI;
import static main.java.common.GlobalVariables.CompareOAPI;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import static main.java.common.TestData.testData;

@Features("monetization")
@Stories({ "Product for Dimensions" })
 
public class ProductForDimensions 
{
	ResponseValidator validator;
	
	@Test(groups = {"smoke", "regression","functional", "monetization" }, enabled = true, priority = 12, testName = "Monetization validation using ProductforDimensions using DimensionId",
			description = "Verify whether the monetization objects brand,ageAppropriateValue,occassion,gender,sportsLeague and sportsTeam are returned in product response with DimensionID")
	public void Monetization_CatalogID_For_Brand_Occasion_Gender_Sports_AgeValue_Combination() {

		String strURL = CATALOG_ADAPTER + "/"+testData.get("BRAND_AGE_OCCA_GENDER_SPORTS");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.monetization.brand.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.ageAppropriate.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.occasion.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.gender.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.sportsLeague.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.sportsTeam.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeNotEquals("$.payload.monetization.adUnit.value", "null", "adUnit value should be present  in response");
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/"+testData.get("BRAND_AGE_OCCA_GENDER_SPORTS");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "monetization" }, enabled = true, priority = 12, testName = "Monetization validation using ProductforDimensions using DimensionId",
			description = "Verify whether the monetization objects AgeRange,ChildAgeRange and Fit are returned in product response with DimensionID")
	public void Monetization_CatalogID_For_AgeRange_ChildAgeRange_Fit_Combination() {

		String strURL = CATALOG_ADAPTER + "/"+testData.get("AGERANGE_CHILD_SIZE_FIT") + "?sortID=4&limit=10";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.monetization.ageAppropriateRange.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.childAgeRange.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.sizeRange.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.fit.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeEquals("$.payload.sorts[3].active", "true", "sort value should be present as true in response");
		validator.nodeEquals("$.limit", "10", "limit vlaue should be present as 10 in response");
		validator.nodeNotEquals("$.payload.monetization.adUnit.value", "null", "adUnit value should be present  in response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/"+testData.get("AGERANGE_CHILD_SIZE_FIT")+ "?sortID=4&limit=10";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "monetization" }, enabled = true, priority = 12, testName = "Monetization validation using ProductforDimensions using DimensionId",
			description = "Verify whether the monetization objects BodyType,PersonalCategory,PersonalSubject and Silhouette are returned in product response with DimensionID")
	public void Monetization_CatalogId_For_LegOpening_Trend_Feature_Activity_Combination() {

		String strURL = CATALOG_ADAPTER + "/"+testData.get("LEG_TREND_FEATURE_ACTIVITY")+ "?sortID=5&limit=20";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.monetization.legOpening.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.trend.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.feature.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.activity.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeEquals("$.payload.sorts[4].active", "true", "sort value should be present as true in response");
		validator.nodeEquals("$.limit", "20", "limit vlaue should be present as 20 in response");
		validator.nodeNotEquals("$.payload.monetization.adUnit.value", "null", "adUnit value should be present  in response");
		
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/"+testData.get("LEG_TREND_FEATURE_ACTIVITY")+ "?sortID=5&limit=20";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "monetization" }, enabled = true, priority = 12, testName = "Monetization validation using ProductforDimensions using DimensionId",
			description = "To verify whether the tag personaTheme+personaGroupCode+silhouette is returned in the catalog response.")
	public void Monetization_CatalogID_For_BodyType_PersonalCategory_PersonalSubject_Silhouette_Combination() {

		String strURL = CATALOG_ADAPTER + "/"+testData.get("BODY_PERCATE_PERSUB_SILH");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.monetization.bodyType.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.personaCategory.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.personaSubject.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.silhouette.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeNotEquals("$.payload.monetization.adUnit.value", "null", "adUnit value should be present  in response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/"+testData.get("BODY_PERCATE_PERSUB_SILH");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "monetization" }, enabled = true, priority = 12, testName = "Monetization validation using ProductforDimensions using DimensionId",
			description = "Verify whether the monetization objects PersonaTheme,PersonaGroupCode and Silhouette are returned in product response with DimensionID")
	public void Monetization_CatalogID_For_PersonaTheme_PersonaGroupCode_Silhouette_Combination() {

		String strURL = CATALOG_ADAPTER + "/"+testData.get("PERTHE_PERGRP_SILH");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.monetization.personaTheme.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.personaGroupCode.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeMatches("$.payload.monetization.silhouette.value", "null||.+", "monetization brand value should be present in response ");
		validator.nodeNotEquals("$.payload.monetization.adUnit.value", "null", "adUnit value should be present  in response");
		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = CATALOG_OAPI + "/"+testData.get("PERTHE_PERGRP_SILH");
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "monetization" }, enabled = true, priority = 12, testName = "zeroSearch_with_adUnit",
			description = "verify whether the tag adUnit is returned when zerosearch in the catalog response")
	public void zeroSearch_with_adUnit()
	
	{
		String strURL = CATALOG_ADAPTER + "?keyword=jhhjd13";
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.monetization.adUnit.value", "/zerosearch", "adUnit value should be present as /zerosearch in response");
		
		// Compare Open API		 		
		 		if (CompareOAPI) {
		 			
		 			String strURLOAPI = CATALOG_OAPI + "?keyword=jhhjd13";
		 			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);
		 		// Compare the result
		 			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		 		}
	}
	
}
