package test.java.adapters;

import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.OAUTHMFP_TOKEN;
import static main.java.common.GlobalVariables.OAUTHMFP_TOKEN_5CHARS;
import static main.java.common.GlobalVariables.MfpToken;
import static main.java.common.GlobalVariables.strAdapterEnv;
import static main.java.common.TestData.testData;

import org.testng.Assert;
import org.testng.IResultMap;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.jayway.jsonpath.JsonPath;

import main.java.common.GlobalVariables;
import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.report.EmailReport;
import main.java.report.HTMLReporter;

public class Config {
	
	public static long OauthTokenGenTime;

	@BeforeSuite(alwaysRun = true)
	public void setupTestSuite(ITestContext context) {

		// Load the test data
		TestData.loadTestData();

		// Get the current group
		String strGroup = context.getCurrentXmlTest().getIncludedGroups().get(0);
		System.out.println("Executing Groups " + strGroup);
		GlobalVariables.strGroup = strGroup;

		// Create Environment Reporting properties in HTMl
		HTMLReporter.createReportingProperties();

		if (MfpToken) {
			OAUTHMFP_TOKEN = oAuthMFP_Token();
			OauthTokenGenTime = System.currentTimeMillis();	
			System.out.println();
			OAUTHMFP_TOKEN_5CHARS = OAUTHMFP_TOKEN.substring(0, 5) + "..." + OAUTHMFP_TOKEN.substring(OAUTHMFP_TOKEN.length()-4);
		}

		// Create Profiles based on Executing group
		createProfiles();

	}


	@AfterSuite(alwaysRun = true)
	public void tearTestSuite(ITestContext result) {

		EmailReport.createPiePanel(result.getPassedTests().size(), result.getFailedTests().size(), result.getSkippedTests().size());

		for (ITestNGMethod m : result.getPassedTests().getAllMethods()) {
			EmailReport.updatePassed(m.getRealClass().getName());
		}

		System.out.println("\n\n*** Printing all failed Testcases ***");
		for (ITestNGMethod m : result.getFailedTests().getAllMethods()) {
			System.out.println(m.getRealClass().getName() + "." + m.getMethodName());
			EmailReport.updateFailed(m.getRealClass().getName());
		}
		System.out.println("***End of failed Testcases");

		for (ITestNGMethod m : result.getSkippedTests().getAllMethods()) {
			EmailReport.updateSkipped(m.getRealClass().getName());
		}

		// EmailReport.printResultStatistics();
		EmailReport.createReportEmail();

	}


	public static void createProfiles() {

		switch (GlobalVariables.strGroup) {

			case "health_check":
				testData.put("ADAPTER_EMAIL_ID", "adapter_health@kohls.com");
				testData.put("ADAPTER_EMAIL_PSWD", "Qwerty#1");
				break;

			case "regression":
			case "functional":
			case "p1_regression":
				// Create a new Emailid and password for Adpater and OAPI
				testData.put("ADAPTER_EMAIL_ID", Utilities.getNewEmailID());
				testData.put("ADAPTER_EMAIL_PSWD", "Qwerty#1");
				testData.put("OAPI_EMAIL_ID", Utilities.getNewEmailID());
				testData.put("OAPI_EMAIL_PSWD", "Qwerty#1");
				// Create login for special chars
				testData.put("SPECIAL_CHAR_ADAPTER_EMAIL_ID", Utilities.getNewEmailID());
				testData.put("SPECIAL_CHAR_OAPI_EMAIL_ID", Utilities.getNewEmailID());
				// create Adapter and OAPI Login for regression
				String strRegProfileAdapter = Utilities.getNewEmailID();
				String strRegProfileOAPI = Utilities.getNewEmailID();
				String strRegProfilePaswd = "Qwerty#1";

				testData.put("ADAPTER_EMAIL_ID_REG", strRegProfileAdapter);
				testData.put("ADAPTER_EMAIL_PSWD_REG", strRegProfilePaswd);
				testData.put("OAPI_EMAIL_ID_REG", strRegProfileOAPI);
				testData.put("OAPI_EMAIL_PSWD_REG", strRegProfilePaswd);

				Utilities.createProfile(strRegProfileAdapter, strRegProfilePaswd, Server.Adapter);
				Utilities.createProfile(strRegProfileOAPI, strRegProfilePaswd, Server.OpenApi);

				Utilities.signInProfile(strRegProfileAdapter, strRegProfilePaswd, Server.Adapter, "Access_Tkn_Reg_Adapter");
				Utilities.signInProfile(strRegProfileOAPI, strRegProfilePaswd, Server.OpenApi, "Access_Tkn_Reg_oapi");
				break;

			default:
				// Create a new Emailid and password for Adpater and OAPI
				testData.put("ADAPTER_EMAIL_ID", Utilities.getNewEmailID());
				testData.put("ADAPTER_EMAIL_PSWD", "Qwerty#1");
				testData.put("OAPI_EMAIL_ID", Utilities.getNewEmailID());
				testData.put("OAPI_EMAIL_PSWD", "Qwerty#1");
				// Create login for special chars
				testData.put("SPECIAL_CHAR_ADAPTER_EMAIL_ID", Utilities.getNewEmailID());
				testData.put("SPECIAL_CHAR_OAPI_EMAIL_ID", Utilities.getNewEmailID());
				break;

		}
	}


	public static String oAuthMFP_Token() {

		String strResponse = "";
		
		System.out.println("Generating Oauth Token at Time " + System.currentTimeMillis());		
		
		try {

			if (testData.get("Adapter_Environemnt").contains("mapps") || testData.get("Adapter_Environemnt").contains("maps")) {

				System.out.println("Getting token from port 443 for Prod Env");
				String URL = "http://kd45.km.sl.edst.ibm.com/token-provider-service/TokenProviderServlet?host=" + strAdapterEnv.replaceAll("http(s|)://", "") + "&contextRoot=kohls&port=443";
				strResponse = RestCall.simpleGetRequest(URL, Server.Adapter, false);
			} else {
				String URL = "http://kd45.km.sl.edst.ibm.com/token-provider-service/TokenProviderServlet?host=" + strAdapterEnv.replaceAll("http(s|)://", "") + "&contextRoot=kohls&port=9443";
				strResponse = RestCall.simpleGetRequest(URL, Server.Adapter, false);
				System.out.println("LLE Env");

			}

			if (strResponse == null || strResponse.equals("")) {
				throw new Exception("No Token received");
			}
		}
		catch (Exception e) {
			Assert.fail("Could not generate oauthMFP Token");
		}

		return strResponse;

	}
}
