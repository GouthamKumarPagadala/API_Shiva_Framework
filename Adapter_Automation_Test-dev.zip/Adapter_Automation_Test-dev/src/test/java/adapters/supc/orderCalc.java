package test.java.adapters.supc;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER;
import static main.java.common.GlobalVariables.ORDERCALC_ADAPTER_V2;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI;
import static main.java.common.GlobalVariables.ORDERCALC_OAPI_V2;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;


@Features("Order")
@Stories({ "Order Calc- With SUPC Promo" })
public class orderCalc {
	ResponseValidator validator;
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Order Calc Guest User - Amex and Promo code", description = "Perform Ordercalculation for guest user with the combination of Amex card and expired SUPC Promo code and validating proper error message is getting displayed")
	public void OrderCalcWithAmex_RedeemedSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("REDEEMED_SUPC") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9459","The promocode 2AMH7FY29CDLP has exceeded the number of times it can be redeemed.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "false", "value should be applied from PromoCode in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level ");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Order Calc Guest User - Amex and Promo code", description = "Perform Ordercalculation as guest user with the combination of Visa card,KC and SUPC Promo code")
	public void OrderCalcWithVISA_SUPCPromoAndKC() {

		String arr[]=TestData.createKohlsCash(10);
		// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("VISA")
						+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level ");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Order Calc Guest User - Discover and Promocode", description = "Perform Ordercalculation as guest user with the combination of Discover card and SUPC Promo code")
	public void OrderCalcWithDisc_SUPCPromoAndGC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level ");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
	
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Order Calc Guest User - Master Card with Promo code", description = "Perform Ordercalculation as guest user with the combination of Master card and Invalid SUPC Promo and validating proper error message is getting displayed")
	public void OrderCalcWithMaster_InvalidSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO")+"235" + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9124","The Promo code you entered doesn't exist. Please double-check the offer and re-enter the code.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("MASTER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as KCC tender specific promo is not used");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "false", "value should be applied from PromoCode in the response");
	
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Order Calc Guest User - Master Card with Promo code", description = "Perform Ordercalculation for an order as guest user with the combination of KCCcard and Expired SUPC Promo code and validating whether proper error message is getting displayed")
	public void OrderCalcWithKCC_ExpiredSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("EXP_PROMO") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9121","We're sorry, but the Promo code you entered has expired.  Please check the offer for details.");
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("KOHLS_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isKccDiscount","false","isKccDiscount should  be false at promoCode level as KCC tender specific promo is not used");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "false", "value should not be applied from PromoCode in the response");
	
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
		
	}

	@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With KohlsCash",
			description = "Verify whether the OrderCalc is successful if we pass Kohls Cash and SUPC promo in the request")
	public void ApplePayOrderCalcSUPCPromoAndKC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE_MULTISHIP") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}]"
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 7, testName = "ApplePay OrderCalc With KohlsCash",
			description = "Verify whether the OrderCalc is successful if we pass SUPC Promocode  in the request")
	public void ApplePayOrderCalcSUPCPromo() {

		

		// Create the Json Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE_MULTISHIP") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"false\","
				+ "\"shipAddress\":" + JsonString.getBillAddressJson("CA_MILPITAS") + ","
				+ " \"paymentTypes\" :{\"paymentDetails\":\"APPLEPAY\",\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("VISA")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}]"
				+ "}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "Value should be applied");
		validator.validatebillAddress();
		validator.validateCustomerInfo();
		validator.validateshipAddress();

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card + PromoCode", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using amex card + SUPC PromoCode for orderCalc API")
    public void MasterPass_OrderCalcWithAmexCard_SUPCPromo() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
			    +"\"type\":\"AMEX\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO")+"\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card + PromoCode", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using VISA card + SUPC PromoCode for orderCalc API")
    public void MasterPass_OrderCalcWithVisaCard_SUPCPromoAndGC() {

		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				+"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO")+"\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Master Pass orderCalc V2 with Amex Card + PromoCode", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using VISA card + SUPC PromoCode + KC for orderCalc API")
    public void MasterPass_OrderCalcWithVisaCard_SUPCPromoAndKC() {

		String arr[]=TestData.createKohlsCash(10);
		String strURL = ORDERCALC_ADAPTER_V2;
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				+"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO")+"\"}],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.validatePaymentInfo();
		validator.validateTotal();
		validator.nodeEquals("$.payload.order.cartItems[0].isSuccessful", "true", "IsSuccessful tag should be true");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.validateMasterPassResponse();
		
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=ORDERCALC_OAPI_V2; 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
	}
	
@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 4, testName = "VXO-Order Calc",
			
			description = "OrderCalc with SUPC promocode VisaCheckout")
	public void VisaCheckoutOrderCalcWithSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validatePaymentInfo();
		validator.validatebillAddress();
		validator.validateshipAddress();
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("SUPC_PROMO"), "PromoCode should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 4, testName = "VXO-Order Calc",

description = "OrderCalc with SUPC promocode and GiftCard by VisaCheckout")
    public void VisaCheckoutOrderCalcWithSUPCPromoAndGC() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
	+ testData.get("VISA_ENC_DATA")
	+ "},\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post Request
String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validatePaymentInfo();
validator.validatebillAddress();
validator.validateshipAddress();
validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("SUPC_PROMO"), "PromoCode should be present in the response");
validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
}
}
    
@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 4, testName = "VXO-Order Calc",
description = "OrderCalc with SUPC promocode and KC by VisaCheckout")
    public void VisaCheckoutOrderCalcWithSUPCPromoAndKC() {

	String arr[]=TestData.createKohlsCash(10);
// Create Request
String strPayload = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
	+ testData.get("VISA_ENC_DATA")
	+ "},\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post Request
String strResponse = RestCall.postRequest(ORDERCALC_ADAPTER_V2, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();
validator.validatePaymentInfo();
validator.validatebillAddress();
validator.validateshipAddress();
validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
validator.nodeEquals("$.payload.order.paymentTypes.promoCodes[0].code", testData.get("SUPC_PROMO"), "PromoCode should be present in the response");
validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_NORMAL"), "Given Sku code should be present in the response");
validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],,\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(ORDERCALC_OAPI_V2, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
}
}

}
