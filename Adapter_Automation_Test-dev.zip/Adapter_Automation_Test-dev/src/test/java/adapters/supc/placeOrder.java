package test.java.adapters.supc;

import static main.java.common.GlobalVariables.CompareOAPI;

import static main.java.common.GlobalVariables.PLACEORDERV2_ADAPTER;
import static main.java.common.GlobalVariables.PLACEORDERV2_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;


@Features("Order")
@Stories({ "Place Order With SUPC Promo" })
public class placeOrder {
	ResponseValidator validator;
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Place Order With Amex_SUPCPromo", description = "PlaceOrder With Amexcard and SUPC Promocode for an order-Normal checkout ")
	public void PlaceOrderWithAmex_SUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("AMEX")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO1") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("AMEX_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "PlaceOrder With VISA_ SUPCPromo and KC", description = "PlaceOrder With KC and SUPC Promocode using Amex card-Normal checkout")
	public void PlaceOrderWithVISA_SUPCPromoAndKC() {

		String arr[]=TestData.createKohlsCash(10);
		// Create Request
				String strPayload = "{\"payload\": {\"order\":"
						+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
						+ "\"email\":\"shankarc44@gmail.com\","
						+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
						+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
						+ "\"shippingMethod\":\"USSTD\","
						+ " \"isBillAddressEqualtoShipAddress\":\"true\","
						+ " \"paymentTypes\" :{\"creditCards\" : ["
						+ JsonString.getPaymentTypeJson("VISA")
						+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO11") + "\"}],\"kohlsCash\": [{\"kohlsCashNum\": \"" + arr[0] + "\",\"pin\": \"" + arr[1] + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("VISA_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "PlaceOrder With Disc_SUPCPromo and GC", description = "Do PlaceOrder with SUPCPromo and GC using Discover card-Normal checkout")
	public void PlaceOrderWithDisc_SUPCPromoAndGC() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("DISCOVER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO2") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
		
		validator.validateshipAddress();
		validator.validatePaymentInfo(testData.get("DISCOVER_TYPE"));
		validator.validateTotal();
		validator.validateCustomerInfo();
		validator.validateOrderResponse(false, false,testData.get("SKU_NORMAL"),"USSTD");
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "PlaceOrder With Mastercard _Invalid SUPCPromo", description = "Do PlaceOrder with Mastercard using Invalid SUPC Promocode and verify proper error message is getting displayed")
	public void PlaceOrderWithMaster_InvalidSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("MASTER")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO3")+"235" + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9124","The Promo code you entered doesn't exist. Please double-check the offer and re-enter the code.");
		
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "PlaceOrder With KCC card and Expired SUPCPromo", description = "Do PlaceOrder with KCC card using Expired SUPC Promocode and validate proper error message is getting displayed")
	public void PlaceOrderWithKCC_ExpiredSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"creditCards\" : ["
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ "],\"promoCodes\":[{\"code\":\"" + testData.get("EXP_PROMO") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ORDER9121","We're sorry, but the Promo code you entered has expired.  Please check the offer for details.");
		
		
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
		
	}

	@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 7, testName = "ApplePay PlaceOrder with SUPC Promocode and KohlsCash",
			description = "Do PlaceOrder with SUPC Promocode and KohlsCash and Applepay in the request")
	public void ApplePayPlaceOrderSUPCPromoAndKC() {

		TestData.getRunTimeData("KOHLS_CASH_NO", true);

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_LESS_THAN_TEN_DOLLAR") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"kohlsCash\":[{\"kohlsCashNum\":\"" + testData.get("RUNTIME_KOHLS_CASH_NO") + "\",\"pin\":\"" + testData.get("RUNTIME_KOHLSCASH_PIN") + "\"}],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO10") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		
		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 7, testName = "PlaceOrder with SUPC Promocode and Applepay",
			description = "Do PlaceOrder with SUPC Promocode and Applepay in the request")
	public void ApplePayPlaceOrderSUPCPromo() {

		

		// Create the Json Request
		String strPayload = "{\"payload\":{\"order\":{\"cartItems\":[{\"skuCode\":\"" + testData.get("SKU_LESS_THAN_TEN_DOLLAR") + "\",\"qty\":1,\"giftWrapItem\":false,\"giftInfo\":{\"to\":\"\",\"from\":\"\",\"message\":\"\"},\"shippingMethod\":\"USSTD\"}],\"paymentTypes\":{\"creditCards\":[{\"type\":\"Visa\"}],\"paymentDetails\":\"APPLEPAY\",\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO4") + "\"}],\"paymentToken\":" + testData.get("APAY_KOHLSCASH_PROMO_TOKEN")
		+ "},\"billAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\",\"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\":\"San Jose\",\"state\":\"CA\",\"county\":\"00\",\"postalCode\":\"95126\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\"},\"isBillAddressEqualtoShipAddress\":true,\"shipAddress\":{\"firstName\":\"Sanrba\",\"lastName\":\"Saba\", \"addr1\":\"1854 northwest circle\",\"addr2\":\"\",\"city\": \"San Jose\",\"state\": \"CA\",\"county\":\"00\",\"postalCode\": \"95131\",\"phoneNumber\":\"2628392748\",\"countryCode\":\"US\",\"shipIndex\":1},\"customerName\":{\"firstName\":\"Vysakh\",\"lastName\":\"DJ\"},\"email\":\"shan123@gmail.com.com\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.order.cartItems[0].skuCode", testData.get("SKU_LESS_THAN_TEN_DOLLAR"), "Given Sku code should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		validator.nodeEquals("$.payload.order.cartItems[0].shippingMethod", "USSTD", "Given Sku code should be present in the response");
		validator.nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
		validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order status should be 'Cancelled'");
		validator.nodeMatches("$.payload.order.orderNumber", "[0-9]+", "Order Number should be present in the response");

		

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.cartItems.cartItemID", true);
		}
	}

	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Master Pass PlaceOrder V2 with Amex Card + SUPC PromoCode", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using amex card + SUPC PromoCode")
    public void MasterPass_PlaceOrderWithAmexCard_SUPCPromo() {

		String strURL = PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
			    +"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"XHy6rluvS+Nb8PWLbcA2X/RRYGjkU77b/7tz3twFxRc=0366\","
			    +"\"type\":\"AMEX\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO6")+"\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
				validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
				validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
			
			
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
	}
	
	@Test(groups = {"SUPC-NAP156"}, enabled = true, priority = 4, testName = "Master Pass PlacceOrder V2 with Visa Card + SUPC PromoCode + GC", 
			description = "Verify whether presentation details are getting displayed for MASTERPASS checkout cases using Visa card + SUPC PromoCode anad GC")
    public void MasterPass_PlaceOrderWithVisaCard_SUPCPromoAndGC() {

		String strURL = PLACEORDERV2_ADAPTER+"&brandID=nativeapp";
		
		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"billAddress\" : " + JsonString.getBillAddressJson("IL_CHICAGO") + ","
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"presentationDetails\" :{"  
				+"\"paymentMethod\":\"MASTERPASS\","
			    +"\"transactionID\":\"442305669\"},"
			    +"\"creditCards\" : [{"
			    +"\"cardNum\":\"ronyK5t417bJ+dR8ROzoW8Aq1fXuULez5Wd5qUJnlYA=0002\","
			    +"\"type\":\"VISA\","
			    +"\"expDate\":\"03/2018\"}"
			    + "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO7")+"\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";
		
				
				

		// Post Request
		String strResponse = RestCall.postRequest(strURL, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		// validator.validateCartResponse();
				validator.validatebillAddress();
				validator.validateshipAddress();
				validator.validatePaymentInfo();
				validator.validateTotal();
				validator.nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
				validator.nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
				validator.nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
				validator.nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
				validator.nodeEquals("$.payload.order.orderStatus", "Submitted", "Order should be submitted in the response");
			
			
		// Compare Open API
		if (CompareOAPI) {
			String strURLOAPI=PLACEORDERV2_OAPI+"&brandID=nativeapp";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(strURLOAPI, strPayload, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"payload.order.cartItems.cartItemID", true);
		}
	}
	
@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 4, testName = "Placeorder with SUPC promocode VisaCheckout",
			
			description = "PlaceorderCalc with SUPC promocode VisaCheckout")
	public void VisaCheckoutPlaceOrderWithSUPCPromo() {

		// Create Request
		String strPayload = "{\"payload\": {\"order\":"
				+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
				+ "\"email\":\"shankarc44@gmail.com\","
				+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
				+ "\"shippingMethod\":\"USSTD\","
				+ " \"isBillAddressEqualtoShipAddress\":\"true\","
				+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
				+ testData.get("VISA_ENC_DATA")
				+ "},\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO8") + "\"}]}}}}";

		// Post Request
		String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
				// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request
			String strPayloadOAPI = "{\"payload\": {\"order\":"
					+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
					+ "\"email\":\"shankarc44@gmail.com\","
					+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
					+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
					+ "\"shippingMethod\":\"USSTD\","
					+ " \"isBillAddressEqualtoShipAddress\":\"true\","
					+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
					+ JsonString.getPaymentTypeJson("VISA")
					+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}]}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
		}
	}

@Test(groups = { "SUPC-NAP156" }, enabled = true, priority = 4, testName = "Place order with SUPC promocode and GC",

description = "Place order with SUPC promocode and GC using VisaCheckout")
    public void VisaCheckoutPlaceOrderWithSUPCPromoAndGC() {

// Create Request
String strPayload = "{\"payload\": {\"order\":"
	+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
	+ "\"email\":\"shankarc44@gmail.com\","
	+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
	+ "\"shippingMethod\":\"USSTD\","
	+ " \"isBillAddressEqualtoShipAddress\":\"true\","
	+ " \"paymentTypes\" :{\"paymentDetails\" : \"VC\",\"paymentToken\":{\"data\":"
	+ testData.get("VISA_ENC_DATA")
	+ "},\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO9") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post Request
String strResponse = RestCall.postRequest(PLACEORDERV2_ADAPTER, strPayload, Server.Adapter, false);

// Validate Response
validator = new ResponseValidator(strResponse);
validator.validateNoErrors();

// Compare Open API
if (CompareOAPI) {
// Create the Json Request
String strPayloadOAPI = "{\"payload\": {\"order\":"
		+ "{\"customerName\" : " + JsonString.getCustomerNameJson("VALID") + ","
		+ "\"email\":\"shankarc44@gmail.com\","
		+ "\"cartItems\" : [" + JsonString.getCartJson("VALID", testData.get("SKU_NORMAL"), "2") + "],"
		+ "\"billAddress\" : " + JsonString.getBillAddressJson("WI_MILWAUKEE") + ","
		+ "\"shippingMethod\":\"USSTD\","
		+ " \"isBillAddressEqualtoShipAddress\":\"true\","
		+ " \"paymentTypes\" :{\"paymentDetails\":\"VC\",\"creditCards\" : ["
		+ JsonString.getPaymentTypeJson("VISA")
		+ "],\"promoCodes\":[{\"code\":\"" + testData.get("SUPC_PROMO") + "\"}],\"kohlsGiftCards\": [{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}]}}}}";

// Post the request
String strResponseOAPI = RestCall.postRequest(PLACEORDERV2_OAPI, strPayloadOAPI, Server.OpenApi, false);

// Compare the result
Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.order.email,payload.order.cartItems.cartItemID", true);
}
}
    
}
