package test.java.adapters.inventory;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PRODUCTS_BY_SKU_ADAPTER;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_INVENTORY;
import static main.java.common.GlobalVariables.PRODUCTS_BY_SKU_INVENTORY;
import static main.java.common.GlobalVariables.PRODUCTS_BY_UPC_INVENTORY;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_INVENTORY_OAPI;
import static main.java.common.GlobalVariables.PRODUCTS_BY_SKU_INVENTORY_OAPI;
import static main.java.common.GlobalVariables.PRODUCTS_BY_UPC_ADAPTER;
import static main.java.common.GlobalVariables.PRODUCTS_BY_UPC_INVENTORY_OAPI;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;
import static main.java.common.TestData.testData;
import net.minidev.json.JSONArray;

import org.testng.annotations.Test;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Inventory")
@Stories({ "Product inventory check" })
public class ProductInventoryCheck {

	ResponseValidator validator;


	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBywebID",
			description = "\n TC Description -Verify whether User is able to view productpricing by WebId \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckBywebID() {

		String strURL = SINGLE_PRODUCT_INVENTORY + "/"+ testData.get("WEBID_SMARTSUPPRESSED");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","smokeTest","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBywebID",
			description = "\n TC Description -Verify whether User is able to view productpricing by WebId \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckBywebIDWithStore() {

		String strURL = SINGLE_PRODUCT_INVENTORY + "/"+ testData.get("WEBID_SMARTSUPPRESSED")+"?storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
		validateStoreInfoAtSkuLevel(strResponse);
	 	
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBywebID",
			description = "\n TC Description -Verify whether User is able to view productpricing by WebId \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckBySuppressed_WithStore() {

		String strURL = PRODUCTS_BY_SKU_INVENTORY  +testData.get("SUPPRESSED_SKU")+"&storeNum=647&inStoreEnabled=true";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
		validateStoreInfoAtSkuLevel(strResponse);
		String suppressed=Utilities.getJsonNodeValue(strResponse, "$.payload.products[0].price.isSuppressed");
		if(suppressed.equals("true"))
		{
			validator.nodeEquals("$.payload.products[0].price.suppressedPricingText","FOR PRICE, ADD TO BAG","FOR PRICE, ADD TO BAG should be displayed");
			 Object	document;
			 document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
		  	 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
		  	 int count = SKUS.size();
		  	 for (int i = 0; i < count-1; i++){  
		  		 validator.nodeEquals("$.payload.products[0].SKUS[" + i + "].price.suppressedPricingText","FOR PRICE, ADD TO BAG","skuCode info should be displayed");
		  		 validator.nodeEquals("$.payload.products[0].SKUS[" + i + "].storeInfo.stores[0].price.currentDisplayPrice.salePriceString","PRICE AVAILABLE IN STORE ONLY","PRICE AVAILABLE IN STORE ONLY");
		  	 }
			
		}
		else
		{
			validator.nodeEquals("$.payload.products[0].price.suppressedPricingText","null","No suppressed text should be displayed if it is a non-suppressed product");
		}
		
		}
	 	
    		
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByskuCode",
			description = "\n TC Description -Verify whether User is able to view productpricing by Skucode \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckBySkuCode() {

		String strURL = PRODUCTS_BY_SKU_INVENTORY + testData.get("SMARTSUPPRESSED_SKUCODE");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
		
		validator.validateNoErrors();
	 	
    	
    	 	}
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByskuCode",
			description = "\n TC Description -Verify whether User is able to view productpricing by Skucode \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckBySkuCodeWithStore() {

		String strURL = PRODUCTS_BY_SKU_INVENTORY + testData.get("SMARTSUPPRESSED_SKUCODE")+"&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
		validateStoreInfoAtSkuLevel(strResponse);
    	
    	 	}

	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy UPC ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by UPC Id \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckByUPC() {

		String strURL = PRODUCTS_BY_UPC_INVENTORY +  testData.get("SMARTSUPPRESSED_UPC");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
		
    	
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy UPC ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by UPC Id \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckByUPCWithStore() {

		String strURL = PRODUCTS_BY_UPC_INVENTORY +  testData.get("SMARTSUPPRESSED_UPC")+"&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtSkuLevel(strResponse);
		validateStoreInfoAtSkuLevel(strResponse);
    	
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy UPC ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by UPC Id \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckByCollectionWithStore() {

		String strURL = SINGLE_PRODUCT_INVENTORY +"/"+  testData.get("COLLECTION_ID")+"?storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);
		validatePricingAtCollectionLevelWithStore(strResponse);
		
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy UPC ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by UPC Id \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckByCollection() {

		String strURL = SINGLE_PRODUCT_INVENTORY +"/"+  testData.get("COLLECTION_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validatePricingAtProductLevel(strResponse);	
		validatePricingAtCollectionLevel(strResponse);	
		
    	 }
	
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy Web ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by Web Id \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckByIncorrectwebID() {

		String strURL = SINGLE_PRODUCT_INVENTORY + "/789975";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2000","Web ID (789975) not found.");
	 	
    	
    	 }

	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByskuCode",
			description = "\n TC Description -Verify whether User is able to view productpricing by Skucode \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckByIncorrectSkuCode() {

		String strURL = PRODUCTS_BY_SKU_INVENTORY + "56"+"&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2001","SKU (56) not found.");
	 	
    	
    	 	}

	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy UPC ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by UPC Id \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckByIncorrectUPC() {

		String strURL = PRODUCTS_BY_UPC_INVENTORY +  "656"+"&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD2002","UPC (656) not found.");
	 	
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy WebID ",
			description = "\n TC Description -Verify whether User is able to view productpricing without Web Id \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckWithoutwebID() {

		String strURL = SINGLE_PRODUCT_INVENTORY + "/";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000","Missing Required Parameter 'Web ID, SKU CODE, UPC'.");
	 	
    	
    	 }

	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByskuCode",
			description = "\n TC Description -Verify whether User is able to view productpricing by Skucode \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckWithoutSkuCode() {

		String strURL = PRODUCTS_BY_SKU_INVENTORY + "&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000","Missing Required Parameter skuCode.");
	 	
    	
    	 	}

	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckBy UPC ID ",
			description = "\n TC Description -Verify whether User is able to view productpricing by UPC Id \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckWithoutUPC() {

		String strURL = PRODUCTS_BY_UPC_INVENTORY +  "&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1000","Missing Required Parameter upc.");
	 	
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByInvalid parameter",
			description = "\n TC Description -Verify whether User is able to view productpricing by WebId \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckByInvalidParameter() {

		String strURL = SINGLE_PRODUCT_INVENTORY + "/"+ testData.get("WEBID_SMARTSUPPRESSED")+"?StoreNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1001","StoreNum is not a valid parameter.");
	 	
    	
    	 }
	
	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByInvalid parameter",
			description = "\n TC Description -Verify whether User is able to view productpricing by WebId \n Feature - ProductInventoryCheck")
	
	public void ProductInventoryCheckByInvalidValueForSkudetail() {

		String strURL = SINGLE_PRODUCT_INVENTORY + "/"+ testData.get("WEBID_SMARTSUPPRESSED")+"?skuDetail=fdsfsd";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	 	
    	
    	 }

	@Test(groups = { "ProductInventoryCheck-NAP147","YourPrice-NAP394","YourPrice","DIE_Changes" }, enabled = true, priority = 12, testName = " ProductInventoryCheckByskuCode",
			description = "\n TC Description -Verify whether User is able to view productpricing by Skucode \n Feature - ProductInventoryCheck")
	public void ProductInventoryCheckByInvalidSkuCode() {

		String strURL = PRODUCTS_BY_SKU_INVENTORY + "njsnfns"+"&storeNum=647";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROD1002","Invalid value passed for skuCode.");
	 	
    	 	}

	
	public void validatePricingAtProductLevel(String response){
	
		validator.nodeMatches("$.payload.products[0].webID",".+","WebId should be in the response");
		validator.nodeMatches("$.payload.products[0].isAvailableforShip","true|false","isAvailableforShip should be in the response");
		validator.nodeMatches("$.payload.products[0].isAvailableforPickUp","true|false","isAvailableforPickUp should be in the response");
		/*validator.nodeMatches("$.payload.products[0].price.regularPrice.minPrice", ".*",
				"minPrice should be displayed for regularPrice");
		validator.nodeMatches("$.payload.products[0].price.regularPrice.maxPrice", ".*",
				"maxPrice should be displayed for regularPrice");
		
		validator.nodeMatches("$.payload.products[0].price.currentDisplayPrice.regularPriceString", ".*",
				"regularPriceString should be displayed");
		validator.nodeMatches("$.payload.products[0].price.currentDisplayPrice.salePriceString", ".*",
				"salePriceString should be displayed");
		validator.nodeMatches("$.payload.products[0].price.currentDisplayPrice.promotionString", ".*",
				"promotionString should be displayed");
		validator.nodeMatches("$.payload.products[0].price.currentDisplayPrice.colorSalePrice", ".*",
				"colorSalePrice should be displayed");
		validator.nodeMatches("$.payload.products[0].price.currentDisplayPrice.regularPricePrefix", ".*",
				"regularPricePrefix should be displayed");
		validator.nodeMatches("$.payload.products[0].price.salePriceStatus", ".+",
				"salePriceStatus should be displayed");
		validator.nodeMatches("$.payload.products[0].price.salePrice.minPrice", ".*",
				"min salePrice should be displayed ");
		validator.nodeMatches("$.payload.products[0].price.salePrice.maxPrice", ".*",
				"max salePrice should be displayed ");
		
		validator.nodeMatches("$.payload.products[0].price.regularPriceType", ".*",
				"regularPricePrefix should be displayed");
		validator.nodeMatches("$.payload.products[0].price.regularPriceType", ".*",
				"regularPricePrefix should be displayed");
				
		validator.nodeMatches("$.payload.products[0].price.isSuppressed", "true|false",
				"isSuppressed should be displayed");
		
		// Promotion Array Validation
       	validator.nodeMatches("$.payload.products[0].price.promotions.group", ".*",
 					"group should be displayed under Promotion");
       	validator.nodeMatches("$.payload.products[0].price[0].promotions.tieredPrice", ".*",
 					"tieredPrice should be displayed under Promotion");
       	validator.nodeMatches("$.payload.products[0].price[0].promotions.bogo", ".*",
 					"bogo should be displayed under Promotion");*/
    
	}
	
	public void validatePricingAtSkuLevel(String response)
	{
	 Object	document;
	 document = Configuration.defaultConfiguration().jsonProvider().parse(response);
  	 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
  	 int count = SKUS.size();
  	 for (int i = 0; i < count-1; i++){  
  		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].skuCode",".+","skuCode info should be displayed");
  		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].availability",".+","availability should be displayed");
  		 validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].UPC.ID",".+","UPC ID should be displayed");
  		
  	 }
	}
	
  	public void validateStoreInfoAtSkuLevel(String response)
	{
	 Object	document;
	 document = Configuration.defaultConfiguration().jsonProvider().parse(response);
  	 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
  	 int count = SKUS.size();
  	 for (int i = 0; i < count-1; i++){  
	
	validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].storeInfo.stores[0].storeNum",".+","storeNum info should be displayed");
	validator.nodeMatches("$.payload.products[0].SKUS[" + i + "].storeInfo.stores[0].availability",".+","availability should be displayed");
    }
	}
  	
  	public void validatePricingAtCollectionLevel(String response)
	{
	 Object	document;
	 document = Configuration.defaultConfiguration().jsonProvider().parse(response);
  	 JSONArray collection = JsonPath.read(document, "$.payload...collection");
  	 int count = collection.size();
  	 for (int i = 0; i < count-1; i++){ 
  		
  		 validator.nodeMatches("$.payload.products[0].collection[" + i + "].webID",".+","webID should be displayed");
  		 validator.nodeMatches("$.payload.products[0].collection[" + i + "].isAvailableforShip",".+","isAvailableforShip should be displayed");
  		 validator.nodeMatches("$.payload.products[0].collection[" + i + "].isAvailableforPickUp",".+","isAvailableforPickUp should be displayed");
  		 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0]..SKUS");
  	  	 count = SKUS.size();
  	  	for (int j= 0; j < count-1; j++){  
  	  	
  	  	validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].skuCode",".+" ,"skuCode should be displayed");
  	    validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].availability",".+" ,"availability should be displayed");
  	    validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].UPC.ID",".+","UPC Code should be displayed");
  	   
  	    }
  	  	
  	 }
	}
  	
  	public void validatePricingAtCollectionLevelWithStore(String response)
	{
	 Object	document;
	 document = Configuration.defaultConfiguration().jsonProvider().parse(response);
  	 JSONArray collection = JsonPath.read(document, "$.payload...collection");
  	 int count = collection.size();
  	 for (int i = 0; i < count-1; i++){ 
  		
  		 validator.nodeMatches("$.payload.products[0].collection[" + i + "].webID",".+","webID should be displayed");
  		 validator.nodeMatches("$.payload.products[0].collection[" + i + "].isAvailableforShip",".+","isAvailableforShip should be displayed");
  		 validator.nodeMatches("$.payload.products[0].collection[" + i + "].isAvailableforPickUp",".+","isAvailableforPickUp should be displayed");
  		 JSONArray SKUS = JsonPath.read(document, "$.payload.products[0]..SKUS");
  	  	 count = SKUS.size();
  	  	for (int j= 0; j < count-1; j++){  
  	  	
  	  	validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].skuCode",".+" ,"skuCode should be displayed");
  	    validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].availability",".+" ,"availability should be displayed");
  	    validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].UPC.ID",".+","UPC Code should be displayed");
  	    validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].storeInfo.stores[0].storeNum",".+","storeNum should be displayed in the response");
  	    validator.nodeMatches("$.payload.products[0].collection[" + i + "].SKUS[" + j + "].storeInfo.stores[0].availability",".+","availability should be displayed in the response");
  	  	}
  	  	
  	 }
	}
}
	


