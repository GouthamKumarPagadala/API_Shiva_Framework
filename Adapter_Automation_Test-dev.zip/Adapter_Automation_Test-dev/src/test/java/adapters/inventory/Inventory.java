package test.java.adapters.inventory;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.INVENTORY_WEBID_ADAPTER;
import static main.java.common.GlobalVariables.INVENTORY_WEBID_OAPI;
import static main.java.common.GlobalVariables.INVENTORY_SKU_ADAPTER;
import static main.java.common.GlobalVariables.INVENTORY_SKU_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Inventory")
@Stories({ "Check inventory" })
public class Inventory {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "Checking error code while passing skuCode with collection ID")
	public void CollectionValuePassedInSku() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("COLLECTION_ID");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("INV1002", "Invalid value passed for skucode.");
		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("COLLECTION_ID");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional" }, enabled = true, priority = 6, testName = "OutOfStockWebID",
			description = "Checking the Product Stock")
	public void OutOfStockWebID() {

		String strURL = INVENTORY_WEBID_ADAPTER + "/" + testData.get("WEB_ID_OUT_OF_STOCK");
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.products[0].webID", testData.get("WEB_ID_OUT_OF_STOCK"), "Given webID should be present in the response");
		validator.nodeMatches("$.payload.products[0].availability", "Out of Stock", "availability should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_WEBID_OAPI + "/" + testData.get("WEB_ID_OUT_OF_STOCK");

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

}
