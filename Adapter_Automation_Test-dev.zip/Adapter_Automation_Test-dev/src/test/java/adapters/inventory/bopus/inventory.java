package test.java.adapters.inventory.bopus;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.INVENTORY_SKU_ADAPTER;
import static main.java.common.GlobalVariables.INVENTORY_WEBID_ADAPTER;
import static main.java.common.GlobalVariables.INVENTORY_WEBID_OAPI;

import static main.java.common.GlobalVariables.INVENTORY_SKU_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import test.java.adapters.Config;

@Features("BOPUS")
@Stories({ "Inventory" })
public class inventory {

	ResponseValidator validator;

	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether isBopusEligibleStore should be returned as true for all the stores")
	public void BopusEligibleMultipleStores() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("BOPUSELIGIBLE_SKU_MUTLIPLE_STORES") + "?storeNum=759,761,762&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreTrueForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("BOPUSELIGIBLE_SKU_MUTLIPLE_STORES") + "?storeNum=759,761,762&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether isBopusEligibleStore should be returned as false for all the stores")
	public void NotBopusEligibleMultipleStores() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("NON_BOPUS_SKU") + "?storeNum=871,873&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreFalseForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("NON_BOPUS_SKU") + "?storeNum=871,873&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether isBopusEligibleStore should be returned as true for all the stores in the response which support BOPUS orders and isBopusEligibleStore as false for all the stores in the response which doesnot support BOPUS orders")
	public void BopusAndNonBopusEligibleMultipleStores() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("BOPUSELIGIBLE_SKU_MUTLIPLE_STORES") + "?storeNum=647,871,759,761,762&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreTrueAndFalseForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("BOPUSELIGIBLE_SKU_MUTLIPLE_STORES") + "?storeNum=647,871,759,761,762&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether isClearance should be populated as false if the SKU's given in the request is not a clearance item and true if the sku's given in the request is a clearence in the store")
	public void BopusClearanceAndNonClearance() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("BOPUSELIGIBLE_SKU_MUTLIPLE_STORES") + "?storeNum=647,871,759,761,762&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreTrueAndFalseForSku("stores should be present in the response");
		validator.InventoryisClearanceTrueAndFalseForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("BOPUSELIGIBLE_SKU_MUTLIPLE_STORES") + "?storeNum=647,871,759,761,762&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To verify whether boolean value is getting displayed for isBopusEligible tag in json format in the inventory by sku response.")
	public void BopusSkuIsBopusEligibleTrue_False() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("SKU_BOPUS") + "?storeNum=759&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreTrueAndFalseForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("SKU_BOPUS") + "?storeNum=759&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether isBopusEligible tag is returning as true if the sku available in the store supports Bopus orders.")
	public void BopusSkuCodeIsBopusEligibleTrue() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("SKU_BOPUS") + "?storeNum=759&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreTrueForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("SKU_BOPUS") + "?storeNum=759&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To verify whether isBopusEligible tag is getting returned as false if the sku provided in the request is clearence, online only , store only and GWP/PWP item in the store")
	public void Bopus_NonBopusSkuCodeFalse() {

		String strURL = INVENTORY_SKU_ADAPTER + "/" + testData.get("NON_BOPUS_SKU") + "?storeNum=871&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.InventoryisBopusEligibleStoreFalseForSku("stores should be present in the response");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/" + testData.get("NON_BOPUS_SKU") + "?storeNum=871&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether the Error message is getting displayed with the invalid sku code.")
	public void Bopus_InvalidSkuCode() {

		String strURL = INVENTORY_SKU_ADAPTER + "/7980fdff?storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("INV1002", "Invalid value passed for skuCode.");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/7980fdff?storeNum=759";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus", "errorhandling" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "To Verify whether the Error message is getting displayed with the alphanumeric  sku code.")
	public void Bopus_AlphaNumericSku() {

		String strURL = INVENTORY_SKU_ADAPTER + "/98asdfasd?storeNum=759";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("INV1002", "Invalid value passed for skuCode.");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/98asdf?storeNum=759";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "Verify whether the Error code is getting displayed-Provide skuID with more than limit of ID")
	public void Bopus_Sku_MoreThanLimit() {

		String strURL = INVENTORY_SKU_ADAPTER + "/123456788?storeNum=759&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateExpectedErrors("PROD1001", "sku is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_SKU_OAPI + "/123456788?storeNum=759&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "bopus" }, enabled = true, priority = 6, testName = "CollectionValuePassedInSku",
			description = "Verify whether the Error code is getting displayed-Provide skuID with more than limit of ID")
	public void Bopus_WEBID_MoreThanLimit() {

		String strURL = INVENTORY_WEBID_ADAPTER + "/123456788?storeNum=759&channel=store";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateExpectedErrors("PROD1001", "sku is not a valid parameter.");

		// Compare Open API
		if (CompareOAPI) {
			// Create the Json Request for create profile
			String strURLOAPI = INVENTORY_WEBID_OAPI + "/123456788?storeNum=759&channel=store";

			// Post the request
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}
