package test.java.adapters.authentication.walletAuth;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.GlobalVariables.V2_REFRESH_TOKEN;
import static main.java.common.GlobalVariables.V1_REFRESH_TOKEN;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Wallet Auth")
@Stories({ "Refresh Token" })
public class refreshToken {

	ResponseValidator validator;


	@Test(groups = { "wallet_auth", "regression","functional" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV1",
			description = "Verify whether the user is able to generate access token using refresh token and wallet ID succesfully(Version V1)")
	public void RefreshTokenV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V1");

		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "wallet_auth", "regression","functional", "errorhandling" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV1",
			description = "Verify whether error message is generate when invalid refresh token is used")
	public void InvalidRefreshTokenV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=jbGxGC8zpbAtjg7lgNaOqrOnYYFpYtaz";

		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Invalid refresh_token");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=jbGxGC8zpbAtjg7lgNaOqrOnYYFpYtaz";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "wallet_auth", "regression","functional","wallet_auth_GR", "errorhandling" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
			description = "Verify whether access token is generate when valid refresh and access token and invalid wallet id is used")
	public void InvalidWalletTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=bSj3YQihUKmcNEIVCQq9D0LZ7FFT4FyyCoSlcPPXouFcE8gfdg677BHXQsxfY7zLOJ3AYC1"+ "&generateWallet=" +"false" +"&grTokenRequired=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.access_token", "ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		//validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}
	
	
	@Test(groups = { "wallet_auth", "regression","wallet_auth_GR","functional", "errorhandling","wallet_hash" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
			description = "Verify whether access token message is generate when valid refresh and access token and Decoded expired wallet token is used")
	public void ExpiredWalletTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token="+testData.get("EXPIRED_WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D")+ "&generateWallet=" +"false"+"&grTokenRequired=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.access_token", "ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		//validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}
	
	
	@Test(groups = { "wallet_auth","wallet_auth_GR", "regression","functional", "errorhandling"}, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
			description = "Verify whether access token message is generate when valid refresh and access token and Encoded expired wallet token is used")
	public void EncodedExpiredWalletTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token="+testData.get("EXPIRED_WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=","%3D")+ "&generateWallet=" +"false"+"&grTokenRequired=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.access_token", "ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		//validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "wallet_auth","wallet_auth_GR", "regression","functional","wallet_hash" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
			description = "Verify whether the user is able to retrieve wallet information while passing encoded wallet token in v2 version of the refreshToken call")
	public void ValidEncodedWalletTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=","%3D")+ "&generateWallet=" +"false"+"&grTokenRequired=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
	//	String strResponse1 = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
	//	Utilities.setTestData(strResponse, "$.payload.access_token", "ACCESS_TOKEN-V2");
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		//validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}
	
	
	@Test(groups = { "wallet_auth","wallet_auth_GR", "regression","functional","wallet_hash" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
			description = "Verify whether the user is able to retrieve wallet information while passing Decoded wallet token in v2 version of the refreshToken call")
	public void RefreshTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D")+ "&generateWallet=" +"false"+"&grTokenRequired=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
	//	String strResponse1 = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
	//	Utilities.setTestData(strResponse, "$.payload.access_token", "ACCESS_TOKEN-V2");
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
//		//validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}
	
	
	@Test(groups = { "wallet_auth","wallet_auth_GR", "regression","functional","wallet_hash" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
			description = "Verify whether the user is able to error message while passing Expired refresh token in v2 version of the refreshToken call")
	public void ExpiredRefreshTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + "2c4fbd801ab4f732944b2ad5ab842dcf" + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2")+ "&generateWallet=" +"false";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
	//	String strResponse1 = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);
	//	Utilities.setTestData(strResponse, "$.payload.access_token", "ACCESS_TOKEN-V2");
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Invalid refresh_token");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + "2c4fbd801ab4f732944b2ad5ab842dcf" + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

		}
	}
	
	
	@Test(groups = { "wallet_auth_GR" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
					description = "API Version - V2/auth/Token \r\n TC Description - Verify whether GR Token is not generated by passing grTokenRequired as false\r\n Feature - Refresh Token")
	@Severity(SeverityLevel.BLOCKER)
	
	public void GenerateGR_TokenFalseV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D") + "&grTokenRequired=false";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		////validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "wallet_auth_GR" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.signInProfile.ValidUserID_AndPasswordV2",
					description = "API Version - V2/auth/Token \r\n TC Description - Verify whether GR Token is generated by passing grTokenRequired as true\r\n Feature - Refresh Token")
	@Severity(SeverityLevel.BLOCKER)
	
	public void GenerateGR_TokenTrueV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D") + "&grTokenRequired=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		//validator.nodeMatches("$.payload.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}

}