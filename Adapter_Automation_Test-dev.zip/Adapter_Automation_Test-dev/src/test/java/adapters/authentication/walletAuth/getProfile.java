package test.java.adapters.authentication.walletAuth;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.V2_PROFILE_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Wallet Auth")
@Stories({ "Get Profile" })
public class getProfile {

	ResponseValidator validator;


	@Test(groups = { "wallet_auth", "regression","functional", "errorhandling" }, enabled = true, priority = 4, testName = "Get Profile with ExpiredAccessToken",
			description = "Verify whether error message is generated when expired access token is used")
	public void WithExpiredAccessTokenV2() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		// Post the request
		String strURL = RestCall.getRequest(V2_PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 401);
		}
	}


	@Test(groups = { "wallet_auth", "regression","functional" }, enabled = true, priority = 4, testName = "Get Profile", 
			dependsOnMethods = "test.java.adapters.authentication.walletAuth.refreshToken.InvalidWalletTokenV2",
			description = "Verify  whether  profile details are getting displayed using access token generated from refresh token version v2")
	public void ValidAccessTokenV2() {
		
		Utilities.signInProfile(testData.get("ADAPTER_EMAIL_ID"), testData.get("ADAPTER_EMAIL_PSWD"), Server.Adapter, "ADAPTER_TOKEN_V2");
		mapheader.clear();
		mapheader.put("access_token", testData.get("ADAPTER_TOKEN_V2"));
		// Post the request
		String strURL = RestCall.getRequest(V2_PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.email", testData.get("ADAPTER_EMAIL_ID"), "Profile email should be present");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", ".+", "LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", ".*", "FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+", "saleAlerts should be available in response");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true);
		}
	}
}