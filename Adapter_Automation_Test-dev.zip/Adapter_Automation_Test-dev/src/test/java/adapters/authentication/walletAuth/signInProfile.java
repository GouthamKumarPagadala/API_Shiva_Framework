package test.java.adapters.authentication.walletAuth;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Wallet Auth")
@Stories({ "SignIn Profile" })
public class signInProfile {

	ResponseValidator validator;


	@Test(groups = { "wallet_auth", "regression","functional", "errorhandling" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify firstName, lastName, customerID, wallet hash and timestamp, expire_token, token_type, access & refresh token and whether the User able to sign in succesfully version v1 with valid user id and password")
	@Severity(SeverityLevel.BLOCKER)
	public void ValidUserID_AndPasswordV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V1");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		//validator.nodeMatches("$.payload.response.signIn.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "OPENAPI_REFRESH_ACCESS_TOKEN-V1");

		}
	}


	@Test(groups = { "wallet_auth","wallet_auth_GR",  "regression","functional", "errorhandling","wallet_hash" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify expire_token, token-type, access & refresh token, lastname, firstname, id and Hash value and whether the User able to sign in succesfully with version v2 with valid user id and password")
	@Severity(SeverityLevel.BLOCKER)
	public void ValidUserID_AndPasswordV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.wallet.token", "WALLET_TOKEN-V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		//validator.nodeMatches("$.payload.response.signIn.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", "[0-9]+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.walletId", "[0-9]+", "walletId should be available in response");
		validator.nodeMatches("$.payload.response.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "OPENAPI_REFRESH_ACCESS_TOKEN-V1");
		}
	}


	@DiscontinuedTest(groups = { "wallet_auth","wallet_auth_GR",  "regression","functional", "errorhandling" }, enabled = false, priority = 1, testName = "Sign In Profile with INVALID PASSWORD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify error message Invalid userId/password with invalid userid/password used in sigIn profile")
	@Severity(SeverityLevel.BLOCKER)
	public void InvalidPassword() {

		testData.put("ADAPTER_EMAIL_INVALID_PSWD", "welocome");
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

		System.out.println(testData.get("OAPI_EMAIL_ID"));
		System.out.println(testData.get("ADAPTER_EMAIL_INVALID_PSWD"));

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateErrors();
		validator.validateExpectedErrors("invalid_request", "Invalid userId/password");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "wallet_auth",  "regression","functional","errorhandling" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "TC09_Verify error message Missing required parameter userId with no userid in sigIn profile")
	@Severity(SeverityLevel.BLOCKER)
	public void WithOutUserIDV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter userId");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "wallet_auth",  "regression","functional","errorhandling" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify error message Missing required parameter password with no password in sigIn profile")
	@Severity(SeverityLevel.BLOCKER)
	public void WithOutPasswordV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=";

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter password");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
}