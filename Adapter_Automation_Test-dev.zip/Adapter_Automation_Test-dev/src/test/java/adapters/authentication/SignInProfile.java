package test.java.adapters.authentication;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Profile")
@Stories({ "SignIn Profile" })
public class SignInProfile {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 1, testName = "Sign In Profile with INVALID PASSWORD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "API Version - V1/auth/signInProfile \r\n TC Description - SignIn Profile with Invalid Credentials and verify proper error message is displayed \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void InvalidPassword() {

		testData.put("ADAPTER_EMAIL_INVALID_PSWD", "welocome");
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

		System.out.println(testData.get("OAPI_EMAIL_ID"));
		System.out.println(testData.get("ADAPTER_EMAIL_INVALID_PSWD"));

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateErrors();
		validator.validateExpectedErrors("invalid_request", "Invalid userId/password");

		/*
		 * validator.validateNoErrors(); validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response"); validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response"); validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response"); validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response"); validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response"); validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		 */     	// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}

	}
}