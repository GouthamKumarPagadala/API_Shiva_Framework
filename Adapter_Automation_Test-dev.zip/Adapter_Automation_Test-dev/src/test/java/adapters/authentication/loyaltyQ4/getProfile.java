package test.java.adapters.authentication.loyaltyQ4;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.V2_PROFILE_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.TestData.Server;
import main.java.common.Utilities;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Loyalty Auth")
@Stories({ "Get Profile" })
public class getProfile {

	ResponseValidator validator;


	@Test(groups = { "loyalty", "regression","functional", "errorhandling" }, enabled = true, priority = 4, testName = "Get Profile with ExpiredAccessToken",
			description = "API Version - V2/profile \r\n TC Description - Get Profile Info with Expired Access Token and verify the error message displayed as per ICD \r\n Feature - Get Profile Info")
	public void GetProfileWithExpiredAccessToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		// Post the request
		String strURL = RestCall.getRequest(V2_PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 401);
		}
	}


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 4, testName = "Get Profile",
			dependsOnMethods = "test.java.adapters.authentication.loyaltyQ4.signInProfile.SigninWithValidUseridAndPassword",
			description = "API Version - V1/profile \r\n TC Description - Get Profile Information \r\n Feature - Get Profile Info")
	public void GetProfileInfo() {

		mapheader.put("access_token", testData.get("ACCESS_TOKEN-V1"));
		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.email", testData.get("ADAPTER_EMAIL_ID"), "Profile email should be present");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", ".+", "LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", ".*", "FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+", "saleAlerts should be available in response");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", testData.get("OPENAPI_ACCESS_TOKEN-V1"));
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 200);
		}
	}


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 4, testName = "Get Profile",
			dependsOnMethods = "test.java.adapters.authentication.loyaltyQ4.signInProfile.SigninWithValidUseridAndPasswordV2",
			description = "API Version - V2/profile \r\n TC Description - Get Profile Information \r\n Feature - Get Profile Info")
	public void GetProfileInfoV2() {

		mapheader.put("access_token", testData.get("ACCESS_TOKEN_V2"));
		// Post the request
		String strURL = RestCall.getRequest(V2_PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.profile.email", testData.get("ADAPTER_EMAIL_ID"), "Profile email should be present");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", ".+", "LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", ".*", "FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+", "saleAlerts should be available in response");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", testData.get("OAPI_ACCESS_TOKEN-V2"));

			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 200);
		}
	}
}