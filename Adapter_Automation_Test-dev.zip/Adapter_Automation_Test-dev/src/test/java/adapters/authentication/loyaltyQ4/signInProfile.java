package test.java.adapters.authentication.loyaltyQ4;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Loyalty Auth")
@Stories({ "SignIn Profile" })
public class signInProfile {

	ResponseValidator validator;

	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "API Version - V1/auth/signInProfile \r\n TC Description - SignIn the Kohls User Profile \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void SigninWithValidUseridAndPassword() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V1");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "ACCESS_TOKEN-V1");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "OPENAPI_REFRESH_ACCESS_TOKEN-V1");
			Utilities.setTestData(strResponseOAPI, "$.access_token", "OPENAPI_ACCESS_TOKEN-V1");

		}
	}


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "API Version - V2/auth/signInProfile \r\n TC Description - SignIn the Kohls User Profile \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void SigninWithValidUseridAndPasswordV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.wallet.token", "WALLET_TOKEN-V2");
		Utilities.setTestData(strResponse, "$.payload.response.wallet.token", "WALLET_TOKEN_V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN_V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "ACCESS_TOKEN_V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", "[0-9]+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.walletId", "[0-9]+", "walletId should be available in response");
		validator.nodeMatches("$.payload.response.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "OAPI_ACCESS_TOKEN-V2");
		}
	}


	@Test(groups = { "loyalty", "regression","functional", "errorhandling" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "API Version - V2/auth/signInProfile \r\n TC Description - SignIn the Kohls User Profile with Invalid Credentials and verify error message is displayed as per ICD.\r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void SigninProfileWithInvalidUseridAndPassword() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("INVALID_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Invalid userId/password");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("INVALID_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
}