package test.java.adapters.authentication.loyaltyQ4;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.GlobalVariables.V2_REFRESH_TOKEN;
import static main.java.common.GlobalVariables.V1_REFRESH_TOKEN;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Issues;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Loyalty Auth")
@Stories({ "Refresh Token" })
public class refreshToken {

	ResponseValidator validator;


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 1, testName = "Refresh Token V1",
			dependsOnMethods = {"test.java.adapters.authentication.loyaltyQ4.signInProfile.SigninWithValidUseridAndPassword","test.java.adapters.authentication.loyaltyQ4.getProfile.GetProfileInfo"},
			description = "API Version - V1/auth/Token \r\n TC Description - Generate new AccessToken using RefreshToken \r\n Feature - Refresh Token")
	public void RefreshTokenV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V1");

		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "loyalty", "regression","functional", "errorhandling" }, enabled = true, priority = 1, testName = "Refresh Token V1",
			description = "API Version - V1/auth/Token \r\n TC Description - Generate new AccessToken using Invalid RefreshToken and verify the proper error message is displayed as per ICD.\r\n Feature - Refresh Token")
	public void InvalidRefreshTokenV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=jbGxGC8zpbAtjg7lgNaOqrOnYYFpYtaz";

		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request","Invalid refresh_token");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=jbGxGC8zpbAtjg7lgNaOqrOnYYFpYtaz";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 1, testName = "Refresh Token V1",
			dependsOnMethods = {"test.java.adapters.authentication.loyaltyQ4.signInProfile.SigninWithValidUseridAndPasswordV2","test.java.adapters.authentication.loyaltyQ4.getProfile.GetProfileInfoV2"},
			description = "API Version - V2/auth/Token \r\n TC Description - Generate new AccessToken using RefreshToken \r\n Feature - Refresh Token")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("FMNP-160") })
	public void RefreshTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D");

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = {"test.java.adapters.authentication.loyaltyQ4.signInProfile.SigninWithValidUseridAndPasswordV2","test.java.adapters.authentication.loyaltyQ4.getProfile.GetProfileInfoV2"},
					description = "API Version - V2/auth/Token \r\n TC Description - Generate new AccessToken by passing Generate Wallet Token as false\r\n Feature - Refresh Token")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("FMNP-160") })
	public void GenerateWalletFalseV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN-V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN-V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D") + "&generateWallet=false";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "loyalty", "regression","functional" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			dependsOnMethods = {"test.java.adapters.authentication.loyaltyQ4.signInProfile.SigninWithValidUseridAndPasswordV2","test.java.adapters.authentication.loyaltyQ4.getProfile.GetProfileInfoV2"},
			description = "API Version - V2/auth/Token \r\n TC Description - Generate new AccessToken by passing Generate Wallet Token as true\r\n Feature - Refresh Token")
	@Severity(SeverityLevel.BLOCKER)
	@Issues({ @Issue("FMNP-160") })
	public void GenerateWalletTrueV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("REFRESH_ACCESS_TOKEN_V2") + "&email=" + testData.get("ADAPTER_EMAIL_ID") + "&wallet_token=" + testData.get("WALLET_TOKEN_V2").replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=", "%3D") + "&generateWallet=true";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("OPENAPI_REFRESH_ACCESS_TOKEN-V1");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "loyalty", "regression","functional", "errorhandling" }, enabled = true, priority = 1, testName = "Refresh Token V2",
			description = "API Version - V2/auth/Token \r\n TC Description - Generate new AccessToken using Invalid RefreshToken and verify the proper error message is displayed as per ICD.\r\n Feature - Refresh Token")
	public void InvalidRefreshTokenV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=jbGxGC8zpbAtjg7lgNaOqrOnYYFpYtaz";

		// Post the request
		String strResponse = RestCall.postRequest(V2_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Invalid refresh_token");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=jbGxGC8zpbAtjg7lgNaOqrOnYYFpYtaz";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
}