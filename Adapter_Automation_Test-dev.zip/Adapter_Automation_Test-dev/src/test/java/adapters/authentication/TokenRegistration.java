package test.java.adapters.authentication;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.GlobalVariables.V1_REFRESH_TOKEN;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Token" })
public class TokenRegistration {

	ResponseValidator validator;
	


	@Test(groups = { "regression","functional" }, enabled = true, priority = 4, testName = "Refresh Token V2",
			description = "API Version - V2/auth/Token \r\n TC Description - Generate new AccessToken using RefreshToken \r\n Feature - Refresh Token")
	public void RefreshTokenV2() {
				
		// Create a new profile for refresh token, as refresh token invalidates all the previously generated tokens 
		String strRefTknEmail = Utilities.getNewEmailID();
		Utilities.createProfile(strRefTknEmail, "refTkn@1Paswd", Server.Adapter);
		String strPayload = "grant_type=password&userId=" + strRefTknEmail + "&password=" + "refTkn@1Paswd";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();

		// Set the refresh token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_forRefToken");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "refToken_adapter");

		// Create the Json Request for Sign In
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_forRefToken"));
		strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("refToken_adapter");
		// Post the request
		strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.expires_in", ".+", "Expires In  should be available in response");
		// validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");

		validator.nodeMatches("$.payload.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.access_token", ".+", "Refresh token should be available in response");
		// validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		// validator.nodeMatches("$.payload.wallet.token", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {
			
			// Create a new profile for refresh token, as refresh token invalidates all the previously generated tokens 
			String strOAPIRefTokenEmail = Utilities.getNewEmailID();
			Utilities.createProfile(strOAPIRefTokenEmail, "refTkn@1Paswd", Server.OpenApi);
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + strOAPIRefTokenEmail + "&password=" + "refTkn@1Paswd";
			// Post the request
			strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false,mapheader);
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();

			// Set the refresh token in testData
			Utilities.setTestData(strResponse, "$.access_token", "access_token_forRefToken_oapi");
			Utilities.setTestData(strResponse, "$.refresh_token", "refToken_oapi");

			// Create the Json Request for Sign In
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_forRefToken_oapi"));

			// Create the Json Request for create profile
			strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("refToken_oapi") + "&userId=" + strOAPIRefTokenEmail + "&password=" + "refTkn@1Paswd_OAPI";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 200);

		}

	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 4, testName = "Refresh Token V2 WithInvalidToken",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "API Version - V2/auth/Token \r\n TC Description - Generate new AccessToken using Invalid RefreshToken and verify the proper error message is displayed as per ICD.\r\n Feature - Refresh Token")
	public void RefreshTokenV2WithInvalidToken() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=refresh_token&refresh_token=" + testData.get("uyfduyf764tgdw6t4");
		// Post the request
		String strResponse = RestCall.postRequest(V1_REFRESH_TOKEN, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Invalid refresh_token");

		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=refresh_token&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&refresh_token=" + testData.get("uydgfuydg673437rt45656") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}

	}
}
