package test.java.adapters.authentication;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Profile")
@Stories({ "SignIn Profile Special Chars" })
public class SignInProfile_charctervalidation {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.HashSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character. \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void HashSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Hash" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=Qwe#rty1";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Hash" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=Qwe#rty1";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.DollarSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character($). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void DollarSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Dollar" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123$Qwerty";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Dollar" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123$Qwerty";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.PercentSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(%). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void PercentSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Percent" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qwe%rty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Percent" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qwe%rty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.PowerSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(^). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void PowerSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Power" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123Q^qwerty";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Power" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123Q^qwerty";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.AmpersandSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(&). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void AmpersandSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Ampersand" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q&qwerty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Ampersand" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q&qwerty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.LessThanSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(<). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void LessThanSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=LessThan" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123Qqwerty<";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=LessThan" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123Qqwerty<";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.StarSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(*). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void StarSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Star" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123Q*qwerty";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Star" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123Q*qwerty";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.OpenBraceSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(\"(\"). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void OpenBraceSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=OpenBrace" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123Q(qwerty";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=OpenBrace" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123Q(qwerty";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.CloseBraceSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(\")\"). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void CloseBraceSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=CloseBrace" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123Q)qwerty";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=CloseBrace" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123Q)qwerty";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.SpaceSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(Space Character). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void SpaceSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Space" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password=123Q@qwe rty";

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Space" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password=123Q@qwe rty";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.PlusSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(#). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void PlusSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Plus" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qqwe+rty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Plus" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qqwe+rty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.EqualToSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(=). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void EqualToSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=EqualTo" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qqwe=rty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=EqualTo" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qqwe=rty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.MinusSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(-). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void MinusSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Minus" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q-qwerty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Minus" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q-qwerty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.QuestionSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(?). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void QuestionSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Question" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q?qwerty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Question" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q?qwerty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.GreaterThanSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(>). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void GreaterThanSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=GreaterThan" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qqwe>rty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=GreaterThan" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Qqwe>rty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.ExclamationSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(!). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void ExclamationSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=Exclamation" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q!qwerty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=Exclamation" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123Q!qwerty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.profile.CreateProfile.AtTheRateSpecialCharacter",
			description = "API Version - V1/auth/SignInProfile \r\n TC Description - SignIn Profile with password contains special Character(@). \r\n Feature - SignIn Profile")
	@Severity(SeverityLevel.BLOCKER)
	public void AtTheRateSpecialCharacter() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=AtTheRate" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123@Qwerty");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=AtTheRate" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "&password="+Utilities.urlEncodeString("123@Qwerty");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}

}