package test.java.adapters.authentication;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Profile")
@Stories({ "SignIn Profile Sales Alert" })

public class SignIn_SalesAlert {

	ResponseValidator validator;


	@Test(groups = { "sales_alert", "regression","functional" }, enabled = true, priority = 1, testName = "Verify whether Sales Alert flag is true in the response when sign In with the email address which is subscribed for sales alert",
			dependsOnMethods = "test.java.adapters.profile.CreateProfileSalesAlert.SalesAlertTrue",
			description = "Verify whether Sales Alert flag is true in the response when sign In with the email address which is subscribed for sales alert")
	@Severity(SeverityLevel.BLOCKER)
	public void SalesAlertTrue() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID_SALE") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD_SALE");

		/*System.out.println(testData.get("OAPI_EMAIL_ID_SALE"));
		System.out.println(testData.get("ADAPTER_EMAIL_PSWD_SALE"));*/

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_sales_alert");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_sales_alert"));
		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateErrors();
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.preferences.saleAlerts", "true", "saleAlerts should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID_SALE") + "&password=" + testData.get("OAPI_EMAIL_PSWD_SALE");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_sales_alert_oapi");
			/*mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_sales_alert_oapi"));*/
		}

	}


	@Test(groups = { "sales_alert", "regression","functional" }, enabled = true, priority = 1, testName = "Verify whether Sales Alert flag is false in the response when sign In with the email address which is subscribed for sales alert",
			dependsOnMethods = "test.java.adapters.profile.CreateProfileSalesAlert.SalesAlertFalse",
			description = "Verify whether Sales Alert flag is false in the response when sign In with the email address which is subscribed for sales alert")
	@Severity(SeverityLevel.BLOCKER)
	public void SalesAlertFalse() {

		testData.put("ADAPTER_EMAIL_PSWD1_SALE", "Ocb@1234");
		// Create the Json Request for Sign In

		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID1_SALE") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD1_SALE");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_sales_alert1");
	//	System.out.println(testData.get("access_token_sales_alert1"));
		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateErrors();
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.preferences.saleAlerts", "false", "saleAlerts should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID1_SALE") + "&password=" + testData.get("OAPI_EMAIL_PSWD1_SALE");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_sales_alert_oapi1");
		//	System.out.println(testData.get("access_token_sales_alert_oapi1"));
		}

	}

}
