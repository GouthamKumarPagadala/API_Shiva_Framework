package test.java.adapters.authentication;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V2_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Wallet Auth")
@Stories({ "SignIn Profile" })


public class Signin_Profile_nudata {

	ResponseValidator validator;
	@DataProvider(name = "channel")
	public Object[][] getChannel() {

		return new Object[][] {
			
			
				{ "android" },
				//{ "iphone" },
				
				
		};

	}


	@Test(groups = {"wallet_auth", "regression","Remedy","functional", "errorhandling","Nudata_captcha"}, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify firstName, lastName, customerID, wallet hash and timestamp, expire_token, token_type, access & refresh token and whether the User able to sign in succesfully version v1 with valid user id and password")
	@Severity(SeverityLevel.BLOCKER)
	public void ValidUserID_AndPasswordV1() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V1");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "OPENAPI_REFRESH_ACCESS_TOKEN-V1");

		}
	}


	@Test(groups = { "wallet_auth", "regression","Remedy","functional", "errorhandling","wallet_hash","Nudata_captcha"}, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify expire_token, token-type, access & refresh token, lastname, firstname, id and Hash value and whether the User able to sign in succesfully with version v2 with valid user id and password")
	@Severity(SeverityLevel.BLOCKER)
	public void ValidUserID_AndPasswordV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.wallet.token", "WALLET_TOKEN-V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.gr_token", ".+", "GR token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", "[0-9]+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.walletId", "[0-9]+", "walletId should be available in response");
		validator.nodeMatches("$.payload.response.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");
		
			// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "OPENAPI_REFRESH_ACCESS_TOKEN-V1");
		}
	}


	@DiscontinuedTest(groups = { "wallet_auth","wallet_auth_GR","regression","functional", "errorhandling","Nudata_captcha"},enabled = false, priority = 1, testName = "Sign In Profile with INVALID PASSWORD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify error message Invalid userId/password with invalid userid/password used in sigIn profile")
	@Severity(SeverityLevel.BLOCKER)
	public void InvalidPassword() {

		testData.put("ADAPTER_EMAIL_INVALID_PSWD", "welocome");
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

		System.out.println(testData.get("OAPI_EMAIL_ID"));
		System.out.println(testData.get("ADAPTER_EMAIL_INVALID_PSWD"));

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateErrors();
		validator.validateExpectedErrors("invalid_request", "Invalid userId/password");

			// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "wallet_auth","wallet_auth_GR", "regression","Remedy","functional","errorhandling","Nudata_captcha"}, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "TC09_Verify error message Missing required parameter userId with no userid in sigIn profile")
	@Severity(SeverityLevel.BLOCKER)
	public void WithoutUserID_V2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter userId");

		
			// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "wallet_auth","wallet_auth_GR", "regression","Remedy","functional","errorhandling","Nudata_captcha"}, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify error message Missing required parameter password with no password in sigIn profile")
	@Severity(SeverityLevel.BLOCKER)
	public void WithoutPasswordV2() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=";

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter password");
		
			// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
	

	@Test(groups = {"signin_nudata"}, enabled = true,dataProvider = "channel", priority = 1, testName = "Sign In Profile",
			description = "Verify  user is able to signin with valid user id and password with nudata")
	@Severity(SeverityLevel.BLOCKER)
	public void Sign_in_ValidUser_Id_and_Password(String channel) {
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Pass@123";
		Utilities.createProfile(strEmail, strPaswd, Server.OpenApi);
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + strEmail + "&password=" + strPaswd + "&nuDataChannel=" +  channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");

		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.wallet.token", "WALLET_TOKEN-V2");
		Utilities.setTestData(strResponse, "$.payload.response.signIn.refresh_token", "REFRESH_ACCESS_TOKEN-V2");

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		validator.nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		validator.nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		validator.nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		validator.nodeMatches("$.payload.response.wallet.timestamp", "[0-9]+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.response.wallet.walletId", "[0-9]+", "walletId should be available in response");
		validator.nodeMatches("$.payload.response.wallet.token", ".+", "token should be available in response");
		validator.nodeMatches("$.payload.response.profileInfo.id", "[0-9]+", "CustomerID should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "firstName should be available in response");
		validator.nodeEquals("$.payload.response.profileInfo.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "lastName should be available in response");
		
			// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.refresh_token", "OPENAPI_REFRESH_ACCESS_TOKEN-V1");
		}
	}

	
	@Test(groups = {"signin_nudata"},enabled = true, priority = 1,dataProvider = "channel", testName = "Sign In Profile with INVALID PASSWORD",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify  user is able to signin with InvalidPassword with nudata")
	@Severity(SeverityLevel.BLOCKER)
	public void Sign_in_Invalid_Password(String channel) {
		
		testData.put("ADAPTER_EMAIL_INVALID_PSWD", "welocome");
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("REMEDY_ACCOUNT") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD")+ "&nuDataSessionId=" + testData.get("Nudata_sessionid") + "&nuDataChannel=" + channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");
		
		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false,200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrorsforremedy(strResponse,"PROF8000", "Remedy Challenge Required.");
		
		validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","captcha","Remedy type should be displayed as captcha in the response");
		validator.nodeMatches("$.errors[0].remedyChallenge.ndpdData",".+","ndpdData should be returned in response");
		
		
			// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_INVALID_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
	
	
	@Test(groups = {"signin_nudata"}, enabled = true,dataProvider = "channel", priority = 1, testName = "Sign In Profile",
			description = "Verify  user is able to signin without user ID with nudata")
	@Severity(SeverityLevel.BLOCKER)
	public void Sign_in_Without_User_Id(String channel) {

		String strPaswd = "Pass@123";

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=&password=" + strPaswd + "&nuDataChannel=" + channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");
		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter userId");

		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=&password=" + testData.get("OAPI_EMAIL_PSWD");

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}


	@Test(groups = { "signin_nudata"}, enabled = true,dataProvider = "channel", priority = 1, testName = "Sign In Profile",
			description = "Verify  user is able to signin without password with nudata")
	@Severity(SeverityLevel.BLOCKER)
	public void Sign_in_Without_Password(String channel) {

		String strEmail = Utilities.getNewEmailID();
		

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + strEmail + "&password=" + "&nuDataChannel=" + channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");
		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter password");
			if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
	
	
	@Test(groups = {"signin_nudata","wallet_auth_GR"}, enabled = true, priority = 1,dataProvider = "channel", testName = "Sign In Profile",
			//dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify  user is able to signin with lockedaccount with nudata")
	@Severity(SeverityLevel.BLOCKER)
	public void Sign_in_with_locked_account(String channel){

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("LOCKED_ACCOUNT") + "&password=" + testData.get("PASSWORD_REMEDY") + "&nuDataChannel=" + channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");
		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrorsforremedy(strResponse,"PROF9100", "To sign in to your account, please reset your password using the Forgot password? link.");

				if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
	
	
	@Test(groups = {"signin_nudata","wallet_auth_GR"}, enabled = true, priority = 1,dataProvider = "channel", testName = "Sign In Profile",
			//dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile",
			description = "Verify  user is able to signin with disabledaccount with nudata")
	@Severity(SeverityLevel.BLOCKER)
	public void Sign_in_with_disabled_account(String channel){

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("DISABLED_ACCOUNT") + "&password=" + testData.get("PASSWORD_REMEDY") + "&nuDataChannel=" + channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");
		// Post the request
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrorsforremedy(strResponse,"PROF9999", "For your security, your account has been disabled. Please call us at (888) 890-1755 for next steps.");

			if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

		}
	}
	
	
	@Test(groups = {"signin_nudata"}, enabled = true,dataProvider = "channel", priority = 1, testName = "Sign In Profile",
			description = "Verify  user is able to signin with remedyaccount with nudata")
	public void Signin_with_remedy_account(String channel) {

		// Create the Json Request for Sign In
		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("REMEDY_ACCOUNT") + "&password=" + testData.get("PASSWORD_REMEDY")+ "&nuDataSessionId=" + testData.get("Nudata_sessionid") + "&nuDataChannel=" + channel + "&nuDataNdpdData=" + testData.get("ADAPTER_NDPD_DATA");
		// Post the request

		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrorsforremedy(strResponse,"PROF8000", "Remedy Challenge Required.");
		validator.nodeEquals("$.errors[0].remedyChallenge.remedyType","captcha","Remedy type should be displayed as captcha in the response");
		validator.nodeMatches("$.errors[0].remedyChallenge.ndpdData",".*","ndpdData should be returned in response");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
		}
	}			
}
