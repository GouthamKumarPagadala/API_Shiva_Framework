package test.java.adapters.authentication;

public class Token {
	// need to check how to revoke token with others.
}