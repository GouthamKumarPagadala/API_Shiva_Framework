package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_BILL_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_BILL_ADDRESS_OAPI;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("Profile")
@Stories({ "Update Ship Address" })

public class UpdateShipAddress {

	ResponseValidator validator;
	String strUpdateProfEmailAdapter;
	String strUpdateProfEmailOAPI;
	String strUpdateProfPaswd = "Ship@123";

	@BeforeClass(alwaysRun = true)
	public void testSetup() {

		strUpdateProfEmailAdapter = Utilities.getNewEmailID();
		strUpdateProfEmailOAPI = Utilities.getNewEmailID();
		Utilities.createProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter);
		Utilities.createProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter, "access_token_updShipAddrs_adapter");
		Utilities.signInProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi, "access_token_updBillAddrs_oapi");

	}

	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Invalid Action Tag", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Update Shipping Address with invalid action tag")
	public void ActionTagHavingWrongValue() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"false\",\"action\":\"WRONGVALUE\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for action.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address empty first name", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Update Shipping Address with empty first name")
	public void EmptyFirstName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("EMPTY_FN_NEW")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 3, testName = "Update Shipping Address Single Char FN", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with single character first name")
	public void FirstNameSingleChar() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("FN_SINGLE_CHAR")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
	

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Numeric FN", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with numeric first name")
	public void FirstNameWithNumericData() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("FN_NUMERIC_NEW")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Invalid Phone Number", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with invalid phone number")
	public void InvalidPhoneNoFormat() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("PHONE_NOFORMAT")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Phone Number.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Invalid City", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with alpha numeric value for city")
	public void AlphanumericValueForCity() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("ALPHANUMERIC_CITY")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for City.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Zip Spans Multi Counties", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with postal code spans over multiple counties")
	public void PostalCodeSpansAccrossMultipleCounties() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("MULTI_COUNTRY_SHIPADDR")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF2001", "Your ZIP code spans across multiple counties.  Please provide a valid county.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address WrongIDValueWithUpdateAction", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with WrongIDValue With UpdateAction")
	public void WrongIDValueWithUpdateAction() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("WROND_ID")
				+ ",\"preferredAddr\":\"false\",\"action\":\"update\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for ID.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address InvalidPhoneGreaterThan10Digit", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with InvalidPhone Greater Than 10 Digit")
	public void InvalidPhoneGreaterThan10Digit() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("INVALID_PHONENUM")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Phone Number.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 3, testName = "Update Shipping Address WrongPreferredAddress", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with WrongPreferredAddress")
	public void WrongPreferredAddress() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"WRONG\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// validator.validateExpectedErrors("PROF2001", "Your ZIP Code spans across multiple counties. Please provide a valid county.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Empty PreferredAddress", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with Empty Preferred Address")
	public void EmptyPreferredAddress() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("UPDATE")
				+ ",\"preferredAddr\":\"\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		 validator.validateExpectedErrors("PROF1000", "Missing Required Parameter preferredAddress.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Shipping Address Empty CITY", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating ship address with Empty CITY")
	public void EmptyCity() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
				+ JsonString.getBillAddressJson("EMPTY_CITY")
				+ ",\"preferredAddr\":\"false\",\"action\":\"add\"}}}}";
		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter City.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Single Character FN",
			description = "Kohls application user wants  to update the ship address with single character Fn")
	@TestCaseId("Update_Ship_Address_01")
	public void SingleCharacterFN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SINGLE_CHAR_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Single Character LN",
			description = "Kohls application user wants  to update the ship address with single character LN")
	@TestCaseId("Update_Ship_Address_02")
	public void SingleCharacterLN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SINGLE_CHAR_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Single Character FN & LN",
			description = "Kohls application user wants  to update the ship address with single character FN & LN")
	@TestCaseId("Update_Ship_Address_03")
	public void SingleCharacterFN_LN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Space As FN",
			description = "Kohls application user wants  to update the ship address with space as FN")
	@TestCaseId("Update_Ship_Address_04")
	public void SpaceAsFN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Space As LN",
			description = "Kohls application user wants  to update the ship address with space as LN")
	@TestCaseId("Update_Ship_Address_05")
	public void SpaceAsLN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Space as both FN & LN",
			description = "Kohls application user wants  to update the ship address with space as both FN & LN")
	@TestCaseId("Update_Ship_Address_06")
	public void SpaceAsBothFN_LN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With  Special Character FN",
			description = "Kohls application user wants  to update the ship address with special character FN")
	@TestCaseId("Update_Ship_Address_07")
	public void  SpecialCharacterFN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Special Character LN",
			description = "Kohls application user wants  to update the ship address with Special character LN")
	@TestCaseId("Update_Ship_Address_08")
	public void SpecialCharacterLN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With Special Character For both FN &LN",
			description = "Kohls application user wants  to update the ship address with special character for both FN & LN")
	@TestCaseId("Update_Ship_Address_09")
	public void SpecialCharacterForBothFN_LN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With  FN starting with Space & LN",
			description = "Kohls application user wants  to update the ship address with FN starting with space & LN")
	@TestCaseId("Update_Ship_Address_10")
	public void FNStartingWithSpace() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With FN & LN starting with Space",
			description = "Kohls application user wants  to update the ship address with FN  & LN starting with space")
	@TestCaseId("Update_Ship_Address_11")
	public void LNStartingWithSpace() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateShipAddress_With both FN & LN starting with Space ",
			description = "Kohls application user wants  to update the ship address with both FN  & LN starting with space")
	@TestCaseId("Update_Ship_Address_12")
	public void bothFN_LNStartingWithSpace () {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updShipAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}