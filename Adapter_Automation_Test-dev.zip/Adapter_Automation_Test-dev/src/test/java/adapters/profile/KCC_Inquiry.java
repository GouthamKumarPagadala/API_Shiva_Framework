package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.KCC_INQUIRY;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;
import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import main.java.common.TestData;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "KCC Inquiry" })


public class KCC_Inquiry {
	
	
	ResponseValidator validator;
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Valid Profile and email ID")
	public void KCC_InquiryValid() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "}"
						+ ",\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+ ""+"\"dob\":\""+testData.get("PREQUAL_DOB")+"T00:00:000Z\",\"email\":\"" 
						+ testData.get("PREQUAL_EMAIL") + "\"}}";
			
				String strURL=KCC_INQUIRY;		
		strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.preQualStatus","true|false","preQualStatus of KCC should be displayed based on eligibility");
		validator.nodeMatches("$.payload.adverseActionReason",".+","adverseActionReason should be displayed ");
		validator.nodeMatches("$.payload.preQualifyId",".+","preQualifyId should be displayed if user is qualified for KCC");
		validator.nodeMatches("$.payload.percentageDiscount",".+","percentageDiscount should be displayed if user is quallified for KCC");
		validator.nodeMatches("$.payload.offerExpirationDate",".+","offerExpirationDate should be displayed");
		validator.nodeMatches("$.payload.oneTimeCode",".+","One time code linked to the offer should be displayed");
	}
	
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Valid Profile and email ID")
	public void KCC_InquiryValid_Positive() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "}"
						+ ",\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+ ""+"\"dob\":\""+testData.get("PREQUAL_DOB")+"T00:00:000Z\",\"email\":\"" 
						+ testData.get("PREQUAL_EMAIL") + "\"}}";
			
				String strURL=KCC_INQUIRY;		
		strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.preQualStatus","true","preQualStatus of KCC should be displayed based on eligibility");
		validator.nodeMatches("$.payload.adverseActionReason",".+","adverseActionReason should be displayed ");
		validator.nodeMatches("$.payload.preQualifyId",".+","preQualifyId should be displayed if user is qualified for KCC");
		validator.nodeMatches("$.payload.percentageDiscount",".+","percentageDiscount should be displayed if user is quallified for KCC");
		validator.nodeMatches("$.payload.offerExpirationDate",".+","offerExpirationDate should be displayed");
		validator.nodeMatches("$.payload.oneTimeCode",".+","One time code linked to the offer should be displayed");
	}
	
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Invalid Json")
	public void KCC_InquiryWithInvalidJson() {

		// Create the Json Request for create profile
				String strPayload = "{\"user\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")
						+ "\","+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR2700","Invalid JSON: Unrecognized field user");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry Without Firstname and check whether proper error message is getting displayed")
	public void KCC_InquiryWithoutFirstName() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("MISSING_FIRSTNAME_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "},"
								+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
								+ ""+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter First Name.");
		
	}
			
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Empty address and check whether proper error message is getting displayed")
	public void KCC_InquiryWithEmptyAddress1() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("EMPTY_ADDR1") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")
						+ "\","+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter Address 1.");
		
	}
			
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Empty value for city and check whether proper error message is getting displayed")
	public void KCC_InquiryWithEmptyCity() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + 
						","+"\"address\":{" +  JsonString.getKCCValidationAddressJson("EMPTY_CITY") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter City.");
	
	}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Empty value for country and check whether proper error message is getting displayed")
	public void KCC_InquiryWithEmptyCountry() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("EMPTY_COUNTRY") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter Country.");
	
	}
	
		@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With Empty value for state and check whether proper error message is getting displayed")
	public void KCC_InquiryWithEmptyState() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("EMPTY_STATE") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter State.");
	
	}
		
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and email ID", 
			description = "KCC Inquiry With empty value for postalCode and check whether proper error message is getting displayed")
	public void KCC_InquiryWithEmptyPostalCode() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("EMPTY_POSTALCODE") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+"\"dob\":\"1959\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		
		validator.validateExpectedErrors("PREQUAL1000","Missing required parameter Postal Code.");
		
			}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and without date of birth", 
			description = "KCC Inquiry Without dob and check whether proper error message is getting displayed")
	public void KCC_InquiryWithoutDob() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+"\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter Dob.");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and with Invalid date of birth", 
			description = "KCC Inquiry With Invalid value for dob and check whether proper error message is getting displayed")
	public void KCC_InquiryWithInvalidDob() {

		// Create the Json Request for create profile
		String strPayload = "{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID_KC") + ","
				+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "},"
				+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
				+"\"dob\":\"****\",\"email\":\"" + testData.get("PREQUAL_EMAIL") + "\"}}";
		String strURL=KCC_INQUIRY;
		strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1002","Invalid value passed for Dob.");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and without Email", 
			description = "KCC Inquiry Without email and check whether proper error message is getting displayed")
	public void KCC_InquiryWithoutEmail() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","
						+"\"address\":{" +  JsonString.getKCCValidationAddressJson("VALID") + "},"
						+ "\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
						+"\"dob\":\"2010-12-12T00:00:000Z\" }";

				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter Email.");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and with Invalid Email", 
			description = "KCC Inquiry With invalid email and check whether proper error message is getting displayed")
	public void KCC_InquiryWithInvalidEmail() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","+"\"address\":{" 
						+  JsonString.getKCCValidationAddressJson("VALID") +"},"+
						"\"ssn\":\""+testData.get("PREQUAL_SSN")+"\","
								+ "\"dob\":\"2010-12-12T00:00:000Z\""
								+ ",\"email\":\"45546\"}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1002","Invalid value passed for Email.");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and with Invalid Email", 
			description = "KCC Inquiry With invalid email and check whether proper error message is getting displayed")
	public void KCC_InquiryWithInvalidSsn() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","+"\"address\":{" 
						+  JsonString.getKCCValidationAddressJson("VALID") +"},"+
							"\"ssn\":\"1hj3432\","
								+ "\"dob\":\"2010-12-12T00:00:000Z\""
								+ ",\"email\":\""+testData.get("PREQUAL_EMAIL")+"\"}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1002","Invalid value passed for ssn.");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and with Invalid Email", 
			description = "KCC Inquiry With invalid email and check whether proper error message is getting displayed")
	public void KCC_InquiryWithSsnLessThan4Digit() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","+"\"address\":{" 
						+  JsonString.getKCCValidationAddressJson("VALID") +"},"+
							"\"ssn\":\"432\","
								+ "\"dob\":\"2010-12-12T00:00:000Z\""
								+ ",\"email\":\""+testData.get("PREQUAL_EMAIL")+"\"}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1002","Invalid value passed for ssn.");
		}
	
	@Test(groups = { "KCCInquiry-NAP231","Prequal" }, enabled = true, testName = "KCC Inquiry With Valid Profile and with Invalid Email", 
			description = "KCC Inquiry With invalid email and check whether proper error message is getting displayed")
	public void KCC_InquiryWithSsnMoreThan9Digit() {

		// Create the Json Request for create profile
				String strPayload = "{\"customerName\":"
						+ JsonString.getCustomerNameJson("VALID_KC") + ","+"\"address\":{" 
						+  JsonString.getKCCValidationAddressJson("VALID") +"},"+
							"\"ssn\":\"525855655555255\","
								+ "\"dob\":\"2010-12-12T00:00:000Z\""
								+ ",\"email\":\""+testData.get("PREQUAL_EMAIL")+"\"}";
				String strURL=KCC_INQUIRY;
				strURL = Utilities.changeURL(strURL);
		// Post the request
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, false,null,200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1002","Invalid value passed for ssn.");
		}
}
