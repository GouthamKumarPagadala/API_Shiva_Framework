package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_SHIPPING_ADDRESS_OAPI;
import static main.java.common.TestData.testData;

import java.util.HashMap;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Delete Ship Address" })
public class DeleteShipAddress {

	public static HashMap<String, String> mapheader = new HashMap<String, String>();

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Shipping Address with InvalidShipId and validAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Deleting a non-prefered shipping address with invalid shipId and valid Access token")
	public void InvalidShipId() {

		String strURL = PROFILE_SHIPPING_ADDRESS_ADAPTER + "/12321njjkjsd";
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for shipAddressId.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_SHIPPING_ADDRESS_OAPI + "/12321njjkjsd";
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, 400);
			// String strResponseBazaarVoice = "{\"payload\":" +strResponseOAPI +"}";

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Shipping Address with InvalidShipId and validAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Deleting a non-prefered shipping address with shipId and Invalid Access token")
	public void InvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");
		String strURL = PROFILE_SHIPPING_ADDRESS_ADAPTER + "/" + testData.get("shipping_id_adapter");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_SHIPPING_ADDRESS_OAPI + "/" + testData.get("shipping_id_oapi");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);
			// String strResponseBazaarVoice = "{\"payload\":" +strResponseOAPI +"}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Shipping Address with InvalidShipId and validAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Deleting a non-prefered shipping address with shipId and Invalid Access token")
	public void withoutAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");
		String strURL = PROFILE_SHIPPING_ADDRESS_ADAPTER + "/" + testData.get("shipping_id_adapter");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_SHIPPING_ADDRESS_OAPI + "/" + testData.get("shipping_id_oapi");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, false, 401);
			// String strResponseBazaarVoice = "{\"payload\":" +strResponseOAPI +"}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Shipping Address with InvalidShipId and validAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateShipAddressNonPreferred",
			description = "Deleting a non-prefered shipping address with shipId and expired Access token")
	public void WithExpiredToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		String strURL = PROFILE_SHIPPING_ADDRESS_ADAPTER + "/" + testData.get("shipping_id_adapter");
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_SHIPPING_ADDRESS_OAPI + "/" + testData.get("shipping_id_oapi");
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, false, mapheader, 401);
			// String strResponseBazaarVoice = "{\"payload\":" +strResponseOAPI +"}";

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}
	}

}