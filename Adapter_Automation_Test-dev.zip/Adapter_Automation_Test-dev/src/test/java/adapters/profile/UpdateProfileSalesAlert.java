package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_INFO_OAPI;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.model.SeverityLevel;
import test.java.adapters.Config;

@Features("Profile")
@Stories({ "Update Profile SalesAlert" })

public class UpdateProfileSalesAlert {

	ResponseValidator validator;



	@Test(groups = { "sales_alert", "regression","functional" }, enabled = true, priority = 5, testName = "SalesAlertFalse", dependsOnMethods = "test.java.adapters.authentication.SignIn_SalesAlert.SalesAlertTrue",

	description = "SalesAlertFalse")
	public void SalesAlertFalse() { 

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("UPDATE")
				+ ",\"preferences\":{\"saleAlerts\":false}}}}";

		System.out.println(testData.get("access_token_sales_alert"));
		mapheader.clear();
		// mapheader.put("access_token",testData.get("access_token_sales_alert1"));
		mapheader.put("access_token", testData.get("access_token_sales_alert"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {

			mapheader.clear();
		
			mapheader.put("access_token", testData.get("access_token_sales_alert_oapi"));
		//	System.out.println(mapheader);
			
			System.out.println(testData.get("access_token_sales_alert_oapi"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "sales_alert", "regression","functional" }, enabled = true, priority = 5, testName = "SalesAlertTrue", dependsOnMethods = "test.java.adapters.authentication.SignIn_SalesAlert.SalesAlertFalse",

	description = "SalesAlertTrue")
	public void SalesAlertTrue() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("UPDATE")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";

	//	System.out.println(testData.get("access_token_sales_alert1"));
		mapheader.clear();
		// mapheader.put("access_token",testData.get("access_token_sales_alert1"));
		mapheader.put("access_token", testData.get("access_token_sales_alert1"));
		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {

			mapheader.clear();
			// System.out.println(testData.get("access_token_sales_alert_oapi1"));
			mapheader.put("access_token", testData.get("access_token_sales_alert_oapi1"));
			
			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("UPDATE")
					+ ",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

}
