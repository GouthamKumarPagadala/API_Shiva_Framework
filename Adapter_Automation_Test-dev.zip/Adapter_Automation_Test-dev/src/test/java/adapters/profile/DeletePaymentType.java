package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_OAPI;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;
import org.testng.annotations.Test;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Delete Payment type" })

public class DeletePaymentType {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Payment details with invalid payment id", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdatePaymentType",
			description = "Deleting Payment type with invalid payment id ")
	public void WithInvalidPaymentId() {

		// String strURL=PROFILE_PAYMENT_ADAPTER+"/"+testData.get("adapter_payment_id");
		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + "789631145";
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for PaymentType ID.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			// String strURLOAPI=PROFILE_PAYMENT_OAPI+"/"+testData.get("openAPI_payment_id");
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + "12365447895";
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Payment details WithInvalidAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdatePaymentType",
			description = "Deleting Payment type with Invalid Access token")
	public void WithInvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");
		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + testData.get("adapter_payment_id_delete");
		// String strURL=PROFILE_PAYMENT_ADAPTER+"/"+"yfguykhv4h5v";
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "ASFDKJ14623H");
			
			// Get the request
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + testData.get("openAPI_payment_id_delete");
			// String strURLOAPI=PROFILE_PAYMENT_OAPI+"/"+"hdgfdsft546";
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errors,errors.code,errorCode,error,errors.entity", true);
		}

	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Payment details ExpiredAccessToken",
			description = "Deleting Payment type with expired AccessToken")
	public void WithExpiredAccessToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + testData.get("adapter_payment_id");
		// String strURL=PROFILE_PAYMENT_ADAPTER+"/"+"yfguykhv4h5v";
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + testData.get("openAPI_payment_id");
			// String strURLOAPI=PROFILE_PAYMENT_OAPI+"/"+"hdgfdsft546";
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}

	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Payment details with WithNonUMERICPaymentId", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdatePaymentType",
			description = "Deleting Payment type with non-numeric PaymentId ")
	public void WithNonNumericPaymentId() {

		// String strURL=PROFILE_PAYMENT_ADAPTER+"/"+testData.get("adapter_payment_id");
		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + "yfguyhjvhjvhj";
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for PaymentType ID.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			// String strURLOAPI=PROFILE_PAYMENT_OAPI+"/"+testData.get("openAPI_payment_id");
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + "hdgfdsftfgjh";
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 7, testName = "Delete Payment details WithoutAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdatePaymentType",
			description = "Deleting Payment type without AccessToken.")
	public void WithoutAccessToken() {

		mapheader.put("access_token", "");
		String strURL = PROFILE_PAYMENT_ADAPTER + "/" + testData.get("adapter_payment_id");
		// String strURL=PROFILE_PAYMENT_ADAPTER+"/"+"yfguykhv4h5v";
		// Post the request
		String strResponse = RestCall.deleteRequest(strURL, Server.Adapter, false, mapheader, 200);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = PROFILE_PAYMENT_OAPI + "/" + testData.get("openAPI_payment_id");
			// String strURLOAPI=PROFILE_PAYMENT_OAPI+"/"+"hdgfdsft546";
			String strResponseOAPI = RestCall.deleteRequest(strURLOAPI, Server.OpenApi, false, mapheader, 401);

			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI,"errorCode,error,errors.entity", true);
		}

	}

}