package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_BILL_ADDRESS_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_BILL_ADDRESS_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("Profile")
@Stories({ "Update Bill Address" })
public class updateBillAddress {

	ResponseValidator validator;

	String strUpdateProfEmailAdapter;
	String strUpdateProfEmailOAPI;
	String strUpdateProfPaswd = "Bill@123";

	@BeforeClass(alwaysRun = true)
	public void testSetup() {

		strUpdateProfEmailAdapter = Utilities.getNewEmailID();
		strUpdateProfEmailOAPI = Utilities.getNewEmailID();
		Utilities.createProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter);
		Utilities.createProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter, "access_token_updBillAddrs_adapter");
		Utilities.signInProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi, "access_token_updBillAddrs_oapi");

	}

	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Bill Adress FirstNameFieldAsEmpty", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating bill address with invalid first name to the profile")
	public void FirstNameFieldAsEmpty() {

		// testData.put("INVALID_BILLING_FIRSTNAME", "");

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("INVALID_FIRSTNAME")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter First Name.");
		// validator.validateNoErrors();
		// validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Bill Adress LastNameFieldAsEmpty", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating bill address with blank lastname")
	public void LastNameFieldAsEmpty() {

		// testData.put("INVALID_BILLING_LASTNAME", "");

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("INVALID_LASTNAME")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Last Name.");
		// validator.validateNoErrors();
		// validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Bill Adress LastNameAlphanumeric", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating bill address with Last Name Alphanumeric to the profile")
	public void LastNameAlphanumeric() {

		testData.put("BILLING_LASTNAME_ALPHANUMERIC", "HGFV4535");

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("LASTNAME_ALPHANUMERIC")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");
		// validator.validateNoErrors();
		// validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Bill Adress EmptyFields", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating bill address with Empty Fields to the profile")

	public void EmptyFields() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("EMPTY_FIELDS")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		 validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Address.");
		// validator.validateNoErrors();
		// validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Bill Adress Invalid Phoneno", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating bill address with Invalid Phone number to the profile")
	public void InvalidPhoneno() {

		testData.put("INVALID_PHONENO", "HGFV4535");

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("INVALID_PHONENO")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Phone Number.");
		// validator.validateNoErrors();
		// validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);

		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Bill Adress SpanPostalcode", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating bill address with Span Postalcode to the profile")
	public void SpanPostalcode() {

		testData.put("SPAN_POSTALCODE", "60601");

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPAN_POSTALCODE")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		System.out.println("Your ZIP Code spans across multiple counties.  Please provide a valid county.");
		validator.validateExpectedErrors("PROF2001", "Your ZIP Code spans across multiple counties.  Please provide a valid county.");

		// validator.validateNoErrors();
		// validator.validateProfileUpadteMessage();
		// validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
		// Compare Open API
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);

		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Single Character FN",
			description = "Kohls application user wants  to update the bill address with single character Fn")
	@TestCaseId("Update_Bill_Address_01")
	public void SingleCharacterFN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SINGLE_CHAR_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Single Character LN",
			description = "Kohls application user wants  to update the bill address with single character LN")
	@TestCaseId("Update_Bill_Address_02")
	public void SingleCharacterLN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SINGLE_CHAR_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Single Character FN & LN",
			description = "Kohls application user wants  to update the bill address with single character FN & LN")
	@TestCaseId("Update_Bill_Address_03")
	public void SingleCharacterFN_LN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SINGLE_CHAR_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Space As FN",
			description = "Kohls application user wants  to update the bill address with space as FN")
	@TestCaseId("Update_Bill_Address_04")
	public void SpaceAsFN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Space As LN",
			description = "Kohls application user wants  to update the bill address with space as LN")
	@TestCaseId("Update_Bill_Address_05")
	public void SpaceAsLN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Space as both FN & LN",
			description = "Kohls application user wants  to update the bill address with space as both FN & LN")
	@TestCaseId("Update_Bill_Address_06")
	public void SpaceAsBothFN_LN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With  Special Character FN",
			description = "Kohls application user wants  to update the bill address with special character FN")
	@TestCaseId("Update_Bill_Address_07")
	public void  SpecialCharacterFN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Special Character LN",
			description = "Kohls application user wants  to update the bill address with Special character LN")
	@TestCaseId("Update_Bill_Address_08")
	public void SpecialCharacterLN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPECIAL_CHAR_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With Special Character For both FN &LN",
			description = "Kohls application user wants  to update the bill address with special character for both FN & LN")
	@TestCaseId("Update_Bill_Address_09")
	public void SpecialCharacterForBothFN_LN() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPECIAL_CHAR_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With  FN starting with Space & LN",
			description = "Kohls application user wants  to update the bill address with FN starting with space & LN")
	@TestCaseId("Update_Bill_Address_10")
	public void FNStartingWithSpace() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With FN & LN starting with Space",
			description = "Kohls application user wants  to update the bill address with FN  & LN starting with space")
	@TestCaseId("Update_Bill_Address_11")
	public void LNStartingWithSpace() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 2, testName = "updateBillAddress_With both FN & LN starting with Space ",
			description = "Kohls application user wants  to update the bill address with both FN  & LN starting with space")
	@TestCaseId("Update_Bill_Address_12")
	public void bothFN_LNStartingWithSpace () {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"billAddress\":"
				+ JsonString.getBillAddressJson("SPACE_SINGLE_CHAR_FNAME_LNAME")
				+ "}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updBillAddrs_adapter"));

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_BILL_ADDRESS_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		// Compare Open API
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updBillAddrs_oapi")); 
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_BILL_ADDRESS_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}