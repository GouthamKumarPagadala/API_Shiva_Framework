package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_INFO_OAPI;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Profile")
@Stories({ "Update Profile Info" })
public class UpdateProfileInfo {

	ResponseValidator validator;
	
	String strUpdateProfEmailAdapter;
	String strUpdateProfEmailOAPI;
	String strUpdateProfPaswd = "Updprof@123";

	@BeforeClass(alwaysRun = true)
	public void testSetup() {

		strUpdateProfEmailAdapter = Utilities.getNewEmailID();
		strUpdateProfEmailOAPI = Utilities.getNewEmailID();
		Utilities.createProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter);
		Utilities.createProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter, "access_token_updProf_adapter");
		Utilities.signInProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi, "access_token_updProf_oapi");

	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without firstname parameter")
	public void MissingFirstName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("MISSING_FIRSTNAME")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without lastname parameter")
	public void MissingLastName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("MISSING_LASTNAME")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Last Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without firstname value")
	public void MissingValueFirstName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("MISSING_FIRSTNAME_VALUE")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without lastname value")
	public void MissingValueLastName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("MISSING_LASTNAME_VALUE")
				+ "}}}";

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Last Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 4, testName = "Get Profile", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.UpdateProfileInfo",
			description = "Get Profile after updating the customer details")
	public void getProfileRetrieveandVerify() {

		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
		Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		System.out.println("Author Id" + testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		// validator.nodeEquals("$.payload.profile.email", testData.get("ADAPTER_EMAIL_ID"), "Profile email should be present");
		validator.nodeMatches("$.payload.wallet.timestamp", ".+", "TimeStamp should be available in response");
		validator.nodeMatches("$.payload.wallet.hash", ".+", "Hash should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.lastName", ".+", "LastName should be available in response");
		validator.nodeMatches("$.payload.profile.customerName.firstName", ".+", "FirstName should be available in response");
		validator.nodeMatches("$.payload.profile.id", ".+", "Profile Id should be available in response");
		validator.nodeMatches("$.payload.profile.updatePaymentId", ".+", "UpdatePayment ID should be available in response");
		validator.nodeMatches("$.payload.profile.updateShipAddressId", ".+", "UpdateShipAddressID should be available in response");
		validator.nodeMatches("$.payload.profile.loyaltyPostalCode", ".+", "loyaltyPostalCode should be available in response");
		validator.nodeMatches("$.payload.profile.loyaltyId", ".+", "loyaltyId should be available in response");
		validator.nodeMatches("$.payload.profile.preferences", ".+", "preferences should be available in response");
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", ".+", "saleAlerts should be available in response");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true);
			Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods="getProfileRetrieveandVerify",
			description = "Updating profile information with new password")
	public void WithNewPassword() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("UPDATE_PASSWORD")
				+ "}}}";
		
		//testData.put("ADAPTER_EMAIL_PSWD", testData.get("NEW_PASSWORD"));

		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			// Post the request
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_updProf_oapi"));
			
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true,mapheader);
			
			//testData.put("OAPI_EMAIL_PSWD", testData.get("NEW_PASSWORD"));
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "WithNewPassword",
			description = "Signs in to the profile with new password updated")
	@Severity(SeverityLevel.BLOCKER)
	public void signInProfileWithNewUpdatedPassword() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + strUpdateProfEmailAdapter + "&password=" + "Update@123";

		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false,mapheader);
		//Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter");
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + strUpdateProfEmailOAPI + "&password=" + "Update@123";			// Post the request
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_updProf_oapi"));
			
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false,mapheader);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_oapi");
			
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "signInProfileWithNewUpdatedPassword",
			description = "Updating profile information with old password")
	public void WithOldPassword() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("UPDATE_OLD_PASSWORD")
				+ ",\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD")
				+ "\"}}}";
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_adapter"));
		
		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9500","Old and current passwords can't be reused. Please create a new password.");
		

		if (CompareOAPI) {

			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("UPDATE_OLD_PASSWORD")
					+ ",\"password\":\"" + testData.get("OAPI_EMAIL_PSWD")
					+ "\"}}}";
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayloadOAPI, Server.OpenApi, true);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 1, testName = "Sign In Profile",
			dependsOnMethods = "WithOldPassword",
			description = "Signs in to the profile again with old password")
	@Severity(SeverityLevel.BLOCKER)
	public void WithOldUpdatedPassword() {

		// Create the Json Request for Sign In
		String strPayload = "grant_type=password&userId=" + testData.get("ADAPTER_EMAIL_ID") + "&password=" + testData.get("ADAPTER_EMAIL_PSWD");

		// Post the request
		String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" + testData.get("OAPI_EMAIL_ID") + "&password=" + testData.get("OAPI_EMAIL_PSWD");
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_singleCharater FN",
			description = "Kohls Application user has the profile and has the ability to update the profile with single character FN")
	@TestCaseId("UpdateProfile_01")
	public void singleCharater_FN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_singleCharater LN",
			description = "Kohls Application user has the profile and has the ability to update the profile with single character LN")
	@TestCaseId("UpdateProfile_02")
	public void singleCharater_LN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_singleCharater FN & LN",
			description = "Kohls Application user has the profile and has the ability to update the profile with single character Fn & LN")
	@TestCaseId("UpdateProfile_03")
	public void singleCharater_FN_LN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_space as FN & with LN",
			description = "Kohls Application user has the profile and has the ability to update the profile with space as FN & with LN")
	@TestCaseId("UpdateProfile_04")
	public void spaceInFN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_FNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_space as LN & with FN",
			description = "Kohls Application user has the profile and has the ability to update the profile with space as LN & with FN")
	@TestCaseId("UpdateProfile_05")
	public void spaceInLN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_space as both FN & LN",
			description = "Kohls Application user has the profile and has the ability to update the profile with space as both FN & LN")
	@TestCaseId("UpdateProfile_06")
	public void spaceInFN_LN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_FNAME_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader, 400);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_special character FN & valid LN",
			description = "Kohls Application user has the profile and has the ability to update the profile with special character FN and valid LN")
	@TestCaseId("UpdateProfile_07")
	public void specialCharacterFN_Valid_LN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_special character LN & valid FN",
			description = "Kohls Application user has the profile and has the ability to update the profile with special character LN and valid FN")
	@TestCaseId("UpdateProfile_08")
	public void specialCharacter_LN_Valid_FN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_both special character LN & FN",
			description = "Kohls Application user has the profile and has the ability to update the profile with both special character LN and FN")
	@TestCaseId("UpdateProfile_09")
	public void bothSpecialCharacter_LN_FN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_ FN starting with space and valid LN",
			description = "Kohls Application user has the profile and has the ability to update the profile with FN starting with space and valid LN")
	@TestCaseId("UpdateProfile_10")
	public void FN_Starting_withSpaceAndValid_LN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_with LN starting with space and valid FN",
			description = "Kohls Application user has the profile and has the ability to update the profile with LN starting with space and valid FN")
	@TestCaseId("UpdateProfile_11")
	public void LN_StartingWithSpaceAndValid_FN() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 5, testName = "UpdateProfile_both FN & LN starting with space",
			description = "Kohls Application user has the profile and has the ability to update the profile with both FN & LN starting with space")
	@TestCaseId("UpdateProfile_12")
	public void bothFN_LN_StartingWithSpace() {

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME_LNAME")
				+ ",\"preferences\":{\"saleAlerts\":true}}}}";
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));

		// Post the request
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true, mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}	
	@Test(groups = { "regression","functional" }, enabled = true, priority = 5, testName = "UpdateProfile_SignOutChangePasswordDiffChannel",
			description = "Kohls Application user has to get signout with expired access token when password is changed in different channel")
	@TestCaseId("UpdateProfile_13")
	public void SignOutChangePasswordDiffChannel() throws Exception {

		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Prof@123";
		Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
		
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_msm546_1");
		
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_msm546_2");
	
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_msm546_2"));
		
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
		
		validator = new ResponseValidator(strURL);
		validator.validateNoErrors();
		
		
		//testData.put("ADAPTER_EMAIL_PSWD", testData.get("NEW_PASSWORD"));
		
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_msm546_1"));
				
		String strURL1 = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
				
		validator = new ResponseValidator(strURL1);
		validator.validateNoErrors();
		
				
	// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
						+ JsonString.getCustomerNameJson("UPDATE_PASSWORD")
						+ "}}}";
		
	// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_msm546_2"));
				
		String strResponse1 = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
			
				// Validate Response
				validator = new ResponseValidator(strResponse1);
				validator.validateNoErrors();
				validator.validateProfileUpadteMessage();
				
				Thread.sleep(180000);
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_msm546_1"));
						
				String strURL2 = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
						
				validator = new ResponseValidator(strURL2);
				validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");
	}	
}