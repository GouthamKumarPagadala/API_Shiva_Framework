package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.TestData.testData;

import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Create Profile Sales Alert" })

public class CreateProfileSalesAlert {

	ResponseValidator validator;


	@BeforeClass(alwaysRun = true)
	public void testSetup() {

	}


	@Test(groups = { "sales_alert", "regression","functional" }, enabled = true, priority = 0, testName = "Create a profile with Sales Alert flag as true",
			description = "Create a profile with Sales Alert flag as true")
	public void SalesAlertTrue() {

		testData.put("ADAPTER_EMAIL_ID_SALE", Utilities.getNewEmailID());
		testData.put("ADAPTER_EMAIL_PSWD_SALE", "Ocb@1234");

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD_SALE") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_SALE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {
			testData.put("OAPI_EMAIL_ID_SALE", Utilities.getNewEmailID());
			testData.put("OAPI_EMAIL_PSWD_SALE", "Ocb@1234");

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD_SALE") + "\","
					+ "\"email\":\"" + testData.get("OAPI_EMAIL_ID_SALE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "sales_alert", "regression","functional" }, enabled = true, priority = 0, testName = "Create a profile with Sales Alert flag as false",
			description = "Create a profile with Sales Alert flag as false")
	public void SalesAlertFalse() {

		testData.put("ADAPTER_EMAIL_ID1_SALE", Utilities.getNewEmailID());
		testData.put("ADAPTER_EMAIL_PSWD1_SALE", "Ocb@1234");

		// Create the Json Request for create profile

		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD1_SALE") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID1_SALE") + "\",\"preferences\":{\"saleAlerts\":false}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			testData.put("OAPI_EMAIL_ID1_SALE", Utilities.getNewEmailID());
			testData.put("OAPI_EMAIL_PSWD1_SALE", "Ocb@1234");

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD1_SALE") + "\","
					+ "\"email\":\"" + testData.get("OAPI_EMAIL_ID1_SALE") + "\",\"preferences\":{\"saleAlerts\":false}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}
