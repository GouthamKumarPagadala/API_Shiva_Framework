package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.TestData.testData;

import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("Profile")
@Stories({ "Create Profile" })
public class CreateProfile {

	ResponseValidator validator;


	@BeforeClass(alwaysRun = true)
	public void testSetup() {

	}
	
	@BeforeMethod(alwaysRun = true)
	public void printTestName(Method method) {
		
		testData.put("ADAPTER_EMAIL_ID_PROFILE", Utilities.getNewEmailID());
		testData.put("ADAPTER_EMAIL_ID_PROFILE_OAPI", Utilities.getNewEmailID());
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 0, testName = "create Profile- Invalid Email",
			description = "Create a new profile with Invalid Email Id")
	public void InvalidEmail() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("INVALID_EMAIL_ID") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Email.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("INVALID_EMAIL_ID") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}

	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 0, testName = "create Profile- Pwd less than 5 digit",
			description = "Create a new profile with pwd less than 5 digit")
	public void PwsLT5Digit() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("PWD_LT_5_DIGIT") + ","
				+ "\"email\":\"" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9998", "the provided password does not meet the requirements.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("PWD_LT_5_DIGIT") + ","
					+ "\"email\":\"" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}

	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 0, testName = "create Profile- First Name Numeric",
			description = "Create a new profile with numeric first name.")
	public void NumericFirstName() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("FN_NUMERIC") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("FN_NUMERIC") + ","
					+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}

	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 0, testName = "create Profile- First Name GT 40 Characters",
			description = "Create a new profile with First name greater than 40 characters")
	public void FNGreaterThan40Char() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("FN_GREATER_THAN_40") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("FN_GREATER_THAN_40") + ","
					+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}

	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 0, testName = "create Profile- First Name GT 40 Characters",
			description = "Create a new profile with Last name greater than 40 characters")
	public void LNGreaterThan40Char() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("LN_GREATER_THAN_40") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("LN_GREATER_THAN_40") + ","
					+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}

	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 0, testName = "create Profile-Already Existing Email",
			description = "Create a new profile with already existing email ID",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.createProfile")
	public void AlreadyExistingEmail() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9163", "According to our system, there is already an account for the E-mail Address you entered. Please enter a different E-mail Address (Sign-in name).");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}

	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char $")
	public void DollarSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123$Qwerty\","
				+ "\"email\":\"Dollar" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123$Qwerty\","
					+ "\"email\":\"Dollar" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char %")
	public void PercentSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Qwe%rty\","
				+ "\"email\":\"Percent" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Qwe%rty\","
					+ "\"email\":\"Percent" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char ^")
	public void PowerSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q^qwerty\","
				+ "\"email\":\"Power" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q^qwerty\","
					+ "\"email\":\"Power" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char &")
	public void AmpersandSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q&qwerty\","
				+ "\"email\":\"Ampersand" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q&qwerty\","
					+ "\"email\":\"Ampersand" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char <")
	public void LessThanSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Qqwerty<\","
				+ "\"email\":\"LessThan" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Qqwerty<\","
					+ "\"email\":\"LessThan" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char *")
	public void StarSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q*qwerty\","
				+ "\"email\":\"Star" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q*qwerty\","
					+ "\"email\":\"Star" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char (")
	public void OpenBraceSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q(qwerty\","
				+ "\"email\":\"OpenBrace" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q(qwerty\","
					+ "\"email\":\"OpenBrace" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char ).")
	public void CloseBraceSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q)qwerty\","
				+ "\"email\":\"CloseBrace" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q)qwerty\","
					+ "\"email\":\"CloseBrace" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char #")
	public void SpaceSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q@qwe rty\","
				+ "\"email\":\"Space" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q@qwe rty\","
					+ "\"email\":\"Space" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char +")
	public void PlusSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Qqwe+rty\","
				+ "\"email\":\"Plus" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Qqwe+rty\","
					+ "\"email\":\"Plus" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char =")
	public void EqualToSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Qqwe=rty\","
				+ "\"email\":\"EqualTo" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Qqwe=rty\","
					+ "\"email\":\"EqualTo" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char -")
	public void MinusSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q-qwerty\","
				+ "\"email\":\"Minus" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q-qwerty\","
					+ "\"email\":\"Minus" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char ?")
	public void QuestionSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q?qwerty\","
				+ "\"email\":\"Question" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q?qwerty\","
					+ "\"email\":\"Question" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char >")
	public void GreaterThanSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Qqwe>rty\","
				+ "\"email\":\"GreaterThan" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Qqwe>rty\","
					+ "\"email\":\"GreaterThan" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char !")
	public void ExclamationSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123Q!qwerty\","
				+ "\"email\":\"Exclamation" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123Q!qwerty\","
					+ "\"email\":\"Exclamation" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special Character @")
	public void AtTheRateSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"123@Qwerty\","
				+ "\"email\":\"AtTheRate" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"123@Qwerty\","
					+ "\"email\":\"AtTheRate" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 0, testName = "create Profile",
			description = "Create a new profile, password prefix with special char #")
	public void HashSpecialCharacter() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"Qwe#rty1\","
				+ "\"email\":\"Hash" + testData.get("SPECIAL_CHAR_ADAPTER_EMAIL_ID") + "\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"Qwe#rty1\","
					+ "\"email\":\"Hash" + testData.get("SPECIAL_CHAR_OAPI_EMAIL_ID") + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSingleCharacterFN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, LN and single character FN")
	@TestCaseId("CP_01")
	public void SingleCharacterFN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSingleCharacterLN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, FN and single character LN")
	@TestCaseId("CP_02")
	public void SingleCharacterLN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SINGLE_CHAR_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSingleCharacterFN&LN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,single character FN & LN")
	@TestCaseId("CP_03")
	public void SingleCharacterFN_LN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSpaceAsFN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,space as FN & single character LN")
	@TestCaseId("CP_04")
	public void SpaceAsFN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_FNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPACE_FNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSpaceAsLN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,single character FN & space as LN")
	@TestCaseId("CP_05")
	public void SpaceAsLN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPACE_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);
//
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_SpaceAsBothFN&LN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,space as FN & LN")
	@TestCaseId("CP_06")
	public void SpaceAsBothFN_LN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_FNAME_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPACE_FNAME_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSpecialCharacterFN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,special character FN & single character LN")
	@TestCaseId("CP_07")
	public void SpecialCharacterFN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSpecialCharacterFN&LN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,special character LN & single character FN")
	@TestCaseId("CP_08")
	public void SpecialCharacterLN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPECIAL_CHAR_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithSpecialCharacterFN&LN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,special character FN & LN")
	@TestCaseId("CP_09")
	public void SpecialCharacterFN_LN() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithFNStartingWithSpace",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,FN starting with space & LN")
	@TestCaseId("CP_10")
	public void FNStartingWithSpace() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithLNStartingWithSpace",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,LN starting with space & FN")
	@TestCaseId("CP_11")
	public void LNStartingWithSpace() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	@Test(groups = { "regression","functional", "fmnp273" }, enabled = true, priority = 0, testName = "createProfile_WithBothFN&LNStartingWithSpace",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password,FN & LN both starting with space")
	@TestCaseId("CP_12")
	public void BothFN_LNStartingWithSpace() {

		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"password\":\"" + testData.get("ADAPTER_EMAIL_PSWD") + "\","
				+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
					+ "\"password\":\"" + testData.get("OAPI_EMAIL_PSWD") + "\","
					+ "\"email\":\"" + testData.get("ADAPTER_EMAIL_ID_PROFILE_OAPI") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
}