package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import java.util.HashMap;

import org.testng.annotations.Test;

import main.java.common.TestData;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Get Customer Profile Sales Alert" })

public class GetProfileSalesAlert {

	ResponseValidator validator;


	@Test(groups = { "sales_alert" }, enabled = true, priority = 4, testName = "Get Profile sales alert True", dependsOnMethods = "test.java.adapters.profile.UpdateProfileSalesAlert.SalesAlertTrue",
			description = "Get Profile Sales Alert True")
	public void SalesAlertTrue() {

		mapheader.put("access_token", testData.get("access_token_sales_alert1"));
		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
		// Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		// System.out.println("Author Id"+testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", "true", "saleAlerts should be available in response");
		// validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			mapheader.put("access_token", testData.get("access_token_sales_alert_oapi1"));
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 200);
			// Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
			// Utilities.compareAdaterOpenApiResponse(strURL, strURLOAPI,"errors.code,errorCode,error,errors.entity",true);
		}
	}


	@Test(groups = { "sales_alert" }, enabled = true, priority = 4, testName = "Get Profile sales alert False", dependsOnMethods = "test.java.adapters.profile.UpdateProfileSalesAlert.SalesAlertTrue",
			description = "Get Profile Sales alert False")
	public void SalesAlertFalse() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_sales_alert"));
		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
		// Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		// System.out.println("Author Id"+testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.nodeMatches("$.payload.profile.preferences.saleAlerts", "false", "saleAlerts should be available in response");
		// validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_sales_alert_oapi"));
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 200);
			// Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
			// Utilities.compareAdaterOpenApiResponse(strURL, strURLOAPI,"errors.code,errorCode,error,errors.entity",true);
		}
	}

}
