package test.java.adapters.profile.passwordChanges;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_INFO_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.lang.reflect.Method;

import org.apache.poi.util.SystemOutLogger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.interfaces.DiscontinuedTest;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("PasswordChanges")
@Stories({ "Update Password" })

public class UpdatePassword {
	String adapterEmail=null;
	String oAPIEmail=null;
	ResponseValidator validator;
	static String adapterPositivePass="YTRewq#1";
    static String oAPIPositivePass="YTRewq#1";
	static String adapterNegativePass="YTRewq#1";
	static String oAPINegativePass="YTRewq#1";
//	static String adapterPositivePass=testData.get("ADAPTER_PASSWORD_PC");
//    static String oAPIPositivePass=testData.get("ADAPTER_PASSWORD_PC");
//	static String adapterNegativePass=testData.get("OAPI_PASSWORD_PC");
//	static String oAPINegativePass=testData.get("OAPI_PASSWORD_PC");

	
	@BeforeClass(alwaysRun = true)
	public void testSetup() {

		
		adapterEmail = Utilities.getNewEmailID();
		oAPIEmail = Utilities.getNewEmailID();
		Utilities.createProfile(adapterEmail, testData.get("ADAPTER_PASSWORD_PC"), Server.Adapter);
		Utilities.createProfile(oAPIEmail, testData.get("OAPI_PASSWORD_PC"), Server.OpenApi);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
//		Utilities.signInProfile(adapterEmail, testData.get("ADAPTER_PASSWORD_PC"), Server.Adapter, "access_token_updProf_adapter");
//		Utilities.signInProfile(oAPIEmail, testData.get("OAPI_PASSWORD_PC"), Server.OpenApi, access_token_updProf_oapi");

	}


	@DiscontinuedTest(groups = { "password_changes", "regression"  }, enabled = true, priority = 0, testName = "create Profile- Invalid Email",
			description = "Update an existing profile with a valid password")
//			dataProvider = "data_keywords_update_pwd")
	public void updatePassWordPositive(String strScenario,String passwordAdapter,String passwordOAPI, String  passwordSignIn ) {
		Utilities.signInProfile(adapterEmail, Utilities.urlEncodeString(testData.get("ADAPTER_PASSWORD_PC")), Server.Adapter, "access_token_updProf_adapter");
		Utilities.signInProfile(oAPIEmail, Utilities.urlEncodeString(testData.get("OAPI_PASSWORD_PC")), Server.OpenApi, "access_token_updProf_oapi");
				String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
						+ "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"NewLastName" + testData.get("CUSTOMER_LASTNAME") + "\"}," + "\"password\":\"" + passwordAdapter + "\""
						+ "}}}";
				
				//testData.put("ADAPTER_EMAIL_PSWD", testData.get("NEW_PASSWORD"));

				// Post the request
				mapheader.clear();
				mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
				String strResponse = RestCall.putRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
				// Validate Response
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");

				if (CompareOAPI) {
					// Post the request
					mapheader.clear();
					mapheader.put("access_token", testData.get("access_token_updProf_oapi"));
					
					
					String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true,mapheader,400);
					
					//testData.put("OAPI_EMAIL_PSWD", testData.get("NEW_PASSWORD"));
					// Compare the result
					Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
				}
//				adapterPositivePass=passwordSignIn;
//				adapterPositivePass=passwordSignIn;
			}

	
	@Test(groups = { "password_changes", "regression" }, enabled = true, priority = 0, testName = "create Profile- Invalid Email",
			description = "Update an existing profile with an invalid password",
			dataProvider = "data_keywords_update_pwd_negative")
	public void updatePassWordNegative(String strScenario,String passwordAdapter,String passwordOAPI ) {
		Utilities.signInProfileV2(adapterEmail, testData.get("ADAPTER_PASSWORD_PC"), Server.Adapter, "access_token_updProf_adapter","walletId","walletToken");
		Utilities.signInProfileV2(oAPIEmail, testData.get("OAPI_PASSWORD_PC"), Server.OpenApi, "access_token_updProf_oapi","walletId","walletToken");

		String adapterStrPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"NewLastName" + testData.get("CUSTOMER_LASTNAME") + "\"}," + "\"password\":\"" + passwordAdapter + "\""
				+ "}}}";
		
		//testData.put("ADAPTER_EMAIL_PSWD", testData.get("NEW_PASSWORD"));

		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.putRequest(PROFILE_ADAPTER, adapterStrPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9998", "The provided password does not meet the requirements.");

		if (CompareOAPI) {
			// Post the request
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_updProf_oapi"));
			
			String oAPIStrPayload = "{\"payload\":{\"profile\":{\"customerName\":"
					+ "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"NewLastName" + testData.get("CUSTOMER_LASTNAME") + "\"}," + "\"password\":\"" + passwordOAPI + "\""
					+ "}}}";
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, oAPIStrPayload, Server.OpenApi, true,mapheader,400);
			
			//testData.put("OAPI_EMAIL_PSWD", testData.get("NEW_PASSWORD"));
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
		adapterPositivePass=passwordAdapter;
		adapterPositivePass=passwordOAPI;
	}	
	@DataProvider(name = "data_keywords_update_pwd")
	public Object[][] data_keywords_positive_testData() {
	return new Object[][] {

		{ "Update Pwd with # Symbol","Qwerty#1","Qwerty#1",Utilities.urlEncodeString("Qwerty#1")},
		{ "Update Pwd with ! Symbol","Qwerty!1","Qwerty!1",Utilities.urlEncodeString("Qwerty!1")},
		{ "Update Pwd with $ Symbol","Qwerty$1","Qwerty$1",Utilities.urlEncodeString("Qwerty$1")},
		{ "Update Pwd with % Symbol","Qwerty%251","Qwerty%251",Utilities.urlEncodeString("Qwerty%251")},
		{ "Update Pwd with ^ Symbol","Qwerty^1","Qwerty^1",Utilities.urlEncodeString("Qwerty^1")},
		{ "Update Pwd with & Symbol","Qwerty&1","Qwerty&1",Utilities.urlEncodeString("Qwerty&1")},
		{ "Update Pwd with * Symbol","Qwerty*1","Qwerty*1",Utilities.urlEncodeString("Qwerty*1")},
		{ "Update Pwd with ( Symbol","Qwerty(1","Qwerty(1",Utilities.urlEncodeString("Qwerty(1")},
		{ "Update Pwd with ) Symbol","Qwerty)1","Qwerty)1",Utilities.urlEncodeString("Qwerty)1")},
		{ "Update Pwd with _ Symbol","Qwerty_1","Qwerty_1",Utilities.urlEncodeString("Qwerty_1")},
		{ "Update Pwd with = Symbol","Qwerty=1","Qwerty=1",Utilities.urlEncodeString("Qwerty=1")},
		{ "Update Pwd with < Symbol","Qwerty<1","Qwerty<1",Utilities.urlEncodeString("Qwerty<1")},
		{ "Update Pwd with > Symbol","Qwerty>1","Qwerty>1",Utilities.urlEncodeString("Qwerty>1")},
		{ "Update Pwd with / Symbol","Qwerty/1","Qwerty/1",Utilities.urlEncodeString("Qwerty/1")},
		{ "Update Pwd with { Symbol","Qwerty{1","Qwerty{1",Utilities.urlEncodeString("Qwerty{1")},
		{ "Update Pwd Prefix with @ Symbol","@Qwer3ty","@Qwer3ty",Utilities.urlEncodeString("@Qwer3ty")},
		{ "Update Pwd Prefix with # Symbol","#Q1werty","#Q1werty",Utilities.urlEncodeString("#Q1werty")},
		{ "Update Pwd Prefix with ! Symbol","!Qw12erty","!Qw12erty",Utilities.urlEncodeString("!Qw12erty")},
		{ "Update Pwd Prefix with $ Symbol","$Qwer44ty1","$Qwer44ty1",Utilities.urlEncodeString("$Qwer44ty1")},
		{ "Update Pwd Prefix with % Symbol","%qweRty1","%qweRty1",Utilities.urlEncodeString("%qweRty1")},
		{ "Update Pwd Prefix with ^ Symbol","^9qwerTy1","^9qwerTy1",Utilities.urlEncodeString("^9qwerTy1")},
		{ "Update Pwd Prefix with & Symbol","&Qwerty31","&Qwerty31",Utilities.urlEncodeString("&Qwerty31")},
		{ "Update Pwd Prefix with * Symbol","*Qwerty_4","*Qwerty_4",Utilities.urlEncodeString("*Qwerty_4")},
		{ "Update Pwd Prefix with ( Symbol","(qWerty1","(qWerty1",Utilities.urlEncodeString("(qWerty1")},
		{ "Update Pwd Prefix with ) Symbol",")Qwerty6",")Qwerty6",Utilities.urlEncodeString(")Qwerty6")},
		{ "Update Pwd Suffix with @ Symbol","qweR3ty@","qweR3ty@",Utilities.urlEncodeString("qweR3ty@")},
		{ "Update Pwd Suffix with # Symbol","Q1werty#k","Q1werty#k",Utilities.urlEncodeString("Q1werty#k")},
		{ "Update Pwd Suffix with ! Symbol","Qw12erty!","Qw12erty!",Utilities.urlEncodeString("Qw12erty!")},
		{ "Update Pwd Suffix with $ Symbol","Qwer44ty1$","Qwer44ty1$",Utilities.urlEncodeString("Qwer44ty1$")},
		{ "Update Pwd Suffix with % Symbol","qweRty1%","qweRty1%",Utilities.urlEncodeString("qweRty1%")},
		{ "Update Pwd Suffix with ^ Symbol","9qwerTy1^","9qwerTy1^",Utilities.urlEncodeString("9qwerTy1^")},
		{ "Update Pwd Suffix with & Symbol","Qwerty31&","Qwerty31&",Utilities.urlEncodeString("Qwerty31&")},
		{ "Update Pwd Suffix with * Symbol","Qwerty_4*","Qwerty_4*",Utilities.urlEncodeString("Qwerty_4*")},
		{ "Update Pwd Suffix with ( Symbol","qWerty1(","qWerty1(",Utilities.urlEncodeString("qWerty1(")},
		{ "Update Pwd Suffix with ) Symbol","Qwerty6)","Qwerty6)",Utilities.urlEncodeString("Qwerty6)")},
		{ "Update Pwd with Multiple Symbols","qwertY==$5","qwertY==$5",Utilities.urlEncodeString("qwertY==$5")},
		{ "Update Pwd with Multiple Numbers","4qwErtY$$8","4qwErtY$$8",Utilities.urlEncodeString("4qwErtY$$8")},
		{"Pasword with space prefix"," Qwerty@1"," Qwerty@1",Utilities.urlEncodeString(" Qwerty@1")},
		{"Password with space suffix","Qwerty@1 ","Qwerty@1 ",Utilities.urlEncodeString("Qwerty@1 ")},
		{"Password with space both prefix and suffix"," Qwerty@1 "," Qwerty@1 ",Utilities.urlEncodeString(" Qwerty@1 ")}
	
	};
	}

	@DataProvider(name = "data_keywords_update_pwd_negative")
	public Object[][] data_keywords_negative_testData() {
		String beforeAtTheRateAdapter=adapterEmail.substring(0,adapterEmail.indexOf("@"));
		String beforeAtTheRateOAPI=adapterEmail.substring(0,adapterEmail.indexOf("@"));
		// Return Special characters

		return new Object[][] {
//		        
//				{"Password with @ symbol","Qwery@1",Utilities.urlEncodeString("Qwery@1")},
//				{"Lower case password","qwerty@1",Utilities.urlEncodeString("qwerty@1")},
//				{"Upper case password","QWERTY@1",Utilities.urlEncodeString("QWERTY@1")},
//				{"Password without special characters","Qwertyui",Utilities.urlEncodeString("Qwertyui")},
			{"Password with @ symbol","Qwery@1","Qwery@1"},
			{"Lower case password","qwerty@1","qwerty@1"},
			{"Upper case password","QWERTY@1","QWERTY@1"},
			{"Password without special characters","Qwertyui","Qwertyui"},
				{"Password with the emailid",beforeAtTheRateAdapter,beforeAtTheRateOAPI},
//				{"Password As Null","",""},
				{"Numeric Password","123","123"}
		};
	}

}
