package test.java.adapters.profile.passwordChanges;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_INFO_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("PasswordChanges")
@Stories({ "Create Profile" })
public class CreateProfile {

	ResponseValidator validator;
	String adapterEmail=null;
	String oAPIEmail=null;
	
    
	/*-----------------------------R7----------------------------------*/
	/*------------------PASSWORD CHANGES TESTCASES---------------------*/
	@Test(groups = { "password_changes", "regression" }, enabled = true, priority = 0, testName = "create Profile- Invalid Email",
			description = "Create a new profile with Strong and SpecialCharcters valid Password",
			dataProvider = "data_keywords_positive_testData")
	public void passwordChangesPositive(String strScenario,String passwordAdapter,String passwordOAPI ,String passwordSignIn, String passwordAdapterProfile) {
		
		adapterEmail=Utilities.getNewEmailID();
		oAPIEmail=Utilities.getNewEmailID();
		
		//Create profile 
		
		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + passwordAdapter  + "\","
						+ "\"email\":\"" + adapterEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";
		testData.put("ADAPTER_PWD", passwordAdapter);
		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");
		
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + passwordOAPI  + "\","
							+ "\"email\":\"" + oAPIEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";
			testData.put("OAPI_PWD", passwordAdapter);
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
		
		//Sign in profile
		
		String strPayloadSignin = "grant_type=password&userId=" +adapterEmail+ "&password="+passwordSignIn;

		// Post the request
		String strResponsesignin = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayloadSignin, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponsesignin);
		validator.validateNoErrors();
		validator.SignInProfileResponse();
		validator.nodeMatches("$.payload.response.wallet.hash", ".+", "Hash should be available in response");
		Utilities.setTestData(strResponsesignin, "$.payload.response.signIn.access_token", "access_token_updProf_adapter");
		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" +oAPIEmail+ "&password="+passwordSignIn;
			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			Utilities.setTestData(strResponseOAPI, "$.access_token", "access_token_updProf_oapi");

		}
		
		
		String strPayloadUpdateprofile = "{\"payload\":{\"profile\":{\"customerName\":"
				+ "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"NewLastName" + testData.get("CUSTOMER_LASTNAME") + "\"}," + "\"password\":\"" + passwordAdapterProfile + "\""
				+ "}}}";

		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponseUpdateprofile = RestCall.putRequest(PROFILE_ADAPTER, 	strPayloadUpdateprofile, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponseUpdateprofile);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");

		if (CompareOAPI) {
			// Post the request
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_updProf_oapi"));
			String strPayloadUpdateprofileOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"NewLastName" + testData.get("CUSTOMER_LASTNAME") + "\"}," + "\"password\":\"" + passwordAdapterProfile + "\""
					+ "}}}";
			
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayloadUpdateprofileOAPI, Server.OpenApi, true,mapheader);
			
			//testData.put("OAPI_EMAIL_PSWD", testData.get("NEW_PASSWORD"));
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponseUpdateprofile, strResponseOAPI, "", true);
		}

	}

	@Test(groups = { "password_changes", "regression" }, enabled = true, priority = 0, testName = "create Profile- Invalid Email",
			description = "Create a new profile with an invalid Password",
			dataProvider = "data_keywords_negative_testData")
	public void passwordChangesnegative(String strScenario,String passwordAdapter,String passwordOAPI ) {

		adapterEmail=Utilities.getNewEmailID();
		oAPIEmail=Utilities.getNewEmailID();
		
		//Create profile 
		
		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + passwordAdapter  + "\","
						+ "\"email\":\"" + adapterEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";
		testData.put("ADAPTER_PWD", passwordAdapter);
		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9998", "The provided password does not meet the requirements.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + passwordOAPI  + "\","
							+ "\"email\":\"" + oAPIEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";
			testData.put("OAPI_PWD", passwordAdapter);
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "password_changes", "regression" ,"regression"}, enabled = true, priority = 0, testName = "create Profile- empty password",
			description = "Create a new profile with an empty Password")
	public void passwordChangesMissingPassword() {

		adapterEmail=Utilities.getNewEmailID();
		oAPIEmail=Utilities.getNewEmailID();
		
		//Create profile 
		
		// Create the Json Request for create profile
		String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"\","
						+ "\"email\":\"" + adapterEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter password.");

		// Compare Open API
		if (CompareOAPI) {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"\","
							+ "\"email\":\"" + oAPIEmail + "\",\"preferences\":{\"saleAlerts\":true}}}}";

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false,400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@DataProvider(name = "data_keywords_negative_testData")
	public Object[][] data_keywords_negative_testData() {
		String beforeAtTheRateAdapter=adapterEmail.substring(0,adapterEmail.indexOf("@"));
		String beforeAtTheRateOAPI=adapterEmail.substring(0,adapterEmail.indexOf("@"));
		// Return Special characters

		return new Object[][] {
//		        
				{"Password with @ symbol","Qwery@1","Qwery@1"},
				{"Lower case password","qwerty@1",Utilities.urlEncodeString("qwerty@1")},
				{"Upper case password","QWERTY@1",Utilities.urlEncodeString("QWERTY@1")},
				{"Password without special characters","Qwertyui",Utilities.urlEncodeString("Qwertyui")},
				{"Password with the emailid",beforeAtTheRateAdapter,beforeAtTheRateOAPI},
//				{"Password As Null","",""},
				{"Numeric Password","123","123"}
		};
	}
	@DataProvider(name = "data_keywords_positive_testData")
	public Object[][] data_keywords_positive_testData() {

		// Return Special characters

		return new Object[][] {

				{ "Password with # Symbol","Qwerty#1","Qwerty#1",Utilities.urlEncodeString("Qwerty#1"),"Qwert#y1"},
				{"Pasword with space prefix"," Qwerty@1"," Qwerty@1",Utilities.urlEncodeString(" Qwerty@1")," Qwert@y1"},
				{"Password with space suffix","Qwerty@1 ","Qwerty@1 ",Utilities.urlEncodeString("Qwerty@1 "),"Qwert@y1 "},
				{"Password with space both prefix and suffix"," Qwerty@1 "," Qwerty@1 ",Utilities.urlEncodeString(" Qwerty@1 ")," Qwert@y1 "},
				{ "Password with ! Symbol","Qwerty!1","Qwerty!1",Utilities.urlEncodeString("Qwerty!1"),"Qwert!y1"},
				{ "Password with $ Symbol","Qwerty$1","Qwerty$1",Utilities.urlEncodeString("Qwerty$1"),"Qwert$y1"},
				{ "Password with % Symbol","Qwerty%1","Qwerty%1",Utilities.urlEncodeString("Qwerty%1"),"Qwert%y1"},
				{ "Password with ^ Symbol","Qwerty^1","Qwerty^1",Utilities.urlEncodeString("Qwerty^1"),"Qwert^y1"},
				{ "Password with & Symbol","Qwerty&1","Qwerty&1",Utilities.urlEncodeString("Qwerty&1"),"Qwert&y1"},
				{ "Password with * Symbol","Qwerty*1","Qwerty*1",Utilities.urlEncodeString("Qwerty*1"),"Qwert*y1"},
				{ "Password with ( Symbol","Qwerty(1","Qwerty(1",Utilities.urlEncodeString("Qwerty(1"),"Qwert(y1"},
				{ "Password with ) Symbol","Qwerty)1","Qwerty)1",Utilities.urlEncodeString("Qwerty)1"),"Qwert)y1"},
				{ "Password with _ Symbol","Qwerty_1","Qwerty_1",Utilities.urlEncodeString("Qwerty_1"),"Qwert_y1"},
				{ "Password with = Symbol","Qwerty=1","Qwerty=1",Utilities.urlEncodeString("Qwerty=1"),"Qwert=y1"},
				{ "Password with < Symbol","Qwerty<1","Qwerty<1",Utilities.urlEncodeString("Qwerty<1"),"Qwert<y1"},
				{ "Password with > Symbol","Qwerty>1","Qwerty>1",Utilities.urlEncodeString("Qwerty>1"),"Qwert>y1"},
				{ "Password with / Symbol","Qwerty/1","Qwerty/1",Utilities.urlEncodeString("Qwerty/1"),"Qwert/y1"},
				{ "Password with { Symbol","Qwerty{1","Qwerty{1",Utilities.urlEncodeString("Qwerty{1"),"Qwert{y1"},
				{ "Password Prefix with @ Symbol","@Qwer3ty","@Qwer3ty",Utilities.urlEncodeString("@Qwer3ty"),"@Qwer3yt"},
				{ "Password Prefix with # Symbol","#Q1werty","#Q1werty",Utilities.urlEncodeString("#Q1werty"),"#Q1weryt"},
				{ "Password Prefix with ! Symbol","!Qw12erty","!Qw12erty",Utilities.urlEncodeString("!Qw12erty"),"!Qw12eryt"},
				{ "Password Prefix with $ Symbol","$Qwer44ty1","$Qwer44ty1",Utilities.urlEncodeString("$Qwer44ty1"),"$Qwer44yt1"},
				{ "Password Prefix with % Symbol","%qweRty1","%qweRty1",Utilities.urlEncodeString("%qweRty1"),"%qweRyt1"},
				{ "Password Prefix with ^ Symbol","^9qwerTy1","^9qwerTy1",Utilities.urlEncodeString("^9qwerTy1"),"^9qweryT1"},
				{ "Password Prefix with & Symbol","&Qwerty31","&Qwerty31",Utilities.urlEncodeString("&Qwerty31"),"&Qweryt31"},
				{ "Password Prefix with * Symbol","*Qwerty_4","*Qwerty_4",Utilities.urlEncodeString("*Qwerty_4"),"*Qweryt_4"},
				{ "Password Prefix with ( Symbol","(qWerty1","(qWerty1",Utilities.urlEncodeString("(qWerty1"),"(qWeryt1"},
				{ "Password Prefix with ) Symbol",")Qwerty6",")Qwerty6",Utilities.urlEncodeString(")Qwerty6"),")Qweryt6"},
				{ "Password Suffix with @ Symbol","qweR3ty@","qweR3ty@",Utilities.urlEncodeString("qweR3ty@"),"qweR3yt@"},
				{ "Password Suffix with # Symbol","Q1werty#","Q1werty#",Utilities.urlEncodeString("Q1werty#"),"Q1weryt#"},
				{ "Password Suffix with ! Symbol","Qw12erty!","Qw12erty!",Utilities.urlEncodeString("Qw12erty!"),"Qw12eryt!"},
				{ "Password Suffix with $ Symbol","Qwer44ty1$","Qwer44ty1$",Utilities.urlEncodeString("Qwer44ty1$"),"Qwer44yt1$"},
				{ "Password Suffix with % Symbol","qweRty1%","qweRty1%",Utilities.urlEncodeString("qweRty1%"),"qweRyt1%"},
				{ "Password Suffix with ^ Symbol","9qwerTy1^","9qwerTy1^",Utilities.urlEncodeString("9qwerTy1^"),"9qweryT1^"},
				{ "Password Suffix with & Symbol","Qwerty31&","Qwerty31&",Utilities.urlEncodeString("Qwerty31&"),"Qweryt31&"},
				{ "Password Suffix with * Symbol","Qwerty_4*","Qwerty_4*",Utilities.urlEncodeString("Qwerty_4*"),"Qweryt_4*"},
				{ "Password Suffix with ( Symbol","qWerty1(","qWerty1(",Utilities.urlEncodeString("qWerty1("),"qWeryt1("},
				{ "Password Suffix with ) Symbol","Qwerty6)","Qwerty6)",Utilities.urlEncodeString("Qwerty6)"),"Qweryt6)"},
				{ "Password with @ Symbol","Qwerty@1","Qwerty@1",Utilities.urlEncodeString("Qwerty@1"),"Qweryt@1"},
		};
	}
}