package test.java.adapters.profile.cvv2;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_OAPI;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

@Features("cvv2")
@Stories({ "Update Payment Type" })

public class UpdatePaymentType {

	ResponseValidator validator;


	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 2, testName = "Update Payment Type",
			description = "Verify whether user is able to update the payment type as KOHLS charge card")
	public void UpdatePaymentType1() {
		
		String strEmail = Utilities.getNewEmailID();
		Utilities.createProfile(strEmail,"Qwerty@123", Server.Adapter);
		Utilities.signInProfile(strEmail,"Qwerty@123", Server.Adapter, "access_token_adapter");
		
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATEPAYMENT")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		//Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id_delete");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);
		//	Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id_delete");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 30, testName = "Update Payment Type with MissingCardName",
			description = "Updating payment type to the profile with MissingCardName")
	public void MissingCardName() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		testData.put("access_token_adapter_updatepayment_cvv2", testData.get("access_token_adapter_updatepayment"));
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("MISSINGCARDNAME")
				+ "\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);

		// validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		validator.validateProfileUpadteMessage();
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id_cvv2");
		// Compare Adapter and OAPI
		String strOCBEmailOAPI = Utilities.getNewEmailID();
		Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));
		if (CompareOAPI) {
			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "access_token_oapi_updatepayment");
			testData.put("access_token_oapi_updatepayment_cvv2", testData.get("access_token_oapi_updatepayment"));
			mapheader.put("access_token", testData.get("access_token_oapi_updatepayment"));
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id_cvv2");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 30, testName = "Update Payment Type with NumericCardName", dependsOnMethods = "MissingCardName",
			description = "Updating payment type to the profile with NumericCardName")
	public void NumericCardName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("NUMERICCARDNAME_UPDATE")
				+ ",\"ID\":\""
				+ testData.get("adapter_payment_id_cvv2") + "\",\"preferredPaymentType\":\"true\",\"action\":\"update\"}}}}";
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment_cvv2"));
		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_updatepayment_cvv2"));
			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"paymentType\":"
					+ JsonString.getPaymentTypeJson("NUMERICCARDNAME_UPDATE")
					+ ",\"ID\":\""
					+ testData.get("openAPI_payment_id_cvv2") + "\",\"preferredPaymentType\":\"true\",\"action\":\"update\"}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 30, testName = "Update Payment Type with SpecialCharcterCardName", 
			description = "Updating payment type to the profile with SpecialCharcterCardName")
	public void SpecialCharcterCardName() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("SPECCHAR_CARDNAME")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		
		if (CompareOAPI)
		{
			String strOCBEmailOAPI = Utilities.getNewEmailID();
			Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "cvv2", "regression","functional", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with NonNumericCardNum", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with NonNumericCardNumber")
	public void NonNumericCardNum() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("NONNUMERIC_CARDNUM")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Card Number.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "cvv2", "regression","functional", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with GreaterThan16DigitCardNum", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with GreaterThan16DigitCardNum")
	public void GreaterThan16DigitCardNum() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("ABOVE16DIGIT_CARDNUM")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Card Number.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "cvv2", "regression","functional", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with INVALIDCardType", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with INVALIDCardType")
	public void INVALID_CardType() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("INVALIDCARDTYPE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Card Type.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 30, testName = "Update Payment Type with SpecialCharcterCardName", 
			description = "Updating payment type to the profile with SpecialCharcterCardName")
	public void invalidDateFormat() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATE_INVALID_DATE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		
		if (CompareOAPI)
		{
			String strOCBEmailOAPI = Utilities.getNewEmailID();
			Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}
	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 30, testName = "Update Payment Type with SpecialCharcterCardName",
			description = "Updating payment type to the profile with SpecialCharcterCardName")
	public void MissingDateElement() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATE_MISSING_DATE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";
		

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		
		if (CompareOAPI)
			{

			String strOCBEmailOAPI = Utilities.getNewEmailID();
			Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}
	@Test(groups = { "cvv2", "regression","functional", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with SpecialCharcterCardName", 
			description = "Updating payment type to the profile with SpecialCharcterCardName")
	public void InvalidSecurityCode() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KCC_CVV2")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR2700", "Invalid JSON: Unrecognized field securityCode");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		
		if (CompareOAPI)
		{
			String strOCBEmailOAPI = Utilities.getNewEmailID();
			Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader,400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errors.entity,errorCode,error", true);
		}
	}
	@Test(groups = { "cvv2", "regression","functional" }, enabled = true, priority = 30, testName = "Update Payment Type with SpecialCharcterCardName", 
			description = "Updating payment type to the profile with SpecialCharcterCardName")
	public void MissingSecurityCode() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KCC_CVV2_UPDATEPAYMENT")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		
		if (CompareOAPI)
		{
			String strOCBEmailOAPI = Utilities.getNewEmailID();
			Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}
}