package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.FORGOT_PASSWORD;
import static main.java.common.GlobalVariables.FORGOT_PASSWORD_OAPI;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Forgot Password" })
public class ForgotPassword {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 14, testName = "Forgot Password with Invalid EmailId",
			description = "Resetting the password using InvalidemailID")
	public void forgotPasswordWithInvalidEmailID() {

		String strURL = FORGOT_PASSWORD + "razzi.gmail.com";
		// Post the request
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Email.");

		// Compare Open API
		if (CompareOAPI) {

			// Get the request
			String strURLOAPI = FORGOT_PASSWORD_OAPI + "razzi.gmail.com";
			String strResponseOAPI = RestCall.getRequest(strURLOAPI, Server.OpenApi, false, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);

		}
	}

}