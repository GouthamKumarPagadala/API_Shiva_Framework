package test.java.adapters.profile.loyalty;
import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.GET_TOKEN_V2;
import static main.java.common.GlobalVariables.CREATE_LOYALTYID;
import static main.java.common.TestData.testData;

import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static main.java.common.TestData.mapheader;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;

@Features("Profile")
@Stories({ "Create Profile Loyalty" })
public class CreateprofileLoyalty {

	ResponseValidator validator;
	String strEmail,strPassword ="";

	@BeforeClass(alwaysRun = true)
	public void testSetup() {

	}
	
	@BeforeMethod(alwaysRun = true)
	public void printTestName(Method method) {
		
		String phoneNumberV2 = Utilities.getNewPhoneNumber();
		testData.put("UNIQUE_PHONE_NUMBER", phoneNumberV2);
		strEmail = Utilities.getNewEmailID();
		testData.put("UNIQUE_EMAIL",strEmail);
		 strPassword="Loyalty@1234";
		
	}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSingleCharacterFN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, LN and single character FN")
	
	public void SingleCharacterFN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
		System.out.println("Access Token:"+testData.get("access_token_oapi"));
		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("access_token_oapi"));
		
		// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
		String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
		Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new");
				
				
		String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("SINGLE_CHAR_FNAME")+"\",\"lastName\":\""+testData.get("CUSTOMER_LASTNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new")+"\"}";
		// Get
		String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
		// Setting wallet details in variables
		String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
		testData.put("WALLET_TOKEN", strToken);
		mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName", testData.get("SINGLE_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", testData.get("CUSTOMER_LASTNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSingleCharacterLN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, and single character LN")
	
	public void SingleCharacterLN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_LNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new1");
				
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\":\""+testData.get("SINGLE_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new1")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", testData.get("SINGLE_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSingleCharacterFNandLN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password and single character FN and LN")
	
	public void SingleCharacterFN_LN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new2");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("SINGLE_CHAR_FNAME")+"\",\"lastName\":\""+testData.get("SINGLE_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new2")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName", testData.get("SINGLE_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", testData.get("SINGLE_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSpaceAsFN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, LN and SpaceAsFN")
	
	public void SpaceAsFN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new3");
				
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\":\""+testData.get("CUSTOMER_LASTNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new3")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + " " + "\",\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeEquals("$.errors[0].errorCode","24", "verify error code is present in the response");
				validator.nodeEquals("$.errors[0].message","A required parameter, firstName, is missing or invalid.", "verify error message is present in the response");
			
			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSpaceAsLN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password and SpaceAsLN")
	
	public void SpaceAsLN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new4");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\":\""+testData.get("CUSTOMER_LASTNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new4")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \"" + " " + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeEquals("$.errors[0].errorCode","24", "verify error code is present in the response");
				validator.nodeEquals("$.errors[0].message","A required parameter, lastName, is missing or invalid.", "verify error message is present in the response");
			

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSpaceAsBothFN_LN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password and SpaceAsBothFN_LN")
	
	public void SpaceAsBothFN_LN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("VALID") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new5");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\":\""+testData.get("CUSTOMER_LASTNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new5")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + " " + "\",\"lastName\": \"" + " " + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeEquals("$.errors[0].errorCode","24", "verify error code is present in the response");
				validator.nodeEquals("$.errors[0].message","A required parameter, firstName, is missing or invalid.", "verify error message is present in the response");
			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSpecialCharacterFN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, LN and  SpecialCharacterFN")
	
	public void SpecialCharacterFN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new6");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("SPECIAL_CHAR_FNAME")+"\",\"lastName\":\""+testData.get("CUSTOMER_LASTNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new6")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName",testData.get("SPECIAL_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName",testData.get("CUSTOMER_LASTNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSpecialCharacterLN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, LN and SpecialCharacterLN")
	
	public void SpecialCharacterLN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_LNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new7");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\":\""+testData.get("SPECIAL_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new7")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"lastName\": \"" + testData.get("SPECIAL_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName", testData.get("CUSTOMER_FIRSTNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", testData.get("SPECIAL_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithSpecialCharacterFN_LN",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password and SpecialCharacterFN_LN")
	
	public void SpecialCharacterFN_LN()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPECIAL_CHAR_FNAME_LNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new8");
				
							
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("SPECIAL_CHAR_FNAME")+"\",\"lastName\":\""+testData.get("SPECIAL_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new8")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SPECIAL_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName", testData.get("SPECIAL_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", testData.get("SPECIAL_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithFNStartingWithSpace",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, LN and FNStartingWithSpace")
	
	public void FNStartingWithSpace()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new9");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\" " +testData.get("SPECIAL_CHAR_FNAME")+"\",\"lastName\":\""+testData.get("SINGLE_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new9")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \" " + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName"," "+testData.get("SPECIAL_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", testData.get("SINGLE_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithLNStartingWithSpace",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password and LNStartingWithSpace")
	
	public void LNStartingWithSpace()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_LNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new10");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\""+testData.get("SINGLE_CHAR_FNAME")+"\",\"lastName\":\" " +testData.get("SPECIAL_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new10")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \" " + testData.get("SPECIAL_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName", testData.get("SINGLE_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName"," "+ testData.get("SPECIAL_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	@Test(groups = { "fmnp273","regression1" }, enabled = true, priority = 0, testName = "createProfile_Loyalty_WithBothFN_LNStartingWithSpace",
			description = "Kohls application user wants to Sign up to log into the appilaction using valid email id,password, BothFN_LNStartingWithSpace")
	
	public void BothFN_LNStartingWithSpace()
		   {
		
		//Create profile using OAPI
		String strPayload2 = "{\"payload\":{\"profile\":{\"customerName\":"
				+ JsonString.getCustomerNameJson("SPACE_SINGLE_CHAR_FNAME_LNAME") + ","
				+ "\"password\":\"" + strPassword + "\","
				+ "\"email\":\"" + testData.get("UNIQUE_EMAIL") + "\",\"preferences\":{\"saleAlerts\":true}}}}";

		// Post the request
		String strResponse2 = RestCall.postRequest(PROFILE_ADAPTER, strPayload2, Server.Adapter, false);
		validator = new ResponseValidator(strResponse2);
				
				// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPassword, Server.OpenApi, "access_token_oapi");
				System.out.println("Access Token:"+testData.get("access_token_oapi"));
				// Update cart through OAPI
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_oapi"));
				
				// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
				String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader);
				Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "atg_id_openapi_new11");
				
				String strPayload="{\"email\":\""+testData.get("UNIQUE_EMAIL")+"\",\"firstName\":\" " +testData.get("SPECIAL_CHAR_FNAME")+"\",\"lastName\":\" " +testData.get("SPECIAL_CHAR_LNAME")+"\",\"atgProfileId\":\""+testData.get("atg_id_openapi_new11")+"\"}";
				// Get
				String	strResponse = RestCall.postRequest(GET_TOKEN_V2 ,strPayload, Server.WalletAuth, false);
					
				// Setting wallet details in variables
				String strToken = Utilities.getJsonNodeValue(strResponse, "$.walletToken.token");
				testData.put("WALLET_TOKEN", strToken);
				mapheader.put("Token", testData.get("WALLET_TOKEN"));
				// Create the Json Request for gift card wallet
				String strPayload1 = "{\"customerName\": {\"firstName\": \" " + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \" " + testData.get("SPECIAL_CHAR_LNAME") + "\" }, \"email\": \"" + testData.get("UNIQUE_EMAIL")+"\", \"birthday\": \"" + testData.get("CUSTOMER_BIRTHDAY") + "\", \"postalCode\": \"" + testData.get("CUSTOMER_POSTAL_CODE") + "\", \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") + "\", \"address\": {\"addr1\": \"" + testData.get("CUSTOMER_ADDRESS1") + "\",\"addr2\": \"" + testData.get("CUSTOMER_ADDRESS2") + "\",\"city\": \"" + testData.get("CUSTOMER_CITY") + "\",\"state\": \"" + testData.get("CUSTOMER_STATE") + "\" }}";
				String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload1, Server.WalletAuth, false,mapheader);
				// Post the request
			//	String strResponse1 = RestCall.postRequest(CREATE_LOYALTYID, strPayload, Server.WalletAuth, false);
				
				validator = new ResponseValidator(strResponse1);
				validator.nodeMatches("$.profile.loyaltyId", "[0-9]+", "verify loyalty id is present in the response");
				validator.nodeEquals("$.profile.customerName.firstName"," "+testData.get("SPECIAL_CHAR_FNAME"), "verify customer first name is present in the response");
				validator.nodeEquals("$.profile.customerName.lastName", " "+testData.get("SPECIAL_CHAR_LNAME"), "verify customer last name is present in the response");

			}
	}
