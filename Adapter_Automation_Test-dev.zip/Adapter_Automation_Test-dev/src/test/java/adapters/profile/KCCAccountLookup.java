package test.java.adapters.profile;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;
import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import main.java.common.TestData;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "KCC Account Lookup" })


public class KCCAccountLookup {
	

	ResponseValidator validator;

	@BeforeMethod(alwaysRun = true)
	public void createProfile() {

		
		// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
		Utilities.signInProfile("jbeggs@testorama.com", "Test1234!!", Server.Adapter, "Bopus_access_token");

		// Update cart through Adapter
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		
	}

	@Test(groups = { "KCCLookup-NAP230","Prequal" }, enabled = true, testName = "KCCLookup With valid AccessToken and valid preQualify ID", 
			description = "KCCLookup With Valid AccessToken and valid preQualify ID")
	public void KCC_LookupWithValidTokenAndPrequalify_ID() throws InterruptedException {
        mapheader.clear();
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		// Create the Json Request for Cart
		String strPayload = "{\"preQualifyId\":\"12529639469874\"}";
		// Post the request
		String strURL=KCC_LOOKUP;		
		strURL = Utilities.changeURL(strURL);
		Thread.sleep(5000);
		
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.last4",".+","Last 4 digit of KCC should be displayed based on eligibility");
		validator.nodeMatches("$.payload.offerCode",".+","Unique code that can be used only once should be displayed if user is quallified for KCC");
		validator.nodeMatches("$.payload.percentDiscount",".+","percent Discount that can be availed should be displayed if user is quallified for KCC");
		validator.nodeMatches("$.payload.loyaltyId",".+","loyaltyId should be displayed if user is quallified for KCC");
		
	}
	
	@Test(groups = { "KCCLookup-NAP230","Prequal" }, enabled = true, testName = "KCCLookup With valid AccessToken and Empty preQualify ID", 
			description = "KCCLookup With Valid AccessToken and Empty preQualify ID")
	public void KCC_LookupWithEmptyPrequalify_ID() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		// Create the Json Request for Cart
		String strPayload = "{\"preQualifyId\":\"\"}";
		// Post the request
		String strURL=KCC_LOOKUP;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter preQualifyId");
			
	}
	
	@Test(groups = { "KCCLookup-NAP230","Prequal" }, enabled = true, testName = "KCCLookup With valid AccessToken and Empty preQualify ID", 
			description = "KCCLookup With Valid AccessToken and without preQualify ID")
	public void KCC_LookupWithoutPrequalify_ID() {

		mapheader.clear();
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		// Create the Json Request for Cart
		String strPayload = "{}";
		// Post the request
		String strURL=KCC_LOOKUP;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL1000","Missing Required Parameter preQualifyId");
			
	}
	
	@Test(groups = { "KCCLookup-NAP230","Prequal" }, enabled = true, testName = "KCCLookup With valid AccessToken and Invalid preQualify ID", 
			description = "KCCLookup With Valid AccessToken and Invalid preQualify ID")
	public void KCC_LookupWithValidTokenAndInvalidPrequalify_ID() {
		mapheader.clear();
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		// Create the Json Request for Cart
		String strPayload = "{\"preQualifyId\":\"cdfgt\"}";
		// Post the request
		String strURL=KCC_LOOKUP;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PREQUAL2002","We're sorry, something went wrong at this moment. So we could not add your credit card to your account.");
	}
		
	@Test(groups = { "KCCLookup-NAP230","Prequal" }, enabled = true, testName = "KCC Lookup With Expired AccessToken", 
			description = "KCCLookup With Expired AccessToken")
	
	public void KCC_LookupWithExpiredAccessToken() {
		mapheader.clear();
		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		// Create the Json Request for Cart
				String strPayload = "{\"preQualifyId\":\"00459444377899\"}";
		// Post the request
				String strURL=KCC_LOOKUP;		
				strURL = Utilities.changeURL(strURL);
				String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, true, mapheader, 200);
				
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		
	}
		
	@Test(groups = { "KCCLookup-NAP230","Prequal" }, enabled = true, testName = "KCCLookup With InvalidJson", 
			description = "KCCLookup With Invalid Json")
	public void KCC_LookupWithInvalidJson() {
		mapheader.clear();
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		// Create the Json Request for Cart
		String strPayload = "{\"preQualify\":\"00459444377899\"}";
		// Post the request
		String strURL=KCC_LOOKUP;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.postRequest(strURL,strPayload, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR2700","Invalid JSON: Unrecognized field preQualify");
			
	}
	
}
