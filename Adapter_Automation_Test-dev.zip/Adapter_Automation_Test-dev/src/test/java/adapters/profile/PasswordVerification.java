package test.java.adapters.profile;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;
@Features("Profile")
@Stories({ "Password Verfication" })

public class PasswordVerification {
		

	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "Password Verfication Positive Scenario",
			description = "Verfiy whether Proper Success Message is getting dispayed or not when we are passing proper EmaiId and password which is match with provided accesstoken in request")
	public void PositiveScenario() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
					
		String strPayload = "userId=" + strEmail+ "&password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader,200);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeEquals("$.payload.message", "Verification Success", "Password Verification Done");
		
			
// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
		
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
					

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,200);

			

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "Without UserID",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are not passing required Userid field in request")
	public void WithoutUserID() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
					
		String strPayload = "password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "invalid_request", "Error code should be invalid_request");
		validator.nodeEquals("$.errors[0].message", "Missing required parameter userId", "Error message should be \"Missing required parameter userId\"");
		
		
		
			
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
		
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
					

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader);
			
			

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "Without Password",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are not passing required password field in request")
	public void WithoutPassword() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
					
		String strPayload = "userId=" + strEmail;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "invalid_request", "Error code should be invalid_request");
		validator.nodeEquals("$.errors[0].message", "Missing required parameter password", "Error message should be \"Missing required parameter userId\"");
		
		
		
		
			
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
		
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
					

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
			
			

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}

	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "Without Access token",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are not passing Access token in header section")
	public void WithoutAccesstoken() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				//Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
					mapheader.clear();		
		String strPayload = "userId=" + strEmail+ "&password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PROF1004", "User should get error code \"PROF1004\"");
		validator.nodeEquals("$.errors[0].message", "Missing Required Header access_token.", "User should get error message \"Missing Required Header access_token.\"");
		
			
// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With invalid email Id",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing email id in invalid format")
	
	public void InvalidEmailID() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		String strPayload = "userId=" + ("invalid@t"+ "&password=" + strPaswd);

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PROF1002", "User should get proper error Code PROF1002");
		validator.nodeEquals("$.errors[0].message", "Invalid value passed for Email.", "User should get proper error message Invalid value passed for Email.");
	
			
// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With invalid Password",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing password in invalid format which is not match with password criteria.")
	public void InvalidPassword() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		String strPayload = "userId=" + strEmail + "&password=Qwerty@2";

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "invalid_request", "Error code should be \"invalid_request\"");
		validator.nodeEquals("$.errors[0].message", "Invalid userId/password", "Error message should be \"Invalid userId/password\"");
		
			
// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
		
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With EmailID which is not associate with accesstoken ",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing invalid email id which is does not match with that access token.")
	public void Stranger_EmailID() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@123";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
				
				String strEmail1 = Utilities.getNewEmailID();
				String strPaswd1 = "Qwerty@12";
				Utilities.createProfile(strEmail1, strPaswd1, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail1, strPaswd1, Server.Adapter, "OCB_access_token_adapter1");
		
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		String strPayload = "userId=" + strEmail1 + "&password=" + strPaswd1;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.errors[0].code", "PROF9092", "PROF9092 should be displayed in response");
		validator.nodeMatches("$.errors[0].message", "There was an error with the password.", "Proper error message should be displayed in response");
		validator.nodeMatches("$.errorCode", "400", "Proper Code should be displayed in response");
		validator.nodeMatches("$.error", "Bad Request", "Proper error message should be displayed in response");
		
		
		
			
// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
		
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With EmailID which is not associate with accesstoken ",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing invalid email id which is does not match with that access token.")
	
	public void Stranger_Password() {
		
		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Qwerty@1";
		Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
		
// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
		
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
						
		
		String strPayload = "userId=" + strEmail + "&password=Qwerty@321";

// Post the request
String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

// Validate Response
ResponseValidator validator = new ResponseValidator(strResponse);
validator.nodeMatches("$.errors[0].code", "invalid_request", "Invalid Request should be displayed in response");
validator.nodeMatches("$.errors[0].message", "Invalid userId/password", "Proper error message should be displayed in response");
validator.nodeMatches("$.errorCode", "400", "Proper Code should be displayed in response");
validator.nodeMatches("$.error", "Bad Request", "Proper error message should be displayed in response");



	
//Compare Open API
if (CompareOAPI) {
	
	Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
	
	mapheader.clear();   // clear any headers set by previous TCs
	mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));

	// Post the request
	String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);


	// Compare the result
	Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
}

}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With Expired accesstoken ",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing valid request with Expired Accesstoken")
	public void Expired_AccessToken() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");
				
			// Revoke the accesstoken 
				
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));
				
				String strResponse = RestCall.deleteRequest(V2_REFRESH_TOKEN, Server.Adapter, true,mapheader);
				

			// Validate Response
				ResponseValidator validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.nodeEquals("$.message", "User Token Expired Successfully", "User Token  Expired Successfully message should be displayed ");
				String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strURL);
				validator.validateExpectedErrors("keymanagement.service.access_token_expired", "access token expired");
				
				//Password Verfication With Expired Accesstoken
				mapheader.clear();   // clear any headers set by previous TCs
				mapheader.put("access_token", testData.get("access_token_adapter"));								
				
				String strPayload = "userId=" + strEmail + "&password=" + strPaswd;

		// Post the request
		String strResponse1 = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader);

		// Validate Response
		ResponseValidator validator1 = new ResponseValidator(strResponse1);
		validator1.nodeMatches("$.errors[0].code", "keymanagement.service.access_token_expired", "Code should be displayed in response");
		validator1.nodeMatches("$.errors[0].message", "Access Token expired", "Proper error message should be displayed in response");
		validator1.nodeMatches("$.errorCode", "401", "Proper Code should be displayed in response");
		validator1.nodeMatches("$.error", "Unauthorized", "Proper error message should be displayed in response");
		
						
// Compare Open API
		if (CompareOAPI) {
			
			Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
			
			// Revoke the accesstoken 
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_OAPI"));
			
			String strResponse2 = RestCall.deleteRequest(V2_REFRESH_TOKEN, Server.OpenApi, true,mapheader);
			

		// Validate Response
			ResponseValidator validator2 = new ResponseValidator(strResponse);
			validator2.validateNoErrors();
			validator2.nodeEquals("$.message", "User Token Expired Successfully", "User Token  Expired Successfully message should be displayed ");
			String strURL2 = RestCall.getRequest(PROFILE_ADAPTER, Server.OpenApi, true);
			validator2 = new ResponseValidator(strURL2);
			validator2.validateExpectedErrors("keymanagement.service.access_token_expired", "access token expired");
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
		
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With Invalid accesstoken ",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing valid request with Invalid Accesstoken")
	public void Invalid_AccessToken() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "OCB_access_token_adapter");
				
								mapheader.clear();   // clear any headers set by previous TCs
								mapheader.put("access_token", ("sdfgjhsgadfuyufrguweguyfsau"));
				
		String strPayload = "userId=" + strEmail + "&password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader,200);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.errors[0].code", "401", "Error code should be displayed in response");
		validator.nodeMatches("$.errors[0].message", "Invalid token. Please enter valid token.", "Proper error message should be displayed in response");
		validator.nodeMatches("$.errorCode", "401", "Proper Code should be displayed in response");
		validator.nodeMatches("$.error", "Unauthorized", "Proper error message should be displayed in response");
		
					
// Compare Open API
		if (CompareOAPI) {
					
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", ("sdfgjhsgadfuyufrguweguyfsau"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
		
	}
	
	@Test(groups = { "PWD_VERF","regression" }, enabled = true, priority = 1, testName = "With Invalid accesstoken ",
			description = "Verfiy whether Proper Error Message is getting dispayed or not when we are passing valid request with Invalid Accesstoken")
	public void SixTimes_with_InvalidPassword() {
		
				// Create a new profile through OAPI
				String strEmail = Utilities.getNewEmailID();
				String strPaswd = "Qwerty@1";
				Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
				Utilities.signInProfile(strEmail, "Qwerty@1", Server.Adapter, "OCB_access_token_adapter");
				
			//Storing Openapi AccessToken
				
				Utilities.signInProfile(strEmail, strPaswd, Server.OpenApi, "OCB_access_token_OAPI");
		
		// locking Accounts
				for (int i=0;i<=5;i++){
					String strPayload = "grant_type=password&userId=" + strEmail + "&password=Qwerty@321";
					// Post the request
					String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);
				}
				
								mapheader.clear();   // clear any headers set by previous TCs
								mapheader.put("access_token", testData.get("OCB_access_token_adapter"));
				
		String strPayload = "userId=" + strEmail + "&password=" + strPaswd;

		// Post the request
		String strResponse = RestCall.postRequest(PWD_VERFICATION_ADAPTER, strPayload, Server.Adapter, false,mapheader,200);

		// Validate Response
		ResponseValidator validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.errors[0].code", "PROF9100", "Error code should be \"PROF9100\"");
		validator.nodeEquals("$.errors[0].message", "To sign in to your account, please reset your password using the Forgot password? link.", "Error message should be \"To sign in to your account, please reset your password using the Forgot password? link.\"");
// Compare Open API
		if (CompareOAPI) {
					
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_OAPI"));
		
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PWD_VERFICATION_OAPI, strPayload, Server.OpenApi, false,mapheader,400);
		

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
		
	}
	
}
