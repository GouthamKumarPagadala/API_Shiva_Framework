package test.java.adapters.profile.wallet;

public class GetProfile {

}
