package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;
import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import main.java.common.TestData;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "Get Customer Profile" })


public class GetProfile {
	

	ResponseValidator validator;

	@BeforeMethod(alwaysRun = true)
	public void v2SignIn() {

	String strKohlspayEmail = Utilities.getNewEmailID();
	String strKohlspayPaswd = "Kp@12345";
	Utilities.createProfile(strKohlspayEmail, strKohlspayPaswd, Server.Adapter);

	String strURL = "grant_type=password&userId=" + strKohlspayEmail+ "&password=" +strKohlspayPaswd;

	// Post the request
	// String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);
	String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);

	// Set the access token in testData
	Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter");

	}

	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 4, testName = "Get Profile WithInvalidAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Get Profile With Invalid AccessToken")
	public void WithInvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");
		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
		// Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		// System.out.println("Author Id"+testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "ASFDKJ14623H");
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 401);
			// Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
			// Utilities.compareAdaterOpenApiResponse(strURL, strURLOAPI,"errors.code,errorCode,error,errors.entity",true);
		}
	}


	@Test(groups = { "regression","functional", "errorhandling" }, enabled = true, priority = 4, testName = "Get Profile withExpiredAccessToken", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Get Profile with Expired AccessToken")
	public void WithExpiredAccessToken() {

		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		// Post the request
		String strURL = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true, mapheader, 200);
		// Utilities.setTestData(strURL, "$.payload.profile.id", "author_id_adapter");
		// System.out.println("Author Id"+testData.get("author_id_adapter"));

		// Validate Response
		validator = new ResponseValidator(strURL);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		// Compare Open API
		if (CompareOAPI) {
			mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
			// Get OAPI ProfileCreate the Json Request for create profile [OAPI]
			String strURLOAPI = RestCall.getRequest(PROFILE_OAPI, Server.OpenApi, true, mapheader, 401);
			// Utilities.setTestData(strURLOAPI, "$.payload.profile.id", "author_id_openapi");
			// Utilities.compareAdaterOpenApiResponse(strURL, strURLOAPI,"errors.code,errorCode,error,errors.entity",true);
		}
	}
	
	@Test(groups = { "regression","KPProvision" }, enabled = true, priority = 4, testName = "Get Profile with KCC Card with KP provision status = false",
			description = "Get Profile with KCC Card KP Provision = false")
	public void UpdateProfileWithKCC() {
		
		//Adding Payment to Profile
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KOHLS_CARD_UPDATE")
				+ ",\"preferredPaymentType\":\"true\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				
		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}
	
	@Test(groups = { "regression","KPProvision" }, enabled = true, priority = 4, testName = "Get Profile with KCC Card with KP provision status = false",
			description = "Get Profile with KCC Card KP Provision = false")
	public void UpdateProfileWithKCCProvisioned() {
		String strURL = "grant_type=password&userId=test@kp30.com&password=qwerty";

		// Post the request
		// String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);
		String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strURL, Server.Adapter, false);

		// Set the access token in testData
		Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter");

		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}
	
	@Test(groups = { "regression","KPProvision" }, enabled = true, priority = 4, testName = "Get Profile with Visa Card should not contain kpProvision tag",
			description = "Get Profile with Visa Card")
	public void UpdateProfileWithVISA() {
		
		//Adding Payment to Profile
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("UPDATE")
				+ ",\"preferredPaymentType\":\"true\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				
		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}
	
	@Test(groups = { "regression","KPProvision" }, enabled = true, priority = 4, testName = "Get Profile with Master Card should not contain kpProvision tag",
			description = "Get Profile with Master Card")
	public void UpdateProfileWithMC() {
		
		//Adding Payment to Profile
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("UPDATE_MASTER")
				+ ",\"preferredPaymentType\":\"true\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				
		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}
	
	@Test(groups = { "regression","KPProvision" }, enabled = true, priority = 4, testName = "Get Profile with Amex Card should not contain kpProvision tag",
			description = "Get Profile with Amex Card")
	public void UpdateProfileWithAMEX() {
		
		//Adding Payment to Profile
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("UPDATE_AMEX")
				+ ",\"preferredPaymentType\":\"true\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				
		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}
	
	@Test(groups = { "regression","KPProvision" }, enabled = true, priority = 4, testName = "Get Profile with Discover Card should not contain kpProvision tag",
			description = "Get Profile with Discover Card")
	public void UpdateProfileWithDisc() {
		
		//Adding Payment to Profile
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("UPDATE_DISCOVER")
				+ ",\"preferredPaymentType\":\"true\",\"action\":\"add\"}}}}";

				// Post the request
				String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				
		//Get the profile to see the Status of KP Provisioned
				strResponse = RestCall.getRequest(PROFILE_ADAPTER, Server.Adapter, true);
				validator = new ResponseValidator(strResponse);
				validator.validateNoErrors();
				validator.validateKPStatus(strResponse);
	}


}
