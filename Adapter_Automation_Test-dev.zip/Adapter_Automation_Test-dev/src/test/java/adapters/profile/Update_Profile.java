package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.V2_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_INFO_OAPI;
import static main.java.common.GlobalVariables.PROFILE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.google.common.io.BaseEncoding;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Features("Profile")
@Stories({ "Update Profile Info" })
public class Update_Profile {

	ResponseValidator validator;
	
	String strUpdateProfEmailAdapter;
	String strUpdateProfEmailOAPI;
	String strUpdateProfPaswd = "Updprof@123";
	String strUpdateProfPaswd1 = "Updprof@1234";
	

	@BeforeMethod(alwaysRun = true)
	public void testSetup() {

		strUpdateProfEmailAdapter = Utilities.getNewEmailID();
		strUpdateProfEmailOAPI = Utilities.getNewEmailID();
		String phoneNumberV2 = Utilities.getNewPhoneNumber();
		testData.put("UNIQUE_PHONE_NUMBER", phoneNumberV2);
		Utilities.createProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter);
		Utilities.createProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi);

		// Login using the above profile through Adapter and set the access token in variable 'free_shipping_token_adapter'
		Utilities.signInProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter, "access_token_updProf_adapter");
		Utilities.signInProfile(strUpdateProfEmailOAPI, strUpdateProfPaswd, Server.OpenApi, "access_token_updProf_oapi");

	}


	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without firstname parameter")
	public void MissingFirstName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("MISSING_FIRSTNAME")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without lastname parameter")
	public void MissingLastName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("MISSING_LASTNAME")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Last Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information with empty firstname parameter")
	public void EmptyFirstName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("MISSING_FIRSTNAME_VALUE")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information with empty lastname parameter")
	public void EmptyLastName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("MISSING_LASTNAME_VALUE")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Last Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information with invalid firstname parameter")
	public void InvalidFirstName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("SPACE_FNAME")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for First Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information with invalid lastname parameter")
	public void InvalidLastName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("SPACE_LNAME")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Last Name.");

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, 400);
			// Compare the result
			// Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information withvalid details ")
	public void ValidProfileUpdate() {

	
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_1") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("UPDATE")+ ","
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
	
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information and password")
	public void ProfileAndPasswordUpdate() throws UnsupportedEncodingException {
		
		String OldPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd1.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_2") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("UPDATE")+ ","
				+ "\"currentPassword\": \"" + OldPassword + "\"," 
				+ "\"encodedPassword\":\"" + encodedPassword + "\"," 
				+ "\"email\": \"" + strUpdateProfEmailAdapter + "\"," 
				+ "\"loyaltyId\": null,"
				+ "\"birthday\": null,"
				+ "\"phone\": { \"phoneNumber\": \"" + testData.get("UNIQUE_PHONE_NUMBER") +"\","
				+ "\"phoneNumberType\": \"Mobile\" },"
				+ "\"preferences\": {\"saleAlerts\": false"
				+ "}}}}"; 
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating valid email in the profile")
	public void ValidEmailUpdate() throws UnsupportedEncodingException{
		Utilities.signInProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter, "access_token_updProf_adapter");
		
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_3") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \"" + "New" + strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentEmail\": \"" + strUpdateProfEmailAdapter + "\""
				+ "}}}"; 
			      
		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating valid email in the profile")
	public void InvalidEmailUpdate() throws UnsupportedEncodingException{
		Utilities.signInProfile(strUpdateProfEmailAdapter, strUpdateProfPaswd, Server.Adapter, "access_token_updProf_adapter");
		
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_3") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \"" + "236324" + "\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentEmail\": \"" + strUpdateProfEmailAdapter + "\""
				+ "}}}"; 
			      
		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002","Invalid value passed for Email.");
		
		
		
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
		
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating with invalid opname in the profile")
	public void InvalidOpname() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"operation\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \"" + "New" + strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + strUpdateProfPaswd.replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=","%3D")+ "\","
				+ "\"currentEmail\": \"" + strUpdateProfEmailAdapter + "\""
				+ "}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0005","The required parameter opName is missing or invalid.");
		

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating without opNmae in the request")
	public void MissingOpname() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{"
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \"" + "New" + strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + strUpdateProfPaswd.replaceAll("\\+", "%2B").replaceAll("/", "%2F").replaceAll("=","%3D")+ "\","
				+ "\"currentEmail\": \"" + strUpdateProfEmailAdapter + "\""
				+ "}}}"; 
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("ERR0005","The required parameter opName is missing or invalid.");
		

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating email to profile information without new email parameter in the request")
	public void EmailUpdateWithoutNewEmail() throws UnsupportedEncodingException {
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_3") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \"\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentEmail\": \"" + strUpdateProfEmailAdapter + "\""
				+ "}}}"; 
			      
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing required parameter Email.");

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
		
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating profile information without current email in the request")
	public void EmailUpdateWithoutCurrentEmail() throws UnsupportedEncodingException {
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_3") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \"" + "New" + strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentEmail\": \""+ "\""
				+ "}}}"; 
			      
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter userId");

		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}

	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating valid password to theprofile information")
	public void ValidPasswordUpdate() throws UnsupportedEncodingException {
		
		
		String oldPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));	
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd1.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_4") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \""+ strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentPassword\": \"" + oldPassword + "\""
				+ "}}}"; 
		
		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
	
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.validateProfileUpadteMessage();
		
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating password to profile information without current password parameter")
	public void PasswordUpdateWithoutCurrentPassword() throws UnsupportedEncodingException  {
		String oldPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));	
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd1.getBytes("UTF-8"));
		
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_4") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \""+ strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"\","
				+ "\"currentPassword\": \"" + oldPassword + "\""
				+ "}}}"; 
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing required parameter Password.");
		
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating password to profile information without oldpassword parameter")
	public void PasswordUpdateWithoutOldPassword() throws UnsupportedEncodingException {

		String oldPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));	
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd1.getBytes("UTF-8"));
			
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_4") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \""+ strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentPassword\": \""+ "\""
				+ "}}}"; 
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
		      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("invalid_request", "Missing required parameter password");
		
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating waek password to profile information ")
	public void WeakPasswordUpdate() throws UnsupportedEncodingException {
		String oldPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));	
		String encodedPassword =BaseEncoding.base64().encode("123".getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_4") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \""+ strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + encodedPassword + "\","
				+ "\"currentPassword\": \"" + oldPassword + "\""
				+ "}}}"; 
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
	
			      
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9998", "The provided password does not meet the requirements.");
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
		      
	@Test(groups = { "Profile_Update" }, enabled = true, priority = 3, testName = "Update Profile Info", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating current password to profile information and validate proper error message is displayed")
	public void CurrentPasswordUpdate() throws UnsupportedEncodingException {
		
		String oldPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));	
		String encodedPassword =BaseEncoding.base64().encode(strUpdateProfPaswd.getBytes("UTF-8"));
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"opName\":\"" + testData.get("UPDATE_ACTION_4") + "\","
				+ "\"profile\":{\"customerName\":" 
				+  JsonString.getCustomerNameJson("VALID")+ ","
				+ "\"email\": \""+ strUpdateProfEmailAdapter + "\","
				+ "\"encodedPassword\":\"" + oldPassword + "\","
				+ "\"currentPassword\": \"" + oldPassword + "\""
				+ "}}}"; 
		
		// Post the request
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_updProf_adapter"));
	
		
		// Post the request
		String strResponse = RestCall.putRequest(V2_PROFILE_ADAPTER, strPayload, Server.Adapter, true,mapheader);
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF9500","Old and current passwords can't be reused. Please create a new password.");
		if (CompareOAPI) {
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_updProf_oapi")); 
			
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_INFO_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}
	
	
}
