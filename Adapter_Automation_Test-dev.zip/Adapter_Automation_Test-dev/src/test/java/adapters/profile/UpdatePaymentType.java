package test.java.adapters.profile;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.PROFILE_PAYMENT_ADAPTER;
import static main.java.common.GlobalVariables.*;

import org.testng.annotations.Test;

import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

@Features("Profile")
@Stories({ "Update Payment type" })

public class UpdatePaymentType {

	ResponseValidator validator;


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with edit action", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with edit action")
	public void EditAction() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("UPDATE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"edit\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for action.");

		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);

			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with MissingCardName",
			description = "Updating payment type to the profile with Missing Card Name")
	public void MissingCardName() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		testData.put("access_token_adapter_updatepayment_prof", testData.get("access_token_adapter_updatepayment"));
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment_prof"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("MISSINGCARDNAME")
				+ "\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);

		// validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id_prof");

		if (CompareOAPI) {
			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "access_token_oapi_updatepayment");
			testData.put("access_token_oapi_updatepayment_prof1", testData.get("access_token_oapi_updatepayment"));
			mapheader.put("access_token", testData.get("access_token_oapi_updatepayment_prof1"));
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id_prof");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with NumericCardName",
			dependsOnMethods = "MissingCardName",
			description = "Updating payment type to the profile with Numeric Card Name")
	public void NumericCardName() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("NUMERICCARDNAME_UPDATE")
				+ ",\"ID\":\""
				+ testData.get("adapter_payment_id_prof") + "\",\"preferredPaymentType\":\"true\",\"action\":\"update\"}}}}";

		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment_prof"));
		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			mapheader.clear();
			mapheader.put("access_token", testData.get("access_token_oapi_updatepayment_prof1"));
			// Create the Json Request for Cart
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"paymentType\":"
					+ JsonString.getPaymentTypeJson("NUMERICCARDNAME_UPDATE")
					+ ",\"ID\":\""
					+ testData.get("openAPI_payment_id_prof") + "\",\"preferredPaymentType\":\"true\",\"action\":\"update\"}}}}";
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayloadOAPI, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with SpecialCharcterCardName",
			description = "Updating payment type to the profile with Special charcter in Card name")
	public void SpecialCharcterCardName() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "access_token_adapter_updatepayment");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_adapter_updatepayment"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("SPECCHAR_CARDNAME")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.nodeMatches("$.payload.id", ".+", "Payment ID should be present in the response");
		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		
		if (CompareOAPI){
			String strOCBEmailOAPI = Utilities.getNewEmailID();
			Utilities.createProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmailOAPI, strOCBPaswd, Server.OpenApi, "access_token_oapi_updatepayment_prof");
		mapheader.clear();
		mapheader.put("access_token", testData.get("access_token_oapi_updatepayment_prof"));

			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "payload.id", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with NonNumericCardNum", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with NonNumeric CardNumber")
	public void NonNumericCardNum() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("NONNUMERIC_CARDNUM")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Card Number.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with GreaterThan16DigitCardNum", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with card number greater than 16 digits")
	public void GreaterThan16DigitCardNum() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("ABOVE16DIGIT_CARDNUM")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Card Number.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with INVALIDCardType", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Invalid card")
	public void INVALID_CardType() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("INVALIDCARDTYPE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Card Type.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with INVALIDDateFormat", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with invalid date format")
	public void INVALID_DateFormat() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("INVALIDDATEFORMAT")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for Expiry Date.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with MissingDate", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Missing Date")
	public void MissingDate() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("MISSINGDATE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter Expiry Date.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with InValidID", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with invalid ID")
	public void InValidID() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("INVALID_ID")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"update\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1002", "Invalid value passed for ID.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp", "errorhandling" }, enabled = true, priority = 30, testName = "Update Payment Type with MissingID", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Missing ID")
	public void MissingID() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("MISSING_ID")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"update\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("PROF1000", "Missing Required Parameter id.");

		// Utilities.setTestData(strResponse, "$.payload.id", "adapter_payment_id");
		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, 400);
			// Utilities.setTestData(strResponseOAPI, "$.payload.id", "openAPI_payment_id");
			// Compare the result
			Utilities.compareAdaterOpenApiResponse(strResponse, strResponseOAPI, "errorCode,error,errors.entity", true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with DiscoverCardType",
			dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Discover Card")
	public void DiscoverCardType() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("DISCOVERUPDATE_NEW")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateProfileUpadteMessage();

		// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);
		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with AmexCardType", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Amex Card")
	public void AmexCardType() {

		String strOCBEmail = Utilities.getNewEmailID();
		String strOCBPaswd = "Ocb@1234";
		Utilities.createProfile(strOCBEmail, strOCBPaswd, Server.Adapter);

		// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strOCBEmail, strOCBPaswd, Server.Adapter, "OCB_access_token_adapter");

		// Update cart through OAPI
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("OCB_access_token_adapter"));

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("AMEXUPDATE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true, mapheader);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			String strOCBEmail1 = Utilities.getNewEmailID();
			String strOCBPaswd1 = "Ocb@1234";
			Utilities.createProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi);

			// Login using the above profile through OAPI and set the access token in variable 'OCB_access_token_adapter'
			Utilities.signInProfile(strOCBEmail1, strOCBPaswd1, Server.OpenApi, "OCB_access_token_oapi");

			// Update cart through OAPI
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("OCB_access_token_oapi"));
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true, mapheader);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with KohlsCardType", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Kohls Card")
	public void KohlsCardType() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KOHLS_CARD_UPDATE")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);

		}
	}


	@Test(groups = { "regression","functional", "mfp" }, enabled = true, priority = 30, testName = "Update Payment Type with MasterCardType", dependsOnMethods = "test.java.adapters.smoke.SmokeTest.signInProfile",
			description = "Updating payment type to the profile with Master Card")
	public void MasterCardType() {

		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("MASTER_UPDATE_2")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateProfileUpadteMessage();

		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);

		}
	}

	@Test(groups = { "regression","functional", "MSM-2661" }, enabled = true, priority = 30, testName = "Update Payment Type with DiscoverCardType",
			description = "Updating payment type to the profile with Discover Card")
	public void KCCKPStatus() {

		// Create a new profile through OAPI
		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Qwerty@1";
		Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
		
		// Login using the above profile through Adapter and set the access token in variable 'OCB_access_token_adapter'
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "access_token_adapter");

			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_adapter"));
			mapheader.put("content-type", "application/json");
		
		// Create the Json Request for Cart
		String strPayload = "{\"payload\":{\"profile\":{\"paymentType\":"
				+ JsonString.getPaymentTypeJson("KCC_CVV2_ADD")
				+ ",\"preferredPaymentType\":\"false\",\"action\":\"add\"}}}}";

		// Post the request
		String strResponse = RestCall.postRequest(PROFILE_PAYMENT_ADAPTER, strPayload, Server.Adapter, true);

		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateProfileUpadteMessage();
		
		mapheader.clear();
		strResponse = RestCall.getRequest(V2_PROFILE_ADAPTER, Server.Adapter, true);
		validator = new ResponseValidator(strResponse);
		validator.nodeEquals("$.payload.profile.paymentTypes[0].kpProvisioned", "false", "KP status is not false or found");
		/*// Compare Adapter and OAPI
		if (CompareOAPI) {
			// Post the request
			String strResponseOAPI = RestCall.postRequest(PROFILE_PAYMENT_OAPI, strPayload, Server.OpenApi, true);
		}*/
	}
}
