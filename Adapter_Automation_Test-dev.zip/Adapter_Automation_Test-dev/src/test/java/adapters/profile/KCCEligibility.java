package test.java.adapters.profile;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;
import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import main.java.common.TestData;
import main.java.common.RestCall;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Profile")
@Stories({ "KCC preQualify Eligibility" })


public class KCCEligibility {
	

	ResponseValidator validator;

	@BeforeMethod(alwaysRun = true)
	public void createProfile() {

		String strEmail = Utilities.getNewEmailID();
		String strPaswd = "Pass@123";
		Utilities.createProfile(strEmail, strPaswd, Server.Adapter);
				// Login using the above profile through Adapter and set the access token in variable 'Bopus_access_token'
		Utilities.signInProfile(strEmail, strPaswd, Server.Adapter, "Bopus_access_token");

		// Update cart through Adapter
		mapheader.clear();   // clear any headers set by previous TCs
		mapheader.put("access_token", testData.get("Bopus_access_token"));
		
	}

	@Test(groups = { "KCCEligibility-NAP229","Prequal" }, enabled = true, testName = "Get KCCEligibility With valid AccessToken", 
			description = "Get KCCEligibility With Valid AccessToken")
	public void KCC_EligibilityWithValidToken() {

		mapheader.put("access_token", testData.get("Bopus_access_token"));
		mapheader.put("x-channel", "ios");
		mapheader.put("x-correlationID", "KCC-123");
		// Post the request
		String strURL=KCC_ELIGIBILITY;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateNoErrors();
		validator.nodeMatches("$.payload.displaypreQualBanner","true|false","Banner should be displayed based on eligibility");
		validator.nodeMatches("$.payload.percentageDiscount",".+","percentageDiscount should be displayed if user is quallified for KCC");
		

		
	}
	
	@Test(groups = { "KCCEligibility-NAP229","Prequal" }, enabled = true, testName = "Get KCCEligibility With Invalid AccessToken", 
			description = "Get KCCEligibility With Invalid AccessToken")
	public void KCC_EligibilityWithInvalidAccessToken() {

		mapheader.put("access_token", "ASFDKJ14623H");
		mapheader.put("x-channel", "ios");
		mapheader.put("x-correlationID", "KCC-123");
		// Post the request
		String strURL=KCC_ELIGIBILITY;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		
	}

	@Test(groups = { "KCCEligibility-NAP229","Prequal" }, enabled = true, testName = "Get KCCEligibility With Expired AccessToken", 
			description = "Get KCCEligibility With Expired AccessToken")
	
	public void KCC_EligibilityWithExpiredAccessToken() {
		mapheader.put("access_token", "RnHLeCr6V6C61joKk7ffgGmLKNzh");
		mapheader.put("x-channel", "ios");
		mapheader.put("x-correlationID", "KCC-123");
		// Post the request
		String strURL=KCC_ELIGIBILITY;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, true, mapheader, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("keymanagement.service.access_token_expired", "Access Token expired");

		
	}
	
	@Test(groups = { "KCCEligibility-NAP229","Prequal" }, enabled = true, testName = "Get KCCEligibility Without AccessToken", 
			description = "Get KCCEligibility Without AccessToken")
	
	public void KCC_EligibilityWithoutAccessToken() {
		// Post the request
		String strURL=KCC_ELIGIBILITY;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false, 200);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		
	}

	@Test(groups = { "KCCEligibility-NAP229","Prequal" }, enabled = true, testName = "Get KCCEligibility Without Headers", 
			description = "Get KCCEligibility Without Headers")
	
	public void KCC_EligibilityWithoutHeaders() {
		// Post the request
		String strURL=KCC_ELIGIBILITY;		
		strURL = Utilities.changeURL(strURL);
		String strResponse = RestCall.getRequest(strURL, Server.Adapter, false);
		
		// Validate Response
		validator = new ResponseValidator(strResponse);
		validator.validateExpectedErrors("401", "Invalid token. Please enter valid token.");

		
	}
}
