package main.java.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdapterExceptionLog extends TestData {

	public static String main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String strAdapterURL =  testData.get("Adapter_Environemnt").trim();
		if(System.getenv("URL")!=null){
			strAdapterURL = System.getenv("URL");
		}
		else{
			System.out.println("WARNING !! CANNOT GET JENKINS PARAMETER");
			strAdapterURL = "http://kd41.km.sl.edst.ibm.com/";
		}
		File file = new File("target/allure-results");
		if (!file.exists())
			file.mkdirs();
		FileWriter fw = new FileWriter("target/allure-results/environment.properties", true);

		fw.write("Starting PII Validation" + "\n");
		fw.close();
		System.out.println("\n\n Starting PII Validation for " + strAdapterURL);
		
		File f = new File("c:\\temp\\pii.txt");
		if (f.exists()) f.delete();
		
		
		//Capture adapter logs and write to temp file, 
		String str = getRequestpii(strAdapterURL+"/mfp/mfp-logs/adapterLogs/adapterException.log",  false);
		
		if (str.equals("FAIL"))
	 		return null;
		
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		
		
		String line;
		StringBuffer sb = new StringBuffer();
		
		sb.append(r.readLine()+"\n");
		
		while ((line = r.readLine() )!=null){
			
			if (line.startsWith(("TID"))|line.startsWith(("NAID"))){
				String strReq = new String(sb);
				if (!strReq.trim().equals(""))
					validateRequest(strReq);
				sb = new StringBuffer();
			}
			
			sb.append(line+"\n");
			
		}
		
		r.close();
		
		System.out.println(" ** PII Validation Completed !!\n\n");
		return sb.toString();
	}
	
	
public static void main1(String[] args) throws Exception {
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		String line;
		StringBuffer sb = new StringBuffer();
		while ((line = r.readLine() )!=null){
			sb.append(line+"\n");
		}
		
		
		validateRequest(sb.toString());
	}
	
	static void validateRequest(String s){
    	System.out.println("Validating request" + s);
		String strPayload = s;//.substring(s.indexOf("{\""),s.length());
//		System.out.println("Payload : "+strPayload);
		
		String patternRules[] = {".*j.exception.*"};
		
		
		Pattern pattern;
		for (String strRule : patternRules) {
	        pattern = Pattern.compile(strRule);
	         	
		    Matcher matcher = pattern.matcher(strPayload);
			
			int matchCount = 0; 
			while(matcher.find()){
						
				String strMatch = matcher.group(0);
				
				if (true) {
				
					if (strMatch.contains("KMPREST0001"))
						pattern = Pattern.compile("(TID|NAID).*ERROR\\sj.exception\\s.*(POST|GET|PUT|DELETE).*Status:400.*.");
					
					if (!pattern.matcher(strMatch).find()){
						System.out.println("\n\n\n\nRule Violation in below Request. Found PII " + strMatch);
						
						//s= s.replace(strMatch, "<red>" + strMatch + "</red>");
						System.out.println("**********************\n" + s + "\n*****************************");
					
					}
				}
						
			}
		}
		
		
	}
	
	
public static String getRequestpii(String strURL, boolean RegisteredUser){
		
		URL url;
		try {
			url = new URL(strURL);
			
			
			
		

		    Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
		    HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);        
		    conn.setRequestMethod("GET");
		    
		    
		    //Set the Accept header
			conn.setRequestProperty("Accept", "application/json");  
			
		
		       
		    conn.setDoOutput(true);                
		   
		    StringBuffer sb = new StringBuffer();
		    if (conn.getResponseCode() != 200) {
		        System.out.println("\n\n**Error : Logs are not enabled for this environment : "
		                + conn.getResponseCode() + "\n\n\n");
		        return "FAIL";
		    }
		
		    if(conn.getResponseCode() == 200) {
		        BufferedReader br = new BufferedReader(new InputStreamReader(
		                (conn.getInputStream())));
		
		        String output;
		        
		        BufferedWriter w = new BufferedWriter(new FileWriter("C:\\temp\\pii.txt"));
		        
		        while ((output = br.readLine()) != null) {
		        	w.write(output + "\n");
//		            sb.append(output+"\n");               
		        }
		        
		        w.write("\nTID-");
		         
		        w.flush();
		        w.close();	
		       
		                   
		
		    }
		    conn.disconnect();    
		    
		    //System.out.println(sb.toString());
		    return sb.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}

	}

}
