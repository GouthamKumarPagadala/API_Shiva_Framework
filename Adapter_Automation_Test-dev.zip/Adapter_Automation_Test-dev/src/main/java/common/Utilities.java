package main.java.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.RandomStringUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONException;
import org.skyscreamer.jsonassert.FieldComparisonFailure;
import org.skyscreamer.jsonassert.JSONCompare;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONCompareResult;
import org.skyscreamer.jsonassert.comparator.DefaultComparator;
import org.testng.Assert;

import static main.java.common.GlobalVariables.*;
import static main.java.common.TestData.mapheader;
import static main.java.common.TestData.testData;

import com.jayway.jsonpath.*;

import groovy.json.JsonLexer;
import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import main.java.report.HTMLReporter;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.model.SeverityLevel;

public class Utilities {
	
	private static final byte[] cryptoKeyValues = new byte[]{(byte)84, (byte)104, (byte)105, (byte)115, (byte)73, (byte)115, (byte)65, (byte)83, (byte)101, (byte)99, (byte)114, (byte)101, (byte)116, (byte)75, (byte)101, (byte)121};

	static ResponseValidator	validator;
	String						strResponse;
	Object						document;


	public Utilities(String strResponse) {
		this.strResponse = strResponse;
		document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
	}
	
	public enum CompareType {
		FULL,  PRICE, CART, CART_V2, ORDER, ORDER_V2,
		ERROR, PAYMENT, SHIPADDRESS, BZV_REVIEW, PROMOCODE, BALANCE
	}


	public static String getNewEmailID() {

		try {
			Thread.sleep(2000);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return "autopf" + System.nanoTime() + "@bh.exacttarget.com";
	}

	public static String changeURL(String url) {

		if (url.contains("v1/profile/prequal/eligibility")) {
			url = url.replaceAll("http://", "https://");
			
		}

		else if(url.contains("v1/profile/prequal/kcc")) {
			url = url.replaceAll("http://", "https://");
		}
		
		else if (url.contains("v1/profile/prequal/inquiry")) {
			url = url.replaceAll("http://", "https://");
		}
		return url;
	}

	public static String getRandom() {

		try {
			Thread.sleep(2000);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return String.valueOf(System.nanoTime());
	}


	public static void setTestData(String strResponse, String strJsonPath, String strKEY) {

		try {
			String strActual = String.valueOf(JsonPath.read(strResponse, strJsonPath));
			testData.put(strKEY, strActual);
			System.out.println("Setting testdata " + strActual + " for key " + strKEY);
		}
		catch (InvalidPathException e) {
			Assert.fail("Invalid Json Path provided" + strJsonPath);
			e.printStackTrace();
		}
	}


	public static String getJsonNodeValue(String strResponse, String strJsonPath) {

		String strActual = "";
		try {
			strActual = String.valueOf(JsonPath.read(strResponse, strJsonPath));

		}
		catch (InvalidPathException e) {
			Assert.fail("Invalid Json Path provided" + strJsonPath);
			e.printStackTrace();
		}

		return strActual;
	}
	
	public static String getRandomName() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 5) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }


	public static void getEnabledFeatures(String strResponse) {

		System.out.println("Trying to get enabled features");
		/*
		 * String patternStr = "\"Feature.*?\":.*?,"; Pattern pattern = Pattern.compile(patternStr); Matcher matcher = pattern.matcher(strResponse);
		 * 
		 * if(matcher.find()){ System.out.println(matcher.group(0)); }
		 */

		String[] strLines = strResponse.split("\",");
		String strFeatures = "", strEndPoints = "";

		for (String strLine : strLines) {
			strLine = strLine.toLowerCase();
			if (strLine.contains("feature") && strLine.contains("true")) {
				strLine = strLine.replace(":", "").replace("feature", "").replace("true", "").replace("enabled", "").replace("\"", "");
				strFeatures = strFeatures + strLine.toUpperCase() + ", ";
			}

			if (strLine.contains("walletandloyaltybaseurl\"") || strLine.contains("addtoregistryurl")) {
				strLine = strLine.substring(strLine.indexOf("://") + 3, strLine.indexOf("."));
				strEndPoints = strEndPoints + strLine.toUpperCase() + ", ";

			}
		}

		if (strFeatures.trim().endsWith(","))
			strFeatures = strFeatures.substring(0, strFeatures.length() - 1);

		if (strEndPoints.trim().endsWith(","))
			strEndPoints = strEndPoints.substring(0, strEndPoints.length() - 1);

		HTMLReporter.addReportingProperties("Features_Enabled=" + strFeatures);
		HTMLReporter.addReportingProperties("Other_End_Points=" + strEndPoints);

	}
	public static void validateFeatures(String strResponse) {

		System.out.println("Trying to get enabled features");
		/*
		 * String patternStr = "\"Feature.*?\":.*?,"; Pattern pattern = Pattern.compile(patternStr); Matcher matcher = pattern.matcher(strResponse);
		 * 
		 * if(matcher.find()){ System.out.println(matcher.group(0)); }
		 */

		String[] strLines = strResponse.split("\",");
		String[] strFeatures = new String[100];
		String endpoint="";
		
		for (String strLine : strLines) {
		//	strLine = strLine.toLowerCase();
			if (strLine.contains("payload") && strLine.contains("config")) {
				continue;
			}
			
			endpoint=strLine.replace("\"", "");
			strFeatures=endpoint.split("\":");
			
			/*strLine = strLine.replace(":", "").replace("feature", "").replace("true", "").replace("enabled", "").replace("\"", "");
			strFeatures = strFeatures + strLine.toUpperCase() + ", ";*/

			
		}
		System.out.println(strFeatures[1]);

		/*if (strFeatures.trim().endsWith(","))
			strFeatures = strFeatures.substring(0, strFeatures.length() - 1);

		if (strEndPoints.trim().endsWith(","))
			strEndPoints = strEndPoints.substring(0, strEndPoints.length() - 1);

		HTMLReporter.addReportingProperties("Features_Enabled=" + strFeatures);
		HTMLReporter.addReportingProperties("Other_End_Points=" + strEndPoints);*/

	}


	public static void getMFPVersion(String strResponse) {

		String strMFPVersion = "";

		System.out.println("Trying to get MFP Version");
		String patternStr = "MobileFirst Administration Services version.*?started.";
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(strResponse);

		if (matcher.find()) {
			System.out.println(matcher.group(0));
			strMFPVersion = matcher.group(0);
		}

		/*
		 * String[] strLines = strResponse.split("[");
		 * 
		 * 
		 * 
		 * 
		 * 
		 * for (String strLine : strLines){ if (strLine.contains("MobileFirst Administration Services version")){ strMFPVersion = strLine.substring(strLine.indexOf("MobileFirst Administration Services version")+"MobileFirst Administration Services version".length(), strLine.length()); } }
		 */

		if (!strMFPVersion.equals("")) {
			strMFPVersion = strMFPVersion.replace(" started", "");
			strMFPVersion = strMFPVersion.replace("MobileFirst Administration Services version ", "");

		}

		HTMLReporter.addReportingProperties("MFP_Version=" + strMFPVersion);

	}


	// Compare two Json and provide the difference by ignoring the given key
	// blnBaseOpenApI=true will return (Base) Open API vs Adapter Response
	// blnBaseOpenApI=false will return (Base) Adapter vs Open API Response
	@Step("Responses from Adapter and Open API should be equal")
	public static List<String> compareAdaterOpenApiResponse(String strJson1, String strJson2, String strIgnore, boolean blnBaseOpenApI) {

		String strUniqueDiff = "";

		List<String> lsJson1 = convertJsonToList(strJson1);
		List<String> lsJson2 = convertJsonToList(strJson2);
		List<String> lsDiff1 = new ArrayList<String>(lsJson1);
		lsDiff1.removeAll(lsJson2);

		List<String> lsDiff2 = new ArrayList<String>(lsJson2);
		lsDiff2.removeAll(lsJson1);

		List<String> lsDiff = new ArrayList<String>(lsDiff1);
		// lsDiff.add("\n\n\n\n");
		lsDiff.addAll(lsDiff2);

		// To Ignore any Tag/Value
		List<String> lsFinalDiff = new ArrayList<String>();
		StringTokenizer arrIgnore = new StringTokenizer(strIgnore, ",");
		if (!arrIgnore.hasMoreTokens()) {
			lsFinalDiff.addAll(lsDiff);
		} else {
			for (int i = 0; i < lsDiff.size(); i++) {
				boolean blnIngore = false;

				String strDiffVal = "";
				while (arrIgnore.hasMoreTokens()) {
					String strTemp = arrIgnore.nextToken() + ":";
					strDiffVal = lsDiff.get(i);
					strDiffVal = strDiffVal.replaceAll("ARRAY_", "");
					while (strDiffVal.contains(".RECORD_")) {
						String strPre = strDiffVal.substring(0, strDiffVal.indexOf(".RECORD_"));
						String strPost = strDiffVal.substring(strDiffVal.indexOf(".RECORD_") + 8);
						strPost = strPost.substring(strPost.indexOf("."));
						strDiffVal = strPre + strPost;
					}
					if (strDiffVal.indexOf(strTemp) == 0) {
						blnIngore = true;
						break;
					}
				}

				if (blnIngore == false && !strDiffVal.equals("") && !(strDiffVal.contains("productTitle"))) {
					lsFinalDiff.add(strDiffVal);
				}
			}
		}

		List<String> lsFinalDiffFormatted = new ArrayList<String>();

		for (String str : lsFinalDiff) {
			str = str.replaceAll("RECORD_[0-9]+\\.(ARRAY_|)", "");
			str = str.replace("ARRAY_", "");
			lsFinalDiffFormatted.add(str);

		}

		if (!lsFinalDiffFormatted.isEmpty()) {
			// System.out.println("Error in compare oapi " + lsFinalDiff.toString());
			HTMLReporter.attachToReportComparison(lsFinalDiffFormatted.toString());
		}
		Assert.assertTrue(lsFinalDiffFormatted.isEmpty(), "Adapter and OpenAPI Responses are not matching");

		return (List<String>) lsFinalDiffFormatted;
	}


	// Convert the Json to a List with Key Value separated by colon
	public static ArrayList<String> convertJsonToList(String strJson) {

		JsonLexer jsonLexer = new JsonLexer(new StringReader(strJson));
		List<String> lsJson = new ArrayList<String>();
		String strAllParentID = "";
		String strTempKey = "";
		String strKey = "";
		String strValue = "";
		int iRec = 0;
		boolean blnKeyValAdd = false;

		String strFlag = "FIND-KEY";
		while (jsonLexer.hasNext()) {
			String strText = jsonLexer.next().getText().trim();
			if (strText.equals("\"\""))
				strText = "null";
			if (strFlag == "FIND-KEY") {
				String patternStr = "[A-Za-z0-9]";
				Pattern pattern = Pattern.compile(patternStr);
				Matcher matcher = pattern.matcher(strText);
				if (matcher.find()) {
					if (strText.startsWith("\"")) {
						strTempKey = strText.substring(1, strText.length() - 1);
					} else {
						strTempKey = strText;
					}
				}
			} else if (strFlag == "FIND-VALUE") {
				String patternStr = "[A-Za-z0-9]";
				Pattern pattern = Pattern.compile(patternStr);
				Matcher matcher = pattern.matcher(strText);
				if (matcher.find()) {
					if (strText.startsWith("\"")) {
						strValue = strText.substring(1, strText.length() - 1);
					} else {
						strValue = strText;
					}
				} else if (strText.equals(",")) {
					if (strAllParentID == "") {
						lsJson.add(strKey + ":" + strValue);
					} else {
						lsJson.add(strAllParentID + "." + strKey + ":" + strValue);
					}
					blnKeyValAdd = true;
					strFlag = "FIND-KEY";
				} else if (strText.equals("}")) {
					if (strAllParentID == "") {
						lsJson.add(strKey + ":" + strValue);
					} else {
						lsJson.add(strAllParentID + "." + strKey + ":" + strValue);
					}
					blnKeyValAdd = true;
					strFlag = "FIND-KEY";
				} else if (strText.equals("]")) {
					if (strKey != "") {
						lsJson.add(strAllParentID + "." + strKey + ":" + strValue);
					}
					blnKeyValAdd = true;
					strFlag = "FIND-KEY";
				}
			}
			if (strText.equals(":")) {
				strKey = strTempKey;
				blnKeyValAdd = false;
				strFlag = "FIND-VALUE";
			}
			if (strText.equals("[")) {
				if (strAllParentID == "") {
					strAllParentID = "ARRAY_" + strKey;
				} else {
					strAllParentID = strAllParentID + "." + "ARRAY_" + strKey;
				}
				strFlag = "FIND-KEY";
			}
			if (strText.equals("{")) {
				if (strAllParentID != "") {
					StringTokenizer arrParent = new StringTokenizer(strAllParentID, ".");
					String strTemp = "";
					int iMaxChild = arrParent.countTokens();
					for (int i = 0; i < iMaxChild; i++) {
						strTemp = arrParent.nextToken();
					}
					if (strTemp.startsWith("ARRAY_")) {
						iRec = 1;
						strAllParentID = strAllParentID + "." + "RECORD_" + iRec;
					} else {
						if (strFlag == "FIND-VALUE") {
							strAllParentID = strAllParentID + "." + strKey;
						}
					}
				} else {
					strAllParentID = strKey;
				}
				strFlag = "FIND-KEY";
			}
			if (strText.equals("]")) {
				if (blnKeyValAdd == false) {
					lsJson.add(strAllParentID + ":" + "null");
					blnKeyValAdd = true;
				}
				StringTokenizer arrParent = new StringTokenizer(strAllParentID, ".");
				strAllParentID = "";
				String strTemp = "";
				int iMaxChild = arrParent.countTokens() - 1;
				for (int i = 0; i < iMaxChild; i++) {
					String strParent = arrParent.nextToken();
					strTemp = strParent;
					if (strAllParentID == "") {
						strAllParentID = strParent;
					} else {
						strAllParentID = strAllParentID + "." + strParent;
					}
				}
				if (strTemp.startsWith("ARRAY_")) {
					arrParent = new StringTokenizer(strAllParentID, ".");
					strAllParentID = "";
					iMaxChild = arrParent.countTokens() - 1;
					for (int i = 0; i < iMaxChild; i++) {
						String strParent = arrParent.nextToken();
						if (strAllParentID == "") {
							strAllParentID = strParent;
						} else {
							strAllParentID = strAllParentID + "." + strParent;
						}
					}
				}
			}
			if (strText.equals("}")) {
				if (blnKeyValAdd == false) {
					lsJson.add(strAllParentID + ":" + "null");
					blnKeyValAdd = true;
				}
				StringTokenizer arrParent = new StringTokenizer(strAllParentID, ".");
				strAllParentID = "";
				int iMaxChild = arrParent.countTokens() - 1;
				for (int i = 0; i < iMaxChild; i++) {
					String strParent = arrParent.nextToken();
					if (strAllParentID == "") {
						strAllParentID = strParent;
					} else {
						strAllParentID = strAllParentID + "." + strParent;
					}
				}
				iMaxChild = arrParent.countTokens();
				if (iMaxChild > 0) {
					for (int i = iMaxChild - 1; i < iMaxChild; i++) {
						String strTemp = arrParent.nextToken();
						if (strTemp.startsWith("RECORD_")) {
							iRec = Integer.parseInt(strTemp.substring(strTemp.lastIndexOf("_") + 1));
							iRec++;
							strAllParentID = strAllParentID + "." + "RECORD_" + iRec;
						}
					}
				}
			}
		}
		return (ArrayList<String>) lsJson;
	}


	public static String urlEncodeString(String strToEncode) {

		try {
			strToEncode = URLEncoder.encode(strToEncode, "UTF-8").replace("+", "%20");
		}
		catch (Exception e) {
		}

		return strToEncode;
	}

	@Step("Create new Profile")
	public static void createProfile(String strUserEmail, String strPassword, Server server) {
		
		
		String strTemp = strPassword.replaceAll("[a-zA-z0-9]+", "");
		
		if (strPassword.length()<8 || (strTemp.length()==0)){
			System.out.println("*** PASWD_ERR " + strPassword);
			Assert.fail("Password requirement not met" + strPassword);
		}
		
		

		if (server == Server.Adapter) {
			// Create the Json Request for create profile
			String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + strPassword + "\","
					+ "\"email\":\"" + strUserEmail + "\"}}}";

			// Post the request
			String strResponse = RestCall.simplePostRequest(PROFILE_ADAPTER, strPayload, server, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();
			validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		} else {

			// Create the Json Request for create profile
			String strPayloadOAPI = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"" + strPassword + "\","
					+ "\"email\":\"" + strUserEmail + "\"}}}";

			// Post the request
			String strResponseOAPI = RestCall.simplePostRequest(PROFILE_CREATE_OAPI, strPayloadOAPI, Server.OpenApi, false);
			validator = new ResponseValidator(strResponseOAPI);
			validator.validateNoErrors();
			
			validator.nodeEquals("$.payload.message", "Account Created Successfully", "Account should be created successfully");

		}
	}
	
	@Step("Generate ShipToID")
	public static String getShipToID() {
		String strUserEmail = Utilities.getNewEmailID();
		//Create Profile
			String strPayload = "{\"payload\":{\"profile\":{\"customerName\":"
					+ JsonString.getCustomerNameJson("VALID") + ","
					+ "\"password\":\"Qwerty@123\","
					+ "\"email\":\"" + strUserEmail + "\"}}}";
			RestCall.postRequest(PROFILE_ADAPTER, strPayload, Server.Adapter, false);
			//signin Profile
			strPayload = "grant_type=password&userId=" + strUserEmail + "&password=Qwerty@123";
			String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);
			Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", "access_token_adapter");
			
			//Add shipAddress
			strPayload = "{\"payload\":{\"profile\":{\"shipAddress\":"
					+ JsonString.getBillAddressJson("UPDATE")
					+ ",\"preferredAddr\":\"true\",\"action\":\"add\"}}}}";
			strResponse = RestCall.postRequest(PROFILE_SHIPPING_ADDRESS_ADAPTER, strPayload, Server.Adapter, true);
			String shipToID = Utilities.getJsonNodeValue(strResponse, "$.payload.id");
			return shipToID;
	}
	
	public static String MasterpassEnc(String cardNum) throws Exception{
		String cardNumber = cardNum;
		String encryptedText = getEncrptedPassPhraseText(cardNumber.substring(0, cardNumber.length() - 4));
		return encryptedText + cardNum.substring(cardNum.length()-4,cardNum.length());
	}
	
	public static String getEncrptedPassPhraseText(String plainPassPhraseText) throws Exception {
	    if(plainPassPhraseText != null) {
	        String aCryptoSalt = generateCryptoSalt();
	        return encryptPassPhrase(plainPassPhraseText, aCryptoSalt);
	    } else {
	        throw new Exception("plainPassPhraseText is null");
	    }
	}

	private static String generateCryptoSalt() {
	    return RandomStringUtils.randomAlphanumeric(5);
	}
	
	private static String encryptPassPhrase(String cryptoMessage, String cryptoSalt) throws Exception {
	    SecretKeySpec key = new SecretKeySpec(cryptoKeyValues, "AES");
	    Cipher aCipher = Cipher.getInstance("AES");
	    aCipher.init(1, key);
	    String valueToEnc = null;
	    String eValue = cryptoMessage;

	    for(int counter = 0; counter < 1; ++counter) {
	        valueToEnc = cryptoSalt + eValue;
	        byte[] encValue = aCipher.doFinal(valueToEnc.getBytes());
	        eValue = (new Base64()).encodeAsString(encValue);
	    }

	    return eValue;
	}
	
	@Step("Add Item to Cart")
	public static void AddItemtoCart(String skucode, String qty, Server server) {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getCartJson("VALID_ADD", skucode, qty)
				+ "]}}}";
		
		String strResponseOAPIAddCart = "";
			mapheader.clear();   // clear any headers set by previous TCs
			if(server == Server.Adapter){
			mapheader.put("access_token", testData.get("access_token_adapter"));
			strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, server, true, mapheader);
			}
			else if(server == Server.OpenApi){
			mapheader.put("access_token", testData.get("access_token_oapi"));
			strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, server, true, mapheader);
			}		
			
			Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
			
		
	}
	
	@Step("Add Item to Cart")
	public static void AddBopusItemtoCart(String skucode, String qty, String StoreNum, Server server) {

		String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
				+ JsonString.getBopusCartJson("VALID", skucode, qty, StoreNum)
				+ "]}}}";
		String strResponseOAPIAddCart = "";
		mapheader.clear();   // clear any headers set by previous TCs
		if(server == Server.Adapter){
		mapheader.put("access_token", testData.get("access_token_adapter"));
		strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, server, true, mapheader);
		}
		else if(server == Server.OpenApi){
		mapheader.put("access_token", testData.get("access_token_oapi"));
		strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, server, true, mapheader);
		}	
			Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartItems[0].cartItemID", "OAPI_CART_ITEM_ID");
			Utilities.setTestData(strResponseOAPIAddCart, "$.payload.cart.cartID", "OAPICART_ID");
		
	}
	
	@Step("Add Payment to Cart")
	public static void AddPaymentTypetoCart(String[] KohlsCash, String[] PromoCodes, Server server) {

		if (server == Server.Adapter||server == Server.OpenApi) {
			
			mapheader.clear();   // clear any headers set by previous TCs
			mapheader.put("access_token", testData.get("access_token_adapter"));
					
		
			String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{";
					
			//Adding PromoCodes if not null
					if(PromoCodes != null){
						strPayloadAddCart+="\"promoCodes\":{\"promoCode\":[{\"code\":\""+PromoCodes[0]+"\",\"action\":\"add\"}";
					if(PromoCodes.length>1)	
						for(int i=1; i<PromoCodes.length; i++){
							strPayloadAddCart+=",{\"code\":\""+PromoCodes[i]+"\",\"action\":\"add\"}";}
					
					strPayloadAddCart+="]}";}
					
			//Adding GiftCard if not null
					if(KohlsCash != null){
						if(PromoCodes != null)
							strPayloadAddCart+=",\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\",\"action\":\"add\"}";
						else
							strPayloadAddCart+="\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\",\"action\":\"add\"}";
					if(KohlsCash.length>2)
						for(int i=2; i<KohlsCash.length/2; i+=2){
					strPayloadAddCart+=",{\"kohlsCashNum\":\""+KohlsCash[i]+"\",\"pin\":\""+KohlsCash[i+1]+"\",\"action\":\"add\"}";
						}
						strPayloadAddCart+="]}";}
			
				strPayloadAddCart+="}}}}";
			
				String strResponseOAPIAddCart = "";
				if (server == Server.Adapter){
					strResponseOAPIAddCart = RestCall.postRequest(CART_ADAPTER, strPayloadAddCart, server, true, mapheader);
				}else if(server == Server.OpenApi){
					strResponseOAPIAddCart = RestCall.postRequest(CART_OAPI, strPayloadAddCart, server, true, mapheader);
				}
			
		}	
		
	}
	
	@Step("Add Payment to Cart")
	public static String PayloadPaymentTypetoCart(String[] KohlsCash, String[] PromoCodes, String action) {
		String strPayloadAddCart = "";
		if(action.equalsIgnoreCase("add")){
			strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"paymentTypes\":{";
					
			//Adding PromoCodes if not null
					if(PromoCodes != null){
						strPayloadAddCart+="\"promoCodes\":{\"promoCode\":[{\"code\":\""+PromoCodes[0]+"\",\"action\":\"add\"}";
					if(PromoCodes.length>1)	
						for(int i=1; i<PromoCodes.length; i++){
							strPayloadAddCart+=",{\"code\":\""+PromoCodes[i]+"\",\"action\":\"add\"}";}
					
					strPayloadAddCart+="]}";}
					
			//Adding KohlsCash if not null
					if(KohlsCash != null){
						if(PromoCodes != null)
							strPayloadAddCart+=",\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\",\"action\":\"add\"}";
						else
							strPayloadAddCart+="\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\",\"action\":\"add\"}";
					if(KohlsCash.length>2)
						for(int i=2; i<KohlsCash.length; i+=2){
					strPayloadAddCart+=",{\"kohlsCashNum\":\""+KohlsCash[i]+"\",\"pin\":\""+KohlsCash[i+1]+"\",\"action\":\"add\"}";
						}
						strPayloadAddCart+="]}";}
			
				strPayloadAddCart+="}}}}";}
		else if(action.equalsIgnoreCase("merge")){
			strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartID\":\"" + testData.get("OAPICART_ID")+"\",\"action\": \"merge\",\"paymentTypes\":{";
			
			//Adding PromoCodes if not null
					if(PromoCodes != null){
						strPayloadAddCart+="\"promoCodes\":{\"promoCode\":[{\"code\":\""+PromoCodes[0]+"\"}";
					if(PromoCodes.length>1)	
						for(int i=1; i<PromoCodes.length; i++){
							strPayloadAddCart+=",{\"code\":\""+PromoCodes[i]+"\"}";}
					
					strPayloadAddCart+="]}";}
					
			//Adding KohlsCash if not null
					if(KohlsCash != null){
						if(PromoCodes != null)
							strPayloadAddCart+=",\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\"}";
						else
							strPayloadAddCart+="\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\"}";
					if(KohlsCash.length>2)
						for(int i=2; i<KohlsCash.length; i+=2){
					strPayloadAddCart+=",{\"kohlsCashNum\":\""+KohlsCash[i]+"\",\"pin\":\""+KohlsCash[i+1]+"\"}";
						}
						strPayloadAddCart+="]}";}
			
				strPayloadAddCart+="}}}}";
		}
				return strPayloadAddCart;
		
	}
	
	@Step("Add Payment to Cart")
	public static String PayloadPaymentSkuTypetoCart(String[] KohlsCash, String[] PromoCodes, String SkuCode, String qty, String action) {

			String strPayloadAddCart = "{\"payload\":{\"cart\":{\"cartItems\" :["
			+ JsonString.getCartJson("VALID_ADD", SkuCode, qty)
			+ "],\"paymentTypes\":{";
			//Adding PromoCodes if not null
					if(PromoCodes != null){
						strPayloadAddCart+="\"promoCodes\":{\"promoCode\":[{\"code\":\""+PromoCodes[0]+"\",\"action\":\"add\"}";
					if(PromoCodes.length>1)	
						for(int i=1; i<PromoCodes.length; i++){
							strPayloadAddCart+=",{\"code\":\""+PromoCodes[i]+"\",\"action\":\"add\"}";}
					
					strPayloadAddCart+="]}";}
					
			//Adding KohlsCash if not null
					if(KohlsCash != null){
						if(PromoCodes != null)
							strPayloadAddCart+=",\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\",\"action\":\"add\"}";
						else
							strPayloadAddCart+="\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+ KohlsCash[0]+"\",\"pin\":\""+KohlsCash[1]+"\",\"action\":\"add\"}";
					if(KohlsCash.length>2)
						for(int i=2; i<KohlsCash.length; i+=2){
					strPayloadAddCart+=",{\"kohlsCashNum\":\""+KohlsCash[i]+"\",\"pin\":\""+KohlsCash[i+1]+"\",\"action\":\"add\"}";
						}
						strPayloadAddCart+="]}";}
			
				strPayloadAddCart+="}}}}";
				return strPayloadAddCart;
		
	}
	
	@Step("Clear Cart")
	public static void removeAllItemCart(Server server, String strAccessToken) {

		System.out.println(strAccessToken);
		
		if ((server == Server.Adapter) || (server == Server.OpenApi)) {
			mapheader.clear();
			mapheader.put("access_token", strAccessToken);
			String strResponse2 = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
			JSONArray noOfcartItem = JsonPath.read(strResponse2, "$.payload..cartItemID");
			String strCartItems = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartItems");
			System.out.println(strCartItems.length());
			System.out.println("cartItem =" + strCartItems);
			int size = noOfcartItem.size();
			System.out.println(size);
			String strCartID = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartID");
			JSONArray PromoCodes = JsonPath.read(strResponse2, "$.payload..code");
			JSONArray Kohlcash = JsonPath.read(strResponse2, "$.payload..kohlsCashNum");
			if(PromoCodes.size() >= 1){
				for (int i= 0; i < PromoCodes.size(); i++){
					String Promo = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.paymentTypes.promoCodes.promoCode["+ i +"].code");
				String strPayload = "{\"payload\":{\"cart\":{\"cartID\" :\"" + strCartID + "\",\"paymentTypes\" : {\"promoCodes\" :{\"promoCode\" :[{\"code\":\""+Promo+"\",\"action\":\"remove\"}]}}}}}";
				mapheader.clear();
				mapheader.put("access_token", strAccessToken);
				String strResponse1 = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);
				System.out.println(strResponse1);
				}
			}
			if(Kohlcash.size() >= 1){
				for(int i= 0;i < Kohlcash.size();i++){
					String KohlsCash = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.paymentTypes.kohlsCash.voucher["+ i +"].kohlsCashNum");
					String strPayload = "{\"payload\":{\"cart\":{\"cartID\" :\"" + strCartID + "\",\"paymentTypes\":{\"kohlsCash\":{\"voucher\":[{\"kohlsCashNum\":\""+KohlsCash+"\",\"action\":\"remove\"}]}}}}}";
					System.out.println(strPayload);
					mapheader.clear();
					mapheader.put("access_token", strAccessToken);
					String strResponse1 = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);
					System.out.println(strResponse1);
				}
			}
			if (size >= 1) {

				for (int i = 0; i < noOfcartItem.size(); i++) {
					String strCartItemID = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartItems[" + i + "].cartItemID");
					String strSkuCode = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartItems[" + i + "].skuCode");
					// String strQty=Utilities.getJsonNodeValue(strResponse, "payload.cart.cartItems["+i+"].qty");
					// Create the Json Request for Sign In
					String strPayload = "{\"payload\":{\"cart\":{\"cartID\" :\"" + strCartID + "\",\"cartItems\" :[{\"cartItemID\":\"" + strCartItemID + "\",\"skuCode\": \"" + strSkuCode + "\", \"qty\":\"0\",\"action\":\"remove\"}]}}}";
					mapheader.clear();
					mapheader.put("access_token", strAccessToken);
					String strResponse1 = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);
					
				}
			} 
			else {
				return;
			}
		}

	}

	@Step("Sign-In Profile")
	public static void signInProfile(String strUserEmail, String strPassword, Server server, String strAccessTokenVariable) {

		if (server == Server.Adapter) {
			// Create the Json Request for Sign In
			String strPayload = "grant_type=password&userId=" + strUserEmail + "&password=" + strPassword;

			// Post the request
			String strResponse = RestCall.postRequest(V1_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();

			// Set the access token in testData
			Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", strAccessTokenVariable);

		} else {

			String	strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") 
				+ "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" 
				+ strUserEmail + "&password=" + strPassword;

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Validate Response
			validator = new ResponseValidator(strResponseOAPI);
			validator.validateNoErrors();

			Utilities.setTestData(strResponseOAPI, "$.access_token", strAccessTokenVariable);

		}
	}
	@Step("Sign-In Profile")
	public static void signInProfileV2(String strUserEmail, String strPassword, Server server, String strAccessTokenVariable) {

		if (server == Server.Adapter) {
			// Create the Json Request for Sign In
			String strPayload = "grant_type=password&userId=" + strUserEmail + "&password=" + strPassword;

			// Post the request
			String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();

			// Set the access token in testData
			Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", strAccessTokenVariable);
		}
			else {

				String	strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") + "&userId=" 
								+ strUserEmail + "&password=" + strPassword;
//				}
				String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

				// Validate Response
				validator = new ResponseValidator(strResponseOAPI);
				validator.validateNoErrors();

				Utilities.setTestData(strResponseOAPI, "$.access_token", strAccessTokenVariable);

			}
			
		
	
	}
	@Step("Sign-In Profile")
	public static void signInProfileV2(String strUserEmail, String strPassword, Server server, String strAccessTokenVariable, String strWalletId, String strWalletToken) {

		if (server == Server.Adapter) {
			// Create the Json Request for Sign In
			String strPayload = "grant_type=password&userId=" + strUserEmail + "&password=" + strPassword;

			// Post the request
			String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();

			// Set the access token in testData
			Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", strAccessTokenVariable);
			Utilities.setTestData(strResponse, "$.payload.response.wallet.walletId", strWalletId);
			Utilities.setTestData(strResponse, "$.payload.response.wallet.token", strWalletToken);
			
		} else {

			String	strPayloadOAPI = "grant_type=password&client_id=" + testData.get("OPEN_API_KEY") + "&secret=" + testData.get("OPEN_API_SECRET_KEY") 
				+ "&userId=" + strUserEmail + "&password=" + strPassword;

			// Post the request
			String strResponseOAPI = RestCall.postRequest(V1_SIGNIN_PROFILE_OAPI, strPayloadOAPI, Server.OpenApi, false);

			// Validate Response
			validator = new ResponseValidator(strResponseOAPI);
			validator.validateNoErrors();

			Utilities.setTestData(strResponseOAPI, "$.access_token", strAccessTokenVariable);

		}
	}

	@Step("Sign-In Profile")
	public static void signInProfileV2(String strUserEmail, String strPassword, Server server, String strAccessTokenVariable, String strProfileId) {

		if (server == Server.Adapter) {
			// Create the Json Request for Sign In
			String strPayload = "grant_type=password&userId=" + strUserEmail + "&password=" + strPassword;

			// Post the request
			String strResponse = RestCall.postRequest(V2_SIGNIN_PROFILE_ADAPTER, strPayload, Server.Adapter, false);

			// Validate Response
			validator = new ResponseValidator(strResponse);
			validator.validateNoErrors();

			// Set the access token in testData
			Utilities.setTestData(strResponse, "$.payload.response.signIn.access_token", strAccessTokenVariable);
			Utilities.setTestData(strResponse, "$.payload.response.profileInfo.id", strProfileId);
			
			
		}
	}
	
	@Step("Clear Cart")
	public static void removeCart(Server server, String strAccessToken) {

		System.out.println(strAccessToken);
		if ((server == Server.Adapter) || (server == Server.OpenApi)) {
			mapheader.clear();
			mapheader.put("access_token", strAccessToken);
			String strResponse2 = RestCall.getRequest(CART_ADAPTER, Server.Adapter, true, mapheader);
			JSONArray noOfcartItem = JsonPath.read(strResponse2, "$.payload..cartItemID");
			String strCartItems = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartItems");
			System.out.println(strCartItems.length());
			System.out.println("cartItem =" + strCartItems);
			int size = noOfcartItem.size();
			String strCartID = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartID");
			if (size >= 1) {

				for (int i = 0; i < noOfcartItem.size(); i++) {
					String strCartItemID = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartItems[" + i + "].cartItemID");
					String strSkuCode = Utilities.getJsonNodeValue(strResponse2, "$.payload.cart.cartItems[" + i + "].skuCode");
					// String strQty=Utilities.getJsonNodeValue(strResponse, "payload.cart.cartItems["+i+"].qty");
					// Create the Json Request for Sign In
					String strPayload = "{\"payload\":{\"cart\":{\"cartID\" :\"" + strCartID + "\",\"cartItems\" :[{\"cartItemID\":\"" + strCartItemID + "\",\"skuCode\": \"" + strSkuCode + "\", \"qty\":\"0\",\"action\":\"remove\"}]}}}";
					mapheader.clear();
					mapheader.put("access_token", strAccessToken);
					String strResponse1 = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);
					
				}
			} else {
				return;
			}
		}

	}
	
	@Step("Clear Cart")
	public static String AddToCart(String skucode, String qty, Boolean isGiftItem, Boolean isRegistry){
		String strCartRequest = "{\"payload\":{\"cart\":{\"cartItems\":[";
		strCartRequest+="{\"skuCode\":\""+skucode+"\",\"qty\":\""+qty+"\",\"action\":\"add\",\"giftItem\":\""+isGiftItem+"\"";
				if(isRegistry){
					strCartRequest+=",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+testData.get("shipping_id_adapter")+"\",\"wantedQty\" : 1}";
				}
				strCartRequest+="}]}}}";
				String strResponse = RestCall.postRequest(CART_ADAPTER, strCartRequest, Server.Adapter, true);
				return strResponse;
	}
	
	@Step("Clear Cart")
	public static String AddToCart(String skucode, String qty, Boolean isGiftItem, Boolean isRegistry, String shipToID){
		String strCartRequest = "{\"payload\":{\"cart\":{\"cartItems\":[";
		strCartRequest+="{\"skuCode\":\""+skucode+"\",\"qty\":\""+qty+"\",\"action\":\"add\",\"giftItem\":\""+isGiftItem+"\"";
				if(isRegistry){
					strCartRequest+=",\"registry\" : {\"registryName\" : \"Tests\",\"registryType\" : \"wishlist\",\"registryID\" : \"2522230\",\"shipToId\" : \""+shipToID+"\",\"wantedQty\" : 1}";
				}
				strCartRequest+="}]}}}";
				String strResponse = RestCall.postRequest(CART_ADAPTER, strCartRequest, Server.Adapter, true);
				return strResponse;
	}
	
	
	public static void compareAdapterOAPIResponse(String strAdapterRes, String strOAPIRes, CompareType compareType) {
		
		try {
			List<String> listIgnore = null;
			boolean reportFailure = false;
			StringBuffer sb = new StringBuffer();
			JSONCompareResult j = JSONCompare.compareJSON(strOAPIRes, strAdapterRes, new DefaultComparator(JSONCompareMode.STRICT));
			
			List<FieldComparisonFailure> listFailures = j.getFieldFailures();
			if (!listFailures.isEmpty()){
				
				if (compareType != CompareType.FULL)
					listIgnore = getIgnoreNodes(compareType);
				
				sb.append("\nMismatching Values in adapter response :\n");
				for (FieldComparisonFailure failure : listFailures ){
					String strNode = failure.getField();
					
					if (compareType == CompareType.FULL) {
						sb.append("   " + failure.getField() +". Expected '" + failure.getExpected() +"'" +" Found '" + failure.getActual() +"'\n");
						reportFailure = true;
					}else {
						strNode = strNode.replaceAll("\\[[0-9]+\\]", "");
						if (!listIgnore.contains(strNode)){
							sb.append("   " + failure.getField() +". Expected '" + failure.getExpected() +"'" +" Found '" + failure.getActual() +"'\n");
							reportFailure = true;
						}
						
					}
				}
			}
			
			List<FieldComparisonFailure> listMissing = j.getFieldMissing();
			if (!listMissing.isEmpty()){
				sb.append("\nMissing Values in adapter response :\n");
				for (FieldComparisonFailure missing : listMissing ){
					sb.append("   " +missing.getField() +". Expected '" + missing.getExpected() +"'" +" Found '" + missing.getActual() +"'\n");
					reportFailure = true;
				}
			}
			
			List<FieldComparisonFailure> listUnexpected = j.getFieldUnexpected();
			if (!listUnexpected.isEmpty()){
				sb.append("\nUnexpected Values in adapter response :\n");
				for (FieldComparisonFailure unexpected : listUnexpected ){
					sb.append("   " +unexpected.getField() + ". Expected '" + unexpected.getExpected() +"'" + " Found '" + unexpected.getActual() +"'\n");
					reportFailure = true;	
				}
			}
			
			if (reportFailure) {
				HTMLReporter.attachToReportComparison(sb.toString());
				Assert.fail("Responses from Adapter and OpenAPI are not same");
			}
		}
		catch (Exception e) {
			System.out.println("Execption in Compare OAPI");
		}
	}
	
	
	public static List<String> getIgnoreNodes(CompareType compareType){
		
		List <String> listIgnore = new ArrayList<String>(); 
		
		switch (compareType){

			case ORDER :
				listIgnore.add("payload.order.cartItems.cartItemID");
				listIgnore.add("payload.order.orderNumber");
				listIgnore.add("payload.order.email");
				break;
			case BALANCE :
				listIgnore.add("payload.kohlsCashCoupons.kohlsCashNum");
				listIgnore.add("payload.kohlsCashCoupons.ID");
			//	listIgnore.add("payload.order.email");
				break;
			case PROMOCODE :
				listIgnore.add("payload.order.cartItems.cartItemID");
				listIgnore.add("payload.order.orderNumber");
				listIgnore.add("payload.order.email");
				listIgnore.add("payload.order.paymentTypes.promoCodes.code");
				break;
				
			case CART : 
				listIgnore.add("payload.order.cartItems.cartItemID");
				listIgnore.add("payload.cart.cartID");
				break;
				
			case CART_V2:
				break;
				
			case PAYMENT:
				listIgnore.add("payload.id");
				break;
				
			case SHIPADDRESS:
				listIgnore.add("payload.id");
				break;
				
			case PRICE:
				listIgnore.add("payload.products.stores.prices.displayBegDateTime");
				break;
				
			case BZV_REVIEW:
				listIgnore.add("payload.Data.Fields.usernickname.Value");
				listIgnore.add("payload.Review.SubmissionTime");
				break;
				
		}
		
		return listIgnore;
		
	}
	public static String getNewPhoneNumber() {
		try {
		Thread.sleep(2000);
		} catch (Exception e) {
		e.printStackTrace();
		}
		long strTime = System.nanoTime();
//			System.out.println( strTime);
		String str = String.valueOf(strTime);

		System.out.print("Return Value :" );
		     System.out.println(str.substring(0, 10) );
		return str.substring(0, 10);
		}
	
	public void PIILogValidation() throws IOException{
		String strAdapterURL =  testData.get("Adapter_Environemnt").trim();
		/*if(System.getenv("URL")!=null){
			strAdapterURL = System.getenv("URL");
		}
		else{
			System.out.println("WARNING !! CANNOT GET JENKINS PARAMETER");
			strAdapterURL = "http://kd42.km.sl.edst.ibm.com";
		}*/
		
		System.out.println("\n\n Starting PII Validation for " + strAdapterURL);
		
		File f = new File("c:\\temp\\pii.txt");
		if (f.exists()) f.delete();
		
		
		//Capture adapter logs and write to temp file, 
		String str = getRequestpii(strAdapterURL+"/mfp/mfp-logs/adapterLogs/adapterReqRes.log",  false);
		
		if (str.equals("FAIL"))
			return;
		
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		
		
		String line;
		StringBuffer sb = new StringBuffer();
		
		sb.append(r.readLine()+"\n");
		
		while ((line = r.readLine() )!=null){
			
			if (line.startsWith("TID")||line.startsWith("NAID")){
				String strReq = new String(sb);
				if (!strReq.trim().equals(""))
					validateRequest(strReq);
				sb = new StringBuffer();
			}
			
			sb.append(line+"\n");
			
		}
		
		r.close();
		
		System.out.println(" ** PII Validation Completed !!\n\n");
	
	}
	
	
	public static void main1(String[] args) throws Exception {
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		String line;
		StringBuffer sb = new StringBuffer();
		while ((line = r.readLine() )!=null){
			sb.append(line+"\n");
		}
		validateRequest(sb.toString());
	}
	
	public static String offerId(){
		String strURL=OFFERTYPE_ADAPTER+"TLD";
		String strResponse=RestCall.simpleGetRequest(strURL, Server.Adapter, false);
		String strOfferId=getJsonNodeValue(strResponse,"$.payload.offers[0].id");
		String strOfferCode=getJsonNodeValue(strResponse,"$.payload.offers[0].code");
		testData.put("RUNTIME_OFFER_CODE", strOfferCode);
		return strOfferId;
	}
	
	static void validateRequest(String s){
//		System.out.println("Validating request" + s);
		String strPayload = s;//.substring(s.indexOf("{\""),s.length());
//		System.out.println(strPayload);
		
		String patternRules[] = {"\"email\":.*?,","\"firstName\":.*?,","\"lastName\":.*?,","\"addr1\":.*?,","\"addr2\":.*?,","\"city\":.*?,","\"state\":.*?,",
				"\"postalCode\":.*?,","\"nameOnCard\":.*?,","\"cardNum\":.*?(,|})","\"expDate\":.*?,","\"securityCode\":.*?,",
				"\"name\":.*?,","\"phoneNumber\":.*?,","\"access_token\":.*?,","X-APP-API_KEY:.*?;","access_token:.*?;","\"loyaltyId\":.*?,","\"walletId\":.*?,","\"atgProfileId\":.*?(,|})"};
		
       
		
		Pattern pattern;
		for (String strRule : patternRules) {
	        pattern = Pattern.compile(strRule);
	         	
		    Matcher matcher = pattern.matcher(strPayload);
			
			int matchCount = 0; 
			while(matcher.find()){
						
				String strMatch = matcher.group(0);
//				System.out.println(strMatch);
				
				if (true) {
				
					if (strMatch.contains("X-APP-API_KEY"))
						pattern = Pattern.compile("X-APP-API_KEY:[\\*]+;");
					else if (strMatch.contains("\"email\""))
						pattern = Pattern.compile("\"email\":(\"[\\w\\.]*[\\*]*\"|.*\"kohlsCharge\":\"[*]+\")");
					else if (strMatch.contains("\"access_token\""))
						pattern = Pattern.compile("\"access_token\":\"[\\*]+\\w*\"");
					else if (strMatch.contains("access_token"))
						pattern = Pattern.compile("access_token:(.*Invalid Access Token.*|[\\*]+\\w*;)");
					else if (strMatch.contains("\"phoneNumber\""))
						pattern = Pattern.compile("\"phoneNumber\":(\"[*]+\"|.*\"number\":\"[*]+\"|null)");
					else if (strMatch.contains("\"loyaltyId\""))
						pattern = Pattern.compile("\"loyaltyId\":(\"[0-9]+\"|null)");
					else if (strMatch.contains("\"walletId\""))
						pattern = Pattern.compile("\"walletId\":[0-9]+,");
					else if (strMatch.contains("\"atgProfileId\""))
						pattern = Pattern.compile("\"atgProfileId\":\"[0-9]+\"");
					else
						pattern = Pattern.compile("\".*\":(null|\"[\\*]*)(,|\")");
					
					if (!pattern.matcher(strMatch).find()){
						System.out.println("\n\n\n\nRule Violation in below Request. Found PII " + strMatch);
						
						//s= s.replace(strMatch, "<red>" + strMatch + "</red>");
						System.out.println("**********************\n" + s + "\n*****************************");
					
					}
				}
						
			}
		}
		
		
	}
	
	
public static String getRequestpii(String strURL, boolean RegisteredUser){
		
		URL url;
		try {
			url = new URL(strURL);

		    Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
		    HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);        
		    conn.setRequestMethod("GET");
		    
		    
		    //Set the Accept header
			conn.setRequestProperty("Accept", "application/json");  
			
		
		       
		    conn.setDoOutput(true);                
		   
		    StringBuffer sb = new StringBuffer();
		    if (conn.getResponseCode() != 200) {
		        System.out.println("\n\n**Error : Logs are not enabled for this environment : "
		                + conn.getResponseCode() + "\n\n\n");
		        return "FAIL";
		    }
		
		    if(conn.getResponseCode() == 200) {
		        BufferedReader br = new BufferedReader(new InputStreamReader(
		                (conn.getInputStream())));
		
		        String output;
		        
		        BufferedWriter w = new BufferedWriter(new FileWriter("C:\\temp\\pii.txt"));
		        
		        while ((output = br.readLine()) != null) {
		        	w.write(output + "\n");
//		            sb.append(output+"\n");               
		        }
		        
		        w.write("\nTID-");
		         
		        w.flush();
		        w.close();	
		       
		                   
		
		    }
		    conn.disconnect();    
		    
		    //System.out.println(sb.toString());
		    return sb.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}

	}
	}
	
