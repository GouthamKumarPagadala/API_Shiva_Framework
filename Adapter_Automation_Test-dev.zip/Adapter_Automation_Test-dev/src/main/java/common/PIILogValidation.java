package main.java.common;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static main.java.common.GlobalVariables.*;

public class PIILogValidation extends TestData {
	public static String main(String[] args) throws Exception {
	
		
		String strAdapterURL =  testData.get("Adapter_Environemnt").trim();
		if(System.getenv("Adapter_URL")!=null){
			strAdapterURL = System.getenv("Adapter_URL");
		}
		else{
			System.out.println("WARNING !! CANNOT GET JENKINS PARAMETER");
			strAdapterURL = strAdapterEnv;
		}
		File file = new File("target/allure-results");
		if (!file.exists())
			file.mkdirs();
		FileWriter fw = new FileWriter("target/allure-results/environment.properties", true);

		fw.write("Starting PII Validation" + "\n");
		fw.close();
		System.out.println("\n\n Starting PII Validation for " + strAdapterURL);
		
		File f = new File("c:\\temp\\pii.txt");
		if (f.exists()) f.delete();
		
		
		//Capture adapter logs and write to temp file, 
		String str = getRequestpii(strAdapterURL+"/mfp/mfp-logs/adapterLogs/adapterReqRes.log",  false);
		
		if (str.equals("FAIL"))
	 		return null;
		
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		
		
		String line;
		StringBuffer sb = new StringBuffer();
		
		sb.append(r.readLine()+"\n");
		
		while ((line = r.readLine() )!=null){
			
			if (line.startsWith("TID")||line.startsWith("NAID")){
				String strReq = new String(sb);
				if (!strReq.trim().equals(""))
					validateRequest(strReq);
				sb = new StringBuffer();
			}
			
			sb.append(line+"\n");
			
			
			
		}
		
		r.close();
		
		System.out.println(" ** PII Validation Completed !!\n\n");
		return sb.toString();
	}
	
	
	public static void main1(String[] args) throws Exception {
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		String line;
		StringBuffer sb = new StringBuffer();
		while ((line = r.readLine() )!=null){
			sb.append(line+"\n");
		}
		
		
		validateRequest(sb.toString());
	}
	
	public static void validateRequest(String s){
//		System.out.println("Validating request" + s);
		String strPayload = s;//.substring(s.indexOf("{\""),s.length());
//		System.out.println(strPayload);
		
		//Device Finger Print Headers Validation
		int count = 0;
		String deviceFingerPrintHeadersopenAPI[] = {"X-APP-API_SESSIONID:","X-APP-API_REQUESTURL:","X-APP-API_REMOTEIP:"
				,"X-APP-API_X-FORWARDED-FOR:","X-APP-API_USER-AGENT:"};
		if(strPayload.contains("correlation-id:TID-DeviceFingerPrint")&&strPayload.contains("/token")&&!strPayload.contains("v2/token")){
		for (String dfpRule : deviceFingerPrintHeadersopenAPI){
			if(!strPayload.contains(dfpRule)){
				count += 1;
			}
		}
		if(count>0){
			System.out.println("Device Fingure print Headers not available in below request\n"+strPayload);
		}}
		
		String deviceFingerPrintHeadersPlatform[] = {"X-APP-API_SESSIONID:","User-Agent:","True-Client-IP:"
				,"X-Forwarded-For:"};
		if(strPayload.contains("correlation-id:TID-DeviceFingerPrint")&&strPayload.contains("/adapters/rest/v2/auth/signInProfile")){
		for (String dfpRule : deviceFingerPrintHeadersPlatform){
			if(!strPayload.contains(dfpRule)){
				count += 1;
			}
		}
		if(count>0){
			System.out.println("Device Fingure print Headers not available in below request\n"+strPayload);
		}}
		
		Pattern pattern, pattern1;
		String patternRules[] = {"\"email\":.*?,","\"firstName\":.*?,","\"lastName\":.*?,","\"addr1\":.*?,","\"addr2\":.*?,","\"city\":.*?,","\"state\":.*?,",
				"\"postalCode\":.*?,","\"nameOnCard\":.*?,","\"cardNum\":.*?(,|})","\"expDate\":.*?,","\"securityCode\":.*?,",
				"\"name\":.*?,","\"phoneNumber\":.*?,","\"access_token\":.*?,","X-APP-API_KEY:.*?;","access_token:.*?;",
				"\"loyaltyId\":.*?,","\"walletId\":.*?,","\"atgProfileId\":.*?(,|})","X-Profile-Id:.*?;","\"kohlsCashNum\":.*?,","\"giftCardNum\":.*?,"
				};
       		
		for (String strRule : patternRules) {
			if(strPayload.contains("/v1/cart"))
				break;
			
			if(strPayload.contains("/v1/validation") && !strPayload.contains("/kohls/adapters/rest/") && !strPayload.contains("https://"))
				System.out.println("https protocol is not called for validation API");
			
			
	        pattern = Pattern.compile(strRule);
	         	
		    Matcher matcher = pattern.matcher(strPayload);
			
			int matchCount = 0; 
			while(matcher.find()){
						
				String strMatch = matcher.group(0);
//				System.out.println(strMatch);				
				if (true) {
				
					if (strMatch.contains("X-APP-API_KEY"))
						pattern = Pattern.compile("X-APP-API_KEY:[\\*]+;");
					else if (strMatch.contains("\"email\""))
						pattern = Pattern.compile("\"email\":(\"[\\w\\.]*[\\*]*\"|.*\"kohlsCharge\":\"[*]+\")");
					else if (strMatch.contains("\"access_token\""))
						pattern = Pattern.compile("\"access_token\":\"[\\*]+\\w*\"");
					else if (strMatch.contains("access_token"))
						pattern = Pattern.compile("access_token:(.*Invalid Access Token.*|[\\*]+\\w*;)");
					else if (strMatch.contains("\"phoneNumber\""))
						pattern = Pattern.compile("\"phoneNumber\":(\"[*]+\"|.*\"number\":\"[*]+\"|null)");
					else if (strMatch.contains("\"loyaltyId\""))
						pattern = Pattern.compile("\"loyaltyId\":(\"[0-9]+\"|null)");
					else if (strMatch.contains("\"walletId\""))
						pattern = Pattern.compile("\"walletId\":([0-9]+,|\"[0-9]+\"|[0-9]+})");
					else if (strMatch.contains("\"atgProfileId\""))
						pattern = Pattern.compile("\"atgProfileId\":\"[0-9]+\"");
					else if(strMatch.contains("X-Profile-Id"))
						pattern = Pattern.compile("X-Profile-Id:[0-9]+;");
					else if(strMatch.contains("\"kohlsCashNum\""))
						pattern = Pattern.compile("\"kohlsCashNum\":\"([x]+[0-9]+|[*]+)\"");
					else if(strMatch.contains("\"cardNum\""))
						pattern = Pattern.compile("\"cardNum\":\"([*]+||[x]+[0-9]+)\"");
					else if(strMatch.contains("\"giftCardNum\""))
						pattern = Pattern.compile("\"giftCardNum\":(\"[*]+\"|null)");
					else
						pattern = Pattern.compile("\".*\":(null|\"[\\*]*)(,|\")");
					
					if (!pattern.matcher(strMatch).find()){
						System.out.println("\n\n\n\nRule Violation in below Request. Found PII " + strMatch);
						
						//s= s.replace(strMatch, "<red>" + strMatch + "</red>");
						System.out.println("**********************\n" + s + "\n*****************************");
					
					}
				}
						
			}
		}
		
		
	}
	
	
public static String getRequestpii(String strURL, boolean RegisteredUser){
		
		URL url;
		try {
			url = new URL(strURL);
			
			
			
		

		    Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
		    HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);        
		    conn.setRequestMethod("GET");
		    
		    
		    //Set the Accept header
			conn.setRequestProperty("Accept", "application/json");  
			
		
		       
		    conn.setDoOutput(true);                
		   
		    StringBuffer sb = new StringBuffer();
		    if (conn.getResponseCode() != 200) {
		        System.out.println("\n\n**Error : Logs are not enabled for this environment : "
		                + conn.getResponseCode() + "\n\n\n");
		        return "FAIL";
		    }
		
		    if(conn.getResponseCode() == 200) {
		        BufferedReader br = new BufferedReader(new InputStreamReader(
		                (conn.getInputStream())));
		
		        String output;
		        
		        BufferedWriter w = new BufferedWriter(new FileWriter("C:\\temp\\pii.txt"));
		        
		        while ((output = br.readLine()) != null) {
		        	w.write(output + "\n");
//		            sb.append(output+"\n");               
		        }
		        
		        w.write("\nTID-");
		         
		        w.flush();
		        w.close();	
		       
		                   
		
		    }
		    conn.disconnect();    
		    
		    //System.out.println(sb.toString());
		    return sb.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}

	}

	
}