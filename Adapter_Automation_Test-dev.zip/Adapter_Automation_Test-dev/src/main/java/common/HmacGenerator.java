package main.java.common;

import java.security.MessageDigest;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;


public class HmacGenerator {
	public static final String HMAC_TYPE = "HmacSHA256";
	public static final String CHARSET_NAME = "UTF8";

	private final String signature;

	public HmacGenerator(final Builder builder) {
		this.signature = builder.signature;
	}

	public String getSignature() {
		return signature;
	}

	public static class Builder {
		private String apiSecret;
		private String endpoint;
		private String apiKey;
		private String method;
		private long timestamp;
		private String correlationId;
		private String payload;
		private String queryParams;
		private String signature;

		public Builder apiSecret(final String apiSecret) {
			this.apiSecret = apiSecret;
			return this;
		}

		public Builder endpoint(final String endpoint) {
			this.endpoint = endpoint;
			return this;
		}

		public Builder apiKey(final String apiKey) {
			this.apiKey = apiKey;
			return this;
		}

		public Builder method(final String method) {
			this.method = method;
			return this;
		}

		public Builder timestamp(final long epochUtcSeconds) {
			this.timestamp = epochUtcSeconds;
			return this;
		}

		public Builder correlationId(final String correlationId) {
			this.correlationId = correlationId;
			return this;
		}

		public Builder payload(final String payload) {
			this.payload = payload;
			return this;
		}

		public Builder queryParams(final String queryParams) {
			this.queryParams = queryParams;
			return this;
		}

		public HmacGenerator build() {
			final StringBuilder stringBuffer = new StringBuilder();
			stringBuffer.append(method).append(timestamp).append(apiKey)
					.append(endpoint).append(correlationId);

			if (queryParams != null && queryParams.length() > 0) {
				stringBuffer.append(queryParams);
			}

			if (payload != null && payload.length() > 0) {
				stringBuffer.append(payload);
			}

			signature = createShaToken(stringBuffer.toString(), apiSecret);

			return new HmacGenerator(this);
		}

		private String createSignature(String message, String apiSecret) {
			String hash = null;
			try {
				final Mac mac = Mac.getInstance(HMAC_TYPE);
				final SecretKeySpec secretKey = new SecretKeySpec(
						apiSecret.getBytes(), HMAC_TYPE);
				mac.init(secretKey);
				//NOTE: function called twice to prevent length extension attack
				hash = Base64.encodeBase64String(mac.doFinal(mac.doFinal(message.getBytes(CHARSET_NAME))));
				System.out.println("DEBUG message:"+message);
				System.out.println("DEBUG signature:"+hash);
			} catch (Exception e) {
				System.err.println("Hash exception" + e);
				throw new RuntimeException(e);
			}
			return hash;
		}
		
		private String createShaToken(String message, String apiSecret){
			String hash=null;			
			/*String strStringTtoHash =method+timestamp+apiKey+endpoint+correlationId+message;*/
			try {
				final Mac mac = Mac.getInstance(HMAC_TYPE);
				final SecretKeySpec secretKey = new SecretKeySpec(
						apiSecret.getBytes(), HMAC_TYPE);
				mac.init(secretKey);
				//NOTE: function called twice to prevent length extension attack
				hash = Base64.encodeBase64String(mac.doFinal(mac.doFinal(message.getBytes(CHARSET_NAME))));
				System.out.println("DEBUG message:"+message);
				System.out.println("DEBUG signature:"+hash);
			    }
			    catch (Exception e){
			     System.out.println("Error");
			    }
			return hash;
			
		}
		
		}

}
