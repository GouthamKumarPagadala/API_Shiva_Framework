package main.java.common;

public class GlobalVariables extends TestData {

	// Set Compare Open API variable as true or false
	public static boolean CompareOAPI = testData.get("Compare_OpenAPI").equalsIgnoreCase("true") ? true : false;
	public static boolean MfpToken = testData.get("Mfp_Oauth_Token").equalsIgnoreCase("true") ? true : false;
	public static boolean Device_Finger_Print = testData.get("Device_Finger_Print").equalsIgnoreCase("true") ? true : false;
	public static String strGroup ="" ;
	public static int kohlsCashLim = Integer.parseInt(testData.get("Kohls_Cash_Limit"));

	// Read the environment variables
	public static String strAdapterEnv		= testData.get("Adapter_Environemnt").trim();
	static String	strWalletEnv		= testData.get("Wallet_Environemnt").trim();
	static String	strOpenAPIEnvHTTPS	= testData.get("OPEN_API_BASE_URL_HTTPS").trim();
	static String	strOpenAPIEnvHTTP	= testData.get("OPEN_API_BASE_URL_HTTP").trim();
	static String	strSkavaEnv			= testData.get("SKAVA_BASE_URL").trim();
	static String	strBazaarVoiceEnv	= testData.get("BAZAAR_VOICE_URL").trim();
	static String	strBazaarBaseEnv	= testData.get("BAZAAR_BASE_URL").trim();

	// Set the resource end point URLs for adapter
	// Profile
	public static String	OAUTHMFP_TOKEN="";
	public static String	OAUTHMFP_TOKEN_5CHARS="";				// First 5 chars of MFP token, to print in report to reduce clutter
	public final static String	PWD_VERFICATION_ADAPTER				= strAdapterEnv + "/kohls/adapters/rest/v1/profile/password";
	public final static String	PROFILE_ADAPTER						= strAdapterEnv + "/kohls/adapters/rest/v1/profile";
	public final static String	V2_PROFILE_ADAPTER					= strAdapterEnv + "/kohls/adapters/rest/v2/profile";
	public final static String	V1_SIGNIN_PROFILE_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/auth/signInProfile";
	public final static String	V2_SIGNIN_PROFILE_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v2/auth/signInProfile";
	public final static String	PROFILE_PAYMENT_ADAPTER				= strAdapterEnv + "/kohls/adapters/rest/v1/profile/paymentType";
	public final static String	PROFILE_BILL_ADDRESS_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/profile/billAddress";
	public final static String	PROFILE_SHIPPING_ADDRESS_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/profile/shipAddress";
	public final static String	FORGOT_PASSWORD						= strAdapterEnv + "/kohls/adapters/rest/v1/profile/forgotPassword?email=";
	public final static String	V1_REFRESH_TOKEN					= strAdapterEnv + "/kohls/adapters/rest/v1/auth/token";
	public final static String	V2_REFRESH_TOKEN					= strAdapterEnv + "/kohls/adapters/rest/v2/auth/token";
	public final static String	KCC_ELIGIBILITY					    = strAdapterEnv + "/kohls/adapters/rest/v1/profile/prequal/eligibility";
	public final static String	KCC_LOOKUP					        = strAdapterEnv + "/kohls/adapters/rest/v1/profile/prequal/kcc";
	public final static String	KCC_INQUIRY					        = strAdapterEnv + "/kohls/adapters/rest/v1/profile/prequal/inquiry";
	//public final static String GET_WALLET_ID 						= strWalletEnv + "/wallet/v1/id";

	// Inventory
	public final static String	INVENTORY_WEBID_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/inventory/webID";
	public final static String	INVENTORY_SKU_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/inventory/sku";

	// Price
	public final static String	PRICE_WEB_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/price/webID";
	public final static String	PRICE_SKU_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/price/sku";

	// Category
	public final static String	CATALOG_ADAPTER				= strAdapterEnv + "/kohls/adapters/rest/v1/catalog";
	public final static String	PRODUCT_CATALOG_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/catalog/productCount";
	public final static String	CATEGORY_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/catalog/category";
	public final static String	CATEGORY_V2_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v2/catalog/category";
	public final static String	CACHEFLUSH_CATALOG_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/caching/stats?cname=";
	public final static String	CACHESTATUS_CATALOG_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/caching/stats?cname=";
	public final static String	GET_CACHESTATUS_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/caching/stats";
	public final static String	DELETE_CACHESTATUS_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/caching/namespaces?cname=";

	// Product
	public final static String	SINGLE_PRODUCT_DETAILS_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/products";
	public final static String	PRODUCTS_BY_SKU_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/products?skuCode=";
	public final static String	PRODUCTS_BY_UPC_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/products?upc=";
	public final static String PRODUCTS_BY_SKU_ADAPTER_V2 = strAdapterEnv + "/kohls/adapters/rest/v2/products?skuCode=";
	public final static String PRODUCTS_BY_UPC_ADAPTER_V2 = strAdapterEnv + "/kohls/adapters/rest/v2/products?upc=";
	public final static String PRODUCT_DETAILS_ADAPTER_V2 = strAdapterEnv + "/kohls/adapters/rest/v2/products";
	//public final static String PRODUCT_DETAILS_ADAPTER_V2_BULK = strAdapterEnv + "/kohls/adapters/rest/v2/products";
	
	// Product Inventory chek
		public final static String	SINGLE_PRODUCT_INVENTORY	        = strAdapterEnv + "/kohls/adapters/rest/v1/productInventoryCheck";
		public final static String	PRODUCTS_BY_SKU_INVENTORY			= strAdapterEnv + "/kohls/adapters/rest/v1/productInventoryCheck?skuCode=";
		public final static String	PRODUCTS_BY_UPC_INVENTORY			= strAdapterEnv + "/kohls/adapters/rest/v1/productInventoryCheck?upc=";

	// Cart
	public final static String	CART_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/cart";
	public final static String	ORDERCALC_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/order/calculation?trEnabled=true";
	public final static String	PLACEORDER_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/order?trEnabled=true";
	public final static String	PLACEORDERV2_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v2/order?trEnabled=true";
	public final static String	RETRIEVE_ORDERS_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/orders";
	public final static String	RETRIEVE_ORDER_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/order";
	public final static String	ORDERCALC_ADAPTER_V2	= strAdapterEnv + "/kohls/adapters/rest/v2/order/calculation?trEnabled=true";
	public final static String	ORDERCALC_ADAPTER_INSTANTBUY_V2	= strAdapterEnv + "/kohls/adapters/rest/v2/order/calculation?trEnabled=true&orderType=instant";
	public final static String	PLACEORDERV2_ADAPTER_INSTANTBUY_V2	= strAdapterEnv + "/kohls/adapters/rest/v2/order?trEnabled=true&orderType=instant";
	
	// Configuration
	public final static String CONFIG = strAdapterEnv + "/kohls/adapters/rest/v1/resources/config";

	// Offer
	public final static String	OFFERID_ADAPTER					= strAdapterEnv + "/kohls/adapters/rest/v1/offers?offerId=";
	public final static String	OFFERCODE_ADAPTER				= strAdapterEnv + "/kohls/adapters/rest/v1/offers?offerCode=";
	public final static String	OFFER_PRODUCTID_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/offers/product?productId=";
	public final static String	OFFER_LOOKUP_PRODUCT_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/products";
	public final static String	OFFERTYPE_ADAPTER				= strAdapterEnv + "/kohls/adapters/rest/v1/offers?offerType=";
	public final static String	INVALID_OFFER_PRODUCTID_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/offers/product";
	// Configuration
	public final static String	CONFIG_ADAPTER					= strAdapterEnv + "/kohls/adapters/rest/v1/configures/client";
	public final static String	ADAPTER_VERSION					= strAdapterEnv + "/kohls/adapters/rest/v1/resources/version";
	public final static String	CONFIG_IPAD					= strAdapterEnv + "/kohls/adapters/rest/v1/resources/ipadconfig";
	public final static String	CONFIG_MONETIZATION				= strAdapterEnv + "/kohls/adapters/rest/v1/resources/monetization";
	public final static String	CONFIG_MONETIZATION_INVALIDURL	= strAdapterEnv + "/kohls/adapters/rest/v1/configures/monetiza";
	public final static String	MESSAGES_LOG					= strAdapterEnv + "/messages.log";

	// Balance
	public final static String	BALANCE_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/kohlsCash";
	public final static String	LOG_ADAPTER		= strAdapterEnv + "/adapterReqRes.log";

	// BazaarVoice
	public final static String	GET_SUBMIT_ANSFORM_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/answerform?QuestionId=";
	public final static String	GET_SUBMIT_QFORM_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/questionform?ProductId=";
	public final static String	AUTHORS_ID_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/reviews?Filter=";
	public final static String	GETQA_PRODUCT_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/QandAs?ProductId=";
	public final static String	GETQA_PRODUCT_ADAPTER_FILTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/QandAs?Filter=ProductId:";
	public final static String	SUBMIT_QUESTION_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/questions";
	public final static String	SUBMIT_ANSWER_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/answers";
	public final static String	SUBMIT_ANSFORM_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/answerform?QuestionId=578603&ProductId=1284944";
	public final static String	SUBMIT_QESFORM_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/questionform?ProductId=";
	public final static String	SUBMIT_REVIEW_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/reviews";
	public final static String	SUBMIT_FEEDBACK_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/feedback";
	public final static String	GET_REVIEWS_PRODUCT_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/reviews?Filter=";
	public final static String	SALEALERT_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/subscribe/saleAlerts";
	public final static String	RECOMMENDATION_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/recommendation?type=";
	public final static String	CMS_ADAPTER					= strAdapterEnv + "/kohls/adapters/rest/v1/cms?campaignName=";
	public final static String	SHOW_REVIEW_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/reviews?Sort=SubmissionTime:desc&Stats=Reviews&Include=Products&";
	public final static String	GET_QA_FEEDBACK_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/feedback";
	public final static String	POST_QUESTION_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/questions";
	public final static String	POST_ANSWER_ADAPTER			= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/answers";
	public final static String	GET_QA_PRODUCT_ADAPTER		= strAdapterEnv + "/kohls/adapters/rest/v1/bzv/QandAs";

	
	//MasterPass
	public final static String	REQUEST_DATA		= strAdapterEnv + "/kohls/adapters/rest/v1/payments/masterpass/requestdata?brandID=nativeapp";
	
	// stores
	public final static String	STORESBYOPENSEARCH_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/stores?postalCode=";
	public final static String	GEOFENCE_STORES_ADAPTERS	= strAdapterEnv + "/kohls/adapters/rest/v1/locations";

	// Validation
	public final static String VALIDATION_ADAPTER = strAdapterEnv + "/kohls/adapters/rest/v1/validation";
	
	//Service Metadata
	public final static String METADATA_ADAPTER = strAdapterEnv + "/kohls/adapters/rest/v1/resources/accessInfo";
  
	public final static String GET_TOKEN_V2 = strWalletEnv + "/wallet/v2/token";
	
	public final static String CREATE_LOYALTYID = strWalletEnv + "/loyalty/v1/profiles?channel=E";
	
	public final static String CUSTOMER_ADAPTER = strAdapterEnv + "/kohls/adapters/rest/v1/customer";
	
	public final static String GET_LOYALITY= strWalletEnv +"/loyalty/v1/profiles";
	
	public final static String	GET_WALLET_ID= strWalletEnv + "/wallet/v1/id";
	
	//Recommendation
	public final static String RECOMMENDATION_EDE_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/ede/recommendations";
	
	public final static String EXPERIENCES_EDE_ADAPTER      =strAdapterEnv + "/kohls/adapters/rest/v1/ede/experiences";
	
	public final static String CONTENT_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/content/screensaver";
	
	public final static String POSLOCATION_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/resources/Endyme";
	
	public final static String CMSAPPMESSAGES_ADAPTER	= strAdapterEnv + "/kohls/adapters/rest/v1/resources/appmessages";
	
	// ************************************************************************************************************************************
	// ******************************************************OPEN API URLS*****************************************************************
	// ************************************************************************************************************************************

	// Set the resource end point URLs for OAPI
	// Profile
	public final static String	PWD_VERFICATION_OAPI			= strOpenAPIEnvHTTPS + "v1/profile/password";
	public final static String	PROFILE_CREATE_OAPI				= strOpenAPIEnvHTTPS + "/v1/profile/create";
	public final static String	PROFILE_OAPI					= strOpenAPIEnvHTTPS + "/v1/profile";
	public final static String	PROFILE_INFO_OAPI				= strOpenAPIEnvHTTPS + "/v1/profile/info";
	public final static String	V1_SIGNIN_PROFILE_OAPI			= strOpenAPIEnvHTTPS + "/token";
	public final static String	PROFILE_PAYMENT_OAPI			= strOpenAPIEnvHTTPS + "/v1/profile/paymentType";
	public final static String	PROFILE_BILL_ADDRESS_OAPI		= strOpenAPIEnvHTTPS + "/v1/profile/billAddress";
	public final static String	PROFILE_SHIPPING_ADDRESS_OAPI	= strOpenAPIEnvHTTPS + "/v1/profile/shipAddress";
	public final static String	FORGOT_PASSWORD_OAPI			= strOpenAPIEnvHTTPS + "/v1/profile/forgotPassword?email=";

	// cart and order
	public final static String	CART_OAPI				= strOpenAPIEnvHTTPS + "/v1/cart";
	public final static String	ORDERCALC_OAPI			= strOpenAPIEnvHTTPS + "/v1/order/calculation?trEnabled=true";
	public final static String	PLACEORDER_OAPI			= strOpenAPIEnvHTTPS + "/v1/order?trEnabled=true";
	public final static String	PLACEORDERV2_OAPI		= strOpenAPIEnvHTTPS + "/v2/order?trEnabled=true";
	public final static String	PLACEORDER_OAPI_INSTANTBUY_V2		= strOpenAPIEnvHTTPS + "/v1/order?trEnabled=true&orderType=instant";
	public final static String	PLACEORDERV2_OAPI_INSTANTBUY_V2		= strOpenAPIEnvHTTPS + "/v2/order?trEnabled=true&orderType=instant";
	public final static String	ORDERCALC_OAPI_INSTANTBUY_V2			= strOpenAPIEnvHTTPS + "/v1/order/calculation?trEnabled=true&orderType=instant";
	public final static String	RETRIEVE_ORDERS_OAPI	= strOpenAPIEnvHTTPS + "/v1/orders";
	public final static String	RETRIEVE_ORDER_OAPI		= strOpenAPIEnvHTTPS + "/v1/order";
	public final static String	ORDERCALC_OAPI_V2		= strOpenAPIEnvHTTPS + "/v2/order/calculation?trEnabled=true";
	public final static String	ORDERCALCV2_OAPI_INSTANTBUY_V2		= strOpenAPIEnvHTTPS + "/v2/order/calculation?trEnabled=true&orderType=instant";
	public final static String PROFILE_LOYALITY_CREATE = strOpenAPIEnvHTTPS + "/v1/loyalty/create";
	// Inventory
	public final static String	INVENTORY_WEBID_OAPI	= strOpenAPIEnvHTTP + "/v1/inventory/webID";
	public final static String	INVENTORY_SKU_OAPI		= strOpenAPIEnvHTTP + "/v1/inventory/sku";

	// Product Inventory chek
			public final static String	SINGLE_PRODUCT_INVENTORY_OAPI	        = strOpenAPIEnvHTTP + "/v1/productInventoryCheck";
			public final static String	PRODUCTS_BY_SKU_INVENTORY_OAPI			= strOpenAPIEnvHTTP + "/v1/productInventoryCheck?skuCode=";
			public final static String	PRODUCTS_BY_UPC_INVENTORY_OAPI			= strOpenAPIEnvHTTP + "/v1/productInventoryCheck?upc=";

	// Price
	public final static String	PRICE_WEB_OAPI	= strOpenAPIEnvHTTP + "/v1/price/webID";
	public final static String	PRICE_SKU_OAPI	= strOpenAPIEnvHTTP + "/v1/price/sku";

	// Category
	public final static String	CATALOG_OAPI	= strOpenAPIEnvHTTP + "/v1/catalog";
	public final static String	PRODUCT_CATALOG_OAPI	= strOpenAPIEnvHTTP + "/v1/catalog/productCount";
	public final static String	CATEGORY_OAPI	= strOpenAPIEnvHTTP + "/v1/catalog/category";
	public final static String	CATEGORY_V2_OAPI	= strOpenAPIEnvHTTP + "/v2/catalog/category";

	// SingleProductDetails
	public final static String	SINGLE_PRODUCT_DETAILS_OAPI	= strOpenAPIEnvHTTP + "/v1/product";
	public final static String	PRODUCTS_BY_SKU_OAPI		= strOpenAPIEnvHTTP + "/v1/product?skuCode=";
	public final static String	PRODUCTS_BY_UPC_OAPI		= strOpenAPIEnvHTTP + "/v1/product?upc=";
	public final static String SINGLE_PRODUCT_DETAILS_OAPI_V2 = strOpenAPIEnvHTTP + "/v1/product";
	public final static String PRODUCTS_BY_SKU_OAPI_V2 = strOpenAPIEnvHTTP + "/v1/product?skuCode=";
	public final static String PRODUCTS_BY_UPC_OAPI_V2 = strOpenAPIEnvHTTP + "/v1/product?upc=";
	
	// Offer
	public final static String	OFFERID_OAPI					= strOpenAPIEnvHTTP + "/v1/offers/lookup?offerId=";
	public final static String	OFFERCODE_OAPI					= strOpenAPIEnvHTTP + "/v1/offers/lookup?offerCode=";
	public final static String	OFFER_LOOKUP_PRODUCT_OAPI		= strOpenAPIEnvHTTP + "/v1/product";
	public final static String	OFFERTYPE_OAPI					= strOpenAPIEnvHTTP + "/v1/offers?offerType=";
	public final static String	INVALID_OFFER_PRODUCTID_OAPI	= strOpenAPIEnvHTTP + "/v1/offers/product";
	public final static String	OFFER_PRODUCTID_OAPI			= strOpenAPIEnvHTTP + "/v1/offers/product?productId=";
	// SaleAlert
	public final static String	SALEALERT_OAPI					= strOpenAPIEnvHTTP + "/v1/subscribe/saleAlerts";

	// kohlsCashBalance
	public final static String BALANCE_OAPI = strOpenAPIEnvHTTP + "/v1/kohlsCash";

	// Recommendation
	public final static String RECOMMENDATION_OAPI = strOpenAPIEnvHTTP + "/v1/recommendation?type=";

	// stores
	public final static String STORESBYOPENSEARCH_OAPI = strOpenAPIEnvHTTP + "/v1/stores?postalCode=";

	// Skava URl : CMS
	public final static String CMS_SKAVA = strSkavaEnv + "/skavastream/studio/v2/skava/getSimplePageByName/182/stg/Phone?campaignName=";

	// Validation
	public final static String VALIDATION_OAPI = strOpenAPIEnvHTTP + "/v1/validation";
	
	public final static String CUSTOMER_OAPI = strOpenAPIEnvHTTPS + "/v1/customer";
	
	public final static String CONTENT_OAPI = strOpenAPIEnvHTTP + "/v1/content/screensaver";
	
	

	// ************************************************************************************************************************************
	// ******************************************************BAZZAR VOICE URLS*****************************************************************
	// ************************************************************************************************************************************
	public final static String	SUBMIT_QUESTION_BAZZARVOICE		= strBazaarVoiceEnv + "/data/submitquestion.json?";
	public final static String	SUBMIT_ANSWER_BAZZARVOICE		= strBazaarVoiceEnv + "/data/submitanswer.json?";
	public final static String	AUTHORS_ID_BAZZ					= strBazaarBaseEnv + "/data/reviews.json?";
	public final static String	GETQA_PRODUCT_BAZZ				= strBazaarVoiceEnv + "/data/questions.json?";
	public final static String	AUTHORS_ID_BAZAARVOICE			= strBazaarVoiceEnv + "/data/reviews.json?Filter=";
	public final static String	GET_SUBMIT_ANSFORM_BAZAARVOICE	= strBazaarVoiceEnv + "/data/submitanswer.json?";
	public final static String	GET_SUBMIT_QFORM_BAZAARVOICE	= strBazaarVoiceEnv + "/data/submitquestion.json?";
	public final static String	SUBMIT_REVIEW_BAZAARVOICE		= strBazaarVoiceEnv + "/data/submitreview.json?";
	public final static String	SUBMIT_FEEDBACK_BAZAARVOICE		= strBazaarVoiceEnv + "/data/submitfeedback.json?";
	public final static String	GET_REVIEWS_PRODUCT_BAZAARVOICE	= strBazaarVoiceEnv + "/data/reviews.json?Filter=";
	public final static String	SHOW_REVIEW_BAZAARVOICE			= strBazaarVoiceEnv + "/data/reviews.json?passkey=9ngrf7rngkhm4a7r6n4uvxaq&apiVersion=5.4& ";

}
