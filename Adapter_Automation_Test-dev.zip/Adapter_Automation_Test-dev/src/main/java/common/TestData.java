package main.java.common;

import static main.java.common.GlobalVariables.BALANCE_ADAPTER;
import static main.java.common.GlobalVariables.CATALOG_ADAPTER;
import static main.java.common.GlobalVariables.INVENTORY_WEBID_ADAPTER;
import static main.java.common.GlobalVariables.SINGLE_PRODUCT_DETAILS_ADAPTER;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;


import org.apache.commons.codec.binary.Hex;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;
import org.testng.SkipException;

import com.jayway.jsonpath.JsonPath;

import main.java.json.ResponseValidator;
import net.minidev.json.JSONArray;

public class TestData {

	public enum Server {
		Adapter, OpenApi, BazaarVoice, Skava,WalletAuth;
	}

	public static HashMap<String, String>	mapheader					= new HashMap<String, String>();
	public static HashMap<String, String>	testData					= new HashMap<String, String>();
	public static HashMap<String, String>	kohlsCashData				= new HashMap<String, String>();
	static boolean							KohlsCashLoadedFromExcel	= false;


	// ** Read the Kohls Cash Test_Data.xlsx File
	public static void loadKohlsCashFromExcel() {
		// System.out.println("inside kohls cash script");

		try {
			// System.out.println("inside try block");
			InputStream ExcelFileToRead = new FileInputStream("Resource/Data/KohlsCash.xlsx");

			// System.out.println("after input straem");

			XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);

			// System.out.println("after XSSfworkbook");

			// Select the Common_Data Sheet and add all values
			XSSFSheet sheet = wb.getSheet("Sheet1");
			String strKohlsCashNum = "";
			String strKohlsCashPin = "";
			// Row row = sheet.getRow(0);
			// int intTotalColumnCount = row.getPhysicalNumberOfCells();
			int intTotalRowCount = sheet.getPhysicalNumberOfRows();
			// System.out.println(intTotalColumnCount + " " + intTotalCountCount);
			// System.out.println(intTotalColumnCount + " " + intTotalRowCount);

			for (int intRowCounter = 1; intRowCounter < intTotalRowCount; intRowCounter++) {
				Cell cell = sheet.getRow(intRowCounter).getCell(0);
				strKohlsCashNum = (cell == null) ? "" : cell.getStringCellValue().trim();
				if (!strKohlsCashNum.startsWith("#") && !strKohlsCashNum.equals("")) {
					cell = sheet.getRow(intRowCounter).getCell(3);
					if (cell != null)
						cell.setCellType(Cell.CELL_TYPE_STRING);
					strKohlsCashPin = (cell == null) ? "" : cell.getStringCellValue();
					// System.out.println("Kohls cash card" + strVariableName);
					// System.out.println("Kohls cash pin " + strCellData);

					kohlsCashData.put(strKohlsCashNum, strKohlsCashPin);

				}
			}

			ExcelFileToRead.close();
			wb.close();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("Unable to Load the Test Data File");
		}
		finally {
			KohlsCashLoadedFromExcel = true;
		}

	}


	public static void loadTestData() {

		try {
			// ** Read the Environment_Details.xlsx File
			InputStream ExcelFileToRead = new FileInputStream("Resource/Data/Environment_Details.xlsx");
			XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
			// Select the Select_Environment Sheet and read the Adapter and OAPI environment values
			XSSFSheet sheet = wb.getSheet("Select_Environment");
			String strOAPIEnv, strAdapterEnv, strCompareOAPI,strWalletEnv,strMfpToken,strDeviceFP,kohlsCashLimit,strNuData;
		
			// Check for Jenkins Environment variables, else read from excel sheet
			if (System.getenv("OpenAPI_Environment") != null) {
				strOAPIEnv = System.getenv("OpenAPI_Environment");
				strAdapterEnv = System.getenv("Adapter_URL");
				strCompareOAPI = System.getenv("Compare_OpenAPI");
				strWalletEnv = System.getenv("Wallet_URL");
				strMfpToken = System.getenv("Mfp_Oauth_Token");
				strDeviceFP = System.getenv("Device_Finger_Print");
				kohlsCashLimit =System.getenv("KohlsCash_Limit");
				strNuData =System.getenv("NuData");
			} else {
				strOAPIEnv = sheet.getRow(1).getCell(1).getStringCellValue();
				strAdapterEnv = sheet.getRow(2).getCell(1).getStringCellValue();
				strWalletEnv = sheet.getRow(3).getCell(1).getStringCellValue();
				strCompareOAPI = sheet.getRow(4).getCell(1).getStringCellValue();
				strMfpToken = sheet.getRow(5).getCell(1).getStringCellValue();
				strDeviceFP = sheet.getRow(6).getCell(1).getStringCellValue();
				kohlsCashLimit = sheet.getRow(7).getCell(1).getStringCellValue();
				strNuData = sheet.getRow(8).getCell(1).getStringCellValue();
			}
			// Print the environemnt details
			System.out.println("---- Adapter Env : " + strAdapterEnv + "\n---- OAPI Env :" + strOAPIEnv);
			testData.put("OAPI_Environemnt", strOAPIEnv);
			testData.put("Adapter_Environemnt", strAdapterEnv);
			testData.put("Wallet_Environemnt", strWalletEnv);
			testData.put("Compare_OpenAPI", strCompareOAPI);
			testData.put("Mfp_Oauth_Token", strMfpToken);
			testData.put("Device_Finger_Print", strDeviceFP);
			testData.put("Kohls_Cash_Limit", kohlsCashLimit);
			testData.put("NuData", strNuData);
			// Select the Environment_Details and properties for given environment
			sheet = wb.getSheet("Environment_Details");
			Row row = sheet.getRow(0);
			int intTotalColumnCount = row.getPhysicalNumberOfCells();
			int intTotalRowCount = sheet.getPhysicalNumberOfRows();
			// System.out.println(intTotalColumnCount + " " + intTotalRowCount);
			String strCellData = "", strVariableName = "";
			for (int intColumnCounter = 1; intColumnCounter < intTotalColumnCount; intColumnCounter++) {
				Cell cell = row.getCell(intColumnCounter);
				// Check if the correct OPAI column is present
				if (cell.getStringCellValue().equalsIgnoreCase(strOAPIEnv)) {
					// Loop throuugh all rows for the required environment variables
					for (int intRowCounter = 1; intRowCounter < intTotalRowCount; intRowCounter++) {
						// Read the variable name from the 1st column
						cell = sheet.getRow(intRowCounter).getCell(0);
						strVariableName = (cell == null) ? "" : cell.getStringCellValue().trim();
						if (!strVariableName.startsWith("#") && !strVariableName.equals("")) {
							cell = sheet.getRow(intRowCounter).getCell(intColumnCounter);
							if (cell != null)
								cell.setCellType(Cell.CELL_TYPE_STRING);
							strCellData = (cell == null) ? "" : cell.getStringCellValue();
							testData.put(strVariableName, strCellData);
						}

					}
					break;
				}
			}

			// ** Read the Test_Data.xlsx File
			ExcelFileToRead = new FileInputStream("Resource/Data/Test_Data.xlsx");
			wb = new XSSFWorkbook(ExcelFileToRead);
			// Select the Common_Data Sheet and add all values
			sheet = wb.getSheet("Common_Data");
			intTotalColumnCount = row.getPhysicalNumberOfCells();
			intTotalRowCount = sheet.getPhysicalNumberOfRows();
			for (int intRowCounter = 1; intRowCounter < intTotalRowCount; intRowCounter++) {
				Cell cell = sheet.getRow(intRowCounter).getCell(0);
				strVariableName = (cell == null) ? "" : cell.getStringCellValue().trim();
				if (!strVariableName.startsWith("#") && !strVariableName.equals("")) {
					cell = sheet.getRow(intRowCounter).getCell(1);
					if (cell != null)
						cell.setCellType(Cell.CELL_TYPE_STRING);
					strCellData = (cell == null) ? "" : cell.getStringCellValue();
					testData.put(strVariableName, strCellData);

				}
			}
			// Select the Env_Data and add test data for given environment
			sheet = wb.getSheet("Env_Data");
			row = sheet.getRow(0);
			intTotalColumnCount = row.getPhysicalNumberOfCells();
			intTotalRowCount = sheet.getPhysicalNumberOfRows();
			// System.out.println(intTotalColumnCount + " " + intTotalRowCount);
			for (int intColumnCounter = 1; intColumnCounter < intTotalColumnCount; intColumnCounter++) {
				Cell cell = row.getCell(intColumnCounter);
				// Check if the correct OPAI column is present
				if (cell.getStringCellValue().equalsIgnoreCase(strOAPIEnv)) {
					// Loop throuugh all rows for the required environment variables
					for (int intRowCounter = 1; intRowCounter < intTotalRowCount; intRowCounter++) {
						// Read the variable name from the 1st column
						cell = sheet.getRow(intRowCounter).getCell(0);
						strVariableName = (cell == null) ? "" : cell.getStringCellValue().trim();
						if (!strVariableName.startsWith("#") && !strVariableName.equals("")) {
							cell = sheet.getRow(intRowCounter).getCell(intColumnCounter);
							if (cell != null)
								cell.setCellType(Cell.CELL_TYPE_STRING);
							strCellData = (cell == null) ? "" : cell.getStringCellValue();
							testData.put(strVariableName, strCellData);
						}

					}
					break;
				}
			}

			// Print the properties which are loaded
			/*
			 * for (String s : testData.keySet()){ System.out.println(s + " : " + testData.get(s)); }
			 */

			ExcelFileToRead.close();
			wb.close();

			// Setting a variable to mark Test data load compelte
			testData.put("TEST_DATA_STATUS", "COMPLETE");

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			testData.put("TEST_DATA_STATUS", "FAIL");
			Assert.fail("Unable to Load the Test Data File");
		}

	}


	public static void getRunTimeData(String strRequiredData, boolean ForceNewValue) {

		// Check if required data already available eg. SKU will be available as RUNTIME_SKU if already available
		// If new value Generation is enforced, then generate new value even if there is an existing value
		if (!ForceNewValue && testData.containsKey("RUNTIME_" + strRequiredData))
			return;

		switch (strRequiredData) {

			case "CATEGORY_ID":
				getRunTimeCategory_WebID_SKU();
				break;

			case "WEB_ID":
				getRunTimeCategory_WebID_SKU();
				break;

			case "SKU_CODE":
				getRunTimeCategory_WebID_SKU();
				break;

			case "KOHLS_CASH_NO":
				getRunTimeKohlsCash();
				break;

			case "INSTORE_SKU_CODE":
				getRunTimeCategory_Instore_SKU();
				break;

			case "INSTORE_WEB_ID":
				getRunTimeCategory_Instore_SKU();
				break;

			case "INSTORE_BOGO_SKU":
				getRunTimeCategory_Instore_BOGO_SKU();
				break;

			case "INSTORE_BOGO_WEBID":
				getRunTimeCategory_Instore_BOGO_SKU();
				break;

			case "INSTORE_BOGO_UPC":
				getRunTimeCategory_Instore_BOGO_SKU();
				break;

			case "INSTORE_REBATE_SKU":
				getRunTimeCategory_Instore_Rebate_SKU();
				break;

			case "INSTORE_REBATE_WEB":
				getRunTimeCategory_Instore_Rebate_SKU();
				break;

			case "INSTORE_REBATE_UPC":
				getRunTimeCategory_Instore_Rebate_SKU();
				break;

			case "INSTORE_OUT_OF_STOCK":
				getRunTimeCategory_Instore_OutOfStock_SKU();
				break;
		}

	}


	private static void getRunTimeKohlsCash() {
		
		
		///**************
		// Temporarily hardcoding a KC with high balance as balance api is timing out in kd01
		
		testData.put("RUNTIME_KOHLS_CASH_NO", "142777528537279");
		testData.put("RUNTIME_KOHLSCASH_PIN", "8088");
		
		if (true) return;  // forcing return
		
		// To be removed
		//**///

		// Load Kohls Cash from Xls file if not already loaded
		if (!KohlsCashLoadedFromExcel && kohlsCashData.isEmpty()) {
			loadKohlsCashFromExcel();
		}

		String strKohlsCashCoupon = "";
		String strKohlsCashPin = "";
		boolean KohlsCashFound = false;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date currentdate = new Date();

		try {
			Iterator<Entry<String, String>> iterator = kohlsCashData.entrySet().iterator();
			while (iterator.hasNext()) {
				Entry<String, String> entry = iterator.next();
				strKohlsCashCoupon = entry.getKey();
				strKohlsCashPin = entry.getValue();
				System.out.println("Kohls cash no " + strKohlsCashCoupon);

				String strURL = BALANCE_ADAPTER + "/" + strKohlsCashCoupon + "/" + "balance";
				String strResponse = RestCall.simpleGetRequest(strURL, Server.Adapter, false);

				if (strResponse.contains("errors")) {
					// If Balance gives error, remove that coupon from Hashmap to prevent checking next time
					iterator.remove();
					continue;   // Go to the next iteration
				}

				String strBalance = Utilities.getJsonNodeValue(strResponse, "$.payload.kohlsCash.balance");
				String strstartDate = Utilities.getJsonNodeValue(strResponse, "$.payload.kohlsCash.validDates.startDate");
				String strendDate = Utilities.getJsonNodeValue(strResponse, "$.payload.kohlsCash.validDates.endDate");
				Date Startdate;
				Startdate = dateFormat.parse(strstartDate);
				Date Enddate;
				Enddate = dateFormat.parse(strendDate);

				if (!(strBalance.equals("0.0") || strBalance.equals(""))) {
					if (strBalance.length() > 4 && currentdate.after(Startdate) && currentdate.before(Enddate)) {
						testData.put("RUNTIME_KOHLS_CASH_NO", strKohlsCashCoupon);
						testData.put("RUNTIME_KOHLSCASH_PIN", strKohlsCashPin);
						KohlsCashFound = true;
						break;
						
					} else {
						// If Balance is small, remove that coupn from the HashMap to prevent checking next time
						iterator.remove();
					}
				} else {
					// If Balance is Zero or null, remove that coupon from Hashmap to prevent checking next time
					iterator.remove();
				}
			}

			if (!KohlsCashFound) {
				throw new SkipException("Cannot Find Kohls Cash Coupn with Balance");
			}

		}
		catch (SkipException e) {
			throw e;
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


	private static void getRunTimeCategory_WebID_SKU() {

		try {
			// Send the request to get Catalog response
			String strResponse = RestCall.simpleGetRequest(CATALOG_ADAPTER, Server.Adapter, false);

			// Validate the response has no errors
			new ResponseValidator(strResponse).validateNoErrors();

			JSONArray strActual = JsonPath.read(strResponse, "$.payload.dimensions");
			String categoryID = null;

			outerLoop: for (int i = 0; i < strActual.size(); i++) {
				JSONArray dimensionValues = JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues");
				for (int j = 0; j < dimensionValues.size(); j++) {
					categoryID = String.valueOf(JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues[" + j + "].ID"));
					if ((categoryID != null) && (!categoryID.equals("null"))) {
						break outerLoop;   // break out of both loops
					}

				}

			}

			// Set the Runtime categoryID in Testdata
			testData.put("RUNTIME_CATEGORY_ID", categoryID);

			// Get the Runtime WebID
			JSONArray Products = JsonPath.read(strResponse, "$.payload..webID");
			for (int k = 0; k < Products.size(); k++) {
				if (testData.get("RUNTIME_SKU_CODE") != null) {
					break;
				}
				String webID = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].webID"));
				// Do not pick collections webid
				if (webID.startsWith("c")) {
					continue;				
				}
				testData.put("RUNTIME_WEB_ID", webID);
				String strURL = INVENTORY_WEBID_ADAPTER + "/" + testData.get("RUNTIME_WEB_ID");
				// Post the request
				String strResponseWebID = RestCall.simpleGetRequest(strURL, Server.Adapter, false);

				// If the WebID gives errors, Skip and go to the next one
				if (strResponseWebID.contains("\"errors\""))
					continue;

				// Set the Runtime SKU
				JSONArray SKUS = JsonPath.read(strResponseWebID, "$.payload..skuCode");
				for (int i = 0; i < SKUS.size(); i++) {
					String skuCode = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].skus[" + i + "].skuCode"));
					String StockAvailability = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].skus[" + i + "].stores[0].availability"));
					if (StockAvailability.equals("In Stock")) {
						testData.put("RUNTIME_SKU_CODE", skuCode);
						System.out.println("SKUCODE PRINT=" + testData.get("RUNTIME_SKU_CODE"));
						break;
					}
				}
			}
		}
		catch (Exception e) {

			e.printStackTrace();
			// Skip the testcase as testdata could not be generated
			throw new SkipException("Cannot Find testdata for this Testcase. Error in geenrating CategoryID, WebID and SKU");

		}
	}


	private static void getRunTimeCategory_Instore_SKU() {

		try {

			String strUrl = CATALOG_ADAPTER + "?inStoreEnabled=true&storeNum=759";
			// Send the request to get Catalog response
			String strResponse = RestCall.simpleGetRequest(strUrl, Server.Adapter, false);

			// Validate the response has no errors
			new ResponseValidator(strResponse).validateNoErrors();

			JSONArray strActual = JsonPath.read(strResponse, "$.payload.dimensions");
			String categoryID = null;

			outerLoop: for (int i = 0; i < strActual.size(); i++) {
				JSONArray dimensionValues = JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues");
				for (int j = 0; j < dimensionValues.size(); j++) {
					categoryID = String.valueOf(JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues[" + j + "].ID"));
					System.out.println(categoryID);
					if ((categoryID != null) && (!categoryID.equals("null"))) {
						break outerLoop;   // break out of both loops
					}

				}

			}

			// Set the Runtime categoryID in Testdata
			testData.put("RUNTIME_INSTORE_CATEGORY_ID", categoryID);

			// Get the Runtime WebID

			JSONArray Products = JsonPath.read(strResponse, "$.payload..webID");
			for (int k = 0; k < Products.size(); k++) {
				if (testData.get("RUNTIME_INSTORE_SKU_CODE") != null) {
					break;
				}
				String webID = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].webID"));
				System.out.println(webID);
				testData.put("RUNTIME_INSTORE_WEB_ID", webID);
				String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RUNTIME_INSTORE_WEB_ID") + "?skuDetail=true&storeNum=759";
				// Post the request
				String strResponseWebID = RestCall.simpleGetRequest(strURL, Server.Adapter, false);

				// If the WebID gives errors, Skip and go to the next one
				if (strResponseWebID.contains("\"errors\""))
					continue;

				// Set the Runtime SKU
				JSONArray SKUS = JsonPath.read(strResponseWebID, "$.payload..skuCode");
				for (int i = 0; i < SKUS.size(); i++) {
					String skuCode = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].skuCode"));
					String upc = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].UPC.ID"));
					// String StockAvailability=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].skus[" +i + "].stores[0].availability"));
					testData.put("RUNTIME_INSTORE_SKU_CODE", skuCode);
					testData.put("RUNTIME_INSTORE_UPC", upc);
					System.out.println("SKUCODE PRINT=" + testData.get("RUNTIME_INSTORE_SKU_CODE"));
					break;
				}
			}

		}
		catch (Exception e) {

			e.printStackTrace();
			// Skip the testcase as testdata could not be generated
			throw new SkipException("Cannot Find testdata for this Testcase. Error in geenrating CategoryID, WebID and SKU");

		}
	}


	private static void getRunTimeCategory_Instore_BOGO_SKU() {

		try {

			String strUrl = CATALOG_ADAPTER + "?inStoreEnabled=true&storeNum=647";
			// Send the request to get Catalog response
			String strResponse = RestCall.simpleGetRequest(strUrl, Server.Adapter, false);

			// Validate the response has no errors
			new ResponseValidator(strResponse).validateNoErrors();

			JSONArray strActual = JsonPath.read(strResponse, "$.payload.dimensions");
			String categoryID = null;

			outerLoop: for (int i = 0; i < strActual.size(); i++) {
				JSONArray dimensionValues = JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues");
				for (int j = 0; j < dimensionValues.size(); j++) {
					categoryID = String.valueOf(JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues[" + j + "].ID"));
					System.out.println(categoryID);
					if ((categoryID != null) && (!categoryID.equals("null"))) {

						break outerLoop;   // break out of both loops
					}

				}

			}

			// Set the Runtime categoryID in Testdata
			testData.put("RUNTIME_INSTORE_CATEGORY_ID", categoryID);
			System.out.println(testData.get("RUNTIME_INSTORE_CATEGORY_ID"));

			// Get the Runtime WebID
			JSONArray Products = JsonPath.read(strResponse, "$.payload..webID");

			for (int k = 0; k < Products.size(); k++) {

				if (testData.get("RUNTIME_INSTORE_SKU_BOGO") != null) {

					break;
				}

				String webID = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].webID"));
				System.out.println(webID);
				String isPriceInstore = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].prices[0].isPriceInstore"));
				String strPromotion = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].prices[0].promotion"));
				System.out.println(strPromotion);
				if (isPriceInstore.equals("true") && (strPromotion.matches("BUY 1 GET 1"))) {
					testData.put("RUNTIME_INSTORE_WEB_BOGO", webID);
					break;
				} else {
					continue;
				}
			}

			String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RUNTIME_INSTORE_WEB_BOGO") + "?skuDetail=true&storeNum=647";
			// Post the request
			String strResponseWebID = RestCall.simpleGetRequest(strURL, Server.Adapter, false);
			System.out.println(strResponseWebID);
			// If the WebID gives errors, Skip and go to the next one

			// Set the Runtime SKU
			JSONArray SKUS = JsonPath.read(strResponseWebID, "$.payload..skuCode");
			for (int i = 0; i < SKUS.size(); i++) {
				String skuCode = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].skuCode"));
				String strStorePrice = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].storeInfo.stores[0].price"));
				if (!strStorePrice.equals("null")) {
					// String strPromotion=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].SKUS[" +i + "].storeInfo.stores[0].price.promotion"));

					// String StockAvailability=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].skus[" +i + "].stores[0].availability"));
					testData.put("RUNTIME_INSTORE_SKU_BOGO", skuCode);
					String webID_BOGO = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.prdoucts[0].webID"));
					testData.put("RUNTIME_INSTORE_WEB_BOGO", webID_BOGO);
					System.out.println(testData.get("RUNTIME_INSTORE_SKU_BOGO"));
					System.out.println("SKUCODE PRINT=" + testData.get("RUNTIME_INSTORE_SKU_BOGO"));
					break;
				} else
					continue;
			}

		}
		catch (Exception e) {

			e.printStackTrace();
			// Skip the testcase as testdata could not be generated
			throw new SkipException("Cannot Find testdata for this Testcase. Error in geenrating CategoryID, WebID and SKU");

		}
	}


	private static void getRunTimeCategory_Instore_OutOfStock_SKU() {

		try {

			String strUrl = CATALOG_ADAPTER + "?inStoreEnabled=true&storeNum=647";
			// Send the request to get Catalog response
			String strResponse = RestCall.simpleGetRequest(strUrl, Server.Adapter, false);

			// Validate the response has no errors
			new ResponseValidator(strResponse).validateNoErrors();

			JSONArray strActual = JsonPath.read(strResponse, "$.payload.dimensions");
			String categoryID = null;

			outerLoop: for (int i = 0; i < strActual.size(); i++) {
				JSONArray dimensionValues = JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues");
				for (int j = 0; j < dimensionValues.size(); j++) {
					categoryID = String.valueOf(JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues[" + j + "].ID"));
					System.out.println(categoryID);
					if ((categoryID != null) && (!categoryID.equals("null"))) {

						break outerLoop;   // break out of both loops
					}

				}

			}

			// Set the Runtime categoryID in Testdata
			testData.put("RUNTIME_INSTORE_CATEGORY_ID", categoryID);
			System.out.println(testData.get("RUNTIME_INSTORE_CATEGORY_ID"));

			// Get the Runtime WebID
			JSONArray Products = JsonPath.read(strResponse, "$.payload..webID");

			for (int k = 0; k < Products.size(); k++) {

				if (testData.get("RUNTIME_INSTORE_SKU_OUTOFSTOCK") != null) {

					break;
				}

				String webID = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].webID"));
				System.out.println(webID);
				testData.put("RUNTIME_INSTORE_WEB_OUTOFSTOCK", webID);

			}

			String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RUNTIME_INSTORE_WEB_OUTOFSTOCK") + "?skuDetail=true&storeNum=647";
			// Post the request
			String strResponseWebID = RestCall.simpleGetRequest(strURL, Server.Adapter, false);
			System.out.println(strResponseWebID);
			// If the WebID gives errors, Skip and go to the next one

			// Set the Runtime SKU
			JSONArray SKUS = JsonPath.read(strResponseWebID, "$.payload..skuCode");
			for (int i = 0; i < SKUS.size(); i++) {
				String skuCode = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].skuCode"));
				String storeAvailability = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].storeInfo.stores[0].availability"));
				if (storeAvailability.equals("Out of Stock")) {
					// String strPromotion=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].SKUS[" +i + "].storeInfo.stores[0].price.promotion"));

					// String StockAvailability=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].skus[" +i + "].stores[0].availability"));
					testData.put("RUNTIME_INSTORE_SKU_OUTOFSTOCK", skuCode);
					String upc = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].UPC.ID"));
					testData.put("RUNTIME_INSTORE_UPC_OUTOFSTOCK", upc);
					break;
				} else
					continue;
			}

		}
		catch (Exception e) {

			e.printStackTrace();
			// Skip the testcase as testdata could not be generated
			throw new SkipException("Cannot Find testdata for this Testcase. Error in geenrating CategoryID, WebID and SKU");

		}
	}


	private static void getRunTimeCategory_Instore_Rebate_SKU() {

		try {

			String strUrl = CATALOG_ADAPTER + "?inStoreEnabled=true&storeNum=647";
			// Send the request to get Catalog response
			String strResponse = RestCall.simpleGetRequest(strUrl, Server.Adapter, false);

			// Validate the response has no errors
			new ResponseValidator(strResponse).validateNoErrors();

			JSONArray strActual = JsonPath.read(strResponse, "$.payload.dimensions");
			String categoryID = null;

			outerLoop: for (int i = 0; i < strActual.size(); i++) {
				JSONArray dimensionValues = JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues");
				for (int j = 0; j < dimensionValues.size(); j++) {
					categoryID = String.valueOf(JsonPath.read(strResponse, "$.payload.dimensions[" + i + "].dimensionValues[" + j + "].ID"));
					System.out.println(categoryID);
					if ((categoryID != null) && (!categoryID.equals("null"))) {

						break outerLoop;   // break out of both loops
					}

				}

			}

			// Set the Runtime categoryID in Testdata
			testData.put("RUNTIME_INSTORE_CATEGORY_ID", categoryID);
			System.out.println(testData.get("RUNTIME_INSTORE_CATEGORY_ID"));

			// Get the Runtime WebID
			JSONArray Products = JsonPath.read(strResponse, "$.payload..webID");

			for (int k = 0; k < Products.size(); k++) {

				if (testData.get("RUNTIME_INSTORE_SKU_REBATE") != null) {

					break;
				}

				String webID = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].webID"));
				System.out.println(webID);
				String isPriceInstore = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].prices[0].isPriceInstore"));
				String strPromotion = String.valueOf(JsonPath.read(strResponse, "$.payload.products[" + k + "].valueAddedIcons"));
				System.out.println(strPromotion);
				if (isPriceInstore.equals("true") && strPromotion.equals("[\"rebate.jpg\"]")) {
					// String webID_Rebate=String.valueOf(JsonPath.read(strResponse,"$.payload.prdoucts["+k+"].webID"));
					testData.put("RUNTIME_INSTORE_WEB_REBATE", webID);
					break;
				} else {
					continue;
				}
			}

			String strURL = SINGLE_PRODUCT_DETAILS_ADAPTER + "/" + testData.get("RUNTIME_INSTORE_WEB_REBATE") + "?skuDetail=true&storeNum=647";
			// Post the request
			String strResponseWebID = RestCall.simpleGetRequest(strURL, Server.Adapter, false);
			System.out.println(strResponseWebID);
			// If the WebID gives errors, Skip and go to the next one

			// Set the Runtime SKU
			JSONArray SKUS = JsonPath.read(strResponseWebID, "$.payload..skuCode");
			for (int i = 0; i < SKUS.size(); i++) {
				String skuCode = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].skuCode"));
				String upc = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].UPC.ID"));
				String strStorePrice = String.valueOf(JsonPath.read(strResponseWebID, "$.payload.products[0].SKUS[" + i + "].storeInfo.stores[0].price"));
				if (!strStorePrice.equals("null")) {
					// String strPromotion=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].SKUS[" +i + "].storeInfo.stores[0].price.promotion"));

					// String StockAvailability=String.valueOf(JsonPath.read(strResponseWebID,"$.payload.products[0].skus[" +i + "].stores[0].availability"));
					testData.put("RUNTIME_INSTORE_SKU_REBATE", skuCode);

					testData.put("RUNTIME_INSTORE_UPC_REBATE", upc);
					System.out.println(testData.get("RUNTIME_INSTORE_SKU_REBATE"));
					System.out.println("SKUCODE PRINT=" + testData.get("RUNTIME_INSTORE_SKU_REBATE"));
					break;
				} else
					continue;
			}

		}
		catch (Exception e) {

			e.printStackTrace();
			// Skip the testcase as testdata could not be generated
			throw new SkipException("Cannot Find testdata for this Testcase. Error in geenrating CategoryID, WebID and SKU");

		}
	}
	
	public static void createLocationAuth() {
		
		
		//Generate timestamp
		long lngTimeStamp =new Date().getTime();
		lngTimeStamp += 86400000;
		
		String strMD5String = testData.get("GEO_STORE_NUM")+ lngTimeStamp +"STORELOC";
		
		String strToken = "";
		try {
			
			//strToken = Hex.encodeHexString(MessageDigest.getInstance("MD5").digest(strMD5String.getBytes()));
			strToken= String.valueOf(Hex.encodeHex(MessageDigest.getInstance("MD5").digest(strMD5String.getBytes())));
			System.out.println("strToken= "+strToken);
			System.out.println("lngTimeStamp= "+lngTimeStamp);
						
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		testData.put("USER_TOKEN", strToken);
		testData.put("Time_Stamp", String.valueOf(lngTimeStamp));
}

	
	


	/** 
	 * Create Kohl's Cash using API requests
	 * @throws Exception 
	 */
	public static  String[] createKohlsCash(int intBalance){
		System.out.println("\n***createKohlsCash***\n");

		String[] arrKC = new String[2];
		arrKC[0] = "";
		arrKC[1] = "";

		try {

			String eventId = "14277";
			String strPayload = "{"
					+ "\"event\":{"
					+ "\"id\":\"" + eventId + "\","
					+ "\"emailAddress\":\"Mobile-Automation-QA@testkohls.com\","
					+ "},"
					+ "\"transactionDetails\":{"
					+ "\"receiptId\":\"988026778770930120005380127\","
					+ "\"dateTime\":\"2015-11-11T04:46:43\","
					+ "\"storeNumber\":\"9973\","
					+ "\"registerId\":\"8\","
					+ "\"transactionNumber\":\"1157\","
					+ "\"activityAmount\":\"" + intBalance + "\","
					+ "\"scanedIndicator\":false,"
					+ "\"qualifiedAmount\":\"100\""
					+ "},"
					+ "\"override\":{"
					+ "\"managerId\":\"12\","
					+ "\"overrideCouponIndicator\":\"false\""
					+ "}"
					+ "}";

			String strResponse = RestCall.postKohlsCashCreate("https://ms-qa.tst.kohls.com:443/dep/api/v1/kohls-cash/issue", strPayload);
			System.out.println(strResponse);

			if (!strResponse.contains("\"barcode\"")){
				Thread.sleep(10000);
				strResponse = RestCall.postKohlsCashCreate("https://ms-qa.tst.kohls.com:443/dep/api/v1/kohls-cash/issue", strPayload);
				System.out.println(strResponse);
				if (!strResponse.contains("\"barcode\""))
					Assert.fail("Kohls cash could not be generated");
			}

			String strKohlsCash = strResponse.substring(strResponse.indexOf(":")+1, strResponse.lastIndexOf("}"));
			strKohlsCash = strKohlsCash.replace("\"", "").trim();
			System.out.println("Kohls Cash " + strKohlsCash);
			String strPin =  String.valueOf(((9999) - ((1000-(Integer.parseInt(strKohlsCash.substring(11,14))))*7)));
			System.out.println("Pin " +  strPin);

			arrKC[0] = strKohlsCash;
			arrKC[1] = strPin;

		} catch(Exception e) {
			e.printStackTrace();
		}
		return arrKC;
	}
	
	public static  String[] createKohlsCash(int intBalance, int noOfKC){
		System.out.println("\n***createKohlsCash***\n");
		int numberOfKC = noOfKC *2 ;
		String[] arrKC = new String[numberOfKC];
		for(int i=0; i<numberOfKC; i++){
		arrKC[i] = "";}

		for(int j=0; j<numberOfKC; j+=2){
		try {

			String eventId = "14277";
			String strPayload = "{"
					+ "\"event\":{"
					+ "\"id\":\"" + eventId + "\","
					+ "\"emailAddress\":\"Mobile-Automation-QA@testkohls.com\","
					+ "},"
					+ "\"transactionDetails\":{"
					+ "\"receiptId\":\"988026778770930120005380127\","
					+ "\"dateTime\":\"2015-11-11T04:46:43\","
					+ "\"storeNumber\":\"9973\","
					+ "\"registerId\":\"8\","
					+ "\"transactionNumber\":\"1157\","
					+ "\"activityAmount\":\"" + intBalance + "\","
					+ "\"scanedIndicator\":false,"
					+ "\"qualifiedAmount\":\"100\""
					+ "},"
					+ "\"override\":{"
					+ "\"managerId\":\"12\","
					+ "\"overrideCouponIndicator\":\"false\""
					+ "}"
					+ "}";

			String strResponse = RestCall.postKohlsCashCreate("https://ms-qa.tst.kohls.com:443/dep/api/v1/kohls-cash/issue", strPayload);
			System.out.println(strResponse);

			if (!strResponse.contains("\"barcode\"")){
				Thread.sleep(10000);
				strResponse = RestCall.postKohlsCashCreate("https://ms-qa.tst.kohls.com:443/dep/api/v1/kohls-cash/issue", strPayload);
				System.out.println(strResponse);
				if (!strResponse.contains("\"barcode\""))
					Assert.fail("Kohls cash could not be generated");
			}

			String strKohlsCash = strResponse.substring(strResponse.indexOf(":")+1, strResponse.lastIndexOf("}"));
			strKohlsCash = strKohlsCash.replace("\"", "").trim();
			System.out.println("Kohls Cash " + strKohlsCash);
			String strPin =  String.valueOf(((9999) - ((1000-(Integer.parseInt(strKohlsCash.substring(11,14))))*7)));
			System.out.println("Pin " +  strPin);

			arrKC[j] = strKohlsCash;
			arrKC[j+1] = strPin;

		} catch(Exception e) {
			e.printStackTrace();
		}}
		return arrKC;
	}
	/** 
	 * Create Kohl's Cash using API requests for different eventID
	 * @throws Exception 
	 */
	public static  String[] createKohlsCash(int intBalance,String eventId){
		System.out.println("\n***createKohlsCash***\n");

		String[] arrKC = new String[2];
		arrKC[0] = "";
		arrKC[1] = "";

		try {

			// eventId = "14277";
			String strPayload = "{"
					+ "\"event\":{"
					+ "\"id\":\"" + eventId + "\","
					+ "\"emailAddress\":\"Mobile-Automation-QA@testkohls.com\","
					+ "},"
					+ "\"transactionDetails\":{"
					+ "\"receiptId\":\"988026778770930120005380127\","
					+ "\"dateTime\":\"2015-11-11T04:46:43\","
					+ "\"storeNumber\":\"9973\","
					+ "\"registerId\":\"8\","
					+ "\"transactionNumber\":\"1157\","
					+ "\"activityAmount\":\"" + intBalance + "\","
					+ "\"scanedIndicator\":false,"
					+ "\"qualifiedAmount\":\"100\""
					+ "},"
					+ "\"override\":{"
					+ "\"managerId\":\"12\","
					+ "\"overrideCouponIndicator\":\"false\""
					+ "}"
					+ "}";

			String strResponse = RestCall.postKohlsCashCreate("https://ms-qa.tst.kohls.com:443/dep/api/v1/kohls-cash/issue", strPayload);
			System.out.println(strResponse);

			if (!strResponse.contains("\"barcode\"")){
				Thread.sleep(10000);
				strResponse = RestCall.postKohlsCashCreate("https://ms-qa.tst.kohls.com:443/dep/api/v1/kohls-cash/issue", strPayload);
				System.out.println(strResponse);
				if (!strResponse.contains("\"barcode\""))
					Assert.fail("Kohls cash could not be generated");
			}

			String strKohlsCash = strResponse.substring(strResponse.indexOf(":")+1, strResponse.lastIndexOf("}"));
			strKohlsCash = strKohlsCash.replace("\"", "").trim();
			System.out.println("Kohls Cash " + strKohlsCash);
			String strPin =  String.valueOf(((9999) - ((1000-(Integer.parseInt(strKohlsCash.substring(11,14))))*7)));
			System.out.println("Pin " +  strPin);

			arrKC[0] = strKohlsCash;
			arrKC[1] = strPin;

		} catch(Exception e) {
			e.printStackTrace();
		}
		return arrKC;
	}

}
