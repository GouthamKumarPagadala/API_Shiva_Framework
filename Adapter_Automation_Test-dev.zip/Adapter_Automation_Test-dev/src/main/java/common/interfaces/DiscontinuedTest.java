package main.java.common.interfaces;

public @interface DiscontinuedTest {

	String[]groups();


	//String dependsOnMethods();


	String description();


	boolean enabled();


	int priority();


	String testName();


	String[] dependsOnMethods() default {};

}
