package main.java.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QradarLogValidation extends TestData {

	public static String main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String strAdapterURL =  testData.get("Adapter_Environemnt").trim();
		if(System.getenv("URL")!=null){
			strAdapterURL = System.getenv("URL");
		}
		else{
			System.out.println("WARNING !! CANNOT GET JENKINS PARAMETER");
			strAdapterURL = "https://kohlsmapps01.km.sl.edst.ibm.com";
		}
		File file = new File("target/allure-results");
		if (!file.exists())
			file.mkdirs();
		FileWriter fw = new FileWriter("target/allure-results/environment.properties", true);

		fw.write("Starting PII Validation" + "\n");
		fw.close();
		System.out.println("\n\n Starting PII Validation for " + strAdapterURL);
		
		File f = new File("c:\\temp\\pii.txt");
		if (f.exists()) f.delete();
		
		
		//Capture adapter logs and write to temp file, 
		String str = getRequestpii(strAdapterURL+"/mfp/mfp-logs/adapterLogs/qradar.log",  false);
		
		if (str.equals("FAIL"))
	 		return null;
		
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		
		
		String line;
		StringBuffer sb = new StringBuffer();
		
		sb.append(r.readLine()+"\n");
		
		while ((line = r.readLine() )!=null){
			
			if (line.startsWith("Jan")|line.startsWith("Feb")|line.startsWith("Mar")|line.startsWith("Apr")
					|line.startsWith("May")|line.startsWith("Jun")|line.startsWith("Jul")|line.startsWith("Aug")
					|line.startsWith("Sep")|line.startsWith("Oct")|line.startsWith("Nov")|line.startsWith("Dec")){
				String strReq = new String(sb);
				if (!strReq.trim().equals(""))
					validateRequest(strReq);
				sb = new StringBuffer();
			}
			
			sb.append(line+"\n");
			
		}
		
		r.close();
		
		System.out.println(" ** PII Validation Completed !!\n\n");
		return sb.toString();
	}
	
	
public static void main1(String[] args) throws Exception {
		
		BufferedReader r = new BufferedReader(new FileReader("c:\\temp\\pii.txt"));
		
		String line;
		StringBuffer sb = new StringBuffer();
		while ((line = r.readLine() )!=null){
			sb.append(line+"\n");
		}
		
		
		validateRequest(sb.toString());
	}
	
	static void validateRequest(String s){
    	System.out.println("Validating request" + s);
		String strPayload = s;//.substring(s.indexOf("{\""),s.length());
//		System.out.println("Payload : "+strPayload);
		
		String patternRules[] = {".*KMPREST0001.*",".*KMPREST0002.*",".*KMPREST0003.*",".*KMPREST0004.*",
				".*KMPREST0005.*",".*KMPREST0006.*",".*KMPREST0008.*",".*KMPREST0009.*",".*KMPREST0010.*",".*KMPREST0011.*",
				".*KMPREST0012.*",".*.WALLETAPI0002*",".*WALLETAPI0001.*"};
		
		
		Pattern pattern;
		for (String strRule : patternRules) {
	        pattern = Pattern.compile(strRule);
	         	
		    Matcher matcher = pattern.matcher(strPayload);
			
			int matchCount = 0; 
			while(matcher.find()){
						
				String strMatch = matcher.group(0);
				
				if (true) {
				
					if (strMatch.contains("KMPREST0001") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0001.*cat=Success:(customerip=[0-9.]+:)?customerEmail=[a-zA-Z0-9!@#$%&?.]+:channel=(IOS|ANDROID)");
					
					else if (strMatch.contains("KMPREST0001") && strPayload.contains("Failure"))
						pattern = Pattern.compile(".*KMPREST0001.*cat=Failure:(customerip=[0-9.]+:)?(customerEmail=[a-zA-Z0-9!@#$%&?.]+:)?channel=(IOS|ANDROID)");
					
					else if (strMatch.contains("KMPREST0002") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0002.*cat=Success:(customerip=.*:)?(pid=[0-9]+:)?walletToken=([a-zA-Z0-9=/+]+|):refreshToken=[a-zA-Z0-9]+:channel=(IOS|ANDROID)");
					
					else if (strMatch.contains("KMPREST0002") && strPayload.contains("Failure"))
						pattern = Pattern.compile(".*KMPREST0002.*cat=Failure:(customerip=.*:)?(pid=[0-9]+:)?channel=(IOS|ANDROID)");
					
					else if (strMatch.contains("KMPREST0003") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0003.*lname=[A-Za-z]+:cat=Success:accessToken=[A-Za-z0-9/+=]+:(customerip=192.168.1.1:)?(pid=852456:)?customerEmail=(|[a-zA-Z0-9!@.,?*&^%$#]+):channel=(IOS|ANDROID):fname=[A-Za-z]+");
					
					else if (strMatch.contains("KMPREST0003") && strPayload.contains("Failure"))
						pattern = Pattern.compile(".*KMPREST0003.*lname=(.*)+:cat=Failure:(accessToken=.*)?(customerip=192.168.1.1:)?(pid=852456:)?customerEmail=(.*):channel=(IOS|ANDROID):fname=(.*)");
					
					else if (strMatch.contains("KMPREST0004") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0004.*cardtype=[A-Za-z]+:cat=Success:accessToken=[A-Za-z0-9/+=]+:(customerip=[0-9.]+:)?action=[a-zA-Z]+:(pid=[0-9]+:)?carddigits=[0-9]+:preferedpaytype=(false|true):channel=(IOS|ANDROID)");
					
					else if (strMatch.contains("KMPREST0004") && strPayload.contains("Failure"))
						pattern = Pattern.compile(".*KMPREST0004.*cardtype=[A-Za-z]+:cat=Failure:(accessToken=(.*):)?(customerip=[0-9.]+:)?(action=[a-zA-Z]+:)?(pid=[0-9]+:)?carddigits=([0-9]+|):preferedpaytype=(false|true|):channel=(IOS|ANDROID)");
					
					else if (strMatch.contains("KMPREST0005") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0005.*zip=[0-9]+:lname=[a-zA-Z]+:cat=Success:phoneNumber=[0-9]+:accessToken=[a-zA-Z0-9/+=]+:address=[a-zA-Z0-9\\s]+:(customerip=[0-9.]+:)?state=[A-Z]+:(pid=[0-9]+:)?channel=(ANDROID|IOS):fname=[A-Za-z]+:city=[A-Za-z]+");
					
					else if (strMatch.contains("KMPREST0005") && strPayload.contains("Failure"))
						pattern = Pattern.compile(".*KMPREST0005.*zip=(.*):lname=(.*):cat=Failure:phoneNumber=(.*):(accessToken=(.*):)?address=(.*):(customerip=(.*):)?state=(.*):(pid=(.*):)?channel=(IOS|ANDROID):fname=(.*):city=(.*)");
					
					else if (strMatch.contains("KMPREST0006") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0006.*zip=[0-9]+:cat=Success:lname=[a-zA-Z]+:accessToken=[a-zA-Z0-9=/+]+:(customerip=[0-9.]+:)?state=[A-Z]+:(pid=[0-9]+:)?city=[A-Za-z]+:phoneNumber=[0-9]+:address=[0-9A-Za-z\\s]+:action=[a-zA-Z]+:channel=(IOS|ANDROID):fname=[a-zA-Z]+");
					
					else if (strMatch.contains("KMPREST0008") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0008.*lname=[a-zA-Z]+:cat=Success:(customerip=[0-9.]+:)?customerEmail=[0-9a-zA-Z%!@.#$&*/]+:channel=(IOS|ANDROID):fname=[a-zA-Z]+");
					
					else if (strMatch.contains("KMPREST0009") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0009.*cat=Success:channel=(IOS|ANDROID):orderamount=[0-9]+.[0-9]+");
					
					else if (strMatch.contains("KMPREST0010") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0010.*cat=Success:(customerip=[0-9.]+:)?(pid=[0-9]+:)?channel=(IOS|ANDROID):orderamount=[0-9]+.[0-9]+");
					
					else if (strMatch.contains("KMPREST0011") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0011.*cat=Success:(customerip=[0-9.]+:)?orderNumber=[0-9]+:channel=(IOS|ANDROID):orderamount=[0-9]+.[0-9]+");
					
					else if (strMatch.contains("KMPREST0012") && strPayload.contains("Success"))
						pattern = Pattern.compile(".*KMPREST0012.*cat=Success:(customerip=[0-9.]+:)?orderNumber=[0-9]+:(pid=[0-9]+:)?channel=(IOS|ANDROID):orderamount=[0-9]+.[0-9]+");
					
					else if (strMatch.contains("WALLETAPI0001"))
						pattern = Pattern.compile(".*WALLETAPI0001.*channel=(ANDROID|IOS):customerip=([0-9.]+|):cat=(Success|Failure):wid=[0-9]+:KCNumber=[0-9]+");
					
					else if (strMatch.contains("WALLETAPI0002"))
						pattern = Pattern.compile(".*WALLETAPI0002.*channel=(ANDROID|IOS):customerip=:([0-9.]+|)cat=(Success|Failure):GCNumber=[0-9]+:wid=[0-9]+");
					
					if (!pattern.matcher(strMatch).find()){
						System.out.println("\n\n\n\nRule Violation in below Request. Found PII " + strMatch);
						
						//s= s.replace(strMatch, "<red>" + strMatch + "</red>");
						System.out.println("**********************\n" + s + "\n*****************************");
					
					}
				}
						
			}
		}
		
		
	}
	
	
public static String getRequestpii(String strURL, boolean RegisteredUser){
		
		URL url;
		try {
			url = new URL(strURL);
			
			
			
		

		    Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
		    HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);        
		    conn.setRequestMethod("GET");
		    
		    
		    //Set the Accept header
			conn.setRequestProperty("Accept", "application/json");  
			
		
		       
		    conn.setDoOutput(true);                
		   
		    StringBuffer sb = new StringBuffer();
		    if (conn.getResponseCode() != 200) {
		        System.out.println("\n\n**Error : Logs are not enabled for this environment : "
		                + conn.getResponseCode() + "\n\n\n");
		        return "FAIL";
		    }
		
		    if(conn.getResponseCode() == 200) {
		        BufferedReader br = new BufferedReader(new InputStreamReader(
		                (conn.getInputStream())));
		
		        String output;
		        
		        BufferedWriter w = new BufferedWriter(new FileWriter("C:\\temp\\pii.txt"));
		        
		        while ((output = br.readLine()) != null) {
		        	w.write(output + "\n");
//		            sb.append(output+"\n");               
		        }
		        
		        w.write("\nTID-");
		         
		        w.flush();
		        w.close();	
		       
		                   
		
		    }
		    conn.disconnect();    
		    
		    //System.out.println(sb.toString());
		    return sb.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}

	}

}
