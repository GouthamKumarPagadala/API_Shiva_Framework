package main.java.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
/*import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;*/
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.Reporter;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

import main.java.common.TestData.Server;
import main.java.json.JsonString;
import main.java.json.ResponseValidator;
import main.java.report.HTMLReporter;
import test.java.adapters.Config;

import static main.java.common.TestData.*;
import static main.java.common.GlobalVariables.MfpToken;
import static main.java.common.GlobalVariables.OAUTHMFP_TOKEN;
import static main.java.common.GlobalVariables.OAUTHMFP_TOKEN_5CHARS;
import static main.java.common.GlobalVariables.Device_Finger_Print;
import static main.java.common.HmacGenerator.*;

public class RestCall {

	static Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
	final static boolean generatePostmanRequests  =true; 
	// static Proxy proxy = Proxy.NO_PROXY;
	// static HttpURLConnection conn;
	public static final String API_KEY = testData.get("OPEN_API_KEY");

	static{
		System.out.println("Using API key" + API_KEY);		
	}

	public static String getRequest(String strURL, Server server, boolean RegisteredUser) {

		return genericRESTCall("GET", strURL, null, server, RegisteredUser, null, 200);
	}

	public static String getRequest(String strURL, Server server, boolean RegisteredUser, int intExpectedResponseCode) {

		return genericRESTCall("GET", strURL, null, server, RegisteredUser, null, intExpectedResponseCode);
	}


	public static String getRequest(String strURL, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders, int intExpectedResponseCode) {

		return genericRESTCall("GET", strURL, null, server, RegisteredUser, mapHeaders, intExpectedResponseCode);
	}


	public static String getRequest(String strURL, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders) {

		return genericRESTCall("GET", strURL, null, server, RegisteredUser, mapHeaders, 200);
	}


	public static String postRequest(String strURL, String strPayload, Server server, boolean RegisteredUser) {

		return genericRESTCall("POST", strURL, strPayload, server, RegisteredUser, null, 200);
	}


	public static String postRequest(String strURL, String strPayload, Server server, boolean RegisteredUser, int intExpectedResponseCode) {

		return genericRESTCall("POST", strURL, strPayload, server, RegisteredUser, null, intExpectedResponseCode);
	}


	public static String postRequest(String strURL, String strPayload, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders, int intExpectedResponseCode) {

		return genericRESTCall("POST", strURL, strPayload, server, RegisteredUser, mapHeaders, intExpectedResponseCode);
	}


	public static String postRequest(String strURL, String strPayload, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders) {

		return genericRESTCall("POST", strURL, strPayload, server, RegisteredUser, mapHeaders, 200);
	}


	public static String deleteRequest(String strURL, Server server, boolean RegisteredUser) {

		return genericRESTCall("DELETE", strURL, null, server, RegisteredUser, null, 200);
	}


	public static String deleteRequest(String strURL, Server server, boolean RegisteredUser, int intExpectedResponseCode) {

		return genericRESTCall("DELETE", strURL, null, server, RegisteredUser, null, intExpectedResponseCode);
	}
	public static String deleteRequest(String strURL, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders) {

		// TODO Auto-generated method stub
		return genericRESTCall("DELETE", strURL, null, server, RegisteredUser, mapHeaders, 200);

	}

	public static String deleteRequest(String strURL, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders, int intExpectedResponseCode) {

		// TODO Auto-generated method stub
		return genericRESTCall("DELETE", strURL, null, server, RegisteredUser, mapHeaders, intExpectedResponseCode);

	}


	public static String putRequest(String strURL, String strPayload, Server server, boolean RegisteredUser) {

		return genericRESTCall("PUT", strURL, strPayload, server, RegisteredUser, null, 200);
	}


	public static String putRequest(String strURL, String strPayload, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders) {

		return genericRESTCall("PUT", strURL, strPayload, server, RegisteredUser, mapHeaders, 200);
	}
	public static String putRequest(String strURL, String strPayload, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders,int intExpectedResponseCode) {

		return genericRESTCall("PUT", strURL, strPayload, server, RegisteredUser, mapHeaders, intExpectedResponseCode);
	}


	public static String genericRESTCall(String strMethod, String strURL, String strPayload, Server server, boolean RegisteredUser, HashMap<String, String> mapHeaders, int intExpectedResponseCode) {

		System.out.println("*RestCall " + Thread.currentThread().getStackTrace()[3].getClassName() + "."+ Thread.currentThread().getStackTrace()[3].getMethodName() + ":" + new SimpleDateFormat("MM-dd-yyyy hh:mm:ss").format(new Date()));
		
		HttpURLConnection conn = null;
		StringBuffer strRequestResponseLog = new StringBuffer();
		StringBuffer strRequestHeaders= new StringBuffer();
		String strURLPath = "";

		strRequestResponseLog.append("URL \n" + strMethod + " " + strURL);
		System.out.println(strMethod + " " + strURL);

		try {
			// test server details
			URL url = new URL(strURL);
			strURLPath = url.getPath().replace("/kohls/adapters/rest", "");
			
			if (strURL.startsWith("https")){
				
				
				// Adding a trust manager which trusts all Hostnames
				TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
		            public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
		            public void checkClientTrusted(X509Certificate[] certs, String authType) { }
		            public void checkServerTrusted(X509Certificate[] certs, String authType) { }

		        } };
				
				 SSLContext sc = SSLContext.getInstance("TLSv1.2");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		        
		        // Create all-trusting host name verifier
		        HostnameVerifier allHostsValid = new HostnameVerifier() {
		            public boolean verify(String hostname, SSLSession session) { return true; }
		        };
		        // Install the all-trusting host verifier
		        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
				
		        
		        
		        HttpsURLConnection sslConn = (HttpsURLConnection) url.openConnection(proxy);
				// Use TLS v1.2 for SSL connections
//				SSLContext sc = SSLContext.getInstance("TLSv1.2"); 
//			    sc.init(null, null, new java.security.SecureRandom());
			    sslConn.setSSLSocketFactory(sc.getSocketFactory());
			    conn = sslConn;
			}
			else{
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			
			
			
			conn.setRequestMethod(strMethod);
			conn.setConnectTimeout(60000);
			conn.setReadTimeout(60000);

			// Set the Content-Type header based on URL
			
			 if (strURL.toLowerCase().contains("/v2/auth/signinprofile")) {
					conn.setRequestProperty("nuDataChannel", "iphone");
					conn.setRequestProperty("nuDataNdpdData", "nuDatatobeInserted");
				}
			

			// Set the Content-Type header based on URL
			if(strURL.toLowerCase().contains("wallet/v2/token"))
			{
				conn.setRequestProperty("ClientId","ea9c342cce72899115db");
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("Channel", "Android");
				
			}
			else if (strURL.toLowerCase().contains("/profile/password") || strURL.toLowerCase().contains("/bzv")  || strURL.toLowerCase().contains("/auth/signinprofile") || server == Server.BazaarVoice) {
				conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			}
			else if( strURL.toLowerCase().contains("/token") && testData.get("NuData").equalsIgnoreCase("true")){
				String strSessionId=Utilities.getRandom();
				strSessionId="TID-"+strSessionId;
				conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				conn.setRequestProperty("X-APP-API_REQUESTURL", "https%3A%2F%2Fmobile.kohls.com%2Fcheckout%2Fv2%2Fcheckout.jsp");
				conn.setRequestProperty("X-APP-API_USER-AGENT", "Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%209_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F601.1.46%20(KHTML%2C%20like%20Gecko)%20Version%2F9.0%20Mobile%2F13B143%20Safari%2F601.1");
				conn.setRequestProperty("X-APP-API_SESSIONID", strSessionId);
				strPayload=strPayload+"&nuDataChannel=mobile&nuDataNdpdData=eyAibmRzLXBtZCI6ICJ7IFwianZxdHJnUW5nblwiOiB7IFwiem9jXCI6IFwiZnF"
						+ "4X3RiYnR5cl9jdWJhcl9rODZfNjRcIiwgXCJmZVwiOiBcIjM2MGs2NDAgMzJcIiwgXCJ6dnFzblwiOiBcIjNvczM1cnE1LW84bn"
						+ "EtNHBvOC1uOTZzLTM3NDZwNzU5M3JyMVwiLCBcInpub2ZxeFwiOiAyNCwgXCJ6ZnpcIjogMTU3MTEyMzIwMCwgXCJ6ZmJcIjogX"
						+ "CJOYXFlYnZxXCIsIFwiemZmXCI6IDgxNzE0MzgwOCwgXCJxdnFnbVwiOiA0ODAsIFwiemN6aVwiOiA3LCBcInpoeVwiOiBcInJh"
						+ "dFwiLCBcInp2cXNpXCI6IFwic2MzMkFSSnJtS0RcIiwgXCJvcVwiOiBcIjA6MDowOjA6MzYwOjY0MFwiLCBcInpub2ZcIjogXCJ"
						+ "oYXhhYmphXCIsIFwiemN6dmlcIjogMCwgXCJ6b3pzXCI6IFwiaGF4YWJqYVwiLCBcInpub3NcIj&reCaptchaCode=03AIezHSa"
						+ "_BR9i0vb04nNgfg_-KJsQTRtRN1tbtXZSE1MnNvI4rJV4M2Pw3-opkIytBd7okEe3UC0-cLIn8cGssusxWQB1e4ceb4u1lfNwhpi"
						+ "KP-TcBB3Kln_wNZK-7crFVvpm0CUKImJNtV1VJtKZpy9YH1f28HeF5xYsR99zKO7Qx0uUkdOg228eHHakMGKPI41YSVUYXNVUtn9"
						+ "CfZg3zWfJalix5ij5wE5M8czEDavw-ZzLsBgCtKuXtZLr5SxGJ1Y7GJJmpuiJxS3xvn8pCPfV84NRVk_hoBM-k_cDekf_7dHCoeu"
						+ "c5fn30lofg426aEEpGoIN4siNgCBsag2d20PZn5cz-pjb2beivRTpwHXF1rn235awp-MJCInUSCGZXpEBEVwV4ULrv8Hm1vM9X299"
						+ "6--zzRc2nqqZre0sFvg6qKqqFIT2U0s&rememberMeSelected=true";
				
			}
			else if( strURL.toLowerCase().contains("/token") && testData.get("NuData").equalsIgnoreCase("false")){
				conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			}
			
			else if(strURL.toLowerCase().contains("/locations/545")){
				
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("Timestamp", testData.get("Time_Stamp"));
				
			}
			else if(strURL.toLowerCase().contains("/locations/")){
			
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("Timestamp", testData.get("Time_Stamp"));
				conn.setRequestProperty("LocationAuth", testData.get("USER_TOKEN"));
			}
			
             else if(strURL.toLowerCase().contains("/ede/experiences")){
            
				conn.setRequestProperty("User-Agent", "Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20rv%3A31.0)%20Gecko%2F20130401%20Firefox%2F31.0");
				
				
			}
             else if(strURL.toLowerCase().contains("/v1/profile/prequal/inquiry")){
            	 conn.setRequestProperty("Content-Type", "application/json");
             }   
             else if(strURL.toLowerCase().contains("/v1/catalog")){
            	 conn.setRequestProperty("X-Profile-Id", "10018003945");
            	 conn.setRequestProperty("X-APP-API_ZIP","95035");
             } 
			
			else {
				conn.setRequestProperty("Content-Type", "application/json");
				 

			}

			// Set the Accept header
			
			conn.setRequestProperty("Accept", "application/json");
			if(MfpToken){

				if(server == Server.Adapter){
					if ( (System.currentTimeMillis() - Config.OauthTokenGenTime) > 7200000){  // Oauth token expires in 2 hours 2*60*60*1000 milliseconds
						OAUTHMFP_TOKEN = Config.oAuthMFP_Token();
						Config.OauthTokenGenTime = System.currentTimeMillis();
					}
					conn.setRequestProperty("Authorization","Bearer " + OAUTHMFP_TOKEN);
				}
			}

			// Set the RequestID for Place order
			if (strURL.contains("order?"))
				conn.setRequestProperty("requestID", String.valueOf(System.nanoTime()));
			
			// Set headers for Device Finger Print
			if(Device_Finger_Print)
			{
			if (strURL.contains("v2/order?") || strURL.contains("signInProfile")&& server == Server.Adapter){
				System.out.println("device" + Device_Finger_Print);
				conn.setRequestProperty("X-APP-API_SESSIONID", "0000lbn5agpNtTmXnnqnSp_Cy26:mfp-wlprod12-Dal06-MfpProdSrv");
	//			conn.setRequestProperty("X-APP-API_REMOTEIP", "70.198.50.215");
				conn.setRequestProperty("USER-AGENT", "Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20rv%3A31.0)%20Gecko%2F20130401%20Firefox%2F31.0");
	//			conn.setRequestProperty("X-APP-API_REQUESTURL", URLEncoder.encode(strURL,"UTF-8"));
	//			conn.setRequestProperty("X-APP-API_X-FORWARDED-FOR", "165.254.45.181");
			}}
			// Set the access token for registered user
			if (RegisteredUser) {
				switch (server) {
					case Adapter:
					    conn.setRequestProperty("access_token", testData.get("access_token_adapter"));
					    conn.setRequestProperty("X-Profile-Id", "12345678");
					    conn.setRequestProperty("True-Client-IP", "192.168.1.1");
						break;
						
					case OpenApi:
						conn.setRequestProperty("access_token", testData.get("access_token_oapi"));
						break;
						
					case WalletAuth:
						conn.setRequestProperty("Token", testData.get("WALLET_TOKEN"));
						break;		
				}
			}

			// Set the API_KEY header for open api or skava
			switch (server) {
				case OpenApi:
					conn.setRequestProperty("X-APP-API_KEY", testData.get("OPEN_API_KEY"));
					break;
				case Skava:
					conn.setRequestProperty("X-Skava-APIKey", testData.get("SKAVA_API_KEY"));
					break;

			}
			
			// Set HMAC signature for Customer Lookup
			if (server==Server.OpenApi && strURL.toLowerCase().contains("v1/customer")){
				 setHmacSignature(conn, strPayload);
			}

			// Set any Other special headers if passed
			if (mapHeaders != null &&  !mapHeaders.isEmpty()) {
				for (String strKey : mapHeaders.keySet()) {
					conn.setRequestProperty(strKey, mapHeaders.get(strKey));
				}
//				TestData.mapheader.clear(); // Clear the Headers map after we set it to the request headers
			}

			conn.setDoOutput(true);

			// Print request headers
			strRequestResponseLog.append("\n\nRequest Headers\n");
			for (Map.Entry<String, List<String>> k : conn.getRequestProperties().entrySet()) {
				// System.out.println(k.toString());
				strRequestHeaders.append(k.toString() + ", ");
			}
			if(MfpToken)
			{
			if (server == Server.Adapter){
				strRequestHeaders.append("Authorization=[Bearer "+OAUTHMFP_TOKEN_5CHARS+"]");  // adding manually as JVM masks Authorization header for security
			}}
			strRequestResponseLog.append(strRequestHeaders);

			// Validate the Json
			if (strPayload != null && !strPayload.equals("")){
				if (server==Server.OpenApi && strURL.toLowerCase().contains("v1/customer")){
					strRequestResponseLog.append("\n\nRequest \n " + strPayload.replaceAll(" ",""));
				}else
				{
					strRequestResponseLog.append("\n\nRequest \n " + JsonString.validateJson(strPayload));
				}
			}
			
			// Send Payload if its a post request
			if (strMethod.equals("POST") || strMethod.equals("PUT")) {
				OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
				out.write(strPayload.trim());
				out.close();
			}

			StringBuffer sb = new StringBuffer();

			// System.out.println(conn.getURL() + strPayload);

			InputStream inputStream;
			inputStream = (conn.getResponseCode() == 200||conn.getResponseCode() ==202) ? conn.getInputStream() : conn.getErrorStream();

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(inputStream)));

			String output;

			System.out.println("Adapter Response \n");
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}
			//JsonString.validateJson(sb.toString());

			// Print response headers
			StringBuffer sbHeaders = new StringBuffer();
			strRequestResponseLog.append("\n\nResponse Headers\n");
			for (Map.Entry<String, List<String>> k : conn.getHeaderFields().entrySet()) {
				// System.out.println(k.toString());
				sbHeaders.append(k.toString() + "|");
			}

			// Add the response headers to test data and report log
			testData.put("RESPONSE_HEADERS", sbHeaders.toString());
			strRequestResponseLog.append(sbHeaders.toString());

			String strResponse = sb.toString();
			// Check if response has html content, if yes, replace the <html> tag to avoid parsing with outer html-report
			if (strResponse.contains("<html"))
				strResponse = strResponse.replace("<html", "<HTML-TEXT");

			strRequestResponseLog.append("\n\nResponse \n " + JsonString.validateJson(strResponse));
			// strRequestResponseLog.append("\n\nResponse \n " + "Null response");

			// Validate if expected HTTP status code is present
			if (conn.getResponseCode() != intExpectedResponseCode) {
				System.out.println("Failed : HTTP error code : "
						+ conn.getResponseCode());
				System.out.println(conn.getURL() + "\n" + strPayload);
				ResponseValidator.validateStringEquals(String.valueOf(conn.getResponseCode()), String.valueOf(intExpectedResponseCode), "Response code should be " + intExpectedResponseCode);
			}

			return new String(sb);
		}
		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Exception in " + strMethod + " call to "  + strURL + " \n"+ e.getMessage());
			return "";
		}
		finally {
			Reporter.log("<xmp>" + strRequestResponseLog.toString() + "</xmp>");
			if (generatePostmanRequests)
				attachPostManReq(conn,strRequestHeaders.toString(),strPayload,strRequestResponseLog);

			HTMLReporter.attachToReport(server.toString(),strMethod,StringUtils.abbreviate(strURLPath, 24),strRequestResponseLog.toString());
			
			
			conn.disconnect();

		}

	}


	private static void attachPostManReq(HttpURLConnection conn, String strHeaders, String strPayload,StringBuffer strRequestResponseLog) {
		
		String collID = "Platform_Temp85f0f0db-3a46-4ffb-8948-0f167da7f634" ;
		StringBuffer bufCollection = new StringBuffer();
		String strTCName = Thread.currentThread().getStackTrace()[4].getMethodName();
		bufCollection.append("{\"id\":\""+collID+"\",\"name\":\"Automation_Temp\",\"requests\":[{");
		bufCollection.append("\"id\": \""+ UUID.randomUUID().toString() +"\",");
		bufCollection.append("\"name\": \""+ strTCName +"\",");
		bufCollection.append("\"method\": \""+ conn.getRequestMethod() +"\",");
		bufCollection.append("\"url\": \""+ conn.getURL().toString() +"\",");
		bufCollection.append("\"headers\": \"");
		for (String k : strHeaders.split(", ")) 
			bufCollection.append(k.toString().replaceFirst("=", ":").replace("[", "").replace("]", "") + "\\n");
		bufCollection.append("\",");
		bufCollection.append("\"dataMode\": \"raw\",");
		bufCollection.append("\"collectionId\": \""+ collID +"\"");
		if (strPayload!=null)		
			bufCollection.append(",\"rawModeData\": \""+ strPayload.replace("\"", "\\\"") +"\"");
		bufCollection.append("}]}");
		strRequestResponseLog.append("\n\n\nPostman \n");
		strRequestResponseLog.append(bufCollection);
	}


	// This Get Request Does not log the req/res into HTML report, does not Read Req/REs HEaders. Plain Get request
	public static String simpleGetRequest(String strURL, Server server, boolean RegisteredUser) {

		System.out.println("simpleGetRequest " + strURL);
		URL url;
		try {
			url = new URL(strURL);

			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);
			conn.setRequestMethod("GET");

			// Set the Accept header
			conn.setRequestProperty("Accept", "application/json");

			// Set the access token for registered user
			if (RegisteredUser) {
				switch (server) {
					case Adapter:
						conn.setRequestProperty("access_token", testData.get("access_token_adapter"));
						break;
					case OpenApi:
						conn.setRequestProperty("access_token", testData.get("access_token_oapi"));
						break;
				}
			}
			
			if(server == Server.Adapter)
			{
				conn.setRequestProperty("Authorization","Bearer " + OAUTHMFP_TOKEN);
			}

			// Set the API_KEY header for open api or skava
			switch (server) {
				case OpenApi:
					conn.setRequestProperty("X-APP-API_KEY", testData.get("OPEN_API_KEY"));
					break;
				case Skava:
					conn.setRequestProperty("X-Skava-APIKey", testData.get("SKAVA_API_KEY"));
					break;
			}

			// For place order, add request id in the header
			if (strURL.contains("order?")) {
				conn.setRequestProperty("requestID", "Auto_" + new Date().getTime());
			}

			conn.setDoOutput(true);

			StringBuffer sb = new StringBuffer();
			if (conn.getResponseCode() != 200) {
				System.out.println("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			if (conn.getResponseCode() == 200) {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));

				String output;

				while ((output = br.readLine()) != null) {
					sb.append(output);
				}

			}
			conn.disconnect();
			System.out.println(sb.toString());
			return sb.toString();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}

	}


	// This Post Request Does not log the req/res into HTML report, does not Read Req/REs HEaders. Plain Post request
	public static String simplePostRequest(String strURL, String strPayload, Server server, boolean RegisteredUser) {

		System.out.println("simplePostRequest " + strURL);
		
		try {
			// test server details
			URL url = new URL(strURL);

			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.4.7.10", 3128));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection(proxy);
			conn.setRequestMethod("POST");

			// Set the Content-Type header based on URL
			if (strURL.toLowerCase().contains("profile/password") || strURL.toLowerCase().contains("/token") || strURL.toLowerCase().contains("/auth/signinprofile")) {
				conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			} else {
				conn.setRequestProperty("Content-Type", "application/json");
			}

			// Set the Accept header
			conn.setRequestProperty("Accept", "application/json");

			// Set the access token for registered user
			if (RegisteredUser) {
				switch (server) {
					case Adapter:
						conn.setRequestProperty("access_token", testData.get("access_token_adapter"));
						break;
					case OpenApi:
						conn.setRequestProperty("access_token", testData.get("access_token_oapi"));
						break;
				}
			}

			// Set the API_KEY header for open api or skava
			switch (server) {
				case OpenApi:
					conn.setRequestProperty("X-APP-API_KEY", testData.get("OPEN_API_KEY"));
					break;
				case Skava:
					conn.setRequestProperty("X-Skava-APIKey", testData.get("SKAVA_API_KEY"));
					break;
			}

			if(MfpToken){

				if(server == Server.Adapter){
					if ( (System.currentTimeMillis() - Config.OauthTokenGenTime) > 7200000){  // Oauth token expires in 2 hours 2*60*60*1000 milliseconds
						OAUTHMFP_TOKEN = Config.oAuthMFP_Token();
						Config.OauthTokenGenTime = System.currentTimeMillis();
					}
					conn.setRequestProperty("Authorization","Bearer " + OAUTHMFP_TOKEN);
				}
			}
			
			conn.setDoOutput(true);

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(strPayload);
			out.close();
			StringBuffer sb = new StringBuffer();
			if (conn.getResponseCode() != 200) {
				System.out.println("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			if (conn.getResponseCode() == 200) {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream()),"UTF-8"));
				
				String output;

				System.out.println("Adapter Response \n");
				while ((output = br.readLine()) != null) {
					sb.append(output);
				}

			}
			conn.disconnect();

			return new String(sb);
		}
		catch (Exception e) {
			e.printStackTrace();
			return "";
		}

	}

	public static  String postKohlsCashCreate(String strURL, String strPayload) throws Exception {
		System.out.println("\n***sendRequest***\n");

		String strResponse = null;

		try {
			URL url = new URL(strURL);
			
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("proxy.kohls.com", 8080));

			HttpsURLConnection conn = (HttpsURLConnection) url.openConnection(proxy);
			conn.setRequestMethod("POST");

			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");

			Date today = new Date();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			df.setTimeZone(TimeZone.getTimeZone("UTC"));
			String strTimeStamp = df.format(today);
			conn.setRequestProperty("Authorization", "DEP1-HMAC-SHA256 QCoE:eex2WcIwUc/LmXUX+gYg/9Mxra0paepwkDG2YaRJ8B4=");
			conn.setRequestProperty("X-DEP-Date", strTimeStamp);

			SSLContext ctx = SSLContext.getInstance("SSL");
			X509TrustManager tm = new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}
				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}
			};
			ctx.init(null, new TrustManager[] { tm }, new SecureRandom());
			conn.setSSLSocketFactory(ctx.getSocketFactory());

			conn.setDoOutput(true);

			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(strPayload);
			out.close();

			InputStream inputStream;
			if (conn.getResponseCode() == 200 || conn.getResponseCode() == 201) {
				inputStream = conn.getInputStream();
			} else {
				inputStream = conn.getErrorStream(); 
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((inputStream)));
			StringBuffer sb = new StringBuffer();
			String output;
			while ((output = br.readLine()) != null) {
				sb.append(output);               
			}

			strResponse = sb.toString();

			conn.disconnect();
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return strResponse;
	}

public static String setHmacSignature(HttpURLConnection conn, String strPayload){
		
		String correlationId = "KAS-a9785ceb-715d-4dc1-bec6-1fcca6147deb";
		long epochUtcSeconds = (long) Math.floor(new Date().getTime() / 1000);
		String strMethod = conn.getRequestMethod().toUpperCase();
		final String API_SECRET = "Cp3NjDO45QcThyFw";
		String strURIPath = "/v1/customer";
		String strQueryParams = conn.getURL().getQuery() == null ? "" : conn.getURL().getQuery() ;
		
		
		
		String signature = strMethod.equals("GET")|| strMethod.equals("DELETE")  ?
				
				new HmacGenerator.Builder().apiKey(API_KEY)
				.apiSecret(API_SECRET) 
				.method(strMethod)
				.timestamp(epochUtcSeconds)
				.endpoint(strURIPath)
				.correlationId(correlationId)
				.queryParams(strQueryParams)
				.build().getSignature()
			
				:
					
				 new HmacGenerator.Builder().apiKey(API_KEY)
				.apiSecret(API_SECRET)
				.method(strMethod)
				.timestamp(epochUtcSeconds)
				.endpoint(strURIPath)
				.correlationId(correlationId)
				.payload(strPayload.replaceAll("\\s+",""))
				.build().getSignature();
	
		conn.setRequestProperty("X-APP-API_SIGNATURE", signature);
		conn.setRequestProperty("X-APP-API_TIMESTAMP", String.valueOf(epochUtcSeconds));
		conn.setRequestProperty("correlation-id", correlationId);
		conn.setRequestProperty("Cache-Control", "no-cache");
		
		return "";
	}

}
