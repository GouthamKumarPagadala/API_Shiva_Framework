package main.java.json;

import static main.java.common.TestData.testData;

import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;
import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;

import static main.java.common.GlobalVariables.*;

public class JsonString {

	public static String getCustomerNameJson(String str) {

		String strJson = "";
		switch (str) {

			case "VALID":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				break;
			case "VALID_KC":
				strJson = "{\"firstName\":\"" + testData.get("KCC_FIRSTNAME") + "\",\"middileInitial\":\"L\",\"lastName\": \"" + testData.get("KCC_LASTNAME") + "\"}";
				break;
			case "MISSING_FIRSTNAME_KC":
				strJson = "{\"middileInitial\":null,\"lastName\": \"" + testData.get("KCC_LASTNAME") + "\"}";
				break;
			case "UPDATE":
				strJson = "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"lastName\": \"NewLastName" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				// strJson ="{\"firstName\":\"NewName\",\"middleName\":null,\"lastName\": \"NewLastName\"}";
				break;
			case "FN_NUMERIC":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_INVALID_FIRST_NAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\"}";
				// strJson ="{\"firstName\":\"123456\",\"middleName\":null,\"lastName\": \"Thomas\"}";
				break;
			case "FN_GREATER_THAN_40":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME_MORETHAN_40") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\"}";
				// strJson ="{\"firstName\":\"aaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbb\",\"middleName\":null,\"lastName\": \"Thomas\"}";
				break;
			case "LN_GREATER_THAN_40":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_FIRSTNAME_MORETHAN_40") + "\"}";
				// strJson ="{\"firstName\":\"aaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbbbbbbbbbb\",\"middleName\":null,\"lastName\": \"Thomas\"}";
				break;

			case "INVALID":
				strJson = "{\"firstName1\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\"}";
				// strJson ="{\"firstName1\":\"Blessan\",\"middleName\":null,\"lastName\": \"Thomas\"}";
				break;
			case "INVALID_EMAIL_ID":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\"}," + "\"email\":\"" + testData.get("INVALID_EMAIL_ID") + "\"";
				// strJson ="{\"firstName1\":\"Blessan\",\"middleName\":null,\"lastName\": \"Thomas\"}";
				break;
			case "PWD_LT_5_DIGIT":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_FIRSTNAME") + "\"}," + "\"password\":\"" + testData.get("PWD_LESS_THAN_5_DIGIT") + "\"";
				// strJson ="{\"firstName1\":\"Blessan\",\"middleName\":null,\"lastName\": \"Thomas\"}";
				break;
			case "MISSING_FIRSTNAME":
				strJson = "{\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				break;
			case "MISSING_LASTNAME":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null}";
				break;
			case "MISSING_FIRSTNAME_VALUE":
				strJson = "{\"firstName\":\"\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				break;
			case "MISSING_LASTNAME_VALUE":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"\"}";
				break;
			case "UPDATE_PASSWORD":
				strJson = "{\"firstName\":\"NewName" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"NewLastName" + testData.get("CUSTOMER_FIRSTNAME") + "\"}," + "\"password\":\"" + "Update@123" + "\"";
				// strJson ="{\"firstName\":\"NewName\",\"middleName\":null,\"lastName\": \"NewLastName\"}";
				break;
			case "UPDATE_OLD_PASSWORD":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				// strJson ="{\"firstName\":\"NewName\",\"middleName\":null,\"lastName\": \"NewLastName\"}";
				break;
			case "SINGLE_CHAR_FNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				break;
			case "SINGLE_CHAR_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\"}";
				break;
			case "SINGLE_CHAR_FNAME_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\"}";
				break;
			case "SPACE_FNAME":
				strJson = "{\"firstName\":\" \",\"middleName\":null,\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\"}";
				break;
			case "SPACE_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"middleName\":null,\"lastName\": \" \"}";
				break;
			case "SPACE_FNAME_LNAME":
				strJson = "{\"firstName\":\" \",\"middleName\":null,\"lastName\": \" \"}";
				break;
			case "SPECIAL_CHAR_FNAME":
				strJson = "{\"firstName\":\"" + testData.get("SPECIAL_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\"}";
				break;
			case "SPECIAL_CHAR_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("SPECIAL_CHAR_LNAME") + "\"}";
				break;
			case "SPECIAL_CHAR_FNAME_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SPECIAL_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("SPECIAL_CHAR_LNAME") + "\"}";
				break;
			case "SPACE_SINGLE_CHAR_FNAME":
				strJson = "{\"firstName\":\" " + testData.get("SPECIAL_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\"}";
				break;
			case "SPACE_SINGLE_CHAR_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \" " + testData.get("SPECIAL_CHAR_LNAME") + "\"}";
				break;
			case "SPACE_SINGLE_CHAR_FNAME_LNAME":
				strJson = "{\"firstName\":\" " + testData.get("SPECIAL_CHAR_FNAME") + "\",\"middleName\":null,\"lastName\": \" " + testData.get("SPECIAL_CHAR_LNAME") + "\"}";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}


	public static String getBillAddressJson(String str) {

		String strJson = "";
		switch (str) {

			case "IL_CHICAGO":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
				
			case "IL_CHICAGO_MULTISHIP":
				strJson = "\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "CT_AVON":
				strJson = "{\"firstName\" : \"" + testData.get("CT_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CT_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CT_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CT_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CT_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CT_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CT_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CT_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CT_BILLING_STATE") + "\"}";
				break;
			case "CT_AVON_MULTISHIP":
				strJson = "\"firstName\" : \"" + testData.get("CT_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CT_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CT_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CT_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CT_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CT_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CT_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CT_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CT_BILLING_STATE") + "\"}";
				break;
			case "RI_PAWTUCKET":
				strJson = "{\"firstName\" : \"" + testData.get("RI_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("RI_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("RI_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("RI_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("RI_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("RI_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("RI_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("RI_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("RI_BILLING_STATE") + "\"}";
				break;
			case "FL_ORLANDO":
				strJson = "{\"firstName\" : \"" + testData.get("FL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("FL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("FL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("FL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("FL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("FL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("FL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("FL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("FL_BILLING_STATE") + "\"}";
				break;
			case "NJ_TRENTON":
				strJson = "{\"firstName\" : \"" + testData.get("NJ_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("NJ_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("NJ_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("NJ_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("NJ_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("NJ_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("NJ_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("NJ_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("NJ_BILLING_STATE") + "\"}";
				break;
			case "IL_CHICAGO_ADD":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "AHSTD_AE_APO":
				// strJson ="{\"firstName\" : \""+testData.get("IL_BILLING_FIRSTNAME")+"\", \"lastName\":\""+testData.get("IL_BILLING_LASTNAME")+"\", \"phoneNumber\" : \""+testData.get("IL_BILLING_PHONE")+"\", \"addr1\":\""+testData.get("IL_BILLING_ADDRESS1")+"\", \"addr2\" : \""+testData.get("IL_BILLING_ADDRESS2")+"\", \"city\":\""+testData.get("IL_BILLING_CITY")+"\", \"countryCode\" : \""+testData.get("IL_BILLING_COUNTRYCODE")+"\", \"postalCode\":\""+testData.get("IL_BILLING_POSTAL_CODE")+"\", \"state\" : \""+testData.get("IL_BILLING_STATE")+"\"}";
				strJson = "{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"1854 northwest circle\", \"addr2\" : \"Suite 1800\", \"city\":\"APO\", \"countryCode\" : \"US\", \"postalCode\":\"09211\", \"state\" : \"AE\"}";
				break;
			case "AHSTD_AE_APO_MULTISHIP":
				// strJson ="{\"firstName\" : \""+testData.get("IL_BILLING_FIRSTNAME")+"\", \"lastName\":\""+testData.get("IL_BILLING_LASTNAME")+"\", \"phoneNumber\" : \""+testData.get("IL_BILLING_PHONE")+"\", \"addr1\":\""+testData.get("IL_BILLING_ADDRESS1")+"\", \"addr2\" : \""+testData.get("IL_BILLING_ADDRESS2")+"\", \"city\":\""+testData.get("IL_BILLING_CITY")+"\", \"countryCode\" : \""+testData.get("IL_BILLING_COUNTRYCODE")+"\", \"postalCode\":\""+testData.get("IL_BILLING_POSTAL_CODE")+"\", \"state\" : \""+testData.get("IL_BILLING_STATE")+"\"}";
				strJson = "\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"1854 northwest circle\", \"addr2\" : \"Suite 1800\", \"city\":\"APO\", \"countryCode\" : \"US\", \"postalCode\":\"09211\", \"state\" : \"AE\"}";
				break;
			case "AHSTD_AE_APO_ADD":
				// strJson ="{\"firstName\" : \""+testData.get("IL_BILLING_FIRSTNAME")+"\", \"lastName\":\""+testData.get("IL_BILLING_LASTNAME")+"\", \"phoneNumber\" : \""+testData.get("IL_BILLING_PHONE")+"\", \"addr1\":\""+testData.get("IL_BILLING_ADDRESS1")+"\", \"addr2\" : \""+testData.get("IL_BILLING_ADDRESS2")+"\", \"city\":\""+testData.get("IL_BILLING_CITY")+"\", \"countryCode\" : \""+testData.get("IL_BILLING_COUNTRYCODE")+"\", \"postalCode\":\""+testData.get("IL_BILLING_POSTAL_CODE")+"\", \"state\" : \""+testData.get("IL_BILLING_STATE")+"\"}";
				strJson = "{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"1854 northwest circle\", \"addr2\" : \"Suite 1800\", \"city\":\"APO\", \"countryCode\" : \"US\", \"postalCode\":\"09211\", \"state\" : \"AE\"";
				break;
			case "DUPLICATE":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\",\"shipAddress\":{}}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "INVALID_ADDR1":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("INVALID_SHIPPING_ADDRESS1") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("WI_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "SPECIALCHAR_NAME":
				strJson = "{\"firstName\" : \"rAZZI@#$$%\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "WI_MILWAUKEE":
				strJson = "{\"firstName\" : \"" + testData.get("WI_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("WI_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("WI_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("WI_BILLING_ADDRESS1") + "\", \"city\":\"" + testData.get("WI_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("WI_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("WI_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("WI_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"Shank\", \"lastName\":\"Chandran\", \"phoneNumber\" : \"4143249243\", \"addr1\":\"10500 W Fountain Ave\",\"city\":\"Milwaukee\", \"countryCode\" : \"US\", \"postalCode\":\"53224\", \"state\" : \"WI\"}";
				break;
			case "WI_MILWAUKEE_MULTISHIP":
				strJson = "{\"firstName\" : \"" + testData.get("WI_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("WI_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("WI_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("WI_BILLING_ADDRESS1") + "\", \"city\":\"" + testData.get("WI_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("WI_BILLING_COUNTRYCODE") + "\", \"county\" : \"00\" ,\"postalCode\":\"" + testData.get("WI_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("WI_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"Shank\", \"lastName\":\"Chandran\", \"phoneNumber\" : \"4143249243\", \"addr1\":\"10500 W Fountain Ave\",\"city\":\"Milwaukee\", \"countryCode\" : \"US\",\"county\":\"00\", \"postalCode\":\"53224\", \"state\" : \"WI\"}";
				break;
			case "WI_MILWAUKEE_VC":
				strJson ="{\"firstName\" : \"Muhammad\", \"lastName\":\"Ashik Kamal Batcha\", \"phoneNumber\" : \"4143249243\", \"addr1\":\"Abel Street Southwest\", \"geoCode\": \"00\",\"hasError\": \"false\",\"city\":\"Milpitas\", \"countryCode\" : \"US\", \"postalCode\":\"95035\", \"state\" : \"CA\"}";
				break;
				
			case "UPDATE":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"";
				break;
			case "CA_MILPITAS":
				strJson = "{\"firstName\" : \"" + testData.get("CA_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CA_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"1000 S Abel St\", \"addr2\" : \"Apt 120\", \"city\":\"Milpitas\", \"countryCode\" : \"US\", \"postalCode\":\"95035\", \"state\" : \"CA\"}";
				break;
			case "CA_MILPITAS_MULTISHIP":
				strJson = "{\"firstName\" : \"" + testData.get("CA_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CA_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\",\"county\":\"00\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"1000 S Abel St\", \"addr2\" : \"Apt 120\", \"city\":\"Milpitas\", \"countryCode\" : \"US\", \"postalCode\":\"95035\", \"state\" : \"CA\"}";
				break;
			case "INVALID_POSTALCODE":
				strJson = "{\"firstName\" : \"" + testData.get("CA_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CA_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("INVALID_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"12345\", \"state\" : \"IL\"}";
				break;

			case "ANOTHER_CITY_POSTALCODE":
				strJson = "{\"firstName\" : \"" + testData.get("CA_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CA_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"Milwaukee\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"53295\", \"state\" : \"IL\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"12345\", \"state\" : \"IL\"}";
				break;
			case "INVALID_STATE":
				strJson = "{\"firstName\" : \"" + testData.get("CA_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CA_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("INVALID_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"12345\", \"state\" : \"ZZ\"}";
				break;
			case "INVALID_FIRSTNAME":
				strJson = "{\"firstName\" : \"" + "" + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "INVALID_LASTNAME":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + "" + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "LASTNAME_ALPHANUMERIC":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("BILLING_LASTNAME_ALPHANUMERIC") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "EMPTY_FIELDS":
				strJson = "{\"firstName\" : \"" + "" + "\", \"lastName\":\"" + "" + "\", \"phoneNumber\" : \"" + "" + "\", \"addr1\":\"" + "" + "\", \"addr2\" : \"" + "" + "\", \"city\":\"" + "" + "\", \"countryCode\" : \"" + "" + "\", \"postalCode\":\"" + "" + "\", \"state\" : \"" + "" + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "ONLY_CITY_STATE_PC":
				strJson = "{\"firstName\" : \"" + "" + "\", \"lastName\":\"" + "" + "\", \"phoneNumber\" : \"" + "" + "\", \"addr1\":\"" + "" + "\", \"addr2\" : \"" + "" + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + "" + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "EMPTY_CITY_STATE_PC":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("BILLING_LASTNAME_ALPHANUMERIC") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + "" + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + "" + "\", \"state\" : \"" + "" + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "INVALID_PHONENO":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("INVALID_PHONENO") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "11DIGIT_PHONENO":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"12345678901\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "SPAN_POSTALCODE":
				strJson = "{\"firstName\" : \"" + testData.get("CA_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("CA_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("SPAN_POSTALCODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"12345\", \"state\" : \"IL\"}";
				break;
			case "MULTI_COUNTY":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"60601\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "MULTI_COUNTRY_SHIPADDR":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"60601\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "EMPTY_FN":
				strJson = "{\"firstName\" : \"\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "EMPTY_FN_NEW":
				strJson = "{\"firstName\" : \"\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "FN_SINGLE_CHAR":
				strJson = "{\"firstName\" : \"S\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "FN_NUMERIC":
				strJson = "{\"firstName\" : \"123456\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "FN_NUMERIC_NEW":
				strJson = "{\"firstName\" : \"123456\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "PHONE_NOFORMAT":
				strJson = "{\"firstName\" : \"Shan\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"abcewr123\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "ALPHANUMERIC_CITY":
				strJson = "{\"firstName\" : \"Shan\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"4143249243\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"123fsdfs\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "INVALID_PHONENUM":
				strJson = "{\"firstName\" : \"Shan\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"123456789123\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;
			case "WROND_ID":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("IL_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\" ,\"ID\":\"20151015040548\" ,\"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"}";
				break;

			case "EMPTY_CITY":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"" + "" + "\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"";
				break;
			case "INVALID_CITY":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"wedfs\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"";
				break;

			case "INVALID_ZIP_CITY":
				strJson = "{\"firstName\" : \"" + testData.get("IL_BILLING_FIRSTNAME") + "\", \"lastName\":\"" + testData.get("IL_BILLING_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("IL_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("IL_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("IL_BILLING_ADDRESS2") + "\", \"city\":\"Milwaukee\", \"countryCode\" : \"" + testData.get("IL_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("IL_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("IL_BILLING_STATE") + "\"}";
				// strJson ="{\"firstName\" : \"JOHN\", \"lastName\":\"GEORGE\", \"phoneNumber\" : \"1234567891\", \"addr1\":\"201 West Madison\", \"addr2\" : \"Suite 1800\", \"city\":\"Chicago\", \"countryCode\" : \"US\", \"postalCode\":\"60290\", \"state\" : \"IL\"";
				break;
			case "EMPTY_ADDRESS":
				strJson = "{}";
				break;
			case "SINGLE_CHAR_FNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") +  "\"}";
				break;
			case "SINGLE_CHAR_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SINGLE_CHAR_FNAME_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPACE_FNAME":
				strJson = "{\"firstName\":\" \",\"lastName\": \"" + testData.get("CUSTOMER_LASTNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPACE_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("CUSTOMER_FIRSTNAME") + "\",\"lastName\": \" \", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPACE_FNAME_LNAME":
				strJson = "{\"firstName\":\" \",\"lastName\": \" \", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPECIAL_CHAR_FNAME":
				strJson = "{\"firstName\":\"" + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPECIAL_CHAR_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SPECIAL_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPECIAL_CHAR_FNAME_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SPECIAL_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPACE_SINGLE_CHAR_FNAME":
				strJson = "{\"firstName\":\" " + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \"" + testData.get("SINGLE_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPACE_SINGLE_CHAR_LNAME":
				strJson = "{\"firstName\":\"" + testData.get("SINGLE_CHAR_FNAME") + "\",\"lastName\": \" " + testData.get("SPECIAL_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;
			case "SPACE_SINGLE_CHAR_FNAME_LNAME":
				strJson = "{\"firstName\":\" " + testData.get("SPECIAL_CHAR_FNAME") + "\",\"lastName\": \" " + testData.get("SPECIAL_CHAR_LNAME") + "\", \"phoneNumber\" : \"" + testData.get("CA_BILLING_PHONE") + "\", \"addr1\":\"" + testData.get("CA_BILLING_ADDRESS1") + "\", \"addr2\" : \"" + testData.get("CA_BILLING_ADDRESS2") + "\", \"city\":\"" + testData.get("CA_BILLING_CITY") + "\", \"countryCode\" : \"" + testData.get("CA_BILLING_COUNTRYCODE") + "\", \"postalCode\":\"" + testData.get("CA_BILLING_POSTAL_CODE") + "\", \"state\" : \"" + testData.get("CA_BILLING_STATE") + "\"}";
				break;

			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}


	public static String getPaymentTypeJson(String str) {

		String strJson = "";
		switch (str) {

			case "VISA":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("VISA_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\",\"securityCode\":\"412\"}";
				break;
			case "VISA_VC":
				strJson = "{\"nameOnCard\":\"Muhammad Ashik Kamal Batcha\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"09/2019\",\"securityCode\":\"" + testData.get("VISA_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\",\"securityCode\":\"412\"}";
				break;
			case "VISA_LAST4":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER_LAST4") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("VISA_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\",\"securityCode\":\"412\"}";
				break;
			case "VISA_APPLEPAY":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD_APPLEPAY") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER_APPLEPAY") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE_APPLEPAY") + "\"}";
				break;
			case "UPDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "UPDATE_KCC":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "UPDATE_MASTER":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "UPDATE_AMEX":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("AMEX_CARD_NUMBER") + "\",\"type\":\"" + testData.get("AMEX_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "UPDATE_DISCOVER":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "MASTER":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("MASTER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"5444009999222205\",\"type\":\"MC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "MASTER_VC":
				strJson = "{\"nameOnCard\":\"Muhammad Ashik Kamal Batcha\", \"cardNum\":\"" + testData.get("MASTER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"09/2019\", ,\"securityCode\":\"" + testData.get("MASTER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"5444009999222205\",\"type\":\"MC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "MC_APPLEPAY":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD_APPLEPAY") + "\", \"cardNum\":\"" + testData.get("MC_CARD_NUMBER_APPLEPAY") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE_APPLEPAY") + "\"}";
				break;
			case "MASTER_BINRANGE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_BINRANGE") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("MASTER_EXP_DATE_BINRANGE") + "\",\"securityCode\":\"" + testData.get("MASTER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"5444009999222205\",\"type\":\"MC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "MASTER_LAST4":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_NUMBER_LAST4") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("MASTER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"5444009999222205\",\"type\":\"MC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "DISCOVER":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("DISCOVER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"6011000990911111\",\"type\":\"DISC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "DISCOVER_VC":
				strJson = "{\"nameOnCard\":\"Muhammad Ashik Kamal Batcha\" , \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"08/2019\",\"securityCode\":\"" + testData.get("DISCOVER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"6011000990911111\",\"type\":\"DISC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "DISCOVER_LAST4":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER_LAST4") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("DISCOVER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"6011000990911111\",\"type\":\"DISC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "AMEX":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("AMEX_CARD_NUMBER") + "\",\"type\":\"" + testData.get("AMEX_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("AMEX_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "AMEX_LAST4":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("AMEX_CARD_NUMBER_LAST4") + "\",\"type\":\"" + testData.get("AMEX_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("AMEX_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "AMEX_APPLEPAY":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD_APPLEPAY") + "\", \"cardNum\":\"" + testData.get("AMEX_CARD_NUMBER_APPLEPAY") + "\",\"type\":\"" + testData.get("AMEX_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE_APPLEPAY") + "\"}";
				break;
			case "KCC_CVV2":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("KCC_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KCC_CVV2_FALSE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + "KOHS" + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("KCC_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KCC_CVV2_V2":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("KCC_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KCC_CVV2_V2_UPDTAE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") +"\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KCC_CVV2_UPDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
				
			case "KCC_CVV2_ADD":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			
			case "KCC_CVV2_TEMP":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("TEMPKCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KCC_CVV2_UPDATE_INVALID_DATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + "76T76G76" + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KCC_CVV2_UPDATEPAYMENT":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KOHLS_CARD":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KOHLS_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"001899914401\",\"type\":\"KOHLS\"}";
				break;
			case "KOHLS_CARD1":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KOHLS_CARD_NUMBER1") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"001899914401\",\"type\":\"KOHLS\"}";
				break;
			case "KOHLS_CARD2":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KOHLS_CARD_NUMBER2") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"001899914401\",\"type\":\"KOHLS\"}";
				break;
			case "KOHLS_CARD3":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KOHLS_CARD_NUMBER3") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"001899914401\",\"type\":\"KOHLS\"}";
				break;
			case "GIFT_CARD":
				strJson = "{\"giftCardNum\": \"" + testData.get("GIFT_CARD_NUMBER") + "\",\"pin\": \"" + testData.get("GIFT_CARD_PIN") + "\"}";
				// strJson ="{\"giftCardNum\": \"1000000412\",\"pin\": \"0123\"}";
				break;
			case "EXPIRED_CREDIT_CARD":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("INVALID_EXP_DATE") + "\",\"securityCode\":\"" + testData.get("VISA_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2009\",\"securityCode\":\"412\"}";
				break;
			case "WRONG_CVV_CREDIT_CARD":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("WRONG_CVV_CREDIT_CARD") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\",\"securityCode\":\"000\"}";
				break;
			case "WRONG_EXP_DATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("INVALID_EXP_DATE") + "\",\"securityCode\":\"" + testData.get("WRONG_CVV_CREDIT_CARD") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2029\",\"securityCode\":\"000\"}";
				break;
			case "MISSINGCARDNAME":
				strJson = "{\"nameOnCard\":\"\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;

			case "NUMERICCARDNAME":
				strJson = "{\"nameOnCard\":\"" + "SHAN123" + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;

			case "NUMERICCARDNAME_UPDATE":
				strJson = "{\"nameOnCard\":\"" + "SHAN123" + "\", \"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;

			case "SPECCHAR_CARDNAME":
				strJson = "{\"nameOnCard\":\"" + "$%^&*" + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "NONNUMERIC_CARDNUM":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + "abcdefghijklmnop" + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "ABOVE16DIGIT_CARDNUM":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + "4445222299990007123" + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "INVALIDCARDTYPE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + "4445222299990007" + "\",\"type\":\"" + "EXPRESS" + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "INVALIDDATEFORMAT":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + "201402" + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "MISSINGDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + "" + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "KCC_CVV2_UPDATE_MISSING_DATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KCC_CARD_NUMBER") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + "" + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "INVALID_ID":
				strJson = "{\"ID\":\"" + "9999cdsfsd" + "\", \"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;
			case "MISSING_ID":
				strJson = "{\"ID\":\"" + "" + "\",\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\"";
				break;

			case "DISCOVERUPDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"6011000990911111\",\"type\":\"DISC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;

			case "DISCOVERUPDATE_NEW":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER1") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"6011000990911111\",\"type\":\"DISC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "AMEXUPDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("AMEX_CARD_NUMBER") + "\",\"type\":\"" + testData.get("AMEX_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"373953192351004\",\"type\":\"AMEX\",\"expDate\":\"02/2020\",\"securityCode\":\"2234\"}";
				break;
			case "KOHLS_CARD_UPDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + String.format("%012d", Integer.parseInt(testData.get("KOHLS_CARD_NUMBER"))+1) + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\"";  // Adding 1 to the cardnumber to get a new card number for update card
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"001899914401\",\"type\":\"KOHLS\"}";
				break;
			case "MASTER_UPDATE":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"5444009999222205\",\"type\":\"MC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "MASTER_UPDATE_2":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"07/2020\"";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"5444009999222205\",\"type\":\"MC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "DISCOVER_VCC":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD1") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_NUMBER") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("DISCOVER_EXP_DATE") + "\",\"securityCode\":\"" + testData.get("DISCOVER_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"6011000990911111\",\"type\":\"DISC\",\"expDate\":\"02/2020\",\"securityCode\":\"222\"}";
				break;
			case "EMPTY_VISA":
				strJson = "{\"nameOnCard\":\"\", \"cardNum\":\"" + testData.get("VISA_CARD_NUMBER") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("VISA_SECURITY_CODE") + "\"}";
				// strJson ="{\"nameOnCard\":\"Shank C\", \"cardNum\":\"4445222299990007\",\"type\":\"VISA\",\"expDate\":\"02/2020\",\"securityCode\":\"412\"}";
				break;
			case "TOKEN_VISA":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("VISA_CARD_TOKEN") + "\",\"type\":\"" + testData.get("VISA_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("VISA_SECURITY_CODE") + "\"}";
				break;
			case "TOKEN_MASTER":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("MASTER_CARD_TOKEN") + "\",\"type\":\"" + testData.get("MASTER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("MASTER_SECURITY_CODE") + "\"}";
				break;
			case "TOKEN_DISCOVER":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("DISCOVER_CARD_TOKEN") + "\",\"type\":\"" + testData.get("DISCOVER_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("DISCOVER_SECURITY_CODE") + "\"}";
				break;
			case "TOKEN_AMEX":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("AMEX_CARD_TOKEN") + "\",\"type\":\"" + testData.get("AMEX_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\",\"securityCode\":\"" + testData.get("AMEX_SECURITY_CODE") + "\"}";
				break;
			case "TOKEN_KOHLS_CARD":
				strJson = "{\"nameOnCard\":\"" + testData.get("NAME_ON_CARD") + "\", \"cardNum\":\"" + testData.get("KOHLS_CARD_TOKEN") + "\",\"type\":\"" + testData.get("KOHLS_TYPE") + "\",\"expDate\":\"" + testData.get("EXP_DATE") + "\"}";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}


	public static String getCustomerEmailJson(String str) {

		String strJson = "";
		switch (str) {

			case "EXISTING":
				strJson = "\"email\":\"" + "blessan.thomas@kohls.com" + "\"";
				break;
			case "CREATE":
				strJson = "\"email\":\"" + String.valueOf(new Date().getTime()) + "@testkohls.com" + "\"";
				break;
			case "INVALID":
				strJson = "\"email\":\"" + testData.get("INVALID_EMAIL_ID") + "\"";
				break;

			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}


	public static String getValidationAddressJson(String str) {

		String strJson = "";
		switch (str) {

			case "VALID":
				strJson = "\"addr1\": \"30 WATERMAN ST\",\"city\": \"PROVIDENCE\",\"state\": \"RI\",\"postalCode\": \"02903\"";
				break;
			case "INVALID_ADDR1":
				strJson = "\"addr1\":\"\",\"city\":\"PROVIDENCE\",\"state\":\"RI\",\"postalCode\":\"02903\"";
				break;
			case "EMPTY_ADDR1":
				strJson = "\"addr1\":\"\",\"city\":\"PROVIDENCE\",\"state\":\"RI\",\"postalCode\":\"02903\"";
				break;
			case "INVALID_CITY":
				strJson = "\"addr1\":\"30 WATERMAN ST\",\"city\":\"DCGFDE\",\"state\":\"RI\",\"postalCode\":\"02903\"";
				break;
			case "INVALID_STATE":
				strJson = "\"addr1\":\"30 WATERMAN ST\",\"city\":\"PROVIDENCE\",\"state\":\"DYTVRYVTWI\",\"postalCode\":\"02903\"";
				break;
			case "INVALID_POSTALCODE":
				strJson = "\"addr1\":\"30 WATERMAN ST\",\"city\":\"PROVIDENCE\",\"state\":\"RI\",\"postalCode\":\"55\"";
				break;
			case "EMPTY_CITY":
				strJson = "\"addr1\":\"30 WATERMAN ST\",\"city\":\"\",\"state\":\"RI\",\"postalCode\":\"02903\"";
				break;
			case "EMPTY_STATE":
				strJson = "\"addr1\":\"30 WATERMAN ST\",\"city\":\"PROVIDENCE\",\"state\":\"\",\"postalCode\":\"02903\"";
				break;
			case "EMPTY_POSTALCODE":
				strJson = "\"addr1\":\"30 WATERMAN ST\",\"city\":\"PROVIDENCE\",\"state\":\"RI\",\"postalCode\":\"\"";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}

	public static String getKCCValidationAddressJson(String str) {

		String strJson = "";
		switch (str) {
		
			case "VALID":
				strJson = "\"address1\": \"" +testData.get("PREQUAL_ADDRESS") + "\",\"city\": \"" +testData.get("PREQUAL_CITY") + "\",\"state\": \"" +testData.get("PREQUAL_STATE") + "\",\"postalCode\": \"" +testData.get("PREQUAL_ZIPCODE") + "\",\"country\":\"USA\"";
				break;
			case "EMPTY_ADDR1":
				strJson = "\"address1\": \"\",\"city\": \"" +testData.get("PREQUAL_CITY") + "\",\"state\": \"" +testData.get("PREQUAL_STATE") + "\",\"postalCode\": \"" +testData.get("PREQUAL_ZIPCODE") + "\",\"country\":\"USA\"";
				break;
			case "INVALID_POSTALCODE":
				strJson = "\"address1\": \"" +testData.get("PREQUAL_ADDRESS") + "\",\"city\": \"" +testData.get("PREQUAL_CITY") + "\",\"state\": \"" +testData.get("PREQUAL_STATE") + "\",\"postalCode\": \"55\",\"country\":\"USA\"";
				break;
			case "EMPTY_CITY":
				strJson = "\"address1\": \"" +testData.get("PREQUAL_ADDRESS") + "\",\"city\": \"\",\"state\": \"" +testData.get("PREQUAL_STATE") + "\",\"postalCode\": \"" +testData.get("PREQUAL_ZIPCODE") + "\",\"country\":\"USA\"";
				break;
			case "EMPTY_STATE":
				strJson = "\"address1\": \"" +testData.get("PREQUAL_ADDRESS") + "\",\"city\": \"" +testData.get("PREQUAL_CITY") + "\",\"state\": \"\",\"postalCode\": \"" +testData.get("PREQUAL_ZIPCODE") + "\",\"country\":\"USA\"";
				break;
			case "EMPTY_POSTALCODE":
				strJson = "\"address1\": \"" +testData.get("PREQUAL_ADDRESS") + "\",\"city\": \"" +testData.get("PREQUAL_CITY") + "\",\"state\": \"" +testData.get("PREQUAL_STATE") + "\",\"postalCode\": \"\",\"country\":\"USA\"";
				break;
			case "EMPTY_COUNTRY":
				strJson = "\"address1\": \"" +testData.get("PREQUAL_ADDRESS") + "\",\"city\": \"" +testData.get("PREQUAL_CITY") + "\",\"state\": \"" +testData.get("PREQUAL_STATE") + "\",\"postalCode\": \"" +testData.get("PREQUAL_ZIPCODE") + "\",\"country\":\"\"";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}

	public static String getCartJson(String strOption, String strSku, String strQty) {

		String strJson = "";
		switch (strOption) {

			case "VALID":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"add\",\"shippingMethod\": \"USSTD\"}";
				break;
			case "VALID_TDD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"add\",\"shippingMethod\": \"TDD\"}";
				break;
			case "VALID_V2":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\"}";
				break;
			case "VALID_CVV2":
				strJson = "{\"skuCode\": \"" + strSku + "\",\"qty\": " + strQty + ", \"action\": \"add\"}";
				break;
			case "VALID_CVV2_V2":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"USSTD\"}";
				break;
			case "VALID_CVV2_V2_TDD":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"TDD\"}";
				break;
			case "VALID_APPLEPAY":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"add\"}";
				break;

			case "PLACE_ORDER_VALID":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"USSTD\"}";
				break;
			case "PLACE_ORDER_VALID_TDD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"TDD\"}";
				break;
			case "ORDER_VALID_AHSTD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"AHSTD\"}";
				break;

			case "PLACE_ORDER":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\"}";
				break;
			case "WITH_INDEX":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"USSTD\",\"shipIndex\":1}";
				break;
			case "VALID_ADD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"add\"}";
				break;
			case "VALID_REMOVE":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"remove\"";
				break;
			case "VALID_ADD_TDD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"add\"}";
				break;
			case "MISSING_PARAMETER":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"action\":\"add\"}";
				break;

			case "GIFT_TRUE":
				strJson = "{ \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"giftItem\": \"true\",\"action\":\"add\" }";
				break;
				
			case "GIFT_TRUE_V1":
				strJson = "{ \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"giftItem\": \"true\",\"shippingMethod\": \"USSTD\"}";
				break;

			case "GIFT_FALSE":
				strJson = "{ \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"giftItem\": \"false\" }";
				break;

			case "REGISTRY":
				strJson = "{ \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;

			case "REGISTRY_V2":
				strJson = "\", \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;
			
			case "GIFT_TRUE_GW_TRUE":
				strJson = "{ \"skuCode\": \"" + strSku + "\",\"qty\": \"1\", \"giftItem\": \"true\", \"giftWrapItem\": \"true\", \"giftInfo\": { \"to\": \"Devendran\", \"from\": \"Senthil\", \"message\": \"Its a gift message\" }, \"shippingMethod\": \"USSTD\" }";
				break;

			case "GIFT_FALSE_GW_TRUE":
				strJson = "{ \"skuCode\": \"" + strSku + "\",\"qty\": \"1\", \"giftItem\": \"false\", \"giftWrapItem\": \"true\", \"giftInfo\": { \"to\": \"Devendran\", \"from\": \"Senthil\", \"message\": \"Its a gift message\" }, \"shippingMethod\": \"USSTD\" }";
				break;
			case "INVALID_ACTION":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"dfgffhgh\",\"shippingMethod\": \"USSTD\"}";
				break;

			case "INVALID_SHIPPING_METHOD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"USSSY\"}";
				break;

			case "BLANK_SHIPPING_METHOD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": \"\"}";
				break;
			case "NULL_SHIPPING_METHOD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\": null}";
				break;
			case "CART_INVALID_ACTION":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"dfgffhgh\"}";
				break;
			case "UPDATE_ACTION":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"update\"}";
				break;

			case "UPDATE_WITH_GIFT":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\", \"giftItem\": \"true\",\"action\":\"update\"}";
				break;
			case "REMOVE_ACTION":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"remove\"}";
				break;
			case "EMPTY_ACTION":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"\"}";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}

	public static String getCartJson(String strOption, String strSku, String strQty, String strShipMethod){
		String strJson = "";
		switch (strOption) {
			case "VALID_V2_SHIPMETHOD":
				strJson = "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"shippingMethod\":\""+ strShipMethod + "\"}";
				break;
			case "VALID_V1_SHIPMETHOD":
				strJson = "{\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"add\",\"shippingMethod\": \""+strShipMethod+"\"}";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}

	public static String getOCBCartJson(String strOption, String strCartItemID, String strSku, String strQty) {

		String strJson = "";
		switch (strOption) {

			case "UPDATE_ACTION":
				strJson = "{\"cartItemID\": \"" + strCartItemID + "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"update\"}";
				break;
			case "EMPTY_ACTION":
				strJson = "{\"cartItemID\": \"" + strCartItemID + "\",\"skuCode\":\"" + strSku + "\", \"qty\":\"" + strQty + "\",\"action\":\"update\",\"shippingMethod\": \"USSTD\"}";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}

	public static String getAlternatePickUpJson(String strOption){
		String strJson = "";
		
		switch (strOption){
			case "VALID":
				strJson = "{\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\": \""+testData.get("CUSTOMER_LASTNAME")+"\",\"email\": \"razzirazzu@gmail.com\"}";
				break;
			case "INVALID_EMAIL":
				strJson = "{\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\": \""+testData.get("CUSTOMER_LASTNAME")+"\",\"email\": \"razzirazzugmail.com\"}";
				break;
			case "NEW_FNAME_LNAME":
				strJson = "{\"firstName\":\"Razzi"+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\": \"Sultana"+testData.get("CUSTOMER_LASTNAME")+"\",\"email\": \"razzirazzu@gmail.com\"}";
				break;
			case "NEW_EMAIL_ID":
				strJson = "{\"firstName\":\""+testData.get("CUSTOMER_FIRSTNAME")+"\",\"lastName\": \""+testData.get("CUSTOMER_LASTNAME")+"\",\"email\": \"razzirazia@gmail.com\"}";
				break;
			case "EMPTY_FNAME_LNAME":
				strJson = "{\"firstName\":\"\",\"lastName\": \"\",\"email\": \"razzirazzu@gmail.com\"}";
				break;
			case "MISSING_FNAME":
				strJson = "{\"lastName\": \""+testData.get("CUSTOMER_LASTNAME")+"\",\"email\": \"razzirazzu@gmail.com\"}";
				break;
			default:
				strJson = "NO - INPUT JSON AVAILABLE";
					
		}
		return strJson;
	}

	public static String getBopusCartJson(String strOption, String strSku, String strQty, String strStoreNo) {

		String strJson = "";
		switch (strOption) {

			case "VALID":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"add\"}";
				break;
			case "VALID_V1":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + "}";
				break;
			case "VALID_OMNI":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty +"}";
				break;
			case "VALID_V2":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + "}";
				break;
			case "VALID_V3":
				strJson = "\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + "}";
				break;
			case "VALID_INSTORE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"ODD\"}";
				break;
			case "VALID_INSTORE_TDD":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"add\"}";
				break;
			case "VALID_GIFT_INSTORE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\",\"giftItem\":\"true\", \"qty\": " + strQty + ", \"action\": \"add\"}";
				break;
			case "MISSING_PARAM":
				strJson = "{\"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"add\"}";
				break;

			case "BOPUS_TO_NORMAL":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"false\",\"isBopusToShip\":\"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"update\"}";
				break;

			case "VALID_GIFT":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ",\"giftItem\":\"true\",\"action\": \"add\"}";
				break;
			case "VALID_GIFT_V1":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ",\"giftItem\":\"true\"}";
				break;

			case "BOPUSITEMFALSE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"false\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"USSTD\"}";
				break;
			case "BOPUSFALSE":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"false\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"USSTD\"}";
				break;
			case "CVV2_CART_BOPUS":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"add\"}";
				break;

			case "GIFT_TRUE_GW_TRUE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"USSTD\",\"giftWrapItem\":\"true\"}";
				break;
			case "REGISTRY":
				strJson = "\"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"storeNum\": \"" + strStoreNo + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;

			case "REGISTRY_V2":
				strJson = "\", \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"storeNum\": \"" + strStoreNo + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;
			case "REGISTRY_V1":
				strJson = "{\"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"storeNum\": \"" + strStoreNo + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;

			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}


	public static String getBopusCartJsonShippingType(String strOption, String strSku, String strQty, String strStoreNo, String strShippingType) {

		String strJson = "";
		switch (strOption) {

			case "VALID":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ",\"shippingMethod\": \"" + strShippingType + "\"}";
				break;
			/*case "VALID_INSTORE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;*/
			case "VALID_INSTORE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;
			/*case "VALID_INSTORE_V2":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;*/
			case "VALID_INSTORE_V2":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;
			case "VALID_GIFT_INSTORE":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\",\"giftItem\":\"true\", \"qty\": " + strQty + ", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;

			case "VALID_BOPUS":
				strJson = "\",\"skuCode\": \"" + strSku + "\",\"bopusItem\":\"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;
			case "MISSING_PARAM":
				strJson = "{\"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"add\"}";
				break;

			case "BOPUS_TO_NORMAL":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"false\",\"isBopusToShip\":\"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"action\": \"update\"}";
				break;

			case "VALID_GIFT":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ",\"giftItem\":\"true\", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;
			case "VALID_GIFT_V2":
				strJson = "\",\"skuCode\": \"" + strSku + "\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ",\"giftItem\":\"true\", \"shippingMethod\": \"" + strShippingType + "\"}";
				break;

			case "BOPUSITEMFALSE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"false\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"USSTD\"}";
				break;

			case "GIFT_TRUE_GW_TRUE":
				strJson = "{\"skuCode\": \"" + strSku + "\", \"bopusItem\": \"true\", \"storeNum\": \"" + strStoreNo + "\", \"qty\": " + strQty + ", \"shippingMethod\": \"USSTD\",\"giftWrapItem\":\"true\"}";
				break;
			case "REGISTRY":
				strJson = "\"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"storeNum\": \"" + strStoreNo + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;

			case "REGISTRY_V2":
				strJson = "\", \"skuCode\": \"" + strSku + "\",\"qty\": \"" + strQty + "\", \"storeNum\": \"" + strStoreNo + "\",\"shippingMethod\": \"" + strShippingType + "\",\"registry\":{\"registryName\":\"Tests\",\"registryType\":\"wishlist\",\"registryID\":\"2522230\",";
				break;

			default:
				strJson = "NO - INPUT JSON AVAILABLE";
		}
		return strJson;
	}


	public static String validateJson(String strJson) {

		try {

			// If strJson not contains "payload", return the string as is
			if (!strJson.contains("{"))
				return strJson;

			JsonNode map = new ObjectMapper().readTree(strJson);
			String strPrettyPrint = new ObjectMapper().defaultPrettyPrintingWriter().writeValueAsString(map);
			//System.out.println(strPrettyPrint);
			return strPrettyPrint;
		}
		catch (Exception e) {

			// Assert.fail("Cannot parse Payload " + strJson);
			return strJson;
		}
	}


	public static String[] getResponseErrors(String strJson) {

		// System.out.println("Grep errors for " + strJson);

		String strReturn[] = new String[2];

		String strCode = "", strMessage = "", strErrorString = "";

		String patternStr = "\"(offer|)(E|e)rror(s|)\":(\\[|)\\{.+?\\}";
		Pattern pattern = Pattern.compile(patternStr);
		Matcher matcher = pattern.matcher(strJson.toString());
		if (matcher.find()) {
			strErrorString = "{" + matcher.group(0) + "}";
		}

		/*
		 * String strErrorStringLower = strErrorString.toLowerCase(); if (strErrorStringLower.contains("\"error\":null")||strErrorStringLower.contains("\"errors\":[]")) strErrorString="";
		 */

		// System.out.println("Error string" + strErrorString);

		if (!strErrorString.equals("")) {

			strErrorString = strErrorString.replace("[", "").replace("]", "");
			strErrorString = strErrorString.replaceAll("(offer|)(E|e)rror(s|)", "error");
			strErrorString = strErrorString.replace("Code", "code").replace("Message", "message");

			strCode = String.valueOf(JsonPath.read(strErrorString, "$.error.code"));
			strMessage = String.valueOf(JsonPath.read(strErrorString, "$.error.message"));
		}

		// System.out.println(strCode + strMessage);

		strReturn[0] = strCode;
		strReturn[1] = strMessage;

		return strReturn;

	}

}
