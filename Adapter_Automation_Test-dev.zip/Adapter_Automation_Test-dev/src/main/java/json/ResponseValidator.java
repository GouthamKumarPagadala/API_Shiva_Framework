package main.java.json;

import static main.java.common.GlobalVariables.CompareOAPI;
import static main.java.common.GlobalVariables.INVENTORY_WEBID_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.PROFILE_CREATE_OAPI;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_ADAPTER;
import static main.java.common.GlobalVariables.V1_SIGNIN_PROFILE_OAPI;
import static main.java.common.GlobalVariables.CART_ADAPTER;
import static main.java.common.TestData.testData;
import static main.java.common.TestData.mapheader;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.eclipse.jetty.util.ajax.JSON;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.InvalidPathException;
import com.jayway.jsonpath.JsonPath;

import main.java.common.RestCall;
import main.java.common.TestData;
import main.java.common.Utilities;
import main.java.common.TestData.Server;
import net.minidev.json.JSONArray;
import ru.yandex.qatools.allure.annotations.Step;

public class ResponseValidator {

	@BeforeClass(alwaysRun = true)
	public void testSetup() {

	}

	String	strResponse;
	Object	document;

	public ResponseValidator(String strResponse) {
		this.strResponse = strResponse;
		document = Configuration.defaultConfiguration().jsonProvider().parse(strResponse);
	}


	@Step("\"{2}\"")
	public void nodeMatches(String strJsonPath, String strExpected, String strStepDescription) {

		try {
			String strActual = String.valueOf(JsonPath.read(document, strJsonPath));
			Assert.assertTrue(strActual.matches(strExpected), "Expected : '" + strExpected + "'... Actual : '" + strActual + "'");

		}
		catch (ClassCastException e) {
			Assert.fail("Error Converting Json Node Value " + strJsonPath);
			e.printStackTrace();
		}
		catch (InvalidPathException | NullPointerException e) {
			Assert.fail("Cannot find the Json Node : " + strJsonPath);
			e.printStackTrace();
		}
	}
	
	@Step("\"{2}\"")
	public void nodeContains(String strJsonPath, String strExpected, String strStepDescription) {

		try {
			String strActual = String.valueOf(JsonPath.read(document, strJsonPath));
			Assert.assertTrue(strActual.contains(strExpected), "Expected : '" + strExpected + "'... Actual : '" + strActual + "'");

		}
		catch (ClassCastException e) {
			Assert.fail("Error Converting Json Node Value " + strJsonPath);
			e.printStackTrace();
		}
		catch (InvalidPathException | NullPointerException e) {
			Assert.fail("Cannot find the Json Node : " + strJsonPath);
			e.printStackTrace();
		}
	}


	@Step("\"{2}\"")
	public void nodeEquals(String strJsonPath, String strExpected, String strStepDescription) {

		try {
			String strActual = String.valueOf(JsonPath.read(document, strJsonPath));

			Assert.assertEquals(strActual, strExpected);
		}
		catch (ClassCastException e) {
			Assert.fail("Error Converting Json Node Value " + strJsonPath);
			e.printStackTrace();
		}
		catch (InvalidPathException | NullPointerException e) {
			Assert.fail("Cannot find the Json Node : " + strJsonPath);
			e.printStackTrace();
		}
	}
	
		
	@Step("Validate Product V2 Response")
	public void ValidateProductV2Response(Boolean isSkuDetails, Boolean isInstore, Boolean isRebate) {
		JSONArray products = JsonPath.read(document, "$.payload.products");
		for (int i = 0; i < products.size(); i++) {
			// Product Level

			// Rebate URL Validation
			nodeMatches("$.payload.products[" + i + "].rebate.rebateURL", ".*",
					"Rebate url should be displayed as part of v2 Product response.");
			nodeMatches("$.payload.products[" + i + "].rebate.shortDescription", ".*",
					"shortDescription should be displayed as part of v2 Product response.");
			nodeMatches("$.payload.products[" + i + "].rebate.longDescription", ".*",
					"longDescription should be displayed as part of v2 Product response.");

			// Min and Max Price for RegularPrice
			nodeMatches("$.payload.products[" + i + "].price.regularPrice.minPrice", ".*",
					"minPrice should be displayed for regularPrice");
			nodeMatches("$.payload.products[" + i + "].price.regularPrice.maxPrice", ".*",
					"maxPrice should be displayed for regularPrice");

			// Min and Max Price for SalePrice
			if (Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].price.salePriceStatus")
					.toString().equals("sale")) {
				nodeMatches("$.payload.products[" + i + "].price.salePrice.minPrice", ".*",
						"minPrice should be displayed for salePrice");
				nodeMatches("$.payload.products[" + i + "].price.salePrice.maxPrice", ".*",
						"maxPrice should be displayed for salePrice");
			}

			// Promotion Array Validation
			nodeMatches("$.payload.products[" + i + "].price.promotion.group", ".*",
					"group should be displayed under Promotion");
			nodeMatches("$.payload.products[" + i + "].price.promotion.tieredPrice", ".*",
					"tieredPrice should be displayed under Promotion");
			nodeMatches("$.payload.products[" + i + "].price.promotion.bogo", ".*",
					"bogo should be displayed under Promotion");

			// SuppressedPrice Validation
			if (Utilities.getJsonNodeValue(strResponse, "$.payload.products[" + i + "].price.isSuppressed").toString()
					.equals("true")) {
				nodeEquals("$.payload.products[" + i + "].price.suppressedPricingText", "FOR PRICE, ADD TO BAG",
						"FOR PRICE, ADD TO BAG should be displayed for suppressed Product");
			}

			if (isSkuDetails) {
				// Sku Level
				JSONArray skus = JsonPath.read(document, "$.payload.products[" + i + "].SKUS");
				for (int j = 0; j < skus.size(); j++) {

					// Min and Max Price for RegularPrice
					nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.regularPrice.minPrice", ".*",
							"minPrice should be displayed for regularPrice");
					nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.regularPrice.maxPrice", ".*",
							"maxPrice should be displayed for regularPrice");

					// Min and Max Price for SalePrice
					if (Utilities
							.getJsonNodeValue(strResponse,
									"$.payload.products[" + i + "].SKUS[" + j + "].price.salePriceStatus")
							.toString().equals("sale")) {
						nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.salePrice.minPrice", ".*",
								"minPrice should be displayed for salePrice");
						nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.salePrice.maxPrice", ".*",
								"maxPrice should be displayed for salePrice");
					}

					// Promotion Array Validation
					nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.promotion.group", ".*",
							"group should be displayed under Promotion");
					nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.promotion.tieredPrice", ".*",
							"tieredPrice should be displayed under Promotion");
					nodeMatches("$.payload.products[" + i + "].SKUS[" + j + "].price.promotion.bogo", ".*",
							"bogo should be displayed under Promotion");

					// SuppressedPrice Validation
					if (Utilities
							.getJsonNodeValue(strResponse,
									"$.payload.products[" + i + "].SKUS[" + j + "].price.isSuppressed")
							.toString().equals("true")) {
						nodeEquals("$.payload.products[" + i + "].SKUS[" + j + "].price.suppressedPricingText",
								"FOR PRICE, ADD TO BAG",
								"FOR PRICE, ADD TO BAG should be displayed for suppressed Product");
					}
					// Store Level
					if (isInstore) {
						// Min and Max Price for RegularPrice
						nodeMatches(
								"$.payload.products[" + i + "].SKUS[" + j
										+ "].storeInfo.stores[0].price.regularPrice.minPrice",
								".*", "minPrice should be displayed for regularPrice");
						nodeMatches(
								"$.payload.products[" + i + "].SKUS[" + j
										+ "].storeInfo.stores[0].price.regularPrice.maxPrice",
								".*", "maxPrice should be displayed for regularPrice");

						// Min and Max Price for SalePrice
						if (Utilities
								.getJsonNodeValue(strResponse,
										"$.payload.products[" + i + "].SKUS[" + j
												+ "].storeInfo.stores[0].price.salePriceStatus")
								.toString().equals("sale")) {
							nodeMatches(
									"$.payload.products[" + i + "].SKUS[" + j
											+ "].storeInfo.stores[0].price.salePrice.minPrice",
									".*", "minPrice should be displayed for salePrice");
							nodeMatches(
									"$.payload.products[" + i + "].SKUS[" + j
											+ "].storeInfo.stores[0].price.salePrice.maxPrice",
									".*", "maxPrice should be displayed for salePrice");
						}

						// Promotion Array Validation
						nodeMatches(
								"$.payload.products[" + i + "].SKUS[" + j
										+ "].storeInfo.stores[0].price.promotion.group",
								".*", "group should be displayed under Promotion");
						nodeMatches(
								"$.payload.products[" + i + "].SKUS[" + j
										+ "].storeInfo.stores[0].price.promotion.tieredPrice",
								".*", "tieredPrice should be displayed under Promotion");
						nodeMatches(
								"$.payload.products[" + i + "].SKUS[" + j
										+ "].storeInfo.stores[0].price.promotion.bogo",
								".*", "bogo should be displayed under Promotion");

					}
				}
			}
		}

	}

	@Step("Validate Product V2 Response")
	public void ValidateProductV2Promotion(Boolean isBOGO, Boolean isGROUP, Boolean isTIRED, Boolean isSkuDetail, Boolean isInStore) {

		// Promotion Array Validation - BOGO
		if(isBOGO){
		nodeContains("$.payload.products[0].price.promotion.bogo", "BUY", "bogo should be displayed under Promotion");
		if(isSkuDetail)
			nodeContains("$.payload.products[0].SKUS[0].price.promotion.bogo", "BUY",
				"bogo should be displayed under Promotion");
		if(isInStore)
			nodeContains("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion.bogo", "BUY",
				"bogo should be displayed under Promotion");
		}
		
		// Promotion Array Validation - GROUP
		if(isGROUP){
			nodeContains("$.payload.products[0].price.promotion.group", "$", "group should be displayed under Promotion");
		if(isSkuDetail)
			nodeContains("$.payload.products[0].SKUS[0].price.promotion.group", "$",
				"group should be displayed under Promotion");
		if(isInStore)
			nodeContains("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion.group", "$",
				"group should be displayed under Promotion");
		}
		// Promotion Array Validation - TIRED
		if(isTIRED){
			nodeContains("$.payload.products[0].price.promotion.tieredPrice", "OFF",
					"tieredPrice should be displayed under Promotion");
		if(isSkuDetail)
			nodeContains("$.payload.products[0].SKUS[0].price.promotion.tieredPrice", "OFF",
					"tieredPrice should be displayed under Promotion");
		if(isInStore)
			nodeContains("$.payload.products[0].SKUS[0].storeInfo.stores[0].price.promotion.tieredPrice", "OFF",
				"tieredPrice should be displayed under Promotion");
		}
	}

		

	
	@Step("Validate KohlsCash Balance response")
	public void validateKohlsCashBalance(String kohlsCashNum){
		String kohlscash4digit=kohlsCashNum.substring(11, 15);
		nodeMatches("$.payload.kohlsCash.kohlsCashNum","[x]+"+kohlscash4digit,"KohlsCash Number should be Masked");
		nodeMatches("$.payload.kohlsCash.validDates.endDate", "[0-9]+/[0-9]+/[0-9]+","endDate should not be NULL");
		nodeMatches("$.payload.kohlsCash.validDates.startDate", "[0-9]+/[0-9]+/[0-9]+","startDate should not be NULL");
		nodeMatches("$.payload.kohlsCash.balance", "[0-9]+.[0-9]","Balance should be displayed");
		
	}
	
	@Step("Order attributes should be present in response")
	public void validateSTCResponse(String Country,String recyclingfee) {
		if(Country=="California"){
			nodeEquals("$.payload.order.totals.feeDetails[0].location", "California", "location should be present in the response");
			nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		}
		if(Country=="Connecticut"){
			nodeEquals("$.payload.order.totals.feeDetails[0].location", "Connecticut", "location should be present in the response");
			nodeMatches("$.payload.order.totals.feeDetails[0].cost", ".+", "cost should be present in the response");
		}
		if(recyclingfee.equalsIgnoreCase("ewaste")){	
			
			nodeEquals("$.payload.order.totals.feeDetails[0].name", "eWaste Recycling Fee", "name should be present in the response");
		}
if(recyclingfee.equalsIgnoreCase("Mattress")){	
			
			nodeEquals("$.payload.order.totals.feeDetails[0].name", "Mattress Recycling Fee", "name should be present in the response");
		}
		
		nodeMatches("$.payload.order.totals.salesTax", ".+", "salesTax should be present in the response");
		
		
		
	}
	
	
	@Step("Bopus Item should be present in response")
	public void validateBopusAlternatePickup(String firstName, String lastName, String email) {
		nodeMatches("$.payload.order.alternatePickUpPersons",".*","alternatePickUp field should not be null");
		nodeEquals("$.payload.order.alternatePickUpPersons[0].firstName",firstName,"alternatepickupperson firstname should be same");
		nodeEquals("$.payload.order.alternatePickUpPersons[0].lastName",lastName,"alternatepickupperson lastname should be same");
		nodeEquals("$.payload.order.alternatePickUpPersons[0].email",email,"alternatepickupperson email should be same");
	}
	
	@Step("Bopus Item should be present in response")
	public void validateBopusAlternatePickupNotificationNumber(String notificationNumber) {
		nodeEquals("$.payload.order.textNotificationNumber",notificationNumber,"textNotificationNumber should be present");
	}
	
	
	@Step("Order attributes should be present in response")
	public void validateOrderMasterPassResponse() {
		nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
}
	
	@Step("Payment Info should be present in response")
	public void validateOrderPromoCode(String promoCode, Boolean isPlaceorder) {
		if(!isPlaceorder){
		//nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");
		//nodeMatches("$.payload.order.paymentTypes.promoCodes[0].validDates.startDate", "[0-9]+-[0-9]+-[0-9]+\\s[0-9]+:[0-9]+:[0-9]+.[0-9]", "start Date for promoCode should be displayed in the response");
		nodeMatches("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true|false", "value should be applied from PromoCode in the response");
		//nodeMatches("$.payload.order.paymentTypes.promoCodes[0].validDates.startDate", ".+", "start Date for promoCode should be displayed in the response");
		}
		else{
		nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].value", ".+", "value should be applied from PromoCode in the response");}
		nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+promoCode+".*", "PromoCode should be present in the response");
		//nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].validDates.startDate", ".+", "start Date for promoCode should be displayed in the response");
	//[0-9]+-[0-9]+-[0-9]+\\s[0-9]+:[0-9]+:[0-9]+.[0-9]
	}

	@Step("Payment Info should be present in response")
	public void validateOrderPromoInstore(String promoCode, Boolean isPlaceorder) {
		if(!isPlaceorder){
		nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].isApplied", ".+", "value should be applied from PromoCode in the response");
		nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].validDates.startDate", ".+", "start Date for promoCode should be displayed in the response");
		}
		else{
			nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].value)", ".+", "value should be applied from PromoCode in the response");
			nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].validDates.startDate", "[0-9]+.[0-9]+", "start Date for promoCode should be displayed in the response");
			nodeMatches("$.payload.order.paymentTypes.promoCodes[?(@.code=="+promoCode+")].isApplied", ".+", "value should be applied from PromoCode in the response");
		}
		
	}
	
	@Step("Order attributes should be present in response")
	public void validateOrderVXOResponse() {
		nodeEquals("$.payload.order.paymentTypes.paymentDetails", "VC", "paymentDetials should be present in the response");
}
	
	@Step("Order attributes should be present in response")
	public void validateOrderApplePayResponse() {
		nodeEquals("$.payload.order.paymentTypes.paymentDetails", "APPLEPAY", "paymentDetails should be present as 'APPLEPAY' in the response");
}
	
	@Step("Payment Info should be present in response")
	public void validateOrderKohlsCash(String KohlCashNum, Boolean isPlaceorder) {
		String kohlscash4digit=KohlCashNum.substring(11, 15);
		if(!isPlaceorder){
		nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].validDates.startDate", "[0-9]+/[0-9]+/[0-9]+", "start Date for KohlsCash should be displayed in the response");}
		else {
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9]+.[0-9]+", "Value should be applied in the response");}
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].kohlsCashNum", "([x]+"+kohlscash4digit+"|"+KohlCashNum+")","KohlsCash should be encrypted.");
	}
	
	@Step("Order attributes should be present in response")
	public void validateOrderResponse(Boolean isPlaceOrder, Boolean isRegistered, String skuNum, String shipMethod) {
		if(isRegistered){
		    
			nodeMatches("$.payload.order.cartID", ".+", "CartID should be present in the response");}
		if(isPlaceOrder){
			nodeMatches("$.payload.order.orderNumber","[0-9]+","OrderNumber should be present");
			nodeEquals("$.payload.order.orderStatus", "Submitted", "Order Status should be submitted");
		}
		
		nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		nodeMatches("$.payload.order.cartItems[*].skuCode", ".*"+skuNum+".*", "Given Sku code should be present in the response");
		//nodeEquals("$.payload.order.cartItems[0].shippingMethod", shipMethod, "Given Sku code should be present in the response");
	}
	
	@Step("Order attributes should be present in response")
	public void validateBopusOrderResponse(Boolean isPlaceOrder, Boolean isRegistered, String skuNum, String storeNum) {
		if(isRegistered){
		//nodeMatches("$.payload.order.cartID", ".+", "CartID should be present in the response");}
		nodeMatches("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailableToShip should be true as it is Bopus product");}
		if(isPlaceOrder){
			nodeMatches("$.payload.order.orderNumber","[0-9]+","OrderNumber should be present");
			nodeEquals("$.payload.order.orderStatus", "Submitted", "Order Status should be submitted");
		}
		nodeEquals("$.payload.order.cartItems[0].isAvailableToShip","true","isAvailableToShip should be true as it is Bopus product");
		nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		nodeMatches("$.payload.order.cartItems[*].skuCode", ".*"+skuNum+".*", "Given Sku code should be present in the response");
		nodeMatches("$.payload.order..storeNum", ".*"+storeNum+".*", "Given Sku code should be present in the response");
	}
	
	@Step("Payment Info should be present in response")
	public void validatePaymentInfo(String paymentType) {

		nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", "[x]+[0-9]{4}+", "card number should be present in the response");
		if(paymentType != "KOHLS"){
		nodeMatches("$.payload.order.paymentTypes.creditCards[0].expDate", "([0-9]{2}/[0-9]{4}+|null)", "expiry date should be present in the response");}
		nodeEquals("$.payload.order.paymentTypes.creditCards[0].type", paymentType, "Payment Type should be "+paymentType);
	}


	@Step("\"{2}\"")
	public void nodeNotEquals(String strJsonPath, String strExpected, String strStepDescription) {

		try {
			String strActual = String.valueOf(JsonPath.read(document, strJsonPath));
			// int size=strActual.length();
			Assert.assertNotEquals(strActual, strExpected, strStepDescription);
		}
		catch (ClassCastException e) {
			Assert.fail("Error Converting Json Node Value " + strJsonPath);
			e.printStackTrace();
		}
		catch (InvalidPathException | NullPointerException e) {
			Assert.fail("Cannot find the Json Node : " + strJsonPath);
			e.printStackTrace();
		}
	}


	@Step("\"{0}\"")
	public void ValidatePriceForCategory(String strStepDescription1) {

		JSONArray products = JsonPath.read(document, "$.payload.products");
		System.out.println("products =" + products);
		System.out.println("products size of str=" + products.size());

		for (int i = 0; i < products.size(); i++) {
			String isPriceInstore = String.valueOf(JsonPath.read(document, "$.payload.products[" + i + "].prices[0].isPriceInstore"));
			System.out.println("isPriceInstore=" + isPriceInstore);
			if (isPriceInstore.equals("true")) {
				String minPrice = String.valueOf(JsonPath.read(document, "$.payload.products[" + i + "].prices[0].regularPrice.minPrice"));
				System.out.println("minPrice= " + minPrice);
				Assert.assertNotEquals(minPrice, "null", "Min Proce should not be null");
			} else if (isPriceInstore.equals("false")) {
				String minPrice = String.valueOf(JsonPath.read(document, "$.payload.products[" + i + "].prices[0].regularPrice.minPrice"));
				System.out.println("minPrice= " + minPrice);
				Assert.assertNotEquals(minPrice, "null", "Min Proce should not be null");
			} else {

				Assert.fail("Cannot find Instore Price");
			}
		}
	}


	@Step("\"{0}\"")
	public void isBopusEligibleNotNull(String strStepDescription1) {

		JSONArray cartItems = JsonPath.read(document, "$.payload.order.cartItems");
		System.out.println("cartItems =" + cartItems);
		System.out.println("cartItems size of str=" + cartItems.size());

		for (int i = 0; i < cartItems.size(); i++) {
			String isBopusEligible = String.valueOf(JsonPath.read(document, "$.payload.order.cartItems[" + i + "].isBopusEligible"));
			System.out.println("isBopusEligible=" + isBopusEligible);
			Assert.assertNotEquals(isBopusEligible, "null", "isBopusEligible should not be null");
		}
	}


	@Step("\"{0}\"")
	public void isBopusEligibleTrueForSku(String strStepDescription1) {

		JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
		System.out.println("SKUS =" + SKUS);
		System.out.println("SKUS size of str=" + SKUS.size());

		for (int i = 0; i < SKUS.size(); i++) {
			String isBopusEligible = String.valueOf(JsonPath.read(document, "$.payload.products[0].SKUS[" + i + "].isBopusEligible"));
			System.out.println("isBopusEligible=" + isBopusEligible);
			Assert.assertEquals(isBopusEligible, "true", "isBopusEligible should be true");
		}
	}


	@Step("\"{0}\"")
	public void isBopusEligibleFalseForSku(String strStepDescription1) {

		JSONArray SKUS = JsonPath.read(document, "$.payload.products[0].SKUS");
		System.out.println("SKUS =" + SKUS);
		System.out.println("SKUS size of str=" + SKUS.size());

		for (int i = 0; i < SKUS.size(); i++) {
			String isBopusEligible = String.valueOf(JsonPath.read(document, "$.payload.products[0].SKUS[" + i + "].isBopusEligible"));
			System.out.println("isBopusEligible=" + isBopusEligible);
			Assert.assertEquals(isBopusEligible, "false", "isBopusEligible should be false");
		}
	}


	@Step("\"{0}\"")
	public void InventoryisBopusEligibleStoreTrueForSku(String strStepDescription1) {

		JSONArray stores = JsonPath.read(document, "$.payload.skus[0].stores");
		System.out.println("stores =" + stores);
		System.out.println("stores size of str=" + stores.size());

		for (int i = 0; i < stores.size(); i++) {
			String isBopusEligibleStore = String.valueOf(JsonPath.read(document, "$.payload.skus[0].stores[" + i + "].isBopusEligibleStore"));
			System.out.println("isBopusEligibleStore=" + isBopusEligibleStore);
			Assert.assertEquals(isBopusEligibleStore, "true", "isBopusEligible should be true");
		}
	}


	@Step("\"{0}\"")
	public void InventoryisBopusEligibleStoreFalseForSku(String strStepDescription1) {

		JSONArray stores = JsonPath.read(document, "$.payload.skus[0].stores");
		System.out.println("stores =" + stores);
		System.out.println("stores size of str=" + stores.size());

		for (int i = 0; i < stores.size(); i++) {
			String isBopusEligibleStore = String.valueOf(JsonPath.read(document, "$.payload.skus[0].stores[" + i + "].isBopusEligibleStore"));
			System.out.println("isBopusEligibleStore=" + isBopusEligibleStore);
			Assert.assertEquals(isBopusEligibleStore, "false", "isBopusEligible should be false");
		}
	}


	@Step("\"{0}\"")
	public void InventoryisBopusEligibleStoreTrueAndFalseForSku(String strStepDescription1) {

		JSONArray stores = JsonPath.read(document, "$.payload.skus[0].stores");
		System.out.println("stores =" + stores);
		System.out.println("stores size of str=" + stores.size());

		for (int i = 0; i < stores.size(); i++) {
			String isBopusEligibleStore = String.valueOf(JsonPath.read(document, "$.payload.skus[0].stores[" + i + "].isBopusEligibleStore"));
			System.out.println("isBopusEligibleStore=" + isBopusEligibleStore);
			/*
			 * if(isBopusEligibleStore.equals("true")||isBopusEligibleStore.equals("false")){ System.out.println("isBopusEligibleStore is true or false"); } else{ Assert.fail(); }
			 */

			Assert.assertTrue(isBopusEligibleStore.equals("true") || isBopusEligibleStore.equals("false"), "isBopusEligible should be either true or false");
		}
	}


	@Step("\"{0}\"")
	public void InventoryisClearanceTrueAndFalseForSku(String strStepDescription1) {

		JSONArray stores = JsonPath.read(document, "$.payload.skus[0].stores");
		System.out.println("stores =" + stores);
		System.out.println("stores size of str=" + stores.size());

		for (int i = 0; i < stores.size(); i++) {
			String isClearance = String.valueOf(JsonPath.read(document, "$.payload.skus[0].stores[" + i + "].isClearance"));
			System.out.println("isClearance=" + isClearance);
			/*
			 * if(isClearance.equals("true")||isClearance.equals("false")){ System.out.println("isClearance is true or false"); } else{ Assert.fail(); }
			 */

			Assert.assertTrue(isClearance.equals("true") || isClearance.equals("false"), "isClearance should be either true or false");
		}
	}


	@Step("\"{0}\"")
	public void ValidatingStores(String strStepDescription1) {

		JSONArray stores = JsonPath.read(document, "$.payload.stores");
		System.out.println("stores =" + stores);
		System.out.println("stores size of str=" + stores.size());

		for (int i = 0; i < stores.size(); i++) {
			String storeNum = String.valueOf(JsonPath.read(document, "$.payload.stores[" + i + "].isClearance"));
			Assert.assertNotEquals(storeNum, "null", "Store number should not be null");
			// assert (storeNum != null);
			String isClearance = String.valueOf(JsonPath.read(document, "$.payload.stores[" + i + "].isClearance"));
			System.out.println("isClearance=" + isClearance);
			Assert.assertTrue(isClearance.equals("true") || isClearance.equals("false"), "isClearance should be either true or false");
		}
	}


	@Step("\"{0}\"")
	public void ItemTypeIsBopus(String strStepDescription1) {

		JSONArray cartItems = JsonPath.read(document, "$.payload.order.cartItems");
		System.out.println("cartItems =" + cartItems);
		System.out.println("cartItems size of str=" + cartItems.size());

		for (int i = 0; i < cartItems.size(); i++) {
			String itemType = String.valueOf(JsonPath.read(document, "$.payload.order.cartItems[" + i + "].itemType"));
			System.out.println("itemType=" + itemType);
			Assert.assertEquals(itemType, "BOPUS", "item type should be bopus");
		}
	}


	

	@Step("\"{0}\"")
	public void storeAddresses(String strStepDescription1) {

		JSONArray storeAddresses = JsonPath.read(document, "$.payload.order.storeAddresses");
		System.out.println("storeAddresses =" + storeAddresses);
		System.out.println("storeAddresses size of str=" + storeAddresses.size());

		for (int i = 0; i < storeAddresses.size(); i++) {
			String city = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].city"));
			System.out.println("city=" + city);
			Assert.assertNotEquals(city, "null", "City should not be null in the response");
			String countryCode = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].countryCode"));
			System.out.println("countryCode=" + countryCode);
			Assert.assertNotEquals(countryCode, "null", "countryCode should not be null in the response");
			String addr1 = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].addr1"));
			System.out.println("addr1=" + addr1);
			Assert.assertNotEquals(addr1, "null", "addr1 should not be null in the response");
			String estimatedPickUpMessage = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].estimatedPickUpMessage"));
			System.out.println("estimatedPickUpMessage=" + estimatedPickUpMessage);
			Assert.assertNotEquals(estimatedPickUpMessage, "null", "estimatedPickUpMessage should not be null in the response");
			String phoneNumber = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].phoneNumber"));
			System.out.println("phoneNumber=" + phoneNumber);
			Assert.assertNotEquals(phoneNumber, "null", "phoneNumber should not be null in the response");
			String postalCode = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].postalCode"));
			System.out.println("postalCode=" + postalCode);
			Assert.assertNotEquals(postalCode, "null", "postalCode should not be null in the response");
			String state = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].state"));
			System.out.println("state=" + state);
			Assert.assertNotEquals(state, "null", "state should not be null in the response");
			String storeNum = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].storeNum"));
			System.out.println("storeNum=" + storeNum);
			Assert.assertNotEquals(storeNum, "null", "storeNum should not be null in the response");
			String storeName = String.valueOf(JsonPath.read(document, "$.payload.order.storeAddresses[" + i + "].storeName"));
			System.out.println("storeName=" + storeName);
			Assert.assertNotEquals(storeName, "null", "storeName should not be null in the response");
		}
	}


	@Step("\"{2}\"")
	public static void validateStringEquals(String strActual, String strExpected, String strStepDescription) {

		try {
			Assert.assertEquals(strActual, strExpected, strStepDescription);
		}
		catch (Exception e) {
			Assert.fail("Exception in validateStringEquals");
			e.printStackTrace();
		}
	}


	@Step("Validate No Errors are present")
	public void validateNoErrors() {

		String strError[] = JsonString.getResponseErrors(strResponse);
		if (!(strError[0] + strError[1]).equals(""))
			Assert.assertEquals(strError[0] + " - " + strError[1], ""); // Error code and message should be empty
		// Assert.assertEquals(strError[1], ""); //Error message should be empty
	}


	@Step("Validate No errros except Test Data error " + "\"{1}\"")
	public boolean validateDataErrors(String strCode, String strMessage) {

		// Validate that there are no errors, an expected error can be ignored (e.g test data error)
		String strError[] = JsonString.getResponseErrors(strResponse);
		if (!strError[0].equals("") && !strError[0].contains(strCode))
			Assert.assertEquals(strError[0], ""); // Error code should be empty or expected error

		if (!strError[1].equals("") && !strError[1].contains(strMessage))
			Assert.assertEquals(strError[1], ""); // Error Message should be empty or expected error

		// Return true if no errors occour
		if (strError[0].equals("") && strError[1].equals(""))
			return true;
		else
			return false;

	}


	@Step("Validate Expected Error " + "{1}" + " is present")
	public void validateExpectedErrors(String strCode, String strMessage) {

		// Validate that an expected error should occour ( negative scenario)
		String strError[] = JsonString.getResponseErrors(strResponse);

		if (!strMessage.equals(""))
			Assert.assertEquals(strError[1].toLowerCase(), strMessage.toLowerCase());

		if (!strCode.equals(""))
			Assert.assertEquals(strError[0], strCode);

	}
	@Step("Validate Expected Error " + "{1}" + " is present")
	public void validateExpectedErrorsforremedy(String strResponse,String strCode, String strMessage ) {

		// Validate that an expected error should occour ( negative scenario)
		
		String Errorcode = String.valueOf(JsonPath.read(strResponse, "$.errors[0].code"));
		String ErrorMessage = String.valueOf(JsonPath.read(strResponse, "$.errors[0].message"));
			Assert.assertEquals(Errorcode.toLowerCase(), strCode.toLowerCase());
			Assert.assertEquals(ErrorMessage.toLowerCase(), strMessage.toLowerCase());

		
	}


	@Step("Cart attributes should be present in response")
	public void validateCartResponse() {

		nodeMatches("$.payload.cart.cartID", ".+", "CartID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Step("is suppressed flag should be false at sku,collection and product level in response")
	public void validateSmartsuppressedPrice() {

		nodeMatches("$.payload.cart.cartID", ".+", "CartID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	
	@Step("Order attributes should be present in response")
	public void validateOrderResponse() {

		nodeMatches("$.payload.order.cartID", ".+", "CartID should be present in the response");
		nodeMatches("$.payload.order.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.order.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
	}
	
	@Step("Cart attributes should be present in response")
	public void validateCartResponse(String skuCode, String qty, boolean isBopus, String storeNum) {
		nodeEquals("$.payload.cart.cartItems[0].skuCode", skuCode, "Given Sku code should be present in the response");
		nodeEquals("$.payload.cart.cartItems[0].qty", qty, "Given Sku code should be present in the response");
		nodeMatches("$.payload.cart.cartID", ".+", "CartID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		if(isBopus){
			nodeEquals("$.payload.cart.cartItems[0].itemType", "BOPUS", "ItemType should be Bopus for BopusItem");
		    nodeEquals("$.payload.cart.cartItems[0].storeAddress.storeNum", storeNum, "storeNum should be"+storeNum);}
		else{
			nodeEquals("$.payload.cart.cartItems[0].itemType","OTHERS", "ItemType should be OTHERS");
		}
	}
	
	@Step("Cart attributes should be present in response")
	public void validateMultiCartResponse(String skuCode, String qty, boolean isBopus, String storeNum, String cartItemID, String cartItemID1, boolean giftItem) {
		while(Utilities.getJsonNodeValue(strResponse, "$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].skuCode").equals("[]")){
			 cartItemID = Integer.toString((Integer.parseInt(cartItemID)+1));
			 if(cartItemID.equals(cartItemID1))
				 cartItemID = Integer.toString((Integer.parseInt(cartItemID)+1));
		}
		nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].skuCode", "[\""+skuCode+"\"]", "Given Sku code should be present in the response");
		nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].qty", "[\""+qty+"\"]", "Given Sku code should be present in the response");
		nodeMatches("$.payload.cart.cartID", ".+", "CartID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].cartItemID", "[0-9]+", "cartItemID should be present in the response");
		nodeMatches("$.payload.cart.cartItems[0].webID", "[0-9]+", "webID should be present in the response");
		if(isBopus){
			nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].itemType", "[\"BOPUS\"]", "ItemType should be Bopus for BopusItem");
		    nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].storeAddress.storeNum", "[\""+storeNum+"\"]", "storeNum should be"+storeNum);}
		else{
			nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].itemType","[\"OTHERS\"]", "ItemType should be OTHERS");
		}
		if(giftItem){
			nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].giftItem", "[true]", "giftItem should be TRUE");
		}
		else{
			nodeEquals("$.payload.cart.cartItems[?(@.cartItemID=="+cartItemID+")].giftItem", "[false]", "giftItem should be FALSE");
		}
	}
	


	@Step("Price Attribtes should be present in the response")
	public void validatepriceDetails() {

		nodeMatches("$.payload.products[0].stores[0].prices[0].regularPriceType", ".+", "Prices should be present in the response");
		nodeEquals("$.payload.products[0].stores[0].channel", "web", "Channel should be present in the response");
		nodeMatches("$.payload.products[0].stores[0].storeNum", ".+", "Store Number should be present in the response");
		nodeMatches("$.payload.products[0].stores[0].prices[0].isCurrentPrice", ".+", "Is Current Price should be present in the response");
	}


	@Step("Verifying Sign In response")
	public void SignInProfileResponse() {

		nodeMatches("$.payload.response.signIn.access_token", ".+", "Access token should be available in response");
		nodeMatches("$.payload.response.signIn.expires_in", ".+", "Expires In  should be available in response");
		nodeMatches("$.payload.response.signIn.token_type", ".+", "Token Type should be available in response");
		nodeMatches("$.payload.response.signIn.refresh_token", ".+", "Refresh token should be available in response");
		nodeMatches("$.payload.response.wallet.timestamp", ".+", "TimeStamp should be available in response");
	}


	@Step("profile Upadted Message should be present in Response")
	public void validateProfileUpadteMessage() {

		nodeEquals("$.payload.message", "Profile Updated Successfully", "Profile should be updated successfully");
	}

	@Step("profile Upadted Message should be present in Response")
	public void validateMasterPassResponse() {
		nodeEquals("$.payload.order.paymentTypes.presentationDetails.paymentMethod", "MASTERPASS","paymentmethod should be MASTERPASS");
		nodeMatches("$.payload.order.paymentTypes.presentationDetails.transactionID", ".*","transactionID should not be NULL");
	}
	

	
	
	
	@Step("Payment Info should be present in response")
	public void validateOrderGiftCard(String giftCard, Boolean isPlaceorder) {
		int giftCardlength=giftCard.length();
		int giftCardLength1=giftCardlength-4;
		if(!isPlaceorder){
		nodeEquals("$.payload.order.paymentTypes.kohlsGiftCards[0].isApplied", "true", "gift card should be applied in the response");}
		else{
		nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].valueApplied", "[0-9]+.[0-9]+", "gift card should be applied in the response");}
		nodeMatches("$.payload.order.paymentTypes.kohlsGiftCards[0].giftCardNum","[x]+"+giftCard.substring(giftCardLength1, giftCardlength) , "GiftCard should be present in the response");
		
	}


	@Step("Bill address should be present in response")
	public void validatebillAddress() {

		nodeMatches("$.payload.order.billAddress.addr1", ".+", "Address line 1 should be present in the response");
		nodeMatches("$.payload.order.billAddress.city", ".+", "city should be present in the response");
		nodeMatches("$.payload.order.billAddress.state", ".+", "State should be present in the response");
		nodeMatches("$.payload.order.billAddress.postalCode", "[0-9]+", "Zip Code should be present in the response");
		nodeEquals("$.payload.order.billAddress.countryCode", "US", "Country Code should be present in the response");
		nodeMatches("$.payload.order.billAddress.firstName", ".+", "First Name should be present in the response");
		nodeMatches("$.payload.order.billAddress.lastName", ".+", "last Name should be present in the response");
		nodeMatches("$.payload.order.billAddress.phoneNumber", "[0-9]+", "phone number should be present in the response");
	}
	@Step("Monetiaztion Fields value should be present in response")
	public void validateMonetiaztionValueForProducts() {

		nodeMatches("$.payload.products[0].monetization.brand", "null||.+", "monetization brand value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.ageAppropriate", "null||.+", "monetization ageappropriate value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.occasion", "null||.+", "monetization occasion value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.gender", "null||.+", "monetization gender value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.sportsLeague", "null||.+", "monetization sportsLeague value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.sportsTeam", "null||.+", "monetization sportsTeam value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.ageAppropriateRange", "null||.+", "monetization ageAppropriateRange value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.childAgeRange", "null||.+", "monetization childAgeRange value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.sizeRange", "null||.+", "monetization sizeRange value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.fit", "null||.+", "monetization fit value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.legOpening", "null||.+", "monetization legOpening value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.trend", "null||.+", "monetization trend value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.feature", "null||.+", "monetization feature value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.activity", "null||.+", "monetization activity value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.bodyType", "null||.+", "monetization bodyType value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.personaCategory", "null||.+", "monetization personaCategory value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.personaSubject", "null||.+", "monetization personaSubject value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.silhouette", "null||.+", "monetization silhouette value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.personaTheme", "null||.+", "monetization personaTheme value should be present in response ");
		nodeMatches("$.payload.products[0].monetization.personaGroupCode", "null||.+", "monetization personaGroupCode value should be present in response ");
		nodeNotEquals("$.payload.products[0].monetization.adUnit.value", "null", "adUnit value should be present in response");
		
	}


	@Step("Ship address should be present in response")
	public void validateshipAddress() {

		nodeMatches("$.payload.order.shipAddress.addr1", ".+", "Address line 1 should be present in the response");
		nodeMatches("$.payload.order.shipAddress.city", ".+", "city should be present in the response");
		nodeMatches("$.payload.order.shipAddress.state", ".+", "State should be present in the response");
		nodeMatches("$.payload.order.shipAddress.postalCode", "[0-9]+", "Zip Code should be present in the response");
		nodeEquals("$.payload.order.shipAddress.countryCode", "US", "Country Code should be present in the response");
		nodeMatches("$.payload.order.shipAddress.firstName", ".+", "First Name should be present in the response");
		nodeMatches("$.payload.order.shipAddress.lastName", ".+", "last Name should be present in the response");
		nodeMatches("$.payload.order.shipAddress.phoneNumber", "[0-9]+", "phone number should be present in the response");
	}
	@Step("Ship address should be present in response")
	public void validateshipAddressRegistrySku() {
		boolean isShipAddress=false;
		try {
			String strActual = String.valueOf(JsonPath.read(document, "$.payload.order.shipAddress"));
			if(!strActual.isEmpty())
				isShipAddress=true;
			Assert.assertFalse(isShipAddress,"$.payload.order.shipAddress should notbe present in the response");
		}
		catch (InvalidPathException | NullPointerException e) {
			Assert.assertFalse(isShipAddress,"$.payload.order.shipAddress should notbe present in the response");
		}

	}
	
	@Step("Start date for offers")
	public void validatepromoCodeOrderResponse(String promoCode, Boolean isPlaceorder) {
		if(!isPlaceorder){
			nodeEquals("$.payload.order.paymentTypes.promoCodes[0].isApplied", "true", "value should be applied from PromoCode in the response");}
			else{
			nodeMatches("$.payload.order.paymentTypes.promoCodes[0].value", "[0-9]+.[0-9]+", "value should be applied from PromoCode in the response");}
			nodeMatches("$.payload.order.paymentTypes.promoCodes[*].code",".*"+promoCode+".*", "PromoCode should be present in the response");
		//nodeMatches("$.payload.order.paymentTypes.promoCodes[0].validDates.startDate", "[0-9]+-[0-9]+-[0-9]+\\s[0-9]+:[0-9]+:[0-9]+.[0-9]","startDate should be NULL");
		nodeMatches("$.payload.order.paymentTypes.promoCodes[0].validDates.endDate", "[0-9-:\\s.]+","endDate should not be NULL");
	}
	
	@Step("start date for kc ")
	public void validateKohlsCashOrderResponse(String KohlCashNum, Boolean isPlaceOrder) {
		String kohlscash4digit=KohlCashNum.substring(11, 15);
		if(!isPlaceOrder){
		nodeEquals("$.payload.order.paymentTypes.kohlsCash[0].isApplied", "true", "Value should be applied in the response");}
		else {
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9]+.[0-9]+", "Value should be applied in the response");}
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].kohlsCashNum", "([x]+"+kohlscash4digit+"|"+KohlCashNum+")","KohlsCash should be encrypted.");
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].validDates.startDate", "[0-9]+/[0-9]+/[0-9]+","startDate should be NULL");
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].validDates.endDate", "[0-9]+/[0-9]+/[0-9]+","endDate should not be NULL");
		nodeMatches("$.payload.order.paymentTypes.kohlsCash[0].valueApplied", "[0-9]+.[0-9]","Value should be in Decimal format");
	}
	
	@Step("Validate saleprice status")
	public void validatesaleprice() {

		String salePrice = Utilities.getJsonNodeValue(strResponse, "$.payload.order.cartItems[0].price.salePrice");
		if(salePrice!="null")
		{
		nodeNotEquals("$.payload.order.cartItems[0].price.salePriceLabel","null","sale price status should not be null in the response");
		}
		else
		{
		nodeEquals("$.payload.order.cartItems[0].price.salePriceLabel","null","sale price status should not be null in the response");	
		}}
	
	
	
	@Step("Ship address should not be present in response for BopusOnly order")
	public void validateBopusOnlyshipAddress() {
		
		nodeEquals("$.payload.order.shipAddress", "{}", "shipAddress should be null for BopusOnly orders");
	}
	
	@Step("Order attributes should be present in response")
	public void validateOrderInstoreResponse(Boolean isPlaceOrder, Boolean isFreeShip, Boolean isShipTotalZero) {
		
		if(isFreeShip){
			
			if(isPlaceOrder){
				nodeEquals("$.payload.order.totals.isFreeShipping", "true", "isFreeShipping should be present in the response");
				nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
				}
		
			else{
				nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "true", "isFreeShipping should be present in the response");
				nodeEquals("$.payload.order.totals.shipTotal", "0.0", "ship total should be present in the response");
			}}
		else
		{
		if(isPlaceOrder){
			nodeEquals("$.payload.order.totals.isFreeShipping", "false", "isFreeShipping should be present in the response");
			nodeMatches("$.payload.order.totals.shipTotal", "[0-9]+.[0-9]+", "ship total should be present in the response");
			}
	
		else{
			nodeEquals("$.payload.order.totals.shipMeter.isFreeShipping", "false", "isFreeShipping should be present in the response");
			nodeMatches("$.payload.order.totals.shipTotal", "[0-9]+.[0-9]+", "ship total should be present in the response");
		}}
		nodeEquals("$.payload.order.modes[0]", "INGEOFENCE", "In Geo Fence Should be the Order Mode");
}
	
	@Step("Bopus Item should be present in response")
	public void validateBopusItem(String bopusSku, String bopusStore) {
		nodeEquals("$.payload.order.cartItems[0].bopusItem", "true", "Bopus Item value should be true in the response");
		nodeEquals("$.payload.order.cartItems[0].storeNum", bopusStore, "storeNumber should be present in the response");
		nodeEquals("$.payload.order.cartItems[0].skuCode", bopusSku, "sku should be present in the response");
	}


	@Step("Payment Info should be present in response")
	public void validatePaymentInfo() {

		nodeMatches("$.payload.order.paymentTypes.creditCards[0].nameOnCard", ".+", "name on card should be present in the response");
		nodeMatches("$.payload.order.paymentTypes.creditCards[0].cardNum", ".+", "card number should be present in the response");
		nodeMatches("$.payload.order.paymentTypes.creditCards[0].type", ".+", "card type should be present in the response");
		nodeMatches("$.payload.order.paymentTypes.creditCards[0].expDate", "([0-9]{2}/[0-9]{4}+|null)", "expiry date should be present in the response");
	}
	
	@Step("MFP variables should be present in response")
	public void validateOrderMFPSignal() {
		nodeMatches("$.payload.order.shipmentGroupCount", "[0-9]+", "shipmentGroupCount should be present in the response");
		nodeMatches("$.payload.order.cartItems[0].shipmentGroupID", ".+", "shipmentGroupID should be present in the response");
		nodeMatches("$.payload.order.cartItems[0].price.unitCostAfterLID", "[0-9.]+", "unitCostAfterLID should be present in the response");
	}
	@Step("Customer Info should be present in response")
	public void validateCustomerInfo() {
		
		nodeMatches("$.payload.order.email",".+", "Profile email should be present");
		//validator.nodeMatches("$.payload.profile.customerName.middleName", "", "MiddleName should be available in response");
		nodeMatches("$.payload.order.customerName.lastName", ".+", "LastName should be available in response");
		nodeMatches("$.payload.order.customerName.firstName", ".+", "FirstName should be available in response");
		
			}


	@Step("Cost should be present in response")
	public void validateTotal() {

		nodeMatches("$.payload.order.totals.subTotal", "[0-9]+(\\.[0-9]+)?", "subtotal should be present in the response");
		nodeMatches("$.payload.order.totals.orderTotal", "[0-9]+(\\.[0-9]+)?", "order total should be present in the response");
		nodeMatches("$.payload.order.totals.shipTotal", "[0-9]+(\\.[0-9]+)?", "ship total should be present in the response");
		nodeMatches("$.payload.order.totals.taxTotal", "[0-9]+(\\.[0-9]+)?", "tax total should be present in the response");

	}
	@Step("Validating MFP Signal requirements in response")
	public void validateMFPSignalResponse(String shipGroupCount, String response) {
		nodeEquals("$.payload.order.shipmentGroupCount", shipGroupCount, "shipmentGroupCount mismatch in the response");
		JSONArray noOfcartItems = JsonPath.read(response, "$.payload..cartItems");
		for(int i =0; i < noOfcartItems.size();i++){
			nodeMatches("$.payload.order.cartItems["+i+"].shipmentGroupID", "[0-9A-Za-z]+", "shipmentGroupID should be present at cartLevel");
			nodeMatches("$.payload.order.cartItems["+i+"].price.unitCostAfterLID", "([0-9]+.[0-9]+|[0-9]+)", "UnicostAfterLID should be present at cartLevel");
		}
		JSONArray noOfshipMethods = JsonPath.read(response, "$.payload..shippingMethods");
		for(int i =0; i < noOfshipMethods.size();i++){
			nodeMatches("$.payload.order.shippingMethods["+i+"].shipmentGroupID", "[0-9A-Za-z]+", "shipmentGroupID should be present at shippingMethodLevel");
		}
		
	}
	
	@Step("validating shipIndex")
	public void validateShipIndexOrder(String response){
		JSONArray noOfshipMethods = JsonPath.read(response, "$.payload..shippingMethods");
		for(int i =0; i < noOfshipMethods.size();i++){
			nodeMatches("$.payload.order.shippingMethods["+i+"].shipIndex", "(1|2)", "shipmentGroupID should be present at shippingMethodLevel");
		}
	}
	
	@Step("Validate KP Provision Status for Profile")
	public void validateKPStatus(String response){
		JSONArray noOfcards = JsonPath.read(response, "$.payload..paymentTypes");
		for(int i=0; i<noOfcards.size(); i++){
			String cardType = Utilities.getJsonNodeValue(response, "$.payload.profile.paymentTypes["+i+"].type");
			if(cardType.equalsIgnoreCase("KOHLS")){
				nodeMatches("$.payload.profile.paymentTypes["+i+"].kpProvisioned","(true|false)","KP Provision status should be avalible for KohlsCharge Card");
			}else{
				String otherCards = Utilities.getJsonNodeValue(response, "$.payload.profile.paymentTypes["+i+"]");
				Assert.assertEquals(!otherCards.contains("kpProvisioned"), true);
			}
		}
	}

	ResponseValidator validator;


	public void isSyndicatedFalse() {

		JSONArray Results = JsonPath.read(document, "$.payload.Results");
		System.out.println("Results =" + Results);
		System.out.println("size of str=" + Results.size());

		for (int i = 0; i < Results.size(); i++) {
			String isSyndicated = String.valueOf(JsonPath.read(document, "$.payload.Results[" + i + "].IsSyndicated"));
			System.out.println("isSyndicated=" + isSyndicated);
			// assert isSyndicated == "false";
			Assert.assertTrue(isSyndicated == "false");
		}
	}


	public void isSyndicatedTrue() {

		JSONArray Results = JsonPath.read(document, "$.payload.Results");
		System.out.println("Results =" + Results);
		System.out.println("size of str=" + Results.size());

		for (int i = 0; i < Results.size(); i++) {
			String isSyndicated = String.valueOf(JsonPath.read(document, "$.payload.Results[" + i + "].IsSyndicated"));
			System.out.println("isSyndicated=" + isSyndicated);
			// assert isSyndicated == "true";
			Assert.assertTrue(isSyndicated == "true");
		}
	}
	
	public void isStoreTrue() {

		JSONArray Results = JsonPath.read(document, "$.payload.offers");
		System.out.println("Results =" + Results);
		System.out.println("size of str=" + Results.size());

		for (int i = 0; i < Results.size(); i++) {
			JSONArray Results1 = JsonPath.read(document, "$.payload.offers["+i+"].channels");
			System.out.println("Results1 =" + Results1);
			System.out.println("size of str=" + Results1.size());
			for (int j = 0; j < Results1.size();j++) {
				String channels = String.valueOf(JsonPath.read(document, "$.payload.offers[" + i + "].channels["+j+"].value"));
				System.out.println("channels=" + channels);
				if(!channels.equals("store1"))
				{
					continue;
				}
				else if(channels.equals("store1"))
				{
					break;
				}
				else
				{
					Assert.fail("no store");
				}
				}
				
			}
			
		}
	


	@Step("\"{1}\"")
	public void searchstore(String strJsonPath, String strStepDescription1) {

		JSONArray strActual = JsonPath.read(document, strJsonPath);

		System.out.println("storeAddresses size of str=" + strActual.size());

		for (int i = 0; i < strActual.size(); i++) {
			// assert(strActual.get(i)!= null);
			Assert.assertNotEquals(strActual.get(i), "null", "Store Address fields are not null");

		}
	}


	@Step("\"{1}\"")
	public void eligibleshippingmethod(String strJsonPath, String strStepDescription1) {

		JSONArray strActual = JsonPath.read(document, strJsonPath);
		Assert.assertTrue(strActual.contains("ODD"));
		Assert.assertTrue(strActual.contains("TDD"));

	}


	@Step("Store Address in cart")
	public void storeAddressesCart() {

		nodeEquals("$.payload.cart.cartItems[1].storeAddress.storeNum", testData.get("BOPUS_STORE"), "storeNumber should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.city", "[a-zA-Z]+", "store city should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.addr1", ".+", "store address should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.state", "[a-zA-Z]+", "store state should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.postalCode", "[0-9]+", "store postal code should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.countryCode", "[a-zA-Z]+", "store countryCode should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.phoneNumber", "[0-9]+", "store phoneNumber should be present in the response");
		nodeMatches("$.payload.cart.cartItems[1].storeAddress.storeName", ".+", "store name should be present in the response");
	}

	@Step("Validating Payments in Cart")
	public void validatePaymentCart(String[] PromoCodes, String[] KohlsCash){
		if(PromoCodes!=null){
			for(int i =0;i<PromoCodes.length-1;i++)
				nodeMatches("$.payload.cart.paymentTypes.promoCodes.promoCode[*].code",".*"+PromoCodes[i]+".*", "Given Promocode should be present in the response");
		}else if(KohlsCash != null){
			for(int i=0; i<KohlsCash.length-1;i+=2)
				nodeMatches("$.payload.cart.paymentTypes.kohlsCash.voucher[*].kohlsCashNum", ".*"+ KohlsCash[i]+".*", "Given KohlsCash should be present in the response");
		}
		
	}
	
	public void removeCart(String strResponse, Server server, String strAccessToken) {

		System.out.println(strAccessToken);
		System.out.println("inside remove cart");
		if ((server == Server.Adapter) || (server == Server.OpenApi)) {
			JSONArray noOfcartItem = JsonPath.read(strResponse, "$.payload..cartItemID");

			// System.out.println("cartItem ="+noOfcartItem);
			int size = noOfcartItem.size();
			String strCartID = Utilities.getJsonNodeValue(strResponse, "$.payload.order.cartID");

			for (int i = 0; i < noOfcartItem.size(); i++) {
				String strCartItemID = Utilities.getJsonNodeValue(strResponse, "$.payload.order.cartItems[" + i + "].cartItemID");
				String strSkuCode = Utilities.getJsonNodeValue(strResponse, "$.payload.order.cartItems[" + i + "].skuCode");
				// String strQty=Utilities.getJsonNodeValue(strResponse, "payload.cart.cartItems["+i+"].qty");
				// Create the Json Request for Sign In
				String strPayload = "{\"payload\":{\"cart\":{\"cartID\" :\"" + strCartID + "\",\"cartItems\" :[{\"cartItemID\":\"" + strCartItemID + "\",\"skuCode\": \"" + strSkuCode + "\", \"qty\":\"0\",\"action\":\"remove\"}]}}}";
				mapheader.clear();
				mapheader.put("access_token", strAccessToken);
				String strResponse1 = RestCall.postRequest(CART_ADAPTER, strPayload, Server.Adapter, true, mapheader);

			}
		}

	}


	@Step("\"{0}\"")
	public void ValidateQuestionDetailForQAndA(String strStepDescription1) {

		String TotalResults = String.valueOf(JsonPath.read(document, "$.payload.TotalResults"));
		int TotalResultsCount = Integer.parseInt(TotalResults);
		System.out.println("TotalResults =" + TotalResults);
		Assert.assertNotEquals(TotalResultsCount, "0");
		for (int i = 0; i < TotalResultsCount; i++) {
			nodeMatches("$.payload.Results[" + i + "].QuestionSummary", ".+", "QuestionSummary should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].AuthorId", ".+", "AuthorId should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].LastModeratedTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "LastModeratedTime should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].LastModificationTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "LastModificationTime should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].ProductId", "[0-9]+", "ProductId should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].UserLocation", ".+", "UserLocation should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].UserNickname", ".+", "UserNickname should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].TotalPositiveFeedbackCount", ".+", "TotalPositiveFeedbackCount should be present in the response");
			nodeMatches("$.payload.Results[" + i + "].TotalNegativeFeedbackCount", ".+", "TotalNegativeFeedbackCount should be present in the response");
		}
		JSONArray TotalAnswer = JsonPath.read(document, "$.payload.Includes..Id");
		System.out.println("TotalAnswer =" + TotalAnswer);
		System.out.println("TotalAnswer size =" + TotalAnswer.size());
		int TotalAnswerCount = TotalAnswer.size();
		Assert.assertNotEquals(TotalAnswerCount, "0");
		for (int i = 0; i < TotalAnswer.size()-1; i++) {
			String Id = (String) TotalAnswer.get(i);
			System.out.println("Id = " + Id);
			System.out.println("$.payload.Includes.Answers." + Id + ".AnswerText");
			// nodeMatches("$.payload.Includes.Answers."+Id+".AnswerText","..........+","AnswerText should be present in the response");
			//nodeMatches("$.payload.Includes.Answers." + Id + ".AuthorId", ".+", "AuthorId should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".LastModeratedTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "LastModeratedTime should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".LastModificationTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "LastModificationTime should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".QuestionId", "[0-9]+", "QuestionId should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".SubmissionTime", "[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}\\++" + "[0-9]{2}:[0-9]{2}+", "SubmissionTime should be present in the response");
			nodeEquals("$.payload.Includes.Answers." + Id + ".Id", Id, "Id should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".UserNickname", ".+", "UserNickname should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".TotalPositiveFeedbackCount", ".+", "TotalPositiveFeedbackCount should be present in the response");
			nodeMatches("$.payload.Includes.Answers." + Id + ".TotalNegativeFeedbackCount", ".+", "TotalNegativeFeedbackCount should be present in the response");
		}
	}


	@Step("{1}")
	public void validateResponseHeaders(String strCondition, String strDescription) {

		String[] arrResHdrs = testData.get("RESPONSE_HEADERS").split("\\|");
		HashMap<String, String> mapResHdrs = new HashMap<String, String>();
		System.out.println(arrResHdrs.length);

		for (String hdr : arrResHdrs) {
			hdr = hdr.replace("[", "").replace("]", "");
			if (hdr.contains("=")) {
				mapResHdrs.put(hdr.split("=")[0], hdr.split("=")[1]);
			}
		}

		try {
			switch (strCondition) {

				case "EXPIRES_GT_CURRENT_DATE":  // Validating expires header date is greater than current date
					String strExpiresHeader = mapResHdrs.get("Expires");
					Date expiresdate = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z").parse(strExpiresHeader);  // date format for "Fri, 4 Mar 2016 23:16:45 GMT"
					Date currentdate = new Date();
					String dateString1 = expiresdate.toString();
					testData.put("EXPIRES_DATE_RESPONSE_HEADER", dateString1);
					System.out.println("Expires date ="+dateString1);
					Assert.assertTrue(expiresdate.after(currentdate));
					break;
				case "DATE_GT_CURRENT_DATE":  // Validating expires header date is greateer than current date
					String strDateHeader = mapResHdrs.get("Date");
					Date date = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z").parse(strDateHeader);  // date format for "Fri, 4 Mar 2016 23:16:45 GMT"
					String dateString = date.toString();
					testData.put("DATE_RESPONSE_HEADER", dateString);
					break;

			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Step("{0}")
	public void validateStoreLatLong(String strStepDescription1) {

		JSONArray quadrants = JsonPath.read(strResponse, "$.quadrants");
		int strSize = quadrants.size();
		Assert.assertEquals(strSize, 20, "No. of quadrants should be 20");
		for (int i = 0; i < strSize; i++) {

			JSONArray storeList = JsonPath.read(strResponse, "$.quadrants[" + i + "].stores");
			int storeCount = storeList.size();

			if (storeCount > 0) {
				try {
					double leftLat = Double.parseDouble(Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].leftLat"));
					double leftLong = Double.parseDouble(Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].leftLon"));
					double rightLat = Double.parseDouble(Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].rightLat"));
					double rightLong = Double.parseDouble(Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].rightLon"));

					for (int j = 0; j < storeCount; j++) {
						String storeNum = Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].stores[" + j + "].id");
						double strLatitude = Double.parseDouble(Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].stores[" + j + "].latitude"));
						double strLongitude = Double.parseDouble(Utilities.getJsonNodeValue(strResponse, "$.quadrants[" + i + "].stores[" + j + "].longitude"));

						if (!((leftLat >= strLatitude) && (rightLat <= strLatitude) && (leftLong <= strLongitude) && (rightLong >= strLongitude))) {
							Assert.fail("Latitude/Longitude for store " + storeNum + " is not within the given quadrant");
						}
					}
				}
				catch (Exception e) {
					Assert.fail("Error in reading lat/long for quadrant " + i);
				}
			}

		}

		JSONArray storeIds = JsonPath.read(strResponse, "$..id");
		JSONArray storeLatitude = JsonPath.read(strResponse, "$..latitude");
		JSONArray storeLongitude = JsonPath.read(strResponse, "$..longitude");

		for (int i = 0; i < storeIds.size(); i++) {

			String storeNum = (String) storeIds.get(i);
			String strLatitude = (String) storeLatitude.get(i);
			String strLongitude = (String) storeLongitude.get(i);
			// validating that the store is added to the quadrant
			if (storeNum.equals(testData.get("GEO_STORE_NUM"))) {
				//Assert.assertEquals(storeNum, testData.get("GEO_STORE_NUM"));
				testData.put("STORE_EXISTS", storeNum);
				testData.put("STORENUM_EXISTS", storeNum);
				//Assert.assertEquals(strLatitude, testData.get("GEO_LATITUDE"));
				testData.put("STORE_LATITUDE", strLatitude);
				//.assertEquals(strLongitude, testData.get("GEO_LONGITUDE"));
				testData.put("STORE_LONGITUDE", strLongitude);
				System.out.println(testData.get("STORE_LONGITUDE"));
				break;
			}

		}

	}
	@Step("\"{0}\"")
	public void ValidationForSortInCatalog(String strStepDescription1) {

		JSONArray TotalSorts = JsonPath.read(strResponse, "$.payload.sorts");
		int TotalSortsCount = TotalSorts.size();
		System.out.println("TotalSortsCount =" + TotalSortsCount);
		Assert.assertNotEquals(TotalSortsCount, "0");
		JSONArray SortIds = JsonPath.read(strResponse, "$.payload.sorts..id");
		for (int i = 0; i < TotalSortsCount; i++) {
			String sortID = (String) SortIds.get(i);
			if (sortID.equals(testData.get("sortID1") )) {
				nodeEquals("$.payload.sorts["+i+"].active", "true", "Active should present in the response");
				nodeMatches("$.payload.sorts["+i+"].name", ".+", "name should present in the response");
				nodeEquals("$.payload.sorts["+i+"].ID", testData.get("sortID1"), "ID should present in the response");
			}
			else
			{
				nodeEquals("$.payload.sorts["+i+"].active", "false", "Active should present in the response");
				nodeMatches("$.payload.sorts["+i+"].name", ".+", "name should present in the response");
				nodeEquals("$.payload.sorts["+i+"].ID", testData.get("sortID1"), "ID should present in the response");
			}
		}
	}
	
	public void ValidtaePosLocationResponse() {

		JSONArray Results = JsonPath.read(document, "$.payload..Location");
		System.out.println("Results =" + Results);
		System.out.println("size of Response=" + Results.size());

		for (int i = 0; i < Results.size(); i++) {
				
			System.out.println("i =" + i);
			nodeNotEquals("$.payload["+i+"].Location", "null", "Location value should present in the response");
				nodeNotEquals("$.payload["+i+"].Set", "null", "Set value should present in the response");
			    nodeNotEquals("$.payload["+i+"].Clear", "null", "Clear value should present in the response");
				nodeNotEquals("$.payload["+i+"].Announcement", "null", "Announcement value should present in the response");
				//nodeNotEquals("$.payload["+i+"].\"Physical location\"", "null", "Announcement value should present in the response");
			
			}
	}
	
	public void kohlscashvalidate(String strJsonPath, String kohlscash) {

		JSONArray Results = JsonPath.read(document,strJsonPath);
		System.out.println(Results);
		String kohlscash4digit=kohlscash.substring(11, 15);
		System.out.println(kohlscash4digit);
		int size = Results.size();
		int j=0;
		for (int i = 0; i < size; i++) 
		{
			
			String kohlscash4digit1=(String) Results.get(i);
			//String kohlscash4digit2 = Long.toString(kohlscash4digit1);
			System.out.println(kohlscash4digit1);
			System.out.println(kohlscash4digit);
			
			if(kohlscash4digit1.contains(kohlscash4digit))
			{
				j++;
			   break;
			
			}
			else{
				continue;
			}
						
					
			
		}
		if(j==0)
		{
			Assert.fail("Kohlscash is not in the reponse");
			
		}
		
		}

			// assert isSyndicated == "false";
		//	Assert.assertTrue(isSyndicated == "false");
		}
	
