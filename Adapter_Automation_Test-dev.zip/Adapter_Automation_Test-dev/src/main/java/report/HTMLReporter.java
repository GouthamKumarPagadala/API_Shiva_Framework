package main.java.report;

import static main.java.common.TestData.testData;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.model.AttachmentType;

public class HTMLReporter {

	@Attachment(value = "Adapter Request / Response", type = "text/plain")
	public static String attachToReport(String strLog) {

		return strLog;
	}


	@Attachment(value = "OAPI Request / Response", type = "text/plain")
	public static String attachToReportOAPI(String strLog) {

		return strLog;
	}


	@Attachment(value = "Compare Adapter and OAPI Response", type = "text/plain" )
	public static String attachToReportComparison(String strLog) {

		return strLog.replace(",", "\n");
	}
	
	@Attachment(value = "{0}  {1} {2}", type = "text/plain")
	public static String attachToReport(String strServer, String strMethod, String strResourcePath, String strLog) {

		return strLog;
	}


	public static void createReportingProperties() {

		try {
			File file = new File("target/allure-results");
			if (!file.exists())
				file.mkdirs();
			FileWriter fw = new FileWriter("target/allure-results/environment.properties");
			String strAdapterEnv = testData.get("Adapter_Environemnt");
			strAdapterEnv = strAdapterEnv.replace("https://", "").replace("http://", "");
			strAdapterEnv = strAdapterEnv.replace(".km.sl.edst.ibm.com", "").replace(".kohls.com", "").replace(".maps.ibmcloud.com", "").replace(".kohlsecommerce.com", "");
			strAdapterEnv = strAdapterEnv.replace("kohls", "");
			fw.write("Adapter=" + strAdapterEnv.toUpperCase() + "\n");
			fw.write("OAPI=" + testData.get("OAPI_Environemnt").toUpperCase() + "\n");
			fw.close();

		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}


	public static void addReportingProperties(String str) {

		try {
			File file = new File("target/allure-results");
			if (!file.exists())
				file.mkdirs();
			FileWriter fw = new FileWriter("target/allure-results/environment.properties", true);

			fw.write(str + "\n");
			fw.close();

		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}

}
