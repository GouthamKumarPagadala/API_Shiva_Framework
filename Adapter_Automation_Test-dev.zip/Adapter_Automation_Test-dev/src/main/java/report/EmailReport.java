package main.java.report;

import static main.java.common.TestData.testData;
import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import javax.swing.JPanel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class EmailReport {

	static Map<String, ArrayList> map = new HashMap<String, ArrayList>();

	static Map<String, Integer>	mapPassed	= new HashMap<String, Integer>();
	static Map<String, Integer>	mapFailed	= new HashMap<String, Integer>();
	static Map<String, Integer>	mapSkipped	= new HashMap<String, Integer>();

	static List<String> listAllAdapters = new ArrayList<String>();


	public static void main(String[] args) throws IOException {

		File fXmlFile = new File("target/surefire-reports/testng-results.xml");

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			XPathFactory xPathfactory = XPathFactory.newInstance();
			XPath xpath = xPathfactory.newXPath();
			// XPathExpression expr = xpath.compile("//test/class[contains(@name,'.inventory.')]/test-method[@status='PASS' and not(@name='testSetup')]");
			XPathExpression expr = xpath.compile("//test/class");
			NodeList classNodes = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);

			// System.out.println(classNodes.getLength());
			// if (true) return;

			int intTotalCount = 0;
			for (int i = 0; i < classNodes.getLength(); i++) {
				Node node = classNodes.item(i);
				String name = node.getAttributes().getNamedItem("name").getTextContent();

				System.out.print(name + " ");
				expr = xpath.compile("//test/class[@name='" + name + "']/test-method[not(@name='testSetup')]");
				int intTotal = ((NodeList) expr.evaluate(doc, XPathConstants.NODESET)).getLength();

				intTotalCount += intTotal;

				expr = xpath.compile("//test/class[@name='" + name + "']/test-method[@status='PASS' and not(@name='testSetup')]");
				int intPass = ((NodeList) expr.evaluate(doc, XPathConstants.NODESET)).getLength();
				System.out.println(intPass + "/" + intTotal);

				if (!name.contains("Config"))
					updateList(name, intPass, intTotal);
			}

			for (String key : map.keySet()) {

				System.out.println(key + " : " + map.get(key));
			}

		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}


	public static void updateList(String strClass, final int intPass, final int intTotal) {

		int intMapPass, intMapTotal;
		ArrayList list = new ArrayList<>();
		;

		strClass = strClass.replace("test.java.adapters.", "");
		strClass = strClass.substring(0, strClass.indexOf("."));

		if (!map.containsKey(strClass)) {
			list.add(String.valueOf(intPass));
			list.add(String.valueOf(intTotal));
			map.put(strClass, list);
		} else {
			ArrayList<String> arrMapValue = map.get(strClass);
			intMapPass = Integer.parseInt(arrMapValue.get(0));
			intMapTotal = Integer.parseInt(arrMapValue.get(1));
			intMapPass += intPass;
			intMapTotal += intTotal;

			list.add(String.valueOf(intMapPass));
			list.add(String.valueOf(intMapTotal));
			map.put(strClass, list);
		}

	}


	// CREATE THE PIE CHART
	public static void createPiePanel(int Pass, int Fail, int Blocked) {

		try {

			testData.put("TOTAL_PASS", String.valueOf(Pass));
			testData.put("TOTAL_FAIL", String.valueOf(Fail));
			testData.put("TOTAL_BLOCKED", String.valueOf(Blocked));
			testData.put("TOTAL_EXECUTED", String.valueOf(Pass + Fail + Blocked));

			DefaultPieDataset dataset = new DefaultPieDataset();
			dataset.setValue("Fail", new Double(Fail));
			dataset.setValue("Blocked", new Double(Blocked));
			dataset.setValue("Pass", new Double(Pass));

			JFreeChart pieChart = ChartFactory.createPieChart3D("Test Status", dataset, true, true, false);

			PiePlot3D plot = (PiePlot3D) pieChart.getPlot();
			plot.setBackgroundPaint(Color.white);
			plot.setSectionOutlinesVisible(false);
			plot.setDirection(Rotation.CLOCKWISE);
			plot.setForegroundAlpha(0.7f);

			ChartUtilities.saveChartAsPNG(new File("target/pie.png"), pieChart, 300, 300);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static void updatePassed(String strClass) {

		strClass = strClass.replace("test.java.adapters.", "");
		strClass = strClass.substring(0, strClass.indexOf("."));

		if (!listAllAdapters.contains(strClass))
			listAllAdapters.add(strClass);

		if (!mapPassed.containsKey(strClass)) {
			mapPassed.put(strClass, 1);
		} else {
			mapPassed.put(strClass, mapPassed.get(strClass) + 1);
		}
	}


	public static void updateFailed(String strClass) {

		strClass = strClass.replace("test.java.adapters.", "");
		strClass = strClass.substring(0, strClass.indexOf("."));

		if (!listAllAdapters.contains(strClass))
			listAllAdapters.add(strClass);

		if (!mapFailed.containsKey(strClass)) {
			mapFailed.put(strClass, 1);
		} else {
			mapFailed.put(strClass, mapFailed.get(strClass) + 1);
		}
	}


	public static void updateSkipped(String strClass) {

		strClass = strClass.replace("test.java.adapters.", "");
		strClass = strClass.substring(0, strClass.indexOf("."));

		if (!listAllAdapters.contains(strClass))
			listAllAdapters.add(strClass);

		if (!mapSkipped.containsKey(strClass)) {
			mapSkipped.put(strClass, 1);
		} else {
			mapSkipped.put(strClass, mapSkipped.get(strClass) + 1);
		}
	}


	public static void printResultStatistics() {

		for (String strAdapter : listAllAdapters) {

			System.out.println("*** Printing stats");

			int intPassed = mapPassed.get(strAdapter) != null ? mapPassed.get(strAdapter) : 0;
			int intFailed = mapFailed.get(strAdapter) != null ? mapFailed.get(strAdapter) : 0;
			int intSkipped = mapSkipped.get(strAdapter) != null ? mapSkipped.get(strAdapter) : 0;

			System.out.println(strAdapter);
			System.out.println(intPassed + " " + intFailed + " " + intSkipped);

		}

	}


	public static void createReportEmail() {

		try {

			// Return if it is a local execution
			if (System.getenv("OpenAPI_Environment") == null) {
				return;
			}

			PrintWriter fileResult = new PrintWriter("target/email_report.html", "UTF-8");
			String strGroup = System.getenv("Feature");
			strGroup = strGroup.substring(0, 1).toUpperCase() + strGroup.substring(1);
			fileResult.write("<html><body><br/>");
			fileResult.write("<p style='font-size:16.0pt;padding-left:10em'><u>Adapter " + strGroup + " Test Automation Report</u></p>");
			fileResult.write("<table Table border=1 cellspacing=0 cellpadding=0>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=139 valign=top ><p  >Adapter</p></td>");
			fileResult.write("	<td width=310 valign=top ><p ><u><span>" + testData.get("Adapter_Environemnt") + "</span></u></p></td>");
			fileResult.write(" </tr>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=139 valign=top ><p  >Open API</p></td>");
			fileResult.write("	<td width=310 valign=top ><p ><span >" + testData.get("OPEN_API_BASE_URL_HTTPS") + "</span></p></td>");
			fileResult.write(" </tr>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=139 valign=top ><p  >Build No</p></td>");
			fileResult.write("	<td width=310 valign=top ><p  >" + System.getenv("BUILD_NUMBER") + "</p></td>");
			fileResult.write(" </tr>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=139 valign=top ><p  >Group</p></td>");
			fileResult.write("	<td width=310 valign=top ><p  >" + strGroup + "</p></td>");
			fileResult.write(" </tr>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=139 valign=top ><p  ><u1:p>OpenAPI compare</p></td>");
			fileResult.write("	<td width=310 valign=top ><p  >" + testData.get("Compare_OpenAPI") + "</p></td>");
			fileResult.write(" </tr>");
			fileResult.write("</table>");
			fileResult.write("<p >&nbsp;</p>");
			fileResult.write("<p style='font-size:14.0pt;padding-left:11em'>Overall Results&nbsp;</u1:p></p>");
			fileResult.write("<table border=1 cellspacing=0 cellpadding=0>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=160 valign=top ><p  align=center style='text-align:center'><b >Total</b></p></td>");
			fileResult.write("	<td width=160 valign=top ><p  align=center style='text-align:center'><b >Passed</b></p></td>");
			fileResult.write("	<td width=160 valign=top ><p  align=center style='text-align:center'><b >Failed</b></p></td>");
			fileResult.write("	<td width=139 valign=top ><p  align=center style='text-align:center'><b >Blocked</b></p></td>");
			fileResult.write(" </tr>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=160 valign=top ><p  align=center style='text-align:center'>" + testData.get("TOTAL_EXECUTED") + "</p></td>");
			fileResult.write("	<td width=160 valign=top ><p  align=center style='text-align:center'>" + testData.get("TOTAL_PASS") + "</p></td>");
			fileResult.write("	<td width=160 valign=top ><p  align=center style='text-align:center'>" + testData.get("TOTAL_FAIL") + "</p></td>");
			fileResult.write("	<td width=139 valign=top ><p  align=center style='text-align:center'>" + testData.get("TOTAL_BLOCKED") + "</p></td>");
			fileResult.write(" </tr>");
			fileResult.write("</table>");
			fileResult.write("<div align=center  >   <img src='cid:pie.png'/> </div>");
			fileResult.write("<p  >&nbsp</p>");
			fileResult.write("<p  style='font-size:14.0pt;padding-left:11em' >Results Summary</p>");
			fileResult.write("<table border=1 cellspacing=0 cellpadding=0>");
			fileResult.write(" <tr >");
			fileResult.write("	<td width=106 valign=top ><p  align=center style='text-align:center'><b >Adapter</b></p></td>");
			fileResult.write("	<td width=106 valign=top ><p  align=center style='text-align:center'><b >Total</b></p></td>");
			fileResult.write("	<td width=106 valign=top ><p  align=center style='text-align:center'><b >Pass</b></p></td>");
			fileResult.write("	<td width=106 valign=top ><p  align=center style='text-align:center'><b >Fail</b></p></td>");
			fileResult.write("	<td width=106 valign=top ><p  align=center style='text-align:center'><b >Blocked</b></p></td>");
			fileResult.write("	<td width=85 valign=top ><p  align=center  style='text-align:center'><b >Pass %</b></p></td>");
			fileResult.write(" </tr>");
			Collections.sort(listAllAdapters);
			for (String strAdapter : listAllAdapters) {

				int intPassed = mapPassed.get(strAdapter) != null ? mapPassed.get(strAdapter) : 0;
				int intFailed = mapFailed.get(strAdapter) != null ? mapFailed.get(strAdapter) : 0;
				int intSkipped = mapSkipped.get(strAdapter) != null ? mapSkipped.get(strAdapter) : 0;

				int intTotal = intPassed + intFailed + intSkipped;

				fileResult.write(" <tr >");
				fileResult.write("	<td width=106 valign=center ><p  align=center style='text-align:center'>" + strAdapter + "</p></td>");
				fileResult.write("	<td width=106 valign=center ><p  align=center style='text-align:center'>" + intTotal + "</p></td>");
				fileResult.write("	<td width=106 valign=center ><p  align=center style='text-align:center'>" + intPassed + "</p></td>");
				fileResult.write("	<td width=106 valign=center ><p  align=center style='text-align:center'>" + intFailed + "</p></td>");
				fileResult.write("	<td width=106 valign=center ><p  align=center style='text-align:center'>" + intSkipped + "</p></td>");
				fileResult.write("	<td width=85  valign=center ><p  align=center style='text-align:center'>" + (int) Math.floor((float) intPassed / (float) intTotal * 100) + "%</p></td>");
				fileResult.write(" </tr>");

			}

			fileResult.write("</table>");
			fileResult.write("<p><o:p>&nbsp;</o:p></p>");
			fileResult.write("</body>");
			fileResult.write("</html>");
			fileResult.close();

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
